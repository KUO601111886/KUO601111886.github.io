local ADDON="FQT"
local defaults={progressSound=true,completeSound=true,sendSelf=true,sendParty=true,acceptNotify=true,minimap={hide=false,minimapPos=165},minimapAngle=165,panelX=-430,panelY=0}
local function InitDB()
 FQTDB=FQTDB or {}
 for k,v in pairs(defaults) do
  if FQTDB[k]==nil then
   if type(v)=="table" then FQTDB[k]={};for a,b in pairs(v)do FQTDB[k][a]=b end else FQTDB[k]=v end
  end
 end
 FQTDB.minimap=FQTDB.minimap or {hide=false,minimapPos=FQTDB.minimapAngle or 165}
end
local function ProgressSound(force)
 if not force and not FQTDB.progressSound then return end
 -- Stable built-in UI sound; fallback kept for Forever builds with a smaller SOUNDKIT table.
 PlaySound(618,"Master")
end
local function CompleteSound(force)
 if not force and not FQTDB.completeSound then return end
 PlaySound(619,"Master")
end

local snapshot={}
local function ReadObjectives(questID,logIndex)
 local out={}
 if not questID then return out end
 if C_QuestLog and C_QuestLog.GetQuestObjectives then
  local ok,objs=pcall(C_QuestLog.GetQuestObjectives,questID)
  if ok and type(objs)=="table" and #objs>0 then
   for i,o in ipairs(objs) do
    out[i]={num=tonumber(o.numFulfilled) or 0,need=tonumber(o.numRequired) or 0,finished=o.finished and true or false,text=o.text or ""}
   end
   return out
  end
 end
 if logIndex and GetNumQuestLeaderBoards and GetQuestLogLeaderBoard then
  local n=GetNumQuestLeaderBoards(logIndex) or 0
  for i=1,n do
   local text,objectiveType,finished,numFulfilled,numRequired=GetQuestLogLeaderBoard(i,logIndex)
   out[i]={num=tonumber(numFulfilled) or 0,need=tonumber(numRequired) or 0,finished=finished and true or false,text=text or ""}
  end
 end
 return out
end
local function BuildSnapshot()
 local s={}
 local n=(C_QuestLog and C_QuestLog.GetNumQuestLogEntries and C_QuestLog.GetNumQuestLogEntries()) or (GetNumQuestLogEntries and GetNumQuestLogEntries()) or 0
 for i=1,n do
  local info=C_QuestLog and C_QuestLog.GetInfo and C_QuestLog.GetInfo(i)
  if info and info.questID and not info.isHeader then
   local qid=info.questID
   local complete=(C_QuestLog.IsComplete and C_QuestLog.IsComplete(qid)) and true or false
   s[qid]={complete=complete,objectives=ReadObjectives(qid,i)}
  end
 end
 return s
end
local function QuestTitle(qid)
 if C_QuestLog and C_QuestLog.GetTitleForQuestID then
  local ok,t=pcall(C_QuestLog.GetTitleForQuestID,qid);if ok and t and t~="" then return t end
 end
 return qid and ("任務 #"..qid) or "任務"
end
local primed=false
local updateSerial=0
local function PartyChannel()
 if not IsInGroup or not IsInGroup() then return nil end
 if IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then return "INSTANCE_CHAT" end
 return "PARTY"
end
local function SendSelfLine(line)
 local msg="|cffffd200老哥UI｜|r"..line
 -- Write directly to the primary player chat frame.  This is local-only; it is not /say.
 local frame=_G.ChatFrame1 or _G.DEFAULT_CHAT_FRAME or _G.SELECTED_CHAT_FRAME
 if frame and frame.AddMessage then
  frame:AddMessage(msg,1,0.82,0)
 else
  print(msg)
 end
end
local function SendProgressLine(line)
 if FQTDB.sendSelf then SendSelfLine(line) end
 if FQTDB.sendParty then
  local ch=PartyChannel()
  if ch then SendChatMessage("老哥UI｜"..line,ch) end
 end
end
local function CheckQuestChanges(serial)
 if serial and serial~=updateSerial then return end
 local now=BuildSnapshot()
 if not primed then snapshot=now;primed=true;return end
 local anyProgress=false
 local anyComplete=false
 for qid,q in pairs(now) do
  local old=snapshot[qid]
  if old then
   local questJustCompleted=q.complete and not old.complete
   local completionLine=nil
   for i,o in ipairs(q.objectives) do
    local prev=old.objectives and old.objectives[i]
    if prev and o.num>prev.num then
     anyProgress=true
     local suffix=tostring(o.num).."/"..tostring(o.need)
     local line="[任務] "..QuestTitle(qid).."："..suffix
     if questJustCompleted then
      completionLine=line.."【完成】"
     else
      SendProgressLine(line)
     end
    end
   end
   if questJustCompleted then
    anyComplete=true
    SendProgressLine(completionLine or ("[任務] "..QuestTitle(qid).."：【完成】"))
   end
  end
 end
 snapshot=now
 if anyComplete then CompleteSound(false) elseif anyProgress then ProgressSound(false) end
end
local function QueueCheck()
 updateSerial=updateSerial+1
 local serial=updateSerial
 if C_Timer and C_Timer.After then C_Timer.After(.35,function()CheckQuestChanges(serial)end) else CheckQuestChanges(serial) end
end
local function AnnounceAccepted(qid)
 if not FQTDB.acceptNotify then return end
 local line="[任務] 接取："..QuestTitle(qid)
 SendSelfLine(line)
 if FQTDB.sendParty then
  local ch=PartyChannel()
  if ch then SendChatMessage("老哥UI｜"..line,ch) end
 end
end

-- ===== BY 老哥系列設定視窗（沿用 FXP v0.20 公版） =====
local cfg=CreateFrame("Frame","FQTSettingsFrame",UIParent,"BackdropTemplate")
table.insert(UISpecialFrames,"FQTSettingsFrame")
cfg:SetSize(590,455);cfg:SetPoint("CENTER",UIParent,"CENTER",-430,0);cfg:SetClampedToScreen(true)
cfg:SetFrameStrata("DIALOG");cfg:SetMovable(true);cfg:EnableMouse(true);cfg:RegisterForDrag("LeftButton");cfg:Hide()
cfg:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background-Dark",edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",tile=true,tileSize=32,edgeSize=32,insets={left=8,right=8,top=8,bottom=8}})
cfg:SetBackdropColor(.02,.025,.03,.99)
cfg:SetScript("OnDragStart",cfg.StartMoving)
cfg:SetScript("OnDragStop",function(self) self:StopMovingOrSizing();local x,y=self:GetCenter();local ux,uy=UIParent:GetCenter();if x and y and ux and uy then FQTDB.panelX=x-ux;FQTDB.panelY=y-uy end end)
local logo=cfg:CreateTexture(nil,"ARTWORK");logo:SetSize(62,62);logo:SetPoint("TOPLEFT",20,-22);logo:SetTexture("Interface\\AddOns\\FQT\\FQT_Q.tga")
local title=cfg:CreateFontString(nil,"OVERLAY","GameFontNormalHuge");title:SetPoint("LEFT",cfg,"TOPLEFT",103,-40);title:SetScale(1.05);title:SetText("|cffffd200FQT｜任務提醒 - BY老哥|r")
local rule=cfg:CreateTexture(nil,"ARTWORK");rule:SetColorTexture(1,.82,0,.9);rule:SetPoint("TOPLEFT",100,-76);rule:SetPoint("TOPRIGHT",-20,-76);rule:SetHeight(1)
local close=CreateFrame("Button",nil,cfg,"UIPanelCloseButton");close:SetPoint("TOPRIGHT",-4,-4)
local function Button(label,parent,x,y,w,fn) local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate");b:SetSize(w or 92,25);b:SetPoint("TOPLEFT",x,y);b:SetText(label);b:SetScript("OnClick",fn);return b end
local function Label(parent,content,x,y) local t=parent:CreateFontString(nil,"OVERLAY","GameFontNormal");t:SetPoint("TOPLEFT",x,y);t:SetText(content);return t end
local tabs,pages={},{}
local function Tab(name,y,index)
 local t=Button(name,cfg,28,y,135,function() for n,p in ipairs(pages)do p:SetShown(n==index)end;for n,b in ipairs(tabs)do b:SetEnabled(n~=index)end end)
 tabs[index]=t;t:SetHeight(34);local page=CreateFrame("Frame",nil,cfg);page:SetPoint("TOPLEFT",185,-100);page:SetSize(375,295);pages[index]=page;return page
end
local alerts=Tab("提醒設定",-118,1)
local sounds=Tab("音效測試",-162,2)
local function Check(parent,label,x,y,key)
 local c=CreateFrame("CheckButton",nil,parent,"UICheckButtonTemplate");c:SetPoint("TOPLEFT",x,y);c:SetSize(26,26);c.text:SetText(label)
 c.text:SetFontObject("GameFontNormalLarge");local font,_,flags=c.text:GetFont();if font then c.text:SetFont(font,16,flags) end
 c.text:SetTextColor(1,1,1,1);c.text:ClearAllPoints();c.text:SetPoint("LEFT",c,"RIGHT",8,0);c.text:SetWidth(320);c.text:SetJustifyH("LEFT")
 c:SetHitRectInsets(0,-325,0,0)
 c:SetScript("OnClick",function(self)FQTDB[key]=self:GetChecked() and true or false end);c.Refresh=function()c:SetChecked(FQTDB[key] and true or false)end;return c
end
local alertTitle=Label(alerts,"|cffffd100任務提醒|r",12,-5);alertTitle:SetFontObject("GameFontNormalLarge")
local cProgress=Check(alerts,"任務進度增加播放音效",12,-42,"progressSound")
local cComplete=Check(alerts,"任務達成播放音效",12,-82,"completeSound")
local cSelf=Check(alerts,"進度傳送到個人頻道",12,-122,"sendSelf")
local cParty=Check(alerts,"進度傳送到組隊頻道",12,-162,"sendParty")
local cAccept=Check(alerts,"接取任務時通報",12,-202,"acceptNotify")
Label(sounds,"|cffffd100音效測試|r",0,-5)
Button("測試進度音效",sounds,0,-42,140,function()ProgressSound(true)end)
Button("測試任務完成",sounds,155,-42,140,function()CompleteSound(true)end)
Button("恢復預設",cfg,28,-402,130,function()
 FQTDB.progressSound=true;FQTDB.completeSound=true;FQTDB.sendSelf=true;FQTDB.sendParty=true;FQTDB.acceptNotify=true;FQTDB.panelX=-430;FQTDB.panelY=0
 cfg:ClearAllPoints();cfg:SetPoint("CENTER",UIParent,"CENTER",-430,0);cProgress.Refresh();cComplete.Refresh();cSelf.Refresh();cParty.Refresh();cAccept.Refresh()
end)
Button("完成",cfg,460,-402,100,function()cfg:Hide()end)
local function RefreshCfg()cProgress.Refresh();cComplete.Refresh();cSelf.Refresh();cParty.Refresh();cAccept.Refresh()end
cfg:SetScript("OnShow",RefreshCfg);pages[2]:Hide();tabs[1]:Disable()

local mini
local function OpenSettings() if cfg:IsShown()then cfg:Hide()else cfg:Show()end end
local function SetupStandardMinimap()
 local LibStub=_G.LibStub;if not LibStub then return false end
 local LDB=LibStub("LibDataBroker-1.1",true);local DBIcon=LibStub("LibDBIcon-1.0",true);if not LDB or not DBIcon then return false end
 local obj=LDB:NewDataObject("FQT",{type="launcher",text="FQT",icon="Interface\\AddOns\\FQT\\FQT_Q.tga",OnClick=function()OpenSettings()end,OnTooltipShow=function(tt)tt:AddLine("FQT - BY 老哥");tt:AddLine("左鍵：開啟設定",1,1,1)end})
 if not DBIcon:IsRegistered("FQT")then DBIcon:Register("FQT",obj,FQTDB.minimap)end;return true
end
local function SetupFallbackMinimap()
 mini=CreateFrame("Button","FQTMinimapButton",Minimap);mini:SetSize(38,38);mini:SetFrameStrata("MEDIUM");mini:SetFrameLevel((Minimap:GetFrameLevel()or 0)+8);mini:RegisterForClicks("LeftButtonUp");mini:RegisterForDrag("LeftButton")
 local ic=mini:CreateTexture(nil,"ARTWORK");ic:SetAllPoints();ic:SetTexture("Interface\\AddOns\\FQT\\FQT_Q.tga")
 local function Pos()local r=math.max(Minimap:GetWidth()or 140,Minimap:GetHeight()or 140)/2+18;local a=math.rad(FQTDB.minimapAngle or 165);mini:ClearAllPoints();mini:SetPoint("CENTER",Minimap,"CENTER",math.cos(a)*r,math.sin(a)*r)end
 local dragging=false
 mini:SetScript("OnDragStart",function(self)dragging=true;self:SetScript("OnUpdate",function()local mx,my=Minimap:GetCenter();if not mx then return end;local x,y=GetCursorPosition();local sc=UIParent:GetEffectiveScale();x,y=x/sc,y/sc;FQTDB.minimapAngle=math.deg(math.atan2(y-my,x-mx));Pos()end)end)
 mini:SetScript("OnDragStop",function(self)self:SetScript("OnUpdate",nil);Pos();C_Timer.After(.1,function()dragging=false end)end)
 mini:SetScript("OnClick",function()if not dragging then OpenSettings()end end)
 mini:SetScript("OnEnter",function(self)GameTooltip:SetOwner(self,"ANCHOR_LEFT");GameTooltip:SetText("FQT - BY 老哥");GameTooltip:AddLine("左鍵：開啟設定",1,1,1);GameTooltip:Show()end);mini:SetScript("OnLeave",function()GameTooltip:Hide()end);Pos()
end

local ev=CreateFrame("Frame")
for _,e in ipairs({"PLAYER_LOGIN","PLAYER_ENTERING_WORLD","QUEST_LOG_UPDATE","QUEST_WATCH_UPDATE","UNIT_QUEST_LOG_CHANGED","QUEST_ACCEPTED","QUEST_REMOVED","QUEST_TURNED_IN"})do ev:RegisterEvent(e)end
ev:SetScript("OnEvent",function(_,e,...)
 if e=="PLAYER_LOGIN"then
  InitDB();cfg:ClearAllPoints();cfg:SetPoint("CENTER",UIParent,"CENTER",FQTDB.panelX or -430,FQTDB.panelY or 0)
  if not SetupStandardMinimap()then SetupFallbackMinimap()end
  snapshot=BuildSnapshot();primed=true
  print("|cffffd200FQT｜任務提醒 - BY老哥|r")
 elseif e=="PLAYER_ENTERING_WORLD"then snapshot=BuildSnapshot();primed=true
 elseif e=="QUEST_ACCEPTED"then
  local a,b=...
  local qid=(type(b)=="number" and b) or (type(a)=="number" and a) or nil
  if qid then C_Timer.After(.15,function()AnnounceAccepted(qid);snapshot=BuildSnapshot();primed=true end) end
 elseif e=="QUEST_REMOVED" or e=="QUEST_TURNED_IN"then
  C_Timer.After(.2,function()snapshot=BuildSnapshot();primed=true end)
 elseif e=="UNIT_QUEST_LOG_CHANGED"then
  local unit=...;if not unit or unit=="player" then QueueCheck() end
 else QueueCheck() end
end)
SLASH_FQT1="/fqt";SlashCmdList["FQT"]=function()OpenSettings()end
