local ADDON="FQT"
local defaults={progressSound=true,completeSound=true,sendSelf=true,sendParty=true,acceptNotify=true,pickupDistance="far",pickupArc="160",pickupBubble=true,monsterDistance="normal",monsterArc="90",monsterBubble=true,monsterSense=true,monsterTargetBubble=true,alertWidth=220,alertBgMode=2,alertPoint="TOP",alertRelPoint="TOP",alertX=0,alertY=-245,minimap={hide=false,minimapPos=165},minimapAngle=165,panelX=-430,panelY=0}
local function InitDB()
 FQTDB=FQTDB or {}
if not FQTDB.FQTDefaultsMigrated020 then
 FQTDB.pickupDistance="normal"
 FQTDB.pickupArc="90"
 FQTDB.pickupBubble=true
 FQTDB.monsterDistance="normal"
 FQTDB.monsterArc="90"
 FQTDB.monsterBubble=true
 FQTDB.monsterSense=true
 FQTDB.FQTDefaultsMigrated020=true
end
if not FQTDB.FQTDefaultsMigrated027 then
 FQTDB.monsterTargetBubble=true
 FQTDB.FQTDefaultsMigrated027=true
end
if not FQTDB.FQTDefaultsMigrated030 then
 FQTDB.pickupDistance="normal"
 FQTDB.pickupArc="90"
 FQTDB.pickupBubble=true
 FQTDB.FQTDefaultsMigrated030=true
end
if not FQTDB.FQTDefaultsMigrated032 then
 FQTDB.pickupDistance="normal"
 FQTDB.pickupArc="160"
 FQTDB.pickupBubble=true
 FQTDB.FQTDefaultsMigrated032=true
end
if not FQTDB.FQTDefaultsMigrated033 then
 FQTDB.pickupDistance="far"
 FQTDB.pickupArc="160"
 FQTDB.pickupBubble=true
 FQTDB.monsterTargetBubble=true
 FQTDB.FQTDefaultsMigrated033=true
end
 for k,v in pairs(defaults) do
  if FQTDB[k]==nil then
   if type(v)=="table" then FQTDB[k]={};for a,b in pairs(v)do FQTDB[k][a]=b end else FQTDB[k]=v end
  end
 end
 FQTDB.minimap=FQTDB.minimap or {hide=false,minimapPos=FQTDB.minimapAngle or 165}
end

-- 設定 UI 建立前先初始化 SavedVariables，避免 FQTDB 為 nil
InitDB()

local function ProgressSound(force)
 if not force and not FQTDB.progressSound then return end
 -- Stable built-in UI sound; fallback kept for Forever builds with a smaller SOUNDKIT table.
 PlaySound(618,"Master")
end
local function CompleteSound(force)
 if not force and not FQTDB.completeSound then return end
 PlaySound(619,"Master")
end

local snapshot={}
local function ReadObjectives(questID,logIndex)
 local out={}
 if not questID then return out end
 if C_QuestLog and C_QuestLog.GetQuestObjectives then
  local ok,objs=pcall(C_QuestLog.GetQuestObjectives,questID)
  if ok and type(objs)=="table" and #objs>0 then
   for i,o in ipairs(objs) do
    out[i]={num=tonumber(o.numFulfilled) or 0,need=tonumber(o.numRequired) or 0,finished=o.finished and true or false,text=o.text or ""}
   end
   return out
  end
 end
 if logIndex and GetNumQuestLeaderBoards and GetQuestLogLeaderBoard then
  local n=GetNumQuestLeaderBoards(logIndex) or 0
  for i=1,n do
   local text,objectiveType,finished,numFulfilled,numRequired=GetQuestLogLeaderBoard(i,logIndex)
   out[i]={num=tonumber(numFulfilled) or 0,need=tonumber(numRequired) or 0,finished=finished and true or false,text=text or ""}
  end
 end
 return out
end
local function BuildSnapshot()
 local s={}
 local n=(C_QuestLog and C_QuestLog.GetNumQuestLogEntries and C_QuestLog.GetNumQuestLogEntries()) or (GetNumQuestLogEntries and GetNumQuestLogEntries()) or 0
 for i=1,n do
  local info=C_QuestLog and C_QuestLog.GetInfo and C_QuestLog.GetInfo(i)
  if info and info.questID and not info.isHeader then
   local qid=info.questID
   local complete=(C_QuestLog.IsComplete and C_QuestLog.IsComplete(qid)) and true or false
   s[qid]={complete=complete,objectives=ReadObjectives(qid,i)}
  end
 end
 return s
end
local function QuestTitle(qid)
 if C_QuestLog and C_QuestLog.GetTitleForQuestID then
  local ok,t=pcall(C_QuestLog.GetTitleForQuestID,qid);if ok and t and t~="" then return t end
 end
 return qid and ("任務 #"..qid) or "任務"
end
local primed=false
local updateSerial=0
local function PartyChannel()
 if not IsInGroup or not IsInGroup() then return nil end
 if IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then return "INSTANCE_CHAT" end
 return "PARTY"
end
local function SendSelfLine(line)
 local msg="|cffffd200老哥UI｜|r"..line
 -- Write directly to the primary player chat frame.  This is local-only; it is not /say.
 local frame=_G.ChatFrame1 or _G.DEFAULT_CHAT_FRAME or _G.SELECTED_CHAT_FRAME
 if frame and frame.AddMessage then
  frame:AddMessage(msg,1,0.82,0)
 else
  print(msg)
 end
end
local function SendProgressLine(line)
 if FQTDB.sendSelf then SendSelfLine(line) end
 if FQTDB.sendParty then
  local ch=PartyChannel()
  if ch then SendChatMessage("老哥UI｜"..line,ch) end
 end
end
local function CheckQuestChanges(serial)
 if serial and serial~=updateSerial then return end
 local now=BuildSnapshot()
 if not primed then snapshot=now;primed=true;return end
 local anyProgress=false
 local anyComplete=false
 for qid,q in pairs(now) do
  local old=snapshot[qid]
  if old then
   local questJustCompleted=q.complete and not old.complete
   local completionLine=nil
   for i,o in ipairs(q.objectives) do
    local prev=old.objectives and old.objectives[i]
    if prev and o.num>prev.num then
     anyProgress=true
     local suffix=tostring(o.num).."/"..tostring(o.need)
     local line="[任務] "..QuestTitle(qid).."："..suffix
     if questJustCompleted then
      completionLine=line.."【完成】"
     else
      SendProgressLine(line)
     end
    end
   end
   if questJustCompleted then
    anyComplete=true
    SendProgressLine(completionLine or ("[任務] "..QuestTitle(qid).."：【完成】"))
   end
  end
 end
 snapshot=now
 if anyComplete then CompleteSound(false) elseif anyProgress then ProgressSound(false) end
end
local function QueueCheck()
 updateSerial=updateSerial+1
 local serial=updateSerial
 if C_Timer and C_Timer.After then C_Timer.After(.35,function()CheckQuestChanges(serial)end) else CheckQuestChanges(serial) end
end
local function AnnounceAccepted(qid)
 if not FQTDB.acceptNotify then return end
 local line="[任務] 接取："..QuestTitle(qid)
 SendSelfLine(line)
 if FQTDB.sendParty then
  local ch=PartyChannel()
  if ch then SendChatMessage("老哥UI｜"..line,ch) end
 end
end

-- 提醒視窗共用控制（後面建立實體）
local FQTMonsterAlert, FQT_ApplyAlertSize, FQT_ApplyAlertLook, FQT_RestoreAlertPosition, FQT_ApplySenseCVars, FQT_ShowAlertPreview, FQT_HideAlertPreview
local FQT_ApplyInteractState

-- ===== BY 老哥系列設定視窗（FQT 公版架構） =====
local cfg=CreateFrame("Frame","FQTSettingsFrame",UIParent,"BackdropTemplate")
table.insert(UISpecialFrames,"FQTSettingsFrame")
cfg:SetSize(590,455);cfg:SetPoint("CENTER",UIParent,"CENTER",-430,0);cfg:SetClampedToScreen(true)
cfg:SetFrameStrata("DIALOG");cfg:SetMovable(true);cfg:EnableMouse(true);cfg:RegisterForDrag("LeftButton");cfg:Hide()
cfg:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background-Dark",edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",tile=true,tileSize=32,edgeSize=32,insets={left=8,right=8,top=8,bottom=8}})
cfg:SetBackdropColor(.02,.025,.03,.99)
cfg:SetScript("OnDragStart",cfg.StartMoving)
cfg:SetScript("OnDragStop",function(self) self:StopMovingOrSizing();local x,y=self:GetCenter();local ux,uy=UIParent:GetCenter();if x and y and ux and uy then FQTDB.panelX=x-ux;FQTDB.panelY=y-uy end end)

local logo=cfg:CreateTexture(nil,"ARTWORK");logo:SetSize(62,62);logo:SetPoint("TOPLEFT",20,-22);logo:SetTexture("Interface\\AddOns\\FQT\\FQT_Q.tga")
local title=cfg:CreateFontString(nil,"OVERLAY","GameFontNormalHuge");title:SetPoint("LEFT",cfg,"TOPLEFT",103,-40);title:SetScale(1.05);title:SetText("|cffffd200FQT｜任務提醒 - BY老哥|r")
local rule=cfg:CreateTexture(nil,"ARTWORK");rule:SetColorTexture(1,.82,0,.9);rule:SetPoint("TOPLEFT",100,-76);rule:SetPoint("TOPRIGHT",-20,-76);rule:SetHeight(1)
local close=CreateFrame("Button",nil,cfg,"UIPanelCloseButton");close:SetPoint("TOPRIGHT",-4,-4)

local function Button(label,parent,x,y,w,fn)
 local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate");b:SetSize(w or 125,27);b:SetPoint("TOPLEFT",x,y);b:SetText(label);b:SetScript("OnClick",fn);return b
end
local function Label(parent,content,x,y,large)
 local t=parent:CreateFontString(nil,"OVERLAY",large and "GameFontNormalLarge" or "GameFontNormal")
 t:SetPoint("TOPLEFT",x,y);t:SetText(content);return t
end
local function Check(parent,label,x,y,key)
 local c=CreateFrame("CheckButton",nil,parent,"UICheckButtonTemplate");c:SetPoint("TOPLEFT",x,y);c:SetSize(26,26);c.text:SetText(label)
 c.text:SetFontObject("GameFontNormalLarge");local font,_,flags=c.text:GetFont();if font then c.text:SetFont(font,16,flags) end
 c.text:SetTextColor(1,1,1,1);c.text:ClearAllPoints();c.text:SetPoint("LEFT",c,"RIGHT",8,0);c.text:SetWidth(300);c.text:SetJustifyH("LEFT")
 c:SetHitRectInsets(0,-300,0,0)
 c:SetScript("OnClick",function(self)
  FQTDB[key]=self:GetChecked() and true or false
  if key=="monsterBubble" then
   FQTDB.monsterSense=FQTDB.monsterBubble and true or false
   if not FQTDB.monsterSense and FQTMonsterAlert then FQTMonsterAlert:Hide() end
   if FQT_EnableMonsterSense then FQT_EnableMonsterSense() end
   if FQT_ApplySenseCVars then FQT_ApplySenseCVars() end
  elseif key=="pickupBubble" then
   if not FQTDB.pickupBubble and FQTMonsterAlert then FQTMonsterAlert:Hide() end
   if FQT_ApplyInteractState then FQT_ApplyInteractState() end
   if FQT_ApplySenseCVars then FQT_ApplySenseCVars() end
  elseif key=="monsterTargetBubble" then
   if not FQTDB.monsterTargetBubble and FQTMonsterAlert then FQTMonsterAlert:Hide() end
  end
 end)
 c.Refresh=function()c:SetChecked(FQTDB[key] and true or false)end
 return c
end
local function Radio(parent,label,x,y,key,value,group)
 local c=CreateFrame("CheckButton",nil,parent,"UICheckButtonTemplate");c:SetPoint("TOPLEFT",x,y);c:SetSize(26,26);c.text:SetText(label)
 c.text:SetTextColor(1,1,1,1);c.text:ClearAllPoints();c.text:SetPoint("LEFT",c,"RIGHT",5,0)
 group[#group+1]=c
 c:SetScript("OnClick",function()
  FQTDB[key]=value
  for _,b in ipairs(group) do b:SetChecked(b==c) end
  if FQT_ApplySenseCVars then FQT_ApplySenseCVars() end
 end)
 c.Refresh=function()c:SetChecked(FQTDB[key]==value)end
 return c
end

local pages,nav={},{}
local function ShowPage(n)
 for i,p in ipairs(pages) do p:SetShown(i==n) end
 for i,b in ipairs(nav) do b:SetEnabled(i~=n) end
 if n==5 then
  if FQT_ShowAlertPreview then FQT_ShowAlertPreview() end
 else
  if FQT_HideAlertPreview then FQT_HideAlertPreview() end
 end
end
local function Page()
 local p=CreateFrame("Frame",nil,cfg);p:SetPoint("TOPLEFT",190,-100);p:SetSize(370,295);pages[#pages+1]=p;return p
end

-- 左側功能：1 任務通知 / 2 任務感應 / 3 初始設定
Label(cfg,"|cffffd1001. 任務通知|r",28,-105,true)
nav[1]=Button("文字通知",cfg,28,-135,135,function()ShowPage(1)end)
nav[2]=Button("聲音通知",cfg,28,-170,135,function()ShowPage(2)end)

Label(cfg,"|cffffd1002. 任務感應|r",28,-220,true)
nav[3]=Button("任務物品感應",cfg,28,-250,135,function()ShowPage(3)end)
nav[4]=Button("任務怪感應",cfg,28,-285,135,function()ShowPage(4)end)
nav[5]=Button("視窗設定",cfg,28,-320,135,function()ShowPage(5)end)

Label(cfg,"|cffffd1003. 初始設定|r",28,-355,true)
nav[6]=Button("回到原始設定",cfg,28,-385,135,function()ShowPage(6)end)

-- 文字通知
local pText=Page()
Label(pText,"|cffffd100文字通知|r",12,-5,true)
local cSelf=Check(pText,"自己通知",12,-48,"sendSelf")
local cParty=Check(pText,"隊友通知",12,-92,"sendParty")
local cAccept=Check(pText,"接取任務時通報",12,-136,"acceptNotify")

-- 聲音通知
local pSound=Page()
Label(pSound,"|cffffd100聲音通知|r",12,-5,true)
local cProgress=Check(pSound,"進度通知",12,-48,"progressSound")
local cComplete=Check(pSound,"完成通知",12,-92,"completeSound")
Button("測試進度音效",pSound,12,-145,140,function()ProgressSound(true)end)
Button("測試完成音效",pSound,165,-145,140,function()CompleteSound(true)end)

local function BuildSensePage(titleText,prefix)
 local p=Page()
 Label(p,"|cffffd100"..titleText.."|r",12,-5,true)
 Label(p,"感應距離",12,-52,true)
 local dg={}
 local d1,d2,d3
 if prefix=="pickup" then
  d1=Radio(p,"8碼",95,-44,prefix.."Distance","near",dg)
  d2=Radio(p,"15碼",185,-44,prefix.."Distance","normal",dg)
  d3=Radio(p,"20碼",275,-44,prefix.."Distance","far",dg)
 else
  d1=Radio(p,"5碼",95,-44,prefix.."Distance","near",dg)
  d2=Radio(p,"20碼",185,-44,prefix.."Distance","normal",dg)
  d3=Radio(p,"30碼",275,-44,prefix.."Distance","far",dg)
 end
 Label(p,"感應角度",12,-102,true)
 local ag={}
 local a1=Radio(p,"5度",95,-94,prefix.."Arc","15",ag)
 local a2=Radio(p,"90度",185,-94,prefix.."Arc","90",ag)
 local a3=Radio(p,"160度",275,-94,prefix.."Arc","160",ag)
 local bubbleText
 local targetBubble
 if prefix=="monster" then
  bubbleText="啟動任務怪自動感應視窗"
 else
  bubbleText="啟動任務物品自動感應視窗"
 end
 local bubble=Check(p,bubbleText,12,-148,prefix.."Bubble")
 if prefix=="monster" then
  targetBubble=Check(p,"啟動任務怪點選進度視窗",12,-184,"monsterTargetBubble")
 end
 p.Refresh=function()
  d1.Refresh();d2.Refresh();d3.Refresh();a1.Refresh();a2.Refresh();a3.Refresh();bubble.Refresh()
  if targetBubble then targetBubble.Refresh() end
 end
 return p
end
local pPickup=BuildSensePage("撿拾感應","pickup")
local pMonster=BuildSensePage("任務怪感應","monster")

-- 提醒視窗：比照 FXP v0.20 的背景三段＋滑桿操作
local pAlert=Page()
Label(pAlert,"|cffffd100視窗設定|r",12,-5,true)
Label(pAlert,"|cffffd100背景：|r",12,-55)

local function SetAlertBgMode(mode)
 FQTDB.alertBgMode=mode
 if FQT_ApplyAlertLook then FQT_ApplyAlertLook() end
end
Button("全黑",pAlert,82,-46,78,function()SetAlertBgMode(1)end)
Button("半透明",pAlert,168,-46,82,function()SetAlertBgMode(2)end)
Button("透明",pAlert,258,-46,78,function()SetAlertBgMode(3)end)

Label(pAlert,"|cffffd100大小：|r",12,-108)
local alertSlider=CreateFrame("Slider",nil,pAlert,"UISliderTemplate")
local alertSliderReady=false
alertSlider:SetOrientation("HORIZONTAL")
alertSlider:SetPoint("TOPLEFT",82,-135)
alertSlider:SetSize(220,17)
alertSlider:SetMinMaxValues(220,350)
alertSlider:SetValueStep(1)
if alertSlider.SetObeyStepOnDrag then alertSlider:SetObeyStepOnDrag(true) end

local alertLeft=CreateFrame("Button",nil,pAlert,"UIPanelScrollUpButtonTemplate")
alertLeft:SetSize(22,22);alertLeft:SetPoint("RIGHT",alertSlider,"LEFT",-7,0)
local alertRight=CreateFrame("Button",nil,pAlert,"UIPanelScrollDownButtonTemplate")
alertRight:SetSize(22,22);alertRight:SetPoint("LEFT",alertSlider,"RIGHT",7,0)
for _,b in ipairs({alertLeft,alertRight}) do
 for _,m in ipairs({"GetNormalTexture","GetPushedTexture","GetDisabledTexture"}) do
  local tx=b[m] and b[m](b);if tx then tx:SetRotation(math.pi/2) end
 end
end

local function SetAlertSlider(v)
 v=math.max(220,math.min(350,math.floor((tonumber(v) or 220)+.5)))
 alertSlider:SetValue(v)
end
alertLeft:SetScript("OnClick",function()SetAlertSlider((tonumber(FQTDB.alertWidth) or 220)-1)end)
alertRight:SetScript("OnClick",function()SetAlertSlider((tonumber(FQTDB.alertWidth) or 220)+1)end)
alertSlider:SetScript("OnValueChanged",function(_,v)
 if not alertSliderReady then return end
 FQTDB.alertWidth=math.max(220,math.min(350,math.floor(v+.5)))
 if FQT_ApplyAlertSize then FQT_ApplyAlertSize() end
end)
alertSlider:SetValue(tonumber(FQTDB.alertWidth) or 220)
alertSliderReady=true

Button("重置預設位置",pAlert,12,-218,150,function()
 if FQT_RestoreAlertPosition then FQT_RestoreAlertPosition() end
end)

pAlert.Refresh=function()
 local w=math.max(220,math.min(350,math.floor((tonumber(FQTDB.alertWidth) or 220)+.5)))
 if alertSlider:GetValue()~=w then alertSlider:SetValue(w) end
end

-- 原始設定頁
local pReset=Page()
Label(pReset,"|cffffd100初始設定|r",12,-5,true)
Button("恢復初始設定",pReset,12,-45,150,function()
 FQTDB.progressSound=true;FQTDB.completeSound=true;FQTDB.sendSelf=true;FQTDB.sendParty=true;FQTDB.acceptNotify=true
 FQTDB.pickupDistance="far";FQTDB.pickupArc="160";FQTDB.pickupBubble=true
 FQTDB.monsterDistance="normal";FQTDB.monsterArc="90";FQTDB.monsterBubble=true;FQTDB.monsterSense=true;FQTDB.monsterTargetBubble=true
 FQTDB.alertWidth=220;FQTDB.alertBgMode=2
 if FQT_ApplySenseCVars then FQT_ApplySenseCVars() end
 if FQT_ApplyInteractState then FQT_ApplyInteractState() end
 if FQT_ApplyAlertSize then FQT_ApplyAlertSize() end
 if FQT_ApplyAlertLook then FQT_ApplyAlertLook() end
 if FQT_RestoreAlertPosition then FQT_RestoreAlertPosition() end
 FQTDB.panelX=-430;FQTDB.panelY=0
 cfg:ClearAllPoints();cfg:SetPoint("CENTER",UIParent,"CENTER",-430,0)
 if cfg.Refresh then cfg:Refresh() end
end)

Button("完成",cfg,460,-402,100,function()cfg:Hide()end)

function cfg:Refresh()
 cSelf.Refresh();cParty.Refresh();cAccept.Refresh();cProgress.Refresh();cComplete.Refresh()
 pPickup.Refresh();pMonster.Refresh();pAlert.Refresh()
end
cfg:SetScript("OnShow",function()cfg:Refresh();ShowPage(1)end)
cfg:SetScript("OnHide",function()
 if FQTMonsterAlert then FQTMonsterAlert:Hide() end
end)
for i=2,#pages do pages[i]:Hide() end
nav[1]:Disable()

-- ===== 任務怪感應核心 v0.10 =====
-- 已在 Forever 實機驗證：
-- SoftTargetEnemy 可在靠近怪物時提供 softenemy。
-- 正式版採「任務變動時建立快取；softenemy 換怪時只查快取」，
-- 不使用 0.2 秒全任務掃描，也不修改 SoftTargetInteract。

local FQTQuestMonster = {
    objectiveRows = {},
    directMap = {},
    negativeNames = {},
    lastGUID = nil,
    oldEnemy = nil,
}

local function FQT_Secret(v)
    return type(issecretvalue) == "function" and issecretvalue(v)
end

local function FQT_Safe(fn, ...)
    if type(fn) ~= "function" then return nil end
    local ok, a, b, c, d = pcall(fn, ...)
    if ok then return a, b, c, d end
end

local function FQT_GetEnemyCVar()
    if C_CVar and C_CVar.GetCVar then return C_CVar.GetCVar("SoftTargetEnemy") end
    if GetCVar then return GetCVar("SoftTargetEnemy") end
end

local function FQT_SetEnemyCVar(v)
    if C_CVar and C_CVar.SetCVar then C_CVar.SetCVar("SoftTargetEnemy", tostring(v))
    elseif SetCVar then SetCVar("SoftTargetEnemy", tostring(v)) end
end

local function FQT_EnableMonsterSense()
    if FQTQuestMonster.oldEnemy == nil then
        FQTQuestMonster.oldEnemy = FQT_GetEnemyCVar()
    end
    if FQTDB.monsterSense then
        FQT_SetEnemyCVar(3)
    elseif FQTQuestMonster.oldEnemy ~= nil then
        FQT_SetEnemyCVar(FQTQuestMonster.oldEnemy)
    end
end

local function FQT_BuildObjectiveCache()
    wipe(FQTQuestMonster.objectiveRows)
    wipe(FQTQuestMonster.directMap)
    wipe(FQTQuestMonster.negativeNames)

    if C_QuestLog and C_QuestLog.GetNumQuestLogEntries and C_QuestLog.GetInfo and C_QuestLog.GetQuestObjectives then
        local n = FQT_Safe(C_QuestLog.GetNumQuestLogEntries)
        if type(n) == "number" and not FQT_Secret(n) then
            for i = 1, n do
                local info = FQT_Safe(C_QuestLog.GetInfo, i)
                if info and not info.isHeader and info.questID then
                    local objs = FQT_Safe(C_QuestLog.GetQuestObjectives, info.questID)
                    if type(objs) == "table" then
                        for _, o in ipairs(objs) do
                            if o and o.text and not FQT_Secret(o.text) then
                                FQTQuestMonster.objectiveRows[#FQTQuestMonster.objectiveRows + 1] = {
                                    text = o.text, finished = o.finished, questID = info.questID
                                }
                            end
                        end
                    end
                end
            end
        end
    end

    -- Forever 若新 API 沒回 objectives，保留舊 API fallback。
    if #FQTQuestMonster.objectiveRows == 0 and GetNumQuestLogEntries and GetQuestLogTitle and GetNumQuestLeaderBoards and GetQuestLogLeaderBoard then
        local n = FQT_Safe(GetNumQuestLogEntries)
        if type(n) == "number" then
            for i = 1, n do
                local title, _, _, isHeader = FQT_Safe(GetQuestLogTitle, i)
                if title and not isHeader then
                    local m = FQT_Safe(GetNumQuestLeaderBoards, i) or 0
                    for j = 1, m do
                        local desc, typ, done = FQT_Safe(GetQuestLogLeaderBoard, j, i)
                        if desc and not FQT_Secret(desc) then
                            FQTQuestMonster.objectiveRows[#FQTQuestMonster.objectiveRows + 1] = {
                                text = desc, finished = done, questTitle = title, type = typ
                            }
                        end
                    end
                end
            end
        end
    end
end

local function FQT_FindMonsterObjective(name)
    if not name or name == "" then return nil end

    local cached = FQTQuestMonster.directMap[name]
    if cached then return cached end
    if FQTQuestMonster.negativeNames[name] then return nil end

    -- 只在第一次遇到「這個怪名」時掃一次已快取的 objectiveRows。
    -- 之後同名怪直接 O(1) table lookup。
    for _, row in ipairs(FQTQuestMonster.objectiveRows) do
        if not row.finished and row.text and row.text:find(name, 1, true) then
            FQTQuestMonster.directMap[name] = row.text
            return row.text
        end
    end

    FQTQuestMonster.negativeNames[name] = true
    return nil
end

FQTMonsterAlert = CreateFrame("Frame", "FQTMonsterAlert", UIParent)
FQTMonsterAlert:SetFrameStrata("HIGH")
FQTMonsterAlert:SetClampedToScreen(true)
FQTMonsterAlert:SetMovable(true)
FQTMonsterAlert:EnableMouse(true)
FQTMonsterAlert:RegisterForDrag("LeftButton")

local mbg = FQTMonsterAlert:CreateTexture(nil, "BACKGROUND")
mbg:SetAllPoints()
mbg:SetColorTexture(0,0,0,0.5)

local m1 = FQTMonsterAlert:CreateFontString(nil, "OVERLAY")
m1:SetTextColor(1,.82,.12,1)
m1:SetJustifyH("CENTER")
m1:SetJustifyV("TOP")
m1:SetWordWrap(true)

local m2 = FQTMonsterAlert:CreateFontString(nil, "OVERLAY")
m2:SetTextColor(1,1,1,1)
m2:SetJustifyH("CENTER")
m2:SetJustifyV("TOP")
m2:SetWordWrap(true)

FQT_ApplySenseCVars=function()
 if not FQTDB then return end

 -- 任務怪：只有總開關啟用時才開 Enemy soft-target。
 if FQTDB.monsterSense then SetCVar("SoftTargetEnemy",3) end
 local enemyRange={near=10,normal=25,far=45}
 local enemyArc={["15"]=0,["90"]=1,["160"]=2}
 SetCVar("SoftTargetEnemyRange",enemyRange[FQTDB.monsterDistance] or 45)
 SetCVar("SoftTargetEnemyArc",enemyArc[FQTDB.monsterArc] or 2)

 -- 任務物品只調整 Interact 的距離/方位，不在這裡強制開啟 SoftTargetInteract。
 local interactRange={near=8,normal=15,far=20}
 local interactArc={["15"]=0,["90"]=1,["160"]=2}
 SetCVar("SoftTargetInteractRange",interactRange[FQTDB.pickupDistance] or 20)
 SetCVar("SoftTargetInteractArc",interactArc[FQTDB.pickupArc] or 2)
end

local function FQT_AlertWidth()
 return math.max(220,math.min(350,math.floor((tonumber(FQTDB.alertWidth) or 220)+.5)))
end

local function FQT_ResizeMonsterAlert()
 local scale=FQT_AlertWidth()/220
 local top=10*scale
 local gap=3*scale
 local bottom=10*scale
 local h1=math.max(18*scale,m1:GetStringHeight() or 18*scale)
 local h2=math.max(14*scale,m2:GetStringHeight() or 14*scale)
 FQTMonsterAlert:SetHeight(top+h1+gap+h2+bottom)
end

FQT_ApplyAlertSize=function()
 local w=FQT_AlertWidth()
 local scale=w/220
 FQTMonsterAlert:SetWidth(w)
 m1:SetFont(STANDARD_TEXT_FONT,18*scale,"THICKOUTLINE")
 m2:SetFont(STANDARD_TEXT_FONT,14*scale,"THICKOUTLINE")
 m1:SetWidth(w-(20*scale))
 m2:SetWidth(w-(20*scale))
 m1:ClearAllPoints()
 m1:SetPoint("TOP",FQTMonsterAlert,"TOP",0,-10*scale)
 m2:ClearAllPoints()
 m2:SetPoint("TOP",m1,"BOTTOM",0,-3*scale)
 FQT_ResizeMonsterAlert()
end

FQT_ApplyAlertLook=function()
 local mode=tonumber(FQTDB.alertBgMode) or 2
 local a=1
 if mode==2 then a=.5
 elseif mode==3 then a=0 end
 mbg:SetColorTexture(0,0,0,a)
end

FQT_RestoreAlertPosition=function()
 FQTDB.alertPoint="TOP";FQTDB.alertRelPoint="TOP";FQTDB.alertX=0;FQTDB.alertY=-245
 FQTMonsterAlert:ClearAllPoints()
 FQTMonsterAlert:SetPoint("TOP",UIParent,"TOP",0,-245)
end

FQTMonsterAlert:SetScript("OnDragStart",function(self)
 self:StartMoving()
end)
FQTMonsterAlert:SetScript("OnDragStop",function(self)
 self:StopMovingOrSizing()
 local point,_,relPoint,x,y=self:GetPoint(1)
 FQTDB.alertPoint=point or "TOP"
 FQTDB.alertRelPoint=relPoint or FQTDB.alertPoint
 FQTDB.alertX=x or 0
 FQTDB.alertY=y or -245
end)

FQTMonsterAlert:ClearAllPoints()
FQTMonsterAlert:SetPoint(FQTDB.alertPoint or "TOP",UIParent,FQTDB.alertRelPoint or FQTDB.alertPoint or "TOP",tonumber(FQTDB.alertX) or 0,tonumber(FQTDB.alertY) or -245)
FQT_ApplyAlertSize()
FQT_ApplyAlertLook()
FQTMonsterAlert:Hide()

-- 視窗設定頁模擬預覽：不需要附近有任務怪／任務物品即可調整。
FQT_ShowAlertPreview=function()
 m1:SetText("視窗設定")
 m2:SetText("任務進度：4/10")
 FQT_ApplyAlertSize()
 FQT_ApplyAlertLook()
 FQTMonsterAlert:Show()
end
FQT_HideAlertPreview=function()
 if cfg and cfg:IsShown() and pages and pages[5] and pages[5]:IsShown() then return end
 FQTMonsterAlert:Hide()
end

-- ===== 任務物品 GameObject 感應（v0.31） =====
-- 實機測試確認：GameObject 的 UnitExists("softinteract") 可能為 false，
-- 但 UnitGUID/UnitName 可讀；因此以 GameObject- GUID 前綴判斷，不用 UnitExists 當門檻。
local FQTPickup = { lastGUID=nil, oldInteract=nil }
local FQTAlertSource=nil

local function FQT_GetInteractCVar()
 if C_CVar and C_CVar.GetCVar then return C_CVar.GetCVar("SoftTargetInteract") end
 if GetCVar then return GetCVar("SoftTargetInteract") end
end
local function FQT_SetInteractCVar(v)
 if C_CVar and C_CVar.SetCVar then C_CVar.SetCVar("SoftTargetInteract",tostring(v))
 elseif SetCVar then SetCVar("SoftTargetInteract",tostring(v)) end
end
local function FQT_HasRealTarget()
 local v=FQT_Safe(UnitExists,"target")
 return v and not FQT_Secret(v)
end
local function FQT_FindPickupObjective(name)
 if not name or name=="" then return nil end
 -- 任務物品名稱只和目前未完成的任務目標文字比對；不是任務物品就不顯示。
 for _,row in ipairs(FQTQuestMonster.objectiveRows) do
  if not row.finished and row.text and row.text:find(name,1,true) then return row.text end
 end
 return nil
end
local function FQT_ShowSenseAlert(source,name,objective)
 FQTAlertSource=source
 m1:SetText(name or "任務目標")
 m2:SetText(objective or "")
 FQT_ResizeMonsterAlert()
 FQTMonsterAlert:Show()
end
local function FQT_HideSenseAlert(source)
 if not source or FQTAlertSource==source then
  FQTMonsterAlert:Hide()
  if not source or FQTAlertSource==source then FQTAlertSource=nil end
 end
end

FQT_ApplyInteractState=function()
 if FQTPickup.oldInteract==nil then FQTPickup.oldInteract=FQT_GetInteractCVar() end
 local combat=InCombatLockdown and InCombatLockdown()
 if not FQTDB.pickupBubble or combat or FQT_HasRealTarget() then
  FQT_SetInteractCVar(0)
  FQTPickup.lastGUID=nil
  FQT_HideSenseAlert("pickup")
 else
  FQT_SetInteractCVar(3)
  if FQT_ApplySenseCVars then FQT_ApplySenseCVars() end
 end
end

local function FQT_CheckSoftInteract(force)
 if not FQTDB.pickupBubble or (InCombatLockdown and InCombatLockdown()) or FQT_HasRealTarget() then
  FQT_HideSenseAlert("pickup")
  return
 end
 local guid=FQT_Safe(UnitGUID,"softinteract")
 if FQT_Secret(guid) then guid=nil end
 if type(guid)~="string" or not guid:match("^GameObject%-") then
  FQTPickup.lastGUID=nil
  FQT_HideSenseAlert("pickup")
  return
 end
 if not force and guid==FQTPickup.lastGUID then return end
 FQTPickup.lastGUID=guid
 local name=FQT_Safe(UnitName,"softinteract")
 if FQT_Secret(name) then name=nil end
 -- v0.31：完全沿用已實測成功的 GameObject 判斷。
 -- 不再要求 GameObject 名稱必須出現在任務目標文字中，避免有效任務物品被錯誤過濾。
 local objective=FQT_FindPickupObjective(name)
 FQT_ShowSenseAlert("pickup",name or "任務物品",objective or "任務物品")
end

local function FQT_CheckSoftEnemy(force)
    -- 玩家操作優先：戰鬥中或已有任何目標時，不做附近任務怪自動感應。
    if InCombatLockdown and InCombatLockdown() then
        return
    end
    local hasTarget=FQT_Safe(UnitExists,"target")
    if hasTarget and not FQT_Secret(hasTarget) then
        return
    end
    if not FQTDB.monsterSense then
        FQT_HideSenseAlert("monster")
        return
    end

    local exists = FQT_Safe(UnitExists, "softenemy")
    if not exists or FQT_Secret(exists) then
        FQTQuestMonster.lastGUID = nil
        FQT_HideSenseAlert("monster")
        return
    end

    local guid = FQT_Safe(UnitGUID, "softenemy")
    if FQT_Secret(guid) then guid = nil end
    if not force and guid and guid == FQTQuestMonster.lastGUID then return end
    FQTQuestMonster.lastGUID = guid

    local name = FQT_Safe(UnitName, "softenemy")
    if FQT_Secret(name) then name = nil end
    local objective = FQT_FindMonsterObjective(name)

    if objective and FQTDB.monsterBubble then
        FQT_ShowSenseAlert("monster",name or "任務目標",objective)
    else
        FQT_HideSenseAlert("monster")
    end
end

local FQTMonsterEvents = CreateFrame("Frame")
FQTMonsterEvents:RegisterEvent("PLAYER_LOGIN")
FQTMonsterEvents:RegisterEvent("PLAYER_SOFT_ENEMY_CHANGED")
FQTMonsterEvents:RegisterEvent("PLAYER_SOFT_INTERACT_CHANGED")
FQTMonsterEvents:RegisterEvent("UPDATE_MOUSEOVER_UNIT")
FQTMonsterEvents:RegisterEvent("PLAYER_TARGET_CHANGED")
FQTMonsterEvents:RegisterEvent("PLAYER_REGEN_ENABLED")
FQTMonsterEvents:RegisterEvent("PLAYER_REGEN_DISABLED")
FQTMonsterEvents:RegisterEvent("QUEST_LOG_UPDATE")
FQTMonsterEvents:RegisterEvent("QUEST_WATCH_UPDATE")
FQTMonsterEvents:RegisterEvent("UNIT_QUEST_LOG_CHANGED")
FQTMonsterEvents:RegisterEvent("QUEST_ACCEPTED")
FQTMonsterEvents:RegisterEvent("QUEST_REMOVED")
FQTMonsterEvents:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        FQT_EnableMonsterSense()
        FQT_BuildObjectiveCache()
        FQT_ApplyInteractState()
    elseif event == "PLAYER_SOFT_INTERACT_CHANGED" or event == "UPDATE_MOUSEOVER_UNIT" then
        FQT_CheckSoftInteract(false)
    elseif event == "PLAYER_SOFT_ENEMY_CHANGED" then
        FQT_CheckSoftEnemy(false)
    elseif event == "PLAYER_TARGET_CHANGED" then
        -- target 任何變化都先清除上一個自動感應／點選提醒，避免舊資訊殘留。
        FQT_HideSenseAlert()
        FQT_ApplyInteractState()
        local exists=FQT_Safe(UnitExists,"target")
        if exists and not FQT_Secret(exists) then
            -- 任何 target 存在時，自動感應由 FQT_CheckSoftEnemy 暫停。
            -- 只有玩家點到任務怪時，才顯示該怪任務進度。
            local attack=FQT_Safe(UnitCanAttack,"player","target")
            if attack and not FQT_Secret(attack) then
                local name=FQT_Safe(UnitName,"target")
                if FQT_Secret(name) then name=nil end
                if name and name~="" then
                    local objective=FQT_FindMonsterObjective(name)
                    if objective and FQTDB.monsterTargetBubble then
                        FQT_ShowSenseAlert("monster",name,objective)
                    end
                end
            end
        else
            -- 清除目標時只關閉舊提醒。
            -- 自動感應保留啟用狀態，但等下一次 softenemy 真正重新偵測後再顯示。
        end
    elseif event == "PLAYER_REGEN_DISABLED" then
        -- 一進入戰鬥立即清除提醒，戰鬥期間 FQT_CheckSoftEnemy 也會停止自動感應。
        FQT_HideSenseAlert()
        FQT_ApplyInteractState()
    elseif event == "PLAYER_REGEN_ENABLED" then
        -- 離開戰鬥只解除停止條件，不重顯舊資訊；等下一次 softenemy 重新偵測。
        FQT_HideSenseAlert()
        FQT_ApplyInteractState()
    else
        -- 任務表變動時，同時更新怪物與物品的目標比對快取。
        FQT_BuildObjectiveCache()
        if FQTDB.monsterSense then FQT_CheckSoftEnemy(true) end
        if FQTDB.pickupBubble then FQT_CheckSoftInteract(true) end
    end
end)


local mini
local function OpenSettings() if cfg:IsShown()then cfg:Hide()else cfg:Show()end end
local function SetupStandardMinimap()
 local LibStub=_G.LibStub;if not LibStub then return false end
 local LDB=LibStub("LibDataBroker-1.1",true);local DBIcon=LibStub("LibDBIcon-1.0",true);if not LDB or not DBIcon then return false end
 local obj=LDB:NewDataObject("FQT",{type="launcher",text="FQT",icon="Interface\\AddOns\\FQT\\FQT_Q.tga",OnClick=function()OpenSettings()end,OnTooltipShow=function(tt)tt:AddLine("FQT - BY 老哥");tt:AddLine("左鍵：開啟設定",1,1,1)end})
 if not DBIcon:IsRegistered("FQT")then DBIcon:Register("FQT",obj,FQTDB.minimap)end;return true
end
local function SetupFallbackMinimap()
 mini=CreateFrame("Button","FQTMinimapButton",Minimap);mini:SetSize(38,38);mini:SetFrameStrata("MEDIUM");mini:SetFrameLevel((Minimap:GetFrameLevel()or 0)+8);mini:RegisterForClicks("LeftButtonUp");mini:RegisterForDrag("LeftButton")
 local ic=mini:CreateTexture(nil,"ARTWORK");ic:SetAllPoints();ic:SetTexture("Interface\\AddOns\\FQT\\FQT_Q.tga")
 local function Pos()local r=math.max(Minimap:GetWidth()or 140,Minimap:GetHeight()or 140)/2+18;local a=math.rad(FQTDB.minimapAngle or 165);mini:ClearAllPoints();mini:SetPoint("CENTER",Minimap,"CENTER",math.cos(a)*r,math.sin(a)*r)end
 local dragging=false
 mini:SetScript("OnDragStart",function(self)dragging=true;self:SetScript("OnUpdate",function()local mx,my=Minimap:GetCenter();if not mx then return end;local x,y=GetCursorPosition();local sc=UIParent:GetEffectiveScale();x,y=x/sc,y/sc;FQTDB.minimapAngle=math.deg(math.atan2(y-my,x-mx));Pos()end)end)
 mini:SetScript("OnDragStop",function(self)self:SetScript("OnUpdate",nil);Pos();C_Timer.After(.1,function()dragging=false end)end)
 mini:SetScript("OnClick",function()if not dragging then OpenSettings()end end)
 mini:SetScript("OnEnter",function(self)GameTooltip:SetOwner(self,"ANCHOR_LEFT");GameTooltip:SetText("FQT - BY 老哥");GameTooltip:AddLine("左鍵：開啟設定",1,1,1);GameTooltip:Show()end);mini:SetScript("OnLeave",function()GameTooltip:Hide()end);Pos()
end

local ev=CreateFrame("Frame")
for _,e in ipairs({"PLAYER_LOGIN","PLAYER_ENTERING_WORLD","QUEST_LOG_UPDATE","QUEST_WATCH_UPDATE","UNIT_QUEST_LOG_CHANGED","QUEST_ACCEPTED","QUEST_REMOVED","QUEST_TURNED_IN"})do ev:RegisterEvent(e)end
ev:SetScript("OnEvent",function(_,e,...)
 if e=="PLAYER_LOGIN"then
  InitDB()
  FQTDB.monsterSense=FQTDB.monsterBubble and true or false
  if FQTDB.monsterDistance=="medium" then FQTDB.monsterDistance="normal" end
  if FQTDB.monsterArc=="30" then FQTDB.monsterArc="15" elseif FQTDB.monsterArc=="180" then FQTDB.monsterArc="160" end
  if FQT_ApplySenseCVars then FQT_ApplySenseCVars() end
  if FQT_ApplyInteractState then FQT_ApplyInteractState() end
  cfg:ClearAllPoints();cfg:SetPoint("CENTER",UIParent,"CENTER",FQTDB.panelX or -430,FQTDB.panelY or 0)
  if not SetupStandardMinimap()then SetupFallbackMinimap()end
  snapshot=BuildSnapshot();primed=true
  print("|cffffd200FQT｜任務提醒 - BY老哥|r")
 elseif e=="PLAYER_ENTERING_WORLD"then snapshot=BuildSnapshot();primed=true
 elseif e=="QUEST_ACCEPTED"then
  local a,b=...
  local qid=(type(b)=="number" and b) or (type(a)=="number" and a) or nil
  if qid then C_Timer.After(.15,function()AnnounceAccepted(qid);snapshot=BuildSnapshot();primed=true end) end
 elseif e=="QUEST_REMOVED" or e=="QUEST_TURNED_IN"then
  C_Timer.After(.2,function()snapshot=BuildSnapshot();primed=true end)
 elseif e=="UNIT_QUEST_LOG_CHANGED"then
  local unit=...;if not unit or unit=="player" then QueueCheck() end
 else QueueCheck() end
end)
SLASH_FQT1="/fqt";SlashCmdList["FQT"]=function()OpenSettings()end
