-- Original standalone addon. All rights reserved. See LICENSE.txt.
-- Target API: WoW Forever 1.60.1.69977.
local ADDON = ...
local trackers={}
local function CreateTracker(config)
local GlobalCreateFrame=CreateFrame
local function CreateFrame(kind,name,parent,template)
    if name then name=name:gsub("^ForeverClassTimers",config.prefix) end
    return GlobalCreateFrame(kind,name,parent,template)
end
local VERSION = "0.65"
local HEIGHT, GAP = 24, 3
local TEXTURE = "Interface\\Buttons\\WHITE8X8"
local styles = {flat="Flat", rounded="Rounded", beveled="Beveled"}
local function StyleTexture(style)
    return style == "flat" and TEXTURE or "Interface\\AddOns\\FBUFF\\" .. styles[style]
end
local FONT = GameFontNormal:GetFont()
local defaults = {
    -- Classic ranks plus common later rogue buffs, if available in Forever.
    [5171] = true, [6774] = true, -- Slice and Dice
    [5277] = true, [26669] = true, -- Evasion
    [2983] = true, [8696] = true, [11305] = true, -- Sprint
    [13750] = true, -- Adrenaline Rush
    [13877] = true, -- Blade Flurry
    [32645] = true, -- Envenom
    [31224] = true, -- Cloak of Shadows
    [51690] = true, -- Killing Spree
    [51713] = true, -- Shadow Dance
}
local racialDefaults = {
    [20572]=true, -- Blood Fury
    [20594]=true, -- Stoneform
    [26297]=true, -- Berserking
    [20580]=true, -- Shadowmeld (only if timed)
    [20577]=true, -- Cannibalize (only if represented by a timed buff)
    [7744]=true, -- Will of the Forsaken (only if it grants a timed buff)
}
if config.enemy then defaults={[1943]=true,[703]=true,[8647]=true} end
local resizeGrip
local db, anchor, handle, container, preview
local reminderAnchor, reminderHandle, reminderContainer, reminderPreview, reminderRow
local previewRows = {}
local liveRows = {}
local warningCurve, pulseCurve, durationBinding, optionsWindow
local reminderLiveBar, reminderOpacityCurve
local reminderLiveRows, reminderPreviewRows = {}, {}
local opacityFailed = false
local opacityLastError, opacityRetry = nil, 0
local nativeWarningContainers={}
local nativeWarningAnchor
local minimapButton
local ready = false
local testing = false
local positioningReminder = false
local failure
local events = CreateFrame("Frame")

local function Say(text)
    print("|cffffd24aFBUFF:|r " .. text)
end

local function Copy(t)
    local result = {}
    for k, v in pairs(t) do result[k] = v end
    return result
end

local function Bounded(value, fallback, low, high)
    value = tonumber(value)
    if not value or value ~= value or value < low or value > high then return fallback end
    return value
end

local function ColorValue(value, fallback)
    if type(value) == "string" then
        value = value:gsub("^#", ""):upper()
        if #value == 6 and value:match("^%x+$") then return value end
    end
    return fallback
end

local function RGB(hex)
    return tonumber(hex:sub(1,2),16)/255, tonumber(hex:sub(3,4),16)/255, tonumber(hex:sub(5,6),16)/255
end

local function SortDirection()
    return db.sort == "longest" and AuraContainerSortDirection.Reverse or AuraContainerSortDirection.Normal
end

local function BuildReminderOpacityCurve()
    reminderOpacityCurve=C_CurveUtil.CreateCurve()
    reminderOpacityCurve:SetType(Enum.LuaCurveType.Linear)
    -- Transparent at zero/expired and at/above the threshold. A one
    -- millisecond edge avoids depending on step-curve boundary semantics.
    reminderOpacityCurve:AddPoint(0,0)
    reminderOpacityCurve:AddPoint(0.001,1)
    if db.flash then
        for i=1,math.ceil((db.threshold-0.001)/0.4)-1 do
            reminderOpacityCurve:AddPoint(i*0.4,i%2==1 and 0.35 or 1)
        end
    end
    reminderOpacityCurve:AddPoint(db.threshold-0.001,1)
    reminderOpacityCurve:AddPoint(db.threshold,0)
    reminderOpacityCurve:AddPoint(86401,0)
end

local function BuildDurationBinding()
    BuildReminderOpacityCurve()
    local normal = CreateColor(RGB(db.textColor))
    local warning = CreateColor(RGB(db.warningColor))
    warningCurve = C_CurveUtil.CreateColorCurve()
    warningCurve:SetType(Enum.LuaCurveType.Linear)
    warningCurve:AddPoint(0, normal)
    pulseCurve=C_CurveUtil.CreateCurve()
    pulseCurve:SetType(Enum.LuaCurveType.Linear)
    pulseCurve:AddPoint(0,1)
    -- This is a presentation curve, evaluated by Blizzard against remaining
    -- time. No secret duration is ever returned to addon Lua. Alternate colors
    -- every 0.4 seconds (a complete pulse takes 0.8 seconds).
    if db.flash and db.threshold > 0 then
        for i = 1, math.ceil(db.threshold / 0.4)-1 do
            warningCurve:AddPoint(i * 0.4, i % 2 == 1 and warning or normal)
            pulseCurve:AddPoint(i * 0.4, i % 2 == 1 and 0.35 or 1)
        end
        warningCurve:AddPoint(db.threshold, normal)
        pulseCurve:AddPoint(db.threshold,1)
    end
    warningCurve:AddPoint(86401, normal)
    pulseCurve:AddPoint(86401,1)
    local formatter = C_StringUtil.CreateSecondsFormatter()
    formatter:SetDefaultAbbreviation(Enum.SecondsFormatterAbbreviation.OneLetter)
    formatter:SetMinInterval(Enum.SecondsFormatterInterval.Seconds)
    formatter:SetMillisecondsThreshold(60)
    durationBinding = C_DurationUtil.CreateDurationTextBinding()
    durationBinding:SetFormatter(formatter)
    durationBinding:SetUpdateInterval(0.05)
    durationBinding:SetTextColorCurve(warningCurve, Enum.DurationTextBindingProperty.RemainingDuration)
end

local function NormalizeSaved()
    -- SavedVariables are restored after addon files execute. Read them at login,
    -- not when the tracker factory runs, or persisted settings are lost.
    local ForeverClassTimersDB=_G[config.savedKey]
    local ForeverRogueTimersDB=not config.enemy and _G.ForeverRogueTimersDB or nil
    -- Import legacy settings when an upgrade copies the old SavedVariables file.
    if type(ForeverClassTimersDB) ~= "table" and type(ForeverRogueTimersDB) == "table" then
        ForeverClassTimersDB = ForeverRogueTimersDB
    end
    if not config.enemy then _G.ForeverRogueTimersDB = nil end
    if type(ForeverClassTimersDB) ~= "table" then ForeverClassTimersDB = {} end
    db = ForeverClassTimersDB
    db.width = Bounded(db.width, 280, 180, 600)
    db.scale = Bounded(db.scale, 1, 0.5, 2)
    db.x = Bounded(db.x, 180, -10000, 10000)
    db.y = Bounded(db.y, config.defaultY or (config.enemy and -220 or -80), -10000, 10000)
    db.minimapAngle = Bounded(db.minimapAngle, 220, -360, 360)
    db.locked = db.locked == true
    -- One-time migration to automatic tracking for every class.
    if not db.automaticTrackingVersion then db.all=true;db.automaticTrackingVersion=1 end
    db.all = db.all ~= false
    local excluded={}
    if type(db.excluded)=="table" then
        for id,enabled in pairs(db.excluded) do
            if type(id)=="number" and id>0 and id==math.floor(id) and enabled==true then excluded[id]=true end
        end
    end
    db.excluded=excluded
    db.barColor = config.enemy and "C62828" or ColorValue(db.barColor, "29A31F")
    db.textColor = ColorValue(db.textColor, "FFFFFF")
    db.warningColor = ColorValue(db.warningColor, "FF5533")
    db.growth = db.growth=="up" and "up" or "down"
    db.sort = db.sort == "longest" and "longest" or "shortest"
    db.threshold = Bounded(db.threshold, 5, 1, 30)
    db.flash = db.flash ~= false
    db.style = styles[db.style] and db.style or "flat"
    db.reminder = db.reminder == true
    db.reminderSpell = math.floor(Bounded(db.reminderSpell, config.enemy and 1943 or 5171, 1, 10000000))
    if type(db.reminderSpells)~="table" then db.reminderSpells={[db.reminderSpell]=true} end
    local reminderClean={}
    for id,enabled in pairs(db.reminderSpells) do
        if type(id)=="number" and id>0 and id==math.floor(id) and enabled==true then reminderClean[id]=true end
    end
    db.reminderSpells=reminderClean
    db.reminderScale = Bounded(db.reminderScale, 1.5, 1, 3)
    db.reminderX = Bounded(db.reminderX, -140, -10000, 10000)
    db.reminderY = Bounded(db.reminderY, config.enemy and -40 or 100, -10000, 10000)
    if type(db.spells) ~= "table" then db.spells = {} end
    local clean = {}
    for id, enabled in pairs(db.spells) do
        if type(id) == "number" and id > 0 and id == math.floor(id) and enabled == true then
            clean[id] = true
        end
    end
    db.spells = clean
    if type(db.racialSeen)~="table" then db.racialSeen={} end
    if not config.enemy and not db.racialDefaultsAdded then
        for id in pairs(racialDefaults) do db.spells[id]=true;db.racialSeen[id]=true end
        db.racialDefaultsAdded=true
    end
    _G[config.savedKey]=db
end

local function DiscoverRacials()
    if config.enemy then return 0 end
    if not C_SpellBook or not C_SpellBook.GetNumSpellBookSkillLines then return 0 end
    local added=0
    for lineIndex=1,C_SpellBook.GetNumSpellBookSkillLines() do
        local line=C_SpellBook.GetSpellBookSkillLineInfo(lineIndex)
        if line then
            for slot=line.itemIndexOffset+1,line.itemIndexOffset+line.numSpellBookItems do
                local info=C_SpellBook.GetSpellBookItemInfo(slot,Enum.SpellBookSpellBank.Player)
                if info and info.spellID and not info.isPassive then
                    local sub=info.subName
                    local racial=sub=="Racial" or (RACIAL and sub==RACIAL) or (SPELL_RACIAL and sub==SPELL_RACIAL)
                    if racial and not db.racialSeen[info.spellID] then
                        db.racialSeen[info.spellID]=true;db.spells[info.spellID]=true;added=added+1
                    end
                end
            end
        end
    end
    return added
end

local function Filters()
    -- A finite maximum also excludes permanent auras. The engine filters and
    -- sorts actual aura data; addon Lua never inspects combat aura payloads.
    local result = {maxDuration = 86400, excludeSpellIDs=Copy(db.excluded)}
    if not db.all then result.includeSpellIDs = Copy(db.spells) end
    return result
end

local function Font(parent, size)
    local text = parent:CreateFontString(nil, "OVERLAY")
    text:SetFont(FONT, size, "OUTLINE")
    text:SetTextColor(1, 1, 1)
    return text
end

local function ApplyRowStyle(bar)
    local texture = StyleTexture(db.style)
    bar:SetStatusBarTexture(texture)
    bar.empty:SetTexture(texture)
    bar.empty:SetVertexColor(0.07, 0.08, 0.07, 0.9)
    bar.rowBackground:SetShown(db.style == "flat")
end

local function DrawRow(button)
    button:SetSize(db.width, HEIGHT)
    button:EnableMouse(false)
    local background = button:CreateTexture(nil, "BACKGROUND")
    background:SetAllPoints()
    background:SetColorTexture(0, 0, 0, 0.95)

    local icon = button:CreateTexture(nil, "ARTWORK")
    icon:SetPoint("TOPLEFT", 0, -1)
    icon:SetSize(HEIGHT - 1, HEIGHT - 2)
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    local bar = CreateFrame("StatusBar", nil, button)
    bar:SetPoint("TOPLEFT", button, "TOPLEFT", HEIGHT - 1, -1)
    bar:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -1, 1)
    bar:SetStatusBarTexture(TEXTURE)
    bar:SetStatusBarColor(RGB(db.barColor))
    local empty = bar:CreateTexture(nil, "BACKGROUND")
    empty:SetAllPoints()
    bar.empty = empty
    bar.rowBackground = background
    ApplyRowStyle(bar)

    local time = Font(bar, 14)
    time:SetPoint("RIGHT", -4, 0)
    time:SetWidth(48)
    time:SetJustifyH("RIGHT")
    local name = Font(bar, 13)
    name:SetTextColor(RGB(db.textColor))
    time:SetTextColor(RGB(db.textColor))
    name:SetPoint("LEFT", 5, 0)
    name:SetPoint("RIGHT", time, "LEFT", -5, 0)
    name:SetJustifyH("LEFT")
    name:SetWordWrap(false)
    return icon, bar, name, time
end

local function InitializeAuraButton(button)
    local icon, bar, name, time = DrawRow(button)
    -- Preserve AuraButton's secure intrinsic hover scripts. The engine owns
    -- the active aura tooltip, including updates when this row is reused.
    button:EnableMouse(true)
    button:SetCancelAuraButtons(nil)
    button:SetTooltipAnchorPoint("ANCHOR_RIGHT", 8, 0)
    button:SetIcon(icon)
    button:SetSpellName(name)
    button:SetDurationBar(bar, {
        direction = Enum.StatusBarTimerDirection.RemainingTime,
        interpolation = Enum.StatusBarInterpolation.Immediate,
    })
    button:SetDurationText(time, {binding = durationBinding})
    liveRows[#liveRows+1] = {button=button, bar=bar, name=name, time=time}
end

local function ReminderFilters()
    local ids=Copy(db.reminderSpells)
    for selectedID in pairs(db.reminderSpells) do
        local selected=C_Spell.GetSpellInfo(selectedID)
        if selected then
            for id in pairs(defaults) do
                local info=C_Spell.GetSpellInfo(id)
                if info and info.name==selected.name then ids[id]=true end
            end
        end
    end
    return {maxDuration=86400,includeSpellIDs=ids,excludeSpellIDs=Copy(db.excluded)}
end

local function RefreshNativeWarnings()
    for _,entry in pairs(nativeWarningContainers) do entry.container:SetEnabled(false) end
    -- The native labels share the saved, draggable reminder anchor.
    nativeWarningAnchor=reminderAnchor
    local r,g,b=RGB(db.warningColor)
    local hidden=CreateColor(r,g,b,0)
    local visible=CreateColor(r,g,b,1)
    local dim=CreateColor(r,g,b,0.35)
    local curve=C_CurveUtil.CreateColorCurve()
    curve:SetType(Enum.LuaCurveType.Linear)
    curve:AddPoint(0,hidden);curve:AddPoint(0.001,visible)
    if db.flash then
        for i=1,math.ceil((db.threshold-0.001)/0.4)-1 do
            curve:AddPoint(i*0.4,i%2==1 and dim or visible)
        end
    end
    curve:AddPoint(db.threshold-0.001,visible)
    curve:AddPoint(db.threshold,hidden);curve:AddPoint(86401,hidden)
    local formatter=C_StringUtil.CreateSecondsFormatter()
    formatter:SetDefaultAbbreviation(Enum.SecondsFormatterAbbreviation.OneLetter)
    formatter:SetMinInterval(Enum.SecondsFormatterInterval.Seconds)
    formatter:SetMillisecondsThreshold(60)
    local ids={};for id in pairs(db.reminderSpells) do ids[#ids+1]=id end;table.sort(ids)
    local usedNames={};local index=0
    for _,id in ipairs(ids) do
        local info=C_Spell.GetSpellInfo(id)
        local name=info and info.name or tostring(id)
        if not usedNames[name] then
            usedNames[name]=true;index=index+1
            local entry=nativeWarningContainers[id]
            if not entry then
                entry={rows={}}
                local c=CreateFrame("AuraContainer",nil,nativeWarningAnchor,"CustomAuraContainerTemplate")
                entry.container=c;nativeWarningContainers[id]=entry
                c:SetEnabled(false)
                c:SetFlowLayoutAxis(AnchorUtil.FlowLayoutAxis.Vertical)
                c:SetFlowLayoutAnchorPoint("TOPLEFT")
                c:SetFlowLayoutGrowthDirection(AnchorUtil.FlowDirection.Right,AnchorUtil.FlowDirection.Down)
                c:SetFlowLayoutMaximumLineSize(nil)
                entry.initialize=function(button)
                    button:SetSize(db.width,HEIGHT);button:EnableMouse(false)
                    local text=Font(button,12)
                    text:SetAllPoints();text:SetJustifyH("LEFT");text:SetWordWrap(false)
                    entry.rows[#entry.rows+1]={button=button,text=text}
                    if entry.binding then button:SetDurationText(text,{binding=entry.binding}) end
                end
                local spellIDs={[id]=true}
                for rank in pairs(defaults) do
                    local rankInfo=C_Spell.GetSpellInfo(rank)
                    if rankInfo and rankInfo.name==name then spellIDs[rank]=true end
                end
                entry.spellIDs=spellIDs
                c:AddAuraGroup("warning",config.filter,{maxFrameCount=1,
                    candidateFilters={maxDuration=86400,includeSpellIDs=spellIDs},
                    sortMethod=AuraContainerSortMethod.ExpirationOnly,sortDirection=AuraContainerSortDirection.Normal,
                    layout={elementWidth=db.width,elementHeight=HEIGHT,elementSpacing=GAP},
                    initializeFrame=entry.initialize})
                c:SetUnit(config.unit)
            end
            entry.container:SetAuraGroupCandidateFilters("warning",{maxDuration=86400,includeSpellIDs=entry.spellIDs,excludeSpellIDs=Copy(db.excluded)})
            local binding=C_DurationUtil.CreateDurationTextBinding()
            binding:SetUpdateInterval(0.05)
            binding:SetTextColorCurve(curve,Enum.DurationTextBindingProperty.RemainingDuration)
            local icon=C_Spell.GetSpellTexture(id) or 134400
            binding:SetTextFormat("|T" .. icon .. ":22:22|t " .. name .. "  {}",{
                {property=Enum.DurationTextBindingProperty.RemainingDuration,formatter=formatter}})
            binding:SetExpiredText("");binding:SetZeroDurationText("")
            entry.container:SetAuraGroupLayout("warning",{elementWidth=db.width,elementHeight=HEIGHT,elementSpacing=GAP})
            entry.binding=binding
            for _,row in ipairs(entry.rows) do row.button:SetDurationText(row.text,{binding=binding}) end
            entry.container:ClearAllPoints()
            entry.container:SetPoint("TOPLEFT",nativeWarningAnchor,"TOPLEFT",0,-(index-1)*(HEIGHT+GAP))
            entry.container:SetEnabled(db.reminder and not testing)
        end
    end
end

local function UpdateReminder()
    if not reminderAnchor then return end
    reminderContainer:SetAlpha(0)
    reminderAnchor:SetShown(db.reminder)
    reminderAnchor:SetWidth(db.width)
    reminderAnchor:SetScale(db.reminderScale)
    reminderHandle:SetShown(positioningReminder)
    reminderHandle:EnableMouse(positioningReminder)
    reminderContainer:SetAuraGroupCandidateFilters("buffs", ReminderFilters())
    reminderContainer:SetAuraGroupLayout("buffs", {elementWidth=db.width, elementHeight=HEIGHT, elementSpacing=GAP})
    reminderContainer:SetEnabled(false)
    reminderPreview:SetShown(db.reminder and testing)
    reminderPreview:SetWidth(db.width)
    local ids={}
    for id in pairs(db.reminderSpells) do ids[#ids+1]=id end
    table.sort(ids)
    for i,id in ipairs(ids) do
        local row=reminderPreviewRows[i]
        if not row then
            local frame=CreateFrame("Frame",nil,reminderPreview)
            local icon,bar,name,time=DrawRow(frame)
            row={frame=frame,icon=icon,bar=bar,name=name,time=time}
            bar:Hide();icon:Hide();bar.rowBackground:Hide()
            row.nativeText=Font(frame,12)
            row.nativeText:SetAllPoints();row.nativeText:SetJustifyH("LEFT");row.nativeText:SetWordWrap(false)
            reminderPreviewRows[i]=row
        end
        row.frame:SetPoint("TOPLEFT",reminderPreview,"TOPLEFT",0,-(i-1)*(HEIGHT+GAP))
        row.frame:SetWidth(db.width);row.frame:Show();row.frame:SetAlpha(positioningReminder and 1 or 0)
        row.duration=12+(i-1)*2
        row.bar:SetMinMaxValues(0,row.duration)
        local info=C_Spell.GetSpellInfo(id)
        row.icon:SetTexture(C_Spell.GetSpellTexture(id) or 134400)
        local displayName=info and info.name or tostring(id)
        row.previewFormat="|T" .. (C_Spell.GetSpellTexture(id) or 134400) .. ":22:22|t " .. displayName:gsub("%%","%%%%") .. "  %.1f"
        row.nativeText:SetFormattedText(row.previewFormat,3)
        row.nativeText:SetTextColor(RGB(db.warningColor))
    end
    for i=#ids+1,#reminderPreviewRows do reminderPreviewRows[i].frame:Hide() end
    if db.reminder and testing then
        reminderPreview:SetScript("OnUpdate",function(self,elapsed)
            self.elapsed=(self.elapsed or 0)+elapsed
            for i=1,#ids do
                local row=reminderPreviewRows[i]
                local remaining=row.duration-(self.elapsed%row.duration)
                row.frame:SetAlpha(positioningReminder and 1 or reminderOpacityCurve:Evaluate(remaining))
                row.nativeText:SetFormattedText(row.previewFormat,remaining)
                row.bar:SetValue(remaining)
                row.time:SetFormattedText("%.1f",remaining)
                row.time:SetTextColor(warningCurve:EvaluateUnpacked(remaining))
            end
        end)
    else reminderPreview:SetScript("OnUpdate",nil) end
    RefreshNativeWarnings()
end

local function ApplyAppearance()
    BuildDurationBinding()
    for _, row in ipairs(liveRows) do
        row.bar:SetStatusBarColor(RGB(db.barColor))
        ApplyRowStyle(row.bar)
        row.name:SetTextColor(RGB(db.textColor))
        row.button:SetDurationText(row.time, {binding=durationBinding})
    end
    for _, row in ipairs(previewRows) do
        row.bar:SetStatusBarColor(RGB(db.barColor))
        ApplyRowStyle(row.bar)
        row.name:SetTextColor(RGB(db.textColor))
        row.time:SetTextColor(RGB(db.textColor))
    end
    for _,row in ipairs(reminderPreviewRows) do
        row.bar:SetStatusBarColor(RGB(db.barColor));row.bar.rowBackground:Hide()
        row.name:SetTextColor(RGB(db.textColor));row.time:SetTextColor(RGB(db.textColor))
        if row.nativeText then row.nativeText:SetTextColor(RGB(db.warningColor)) end
    end
    container:SetAuraGroupSortMethod("buffs", AuraContainerSortMethod.ExpirationOnly, SortDirection())
    RefreshNativeWarnings()
end

local function PlaceAnchor()
    anchor:ClearAllPoints()
    anchor:SetPoint("TOPLEFT", UIParent, "CENTER", db.x, db.y)
end

local function UpdateLock()
    handle:SetShown(not db.locked)
    handle:EnableMouse(not db.locked)
    if resizeGrip then resizeGrip:SetShown(not db.locked and not InCombatLockdown()) end
    UpdateReminder()
end

local function SetPreview(show)
    testing = show
    if not show then positioningReminder=false;reminderHandle:Hide();reminderHandle:EnableMouse(false) end
    if InCombatLockdown() then
        -- Do not reconfigure filters/layout while leaving preview for combat.
        reminderContainer:SetAlpha(0)
        reminderPreview:Hide()
        reminderPreview:SetScript("OnUpdate", nil)
        reminderContainer:SetEnabled(false)
        for _,entry in pairs(nativeWarningContainers) do entry.container:SetEnabled(db.reminder) end
    else
        UpdateReminder()
    end
    preview:SetShown(show)
    container:SetEnabled(not show)
    if show then
        preview.elapsed = 0
        preview:SetScript("OnUpdate", function(self, elapsed)
            self.elapsed = self.elapsed + elapsed
            for i, row in ipairs(previewRows) do
                local duration = row.duration
                local remaining = duration - (self.elapsed % duration)
                row.remaining = remaining
                row.bar:SetValue(remaining)
                row.time:SetFormattedText("%.1f", remaining)
                -- Preview values are synthetic, public numbers, so this local
                -- evaluation is safe. Live timers use the native binding above.
                row.time:SetTextColor(warningCurve:EvaluateUnpacked(remaining))
                row.frame:SetAlpha(pulseCurve:Evaluate(remaining))
            end
            table.sort(previewRows, function(a,b)
                if a.remaining == b.remaining then return a.id < b.id end
                if db.sort == "longest" then return a.remaining > b.remaining end
                return a.remaining < b.remaining
            end)
            for i, row in ipairs(previewRows) do
                row.frame:ClearAllPoints()
                row.frame:SetPoint(db.growth=="up" and "BOTTOMLEFT" or "TOPLEFT", anchor, "TOPLEFT", 0, (db.growth=="up" and 1 or -1)*(i-1)*(HEIGHT+GAP))
            end
        end)
    else
        preview:SetScript("OnUpdate", nil)
    end
end

local function ApplyGrowth()
    local up=db.growth=="up"
    local point=up and "BOTTOMLEFT" or "TOPLEFT"
    container:ClearAllPoints()
    container:SetPoint(point,anchor,"TOPLEFT",0,0)
    container:SetFlowLayoutAnchorPoint(point)
    container:SetFlowLayoutGrowthDirection(AnchorUtil.FlowDirection.Right,up and AnchorUtil.FlowDirection.Up or AnchorUtil.FlowDirection.Down)
    handle:ClearAllPoints()
    handle:SetPoint(up and "TOPLEFT" or "BOTTOMLEFT",anchor,"TOPLEFT",0,up and -4 or 4)
    handle:SetPoint(up and "TOPRIGHT" or "BOTTOMRIGHT",anchor,"TOPRIGHT",0,up and -4 or 4)
    for i,row in ipairs(previewRows) do
        row.frame:ClearAllPoints()
        row.frame:SetPoint(point,anchor,"TOPLEFT",0,(up and 1 or -1)*(i-1)*(HEIGHT+GAP))
    end
end

local function Resize(skipReminders)
    anchor:SetWidth(db.width)
    anchor:SetScale(db.scale)
    container:SetAuraGroupLayout("buffs", {elementWidth = db.width, elementHeight = HEIGHT, elementSpacing = GAP})
    -- Existing AuraButtons keep the size assigned at initialization unless we
    -- update them too.  Keep live bars exactly matched to the FBUFF sliders.
    for _, row in ipairs(liveRows) do
        if row.button then row.button:SetSize(db.width, HEIGHT) end
    end
    for _, row in ipairs(previewRows) do row.frame:SetWidth(db.width) end
    if not skipReminders then UpdateReminder() end
end

local function PlaceReminder()
    reminderAnchor:ClearAllPoints()
    reminderAnchor:SetPoint("TOPLEFT", UIParent, "CENTER", db.reminderX, db.reminderY)
end

local function CreateReminder()
    reminderAnchor=CreateFrame("Frame", "ForeverClassTimersReminderAnchor", UIParent)
    reminderAnchor:SetSize(db.width, HEIGHT)
    reminderAnchor:SetScale(db.reminderScale)
    reminderAnchor:SetMovable(true)
    reminderAnchor:SetClampedToScreen(true)
    reminderAnchor:SetFrameStrata("HIGH")
    PlaceReminder()
    reminderHandle=CreateFrame("Frame", "ForeverClassTimersReminderHandle", reminderAnchor)
    reminderHandle:SetPoint("BOTTOMLEFT", reminderAnchor, "TOPLEFT", 0, 4)
    reminderHandle:SetPoint("BOTTOMRIGHT", reminderAnchor, "TOPRIGHT", 0, 4)
    reminderHandle:SetHeight(24)
    reminderHandle:EnableMouse(true)
    reminderHandle:RegisterForDrag("LeftButton")
    local bg=reminderHandle:CreateTexture(nil,"BACKGROUND")
    bg:SetAllPoints();bg:SetColorTexture(0.15,0.08,0.03,0.95)
    local label=Font(reminderHandle,10)
    label:SetPoint("CENTER");label:SetText((config.enemy and "DEBUFF REMINDERS" or "BUFF REMINDERS") .. " | Drag | " .. config.command .. " lock")
    reminderHandle:SetScript("OnDragStart",function()
        if positioningReminder and not InCombatLockdown() then reminderAnchor:StartMoving() end
    end)
    reminderHandle:SetScript("OnDragStop",function()
        reminderAnchor:StopMovingOrSizing()
        if InCombatLockdown() then return end
        local left,top=reminderAnchor:GetLeft(),reminderAnchor:GetTop()
        if left and top then
            local ratio=reminderAnchor:GetEffectiveScale()/UIParent:GetEffectiveScale()
            db.reminderX=left-(UIParent:GetWidth()/2)/ratio
            db.reminderY=top-(UIParent:GetHeight()/2)/ratio
            PlaceReminder()
        end
    end)
    reminderContainer=CreateFrame("AuraContainer", "ForeverClassTimersReminderAuras", reminderAnchor,"CustomAuraContainerTemplate")
    reminderContainer:SetEnabled(false)
    reminderContainer:SetPoint("TOPLEFT",reminderAnchor,"TOPLEFT")
    reminderContainer:SetFlowLayoutAxis(AnchorUtil.FlowLayoutAxis.Vertical)
    reminderContainer:SetFlowLayoutAnchorPoint("TOPLEFT")
    reminderContainer:SetFlowLayoutGrowthDirection(AnchorUtil.FlowDirection.Right,AnchorUtil.FlowDirection.Down)
    reminderContainer:SetFlowLayoutMaximumLineSize(nil)
    reminderContainer:AddAuraGroup("buffs",config.filter,{
        maxFrameCount=math.huge, candidateFilters=ReminderFilters(),
        sortMethod=AuraContainerSortMethod.ExpirationOnly, sortDirection=AuraContainerSortDirection.Normal,
        layout={elementWidth=db.width,elementHeight=HEIGHT,elementSpacing=GAP},
        initializeFrame=function(button)
            InitializeAuraButton(button)
            local row=liveRows[#liveRows]
            row.isReminder=true;row.button:SetAlpha(0)
            reminderLiveRows[#reminderLiveRows+1]=row
        end,
    })
    reminderContainer:SetAlpha(0)
    reminderContainer:SetUnit(config.unit)
    -- Live threshold opacity cannot query these forbidden timer objects.
    -- Keep live reminders hidden until a supported native binding is available.
    reminderPreview=CreateFrame("Frame","ForeverClassTimersReminderPreview",reminderAnchor)
    reminderPreview:SetPoint("TOPLEFT",reminderAnchor,"TOPLEFT")
    reminderPreview:SetSize(db.width,1)
    UpdateReminder()
end

local function CreateResizeGrip()
    resizeGrip=CreateFrame("Frame","ForeverClassTimersResizeGrip",handle)
    resizeGrip:SetSize(22,22);resizeGrip:SetPoint("TOPRIGHT",handle,"TOPRIGHT",0,0)
    resizeGrip:EnableMouse(true)
    local mark=Font(resizeGrip,16);mark:SetPoint("CENTER");mark:SetText("+")
    local drag
    local function Stop()
        local wasDragging=drag~=nil
        drag=nil;resizeGrip:SetScript("OnUpdate",nil)
        if wasDragging and not InCombatLockdown() then
            Resize();PlaceAnchor()
            if optionsWindow then optionsWindow:Refresh() end
        end
    end
    resizeGrip:SetScript("OnMouseDown",function(_,button)
        if button~="RightButton" or db.locked or InCombatLockdown() then return end
        local x,y=GetCursorPosition()
        drag={x=x,y=y,width=db.width,scale=db.scale,px=db.x,py=db.y,parentScale=UIParent:GetEffectiveScale()}
        resizeGrip:SetScript("OnUpdate",function()
            if InCombatLockdown() or db.locked then Stop();return end
            local cx,cy=GetCursorPosition()
            local scale=math.max(0.5,math.min(2,drag.scale+(drag.y-cy)/(200*drag.parentScale)))
            local width=math.max(180,math.min(600,(drag.width*drag.scale+(cx-drag.x)/drag.parentScale)/scale))
            db.scale=scale;db.width=math.floor(width+0.5)
            -- Keep the list's screen anchor stationary as its scale changes.
            db.x=drag.px*drag.scale/scale;db.y=drag.py*drag.scale/scale
            Resize(true);PlaceAnchor()
        end)
    end)
    resizeGrip:SetScript("OnMouseUp",function(_,button) if button=="RightButton" then Stop() end end)
    resizeGrip:SetScript("OnHide",Stop)
    resizeGrip:SetScript("OnEnter",function()
        GameTooltip:SetOwner(resizeGrip,"ANCHOR_RIGHT")
        GameTooltip:SetText("Hold right-click and drag to resize")
        GameTooltip:AddLine("Left/right: width. Down/up: larger/smaller text and bars.",1,1,1,true)
        GameTooltip:Show()
    end)
    resizeGrip:SetScript("OnLeave",function() GameTooltip:Hide() end)
end

local function CreateUI()
    BuildDurationBinding()
    anchor = CreateFrame("Frame", "ForeverClassTimersAnchor", UIParent)
    anchor:SetSize(db.width, 1)
    anchor:SetScale(db.scale)
    anchor:SetMovable(true)
    anchor:SetClampedToScreen(true)
    anchor:SetFrameStrata("MEDIUM")
    PlaceAnchor()

    handle = CreateFrame("Frame", nil, anchor)
    handle:SetPoint("BOTTOMLEFT", anchor, "TOPLEFT", 0, 4)
    handle:SetPoint("BOTTOMRIGHT", anchor, "TOPRIGHT", 0, 4)
    handle:SetHeight(28)
    handle:EnableMouse(true)
    handle:RegisterForDrag("LeftButton")
    local bg = handle:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0.13, 0.12, 0.05, 0.95)
    local label = Font(handle, 10)
    label:SetPoint("CENTER")
    label:SetFont(FONT, 16, "OUTLINE")
    label:SetText(config.label or (config.enemy and "DOT" or "BUFF"))
    handle:SetScript("OnDragStart", function()
        if not db.locked and not InCombatLockdown() then anchor:StartMoving() end
    end)
    handle:SetScript("OnDragStop", function()
        anchor:StopMovingOrSizing()
        local left, top = anchor:GetLeft(), anchor:GetTop()
        if left and top then
            local ratio = anchor:GetEffectiveScale() / UIParent:GetEffectiveScale()
            -- SetPoint offsets are in the scaled anchor's coordinate space.
            db.x = left - (UIParent:GetWidth() / 2) / ratio
            db.y = top - (UIParent:GetHeight() / 2) / ratio
            PlaceAnchor()
        end
    end)

    container = CreateFrame("AuraContainer", config.prefix .. "Auras", anchor, "CustomAuraContainerTemplate")
    container:SetEnabled(false)
    container:SetPoint("TOPLEFT", anchor, "TOPLEFT")
    container:SetFlowLayoutAxis(AnchorUtil.FlowLayoutAxis.Vertical)
    container:SetFlowLayoutAnchorPoint("TOPLEFT")
    container:SetFlowLayoutGrowthDirection(AnchorUtil.FlowDirection.Right, AnchorUtil.FlowDirection.Down)
    container:SetFlowLayoutMaximumLineSize(nil)
    container:AddAuraGroup("buffs", config.filter, {
        maxFrameCount = 20,
        candidateFilters = Filters(),
        sortMethod = AuraContainerSortMethod.ExpirationOnly,
        sortDirection = SortDirection(),
        layout = {elementSpacing = GAP, elementWidth = db.width, elementHeight = HEIGHT},
        initializeFrame = InitializeAuraButton,
    })
    container:SetUnit(config.unit)
    container:SetEnabled(true)
    -- FBUFF friend buffs are rendered only by the persistent multi-target cache.
    -- Keep Blizzard's target-bound AuraContainer alive for compatibility/filter APIs,
    -- but never let it draw a second copy of the current friendly target.
    if config.persistMulti then
        -- Multi-target rows are custom-rendered.  Friendly buffs keep their
        -- existing cache; enemy DoTs are fed by confirmed player casts so we
        -- never inspect secret combat aura payloads.
        container:SetAlpha(0)
    end
    -- Target-bound AuraContainers must be rebound when the target changes.
    -- This prevents an aura from the previous target remaining as a stale row.
    if config.unit == "target" then
        local targetRefresh = CreateFrame("Frame")
        targetRefresh:RegisterEvent("PLAYER_TARGET_CHANGED")
        targetRefresh:SetScript("OnEvent", function()
            if InCombatLockdown() then return end
            container:SetEnabled(false)
            container:SetUnit("target")
            container:SetEnabled(true)
            if config.persistMulti and not config.enemy then container:SetAlpha(0) end
        end)
    end

    preview = CreateFrame("Frame", nil, anchor)
    preview:SetAllPoints(anchor)
    for i, entry in ipairs(config.enemy and {{1943,"Rupture",16},{703,"Garrote",18},{8647,"Expose Armor",30}} or {{5171,"Slice and Dice",24},{5277,"Evasion",15},{2983,"Sprint",8}}) do
        local frame = CreateFrame("Frame", nil, preview)
        frame:SetPoint("TOPLEFT", anchor, "TOPLEFT", 0, -(i-1)*(HEIGHT+GAP))
        local icon, bar, name, time = DrawRow(frame)
        icon:SetTexture(C_Spell.GetSpellTexture(entry[1]) or 134400)
        name:SetText(entry[2])
        bar:SetMinMaxValues(0, entry[3])
        previewRows[i] = {frame = frame, bar = bar, name = name, time = time, duration = entry[3], id=entry[1]}
    end
    preview:Hide()
    ApplyGrowth()
    CreateReminder()
    -- FBUFF uses the settings sliders for size; do not create FCT's + resize grip.
    UpdateLock()
end

local function OpenOptions()
    if optionsWindow then optionsWindow:Show(); optionsWindow:Refresh(); return end
    local window = CreateFrame("Frame", "ForeverClassTimersOptions", UIParent)
    optionsWindow = window
    window:SetSize(780, 560)
    window:SetPoint("CENTER")
    window:SetScale(math.min(1,(UIParent:GetWidth()-40)/780,(UIParent:GetHeight()-40)/560))
    window:SetFrameStrata("DIALOG")
    window:SetClampedToScreen(true)
    window:SetMovable(true);window:EnableMouse(true)
    local function Surface(parent,r,g,b)
        local tex=parent:CreateTexture(nil,"BACKGROUND")
        tex:SetAllPoints();tex:SetColorTexture(r,g,b,1)
        return tex
    end
    Surface(window,0.055,0.065,0.085)
    local titlebar=CreateFrame("Frame",nil,window)
    titlebar:SetPoint("TOPLEFT");titlebar:SetPoint("TOPRIGHT");titlebar:SetHeight(66)
    Surface(titlebar,0.085,0.10,0.13)
    titlebar:EnableMouse(true);titlebar:RegisterForDrag("LeftButton")
    titlebar:SetScript("OnDragStart",function() if not InCombatLockdown() then window:StartMoving() end end)
    titlebar:SetScript("OnDragStop",function() window:StopMovingOrSizing() end)
    local heading=Font(titlebar,19);heading:SetPoint("TOPLEFT",22,-15);heading:SetText("Forever Class Timers")
    local subtitle=Font(titlebar,11);subtitle:SetPoint("TOPLEFT",23,-41);subtitle:SetText(config.enemy and "ENEMY DEBUFFS  /  YOUR CURRENT TARGET" or "PLAYER BUFFS  /  PERSONALIZE YOUR DISPLAY")
    subtitle:SetTextColor(0.57,0.69,0.77)
    local function ModernButton(parent,label,x,y,width,callback)
        local button=CreateFrame("Button",nil,parent)
        button:SetPoint("TOPLEFT",x,y);button:SetSize(width,34)
        local bg=Surface(button,0.12,0.15,0.19)
        local caption=Font(button,12);caption:SetPoint("CENTER");caption:SetWidth(width-16)
        button:SetFontString(caption);button:SetText(label)
        button:SetScript("OnEnter",function() bg:SetColorTexture(0.18,0.24,0.29,1) end)
        button:SetScript("OnLeave",function() bg:SetColorTexture(0.12,0.15,0.19,1) end)
        button:SetScript("OnClick",function() if not InCombatLockdown() then callback() end end)
        return button
    end
    ModernButton(titlebar,"Close",684,-16,74,function() window:Hide() end)
    local sidebar=CreateFrame("Frame",nil,window)
    sidebar:SetPoint("TOPLEFT",0,-66);sidebar:SetPoint("BOTTOMLEFT",0,0);sidebar:SetWidth(174)
    Surface(sidebar,0.075,0.085,0.11)
    local pages={}
    local scroll=CreateFrame("ScrollFrame",nil,window,"UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT",196,-84);scroll:SetSize(540,390)
    local content=CreateFrame("Frame",nil,scroll);content:SetSize(520,1430);scroll:SetScrollChild(content)
    for i,titleText in ipairs({"Appearance","Warnings","Reminders"}) do
        local section=CreateFrame("Frame",nil,content)
        section:SetPoint("TOPLEFT",0,-(i==1 and 0 or i==2 and 335 or 595))
        section:SetSize(520,320);pages[i]=section
        local title=Font(section,17);title:SetPoint("TOPLEFT");title:SetText(titleText)
    end
    local nav={}
    function window:SelectPage(index)
        -- Legacy section shortcuts now scroll within the selected tracker tab.
        self.page=index;scroll:SetVerticalScroll(index==2 and 335 or index==3 and 595 or 0)
    end
    for i,name in ipairs({"Player Buffs","Enemy Debuffs"}) do
        local key=i==1 and "buffs" or "debuffs"
        local selected=(config.enemy and i==2) or (not config.enemy and i==1)
        nav[i]=ModernButton(sidebar,(selected and "|cff71d5c7" or "|cffdddddd") .. name .. "|r",12,-18-(i-1)*44,150,function()
            local tracker=trackers[key]
            if tracker then
                window:Hide()
                if window.reminderEditor then window.reminderEditor:Hide() end
                tracker.open()
            end
        end)
    end
    local version=Font(sidebar,11);version:SetPoint("BOTTOMLEFT",18,22);version:SetText("VERSION " .. VERSION);version:SetTextColor(0.57,0.64,0.71)
    local footer=Font(window,11);footer:SetPoint("BOTTOMLEFT",196,67)
    footer:SetText("Changes save automatically. Configure outside combat.");footer:SetTextColor(0.64,0.70,0.77)
    ModernButton(window,"Finish positioning / lock",196,-508,265,function()
        db.locked=true;SetPreview(false);UpdateLock()
    end)
    local controls = {}
    ModernButton(content,"Move timer list",0,-938,250,function() db.locked=false;SetPreview(true);UpdateLock();window:Hide() end)
    ModernButton(content,"Reset timer position",270,-938,250,function() db.x=180;db.y=config.enemy and -220 or -80;PlaceAnchor() end)
    controls.mode=ModernButton(content,"",0,-982,520,function()
        db.all=not db.all;container:SetAuraGroupCandidateFilters("buffs",Filters());window:Refresh()
    end)
    local excludeTitle=Font(content,15);excludeTitle:SetPoint("TOPLEFT",0,-1040);excludeTitle:SetText("Hide unwanted effects (all classes)")
    local excludeEntry=CreateFrame("EditBox",nil,content,"InputBoxTemplate")
    excludeEntry:SetPoint("TOPLEFT",8,-1074);excludeEntry:SetSize(500,26);excludeEntry:SetAutoFocus(false)
    local function ExclusionAction(command)
        SlashCmdList[config.slashKey](command .. " " .. (excludeEntry:GetText() or ""))
        excludeEntry:ClearFocus()
    end
    ModernButton(content,"Hide effect",0,-1116,165,function() ExclusionAction("remove") end)
    ModernButton(content,"Restore effect",177,-1116,165,function() ExclusionAction("add") end)
    ModernButton(content,"List hidden",354,-1116,166,function() ExclusionAction("excluded") end)
    local excludeHelp=Font(content,11);excludeHelp:SetPoint("TOPLEFT",0,-1164);excludeHelp:SetWidth(520)
    excludeHelp:SetText("Enter the effect's spell ID or exact name. Hidden IDs stay hidden after reload.\nList hidden prints IDs in chat. Restore allows that effect to appear again.")
    local sizeTitle=Font(content,17);sizeTitle:SetPoint("TOPLEFT",0,-1230);sizeTitle:SetText("Bar size")
    local function SizeInput(key,label,x,defaultValue)
        local caption=Font(content,12);caption:SetPoint("TOPLEFT",x,-1265);caption:SetText(label)
        local entry=CreateFrame("EditBox",nil,content,"InputBoxTemplate")
        entry:SetPoint("TOPLEFT",x+8,-1288);entry:SetSize(220,26);entry:SetAutoFocus(false)
        local function Apply()
            if InCombatLockdown() then return end
            SlashCmdList[config.slashKey](key .. " " .. (entry:GetText() or ""))
            entry:ClearFocus();window:Refresh()
        end
        entry:SetScript("OnEnterPressed",Apply)
        ModernButton(content,"Apply " .. key,x,-1330,240,Apply)
        return entry
    end
    controls.widthInput=SizeInput("width","Width (180-600)",0)
    controls.scaleInput=SizeInput("scale","Overall size (0.5-2.0)",270)
    ModernButton(content,"Reset bar size",0,-1374,240,function()
        db.width=280;db.scale=1;Resize();window:Refresh()
    end)
    local sizeHelp=Font(content,11);sizeHelp:SetPoint("TOPLEFT",270,-1374);sizeHelp:SetWidth(240)
    sizeHelp:SetText("Overall size scales bar height, icons and text together. Changes save automatically.")
    controls.growth=ModernButton(pages[1],"",0,-295,520,function()
        db.growth=db.growth=="up" and "down" or "up";ApplyGrowth();window:Refresh()
    end)
    local placements={[-38]={1,-66},[-72]={1,-110},[-106]={1,-154},[-145]={1,-210},[-325]={1,-254},
        [-179]={2,-66},[-251]={2,-164},[-287]={0,-508},
        [-363]={3,-66},[-397]={3,-110},[-431]={3,-154},[-465]={3,-198}}
    local function Button(label,y,callback)
        local place=placements[y]
        return ModernButton(place[1]==0 and window or pages[place[1]],label,place[1]==0 and 477 or 0,place[2],place[1]==0 and 279 or 520,callback)
    end
    local function PickColor(key)
        local previous = db[key]
        local r,g,b = RGB(previous)
        local function SetColor(hex)
            if InCombatLockdown() then return end
            db[key] = hex; ApplyAppearance(); window:Refresh()
        end
        ColorPickerFrame:SetupColorPickerAndShow({r=r,g=g,b=b,hasOpacity=false,extraInfo=ADDON,
            swatchFunc=function()
                local cr,cg,cb = ColorPickerFrame:GetColorRGB()
                SetColor(string.format("%02X%02X%02X", math.floor(cr*255+0.5), math.floor(cg*255+0.5), math.floor(cb*255+0.5)))
            end,
            cancelFunc=function() SetColor(previous) end,
        })
    end
    for i, spec in ipairs({{"barColor","Bar color"},{"textColor","Text color"},{"warningColor","Warning color"}}) do
        local key, label = spec[1], spec[2]
        controls[key] = Button(label, -38-(i-1)*34, function() PickColor(key) end)
    end
    controls.sort = Button("", -145, function()
        db.sort = db.sort == "shortest" and "longest" or "shortest"
        ApplyAppearance(); window:Refresh()
    end)
    controls.flash = Button("", -179, function() db.flash=not db.flash;ApplyAppearance();window:Refresh() end)
    local label = Font(pages[2], 12)
    label:SetPoint("TOPLEFT", 0, -122)
    label:SetText("Flash below (seconds):")
    local input = CreateFrame("EditBox", nil, pages[2], "InputBoxTemplate")
    input:SetPoint("TOPLEFT", 290, -114)
    input:SetSize(65, 24)
    input:SetAutoFocus(false)
    input:SetMaxLetters(4)
    local function CommitThreshold()
        if InCombatLockdown() then return end
        local threshold = Bounded(input:GetText(), nil, 1, 30)
        if threshold then db.threshold=threshold;ApplyAppearance()
        else Say("Warning threshold must be 1-30 seconds.") end
        input:ClearFocus();window:Refresh()
    end
    input:SetScript("OnEnterPressed", CommitThreshold)
    input:SetScript("OnEscapePressed", function() input:ClearFocus();window:Refresh() end)
    Button("Apply threshold", -251, CommitThreshold)
    Button("Toggle preview bars", -287, function()
        if not testing then db.locked=false;UpdateLock() end
        SetPreview(not testing)
    end)
    controls.style = Button("", -325, function()
        local nextStyle = {flat="rounded", rounded="beveled", beveled="flat"}
        db.style = nextStyle[db.style]; ApplyAppearance(); window:Refresh()
    end)
    controls.reminder = Button("", -363, function()
        db.reminder=not db.reminder;if not db.reminder then positioningReminder=false end;UpdateReminder();window:Refresh()
    end)
    controls.reminderSpell = Button("Manage reminder abilities", -397, function()
        local editor=window.reminderEditor
        if not editor then
            editor=CreateFrame("Frame",nil,UIParent,"BasicFrameTemplateWithInset")
            window.reminderEditor=editor
            editor:SetSize(350,200);editor:SetPoint("CENTER");editor:SetFrameStrata("DIALOG")
            editor.TitleText:SetText("Reminder abilities - add or remove")
            local entry=CreateFrame("EditBox",nil,editor,"InputBoxTemplate")
            entry:SetSize(300,24);entry:SetPoint("TOPLEFT",24,-40);entry:SetAutoFocus(false)
            local function Action(text,x,command)
                local btn=CreateFrame("Button",nil,editor,"UIPanelButtonTemplate")
                btn:SetSize(94,28);btn:SetPoint("TOPLEFT",x,-78);btn:SetText(text)
                btn:SetScript("OnClick",function()
                    if InCombatLockdown() then return end
                    SlashCmdList[config.slashKey](command .. " " .. (entry:GetText() or ""))
                    entry:ClearFocus()
                end)
            end
            Action("Add",20,"reminderadd");Action("Remove",128,"reminderremove");Action("List",236,"reminderlist")
            local help=Font(editor,11);help:SetPoint("TOPLEFT",20,-122);help:SetWidth(310)
            help:SetText("Enter an ability name or buff ID. Add each ability you want. List prints your selection in chat.")
        end
        editor:Show()
    end)
    controls.reminderSize = Button("", -431, function()
        db.reminderScale=db.reminderScale+0.25
        if db.reminderScale>3 then db.reminderScale=1 end
        UpdateReminder();window:Refresh()
    end)
    Button("Position reminder (drag its handle)", -465, function()
        positioningReminder=true;db.reminder=true;SetPreview(true);UpdateLock();window:Refresh();window:Hide()
    end)
    local note=Font(pages[3],11)
    note:SetPoint("TOPLEFT",0,-256);note:SetWidth(520)
    note:SetText(("Icon and countdown reminders appear below the threshold.\nPosition moves the entire reminder group.\nUse /fct lock to finish; positions and choices are saved."):gsub("/fct",config.command))
    function window:Refresh()
        controls.widthInput:SetText(tostring(db.width))
        controls.scaleInput:SetText(string.format("%.2f",db.scale))
        controls.growth:SetText(db.growth=="up" and "List grows: UP (click to change)" or "List grows: DOWN (click to change)")
        controls.mode:SetText(db.all and "Tracking: all matching timed effects" or "Tracking: selected spell IDs")
        controls.reminder:SetText(db.reminder and "Large reminders: ON" or "Large reminders: OFF")
        local count=0;for _ in pairs(db.reminderSpells) do count=count+1 end
        controls.reminderSpell:SetText("Manage reminder abilities (" .. count .. " selected)")
        controls.reminderSize:SetText(string.format("Reminder size: %.2fx (click to change)",db.reminderScale))
        controls.style:SetText("Bar style: " .. styles[db.style] .. " (click to change)")
        controls.barColor:SetText("Bar color: |cff" .. db.barColor .. db.barColor .. "|r")
        controls.textColor:SetText("Text color: |cff" .. db.textColor .. db.textColor .. "|r")
        controls.warningColor:SetText("Warning color: |cff" .. db.warningColor .. db.warningColor .. "|r")
        controls.sort:SetText(db.sort == "shortest" and "From anchor: shortest to longest" or "From anchor: longest to shortest")
        controls.flash:SetText(db.flash and "Countdown color pulse: ON" or "Countdown color pulse: OFF")
        input:SetText(tostring(db.threshold))
    end
    window:SelectPage(1)
    window:Refresh()
end

local function CreateMinimapButton()
    local button=CreateFrame("Button","ForeverClassTimersMinimapButton",Minimap)
    minimapButton=button
    button:SetSize(32,32)
    button:SetFrameStrata("MEDIUM")
    button:SetFrameLevel(Minimap:GetFrameLevel()+8)
    button:RegisterForClicks("LeftButtonUp","RightButtonUp")
    button:RegisterForDrag("LeftButton")
    local icon=button:CreateTexture(nil,"ARTWORK")
    icon:SetPoint("CENTER");icon:SetSize(23,23)
    icon:SetTexture("Interface\\Icons\\INV_Misc_PocketWatch_01")
    local border=button:CreateTexture(nil,"OVERLAY")
    border:SetSize(54,54);border:SetPoint("TOPLEFT")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    local label=Font(button,9);label:SetPoint("BOTTOM",0,1);label:SetText("FCT")
    button:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    local function Place()
        local angle=math.rad(db.minimapAngle)
        local rx,ry=Minimap:GetWidth()/2+8,Minimap:GetHeight()/2+8
        button:ClearAllPoints()
        button:SetPoint("CENTER",Minimap,"CENTER",math.cos(angle)*rx,math.sin(angle)*ry)
    end
    Place()
    button:SetScript("OnClick",function()
        if button.wasDragged then button.wasDragged=false;return end
        if InCombatLockdown() then Say("Leave combat before opening settings.");return end
        OpenOptions()
    end)
    button:SetScript("OnEnter",function()
        GameTooltip:SetOwner(button,"ANCHOR_LEFT")
        GameTooltip:SetText("Forever Class Timers")
        GameTooltip:AddLine("Click: open settings",1,1,1)
        GameTooltip:AddLine("Drag: move around the minimap",0.7,0.8,0.9)
        GameTooltip:Show()
    end)
    button:SetScript("OnLeave",function() GameTooltip:Hide() end)
    button:SetScript("OnDragStart",function()
        if InCombatLockdown() then return end
        button.wasDragged=true
        GameTooltip:Hide()
        button:SetScript("OnUpdate",function()
            local x,y=GetCursorPosition()
            local cx,cy=Minimap:GetCenter()
            if not cx or not cy then return end
            local scale=Minimap:GetEffectiveScale()
            db.minimapAngle=math.deg(math.atan2(y/scale-cy,x/scale-cx))
            Place()
        end)
    end)
    button:SetScript("OnDragStop",function() button:SetScript("OnUpdate",nil) end)
    -- Clear the drag-click suppression at the start of the next real click.
    button:SetScript("OnMouseDown",function() button.wasDragged=false end)
end

local function RegisterOptionsCategory()
    local panel=CreateFrame("Frame","ForeverClassTimersSettingsPanel",UIParent)
    panel:Hide()
    local title=Font(panel,20);title:SetPoint("TOPLEFT",20,-20);title:SetText("Forever Class Timers")
    local description=Font(panel,12);description:SetPoint("TOPLEFT",20,-58);description:SetWidth(520)
    description:SetJustifyH("LEFT")
    description:SetText("Customize buff bars, low-time warnings, and large reminders. Settings save automatically. Open the controls outside combat.")
    local function OpenSection(section)
        if InCombatLockdown() then Say("Leave combat before changing settings.");return end
        OpenOptions()
        optionsWindow:SelectPage(section)
    end
    for i,label in ipairs({"Open settings", "Warning settings", "Reminder settings"}) do
        local section=i
        local button=CreateFrame("Button",nil,panel,"UIPanelButtonTemplate")
        button:SetSize(260,32);button:SetPoint("TOPLEFT",20,-115-(i-1)*44);button:SetText(label)
        button:SetScript("OnClick",function() OpenSection(section) end)
    end
    local hint=Font(panel,11);hint:SetPoint("TOPLEFT",20,-265);hint:SetText(("Chat shortcut: /fct options  |  Version "):gsub("/fct",config.command) .. VERSION)
    local category=Settings.RegisterCanvasLayoutCategory(panel,"Forever Class Timers")
    Settings.RegisterAddOnCategory(category)
end

local function Secret(value)
    return issecretvalue and issecretvalue(value)
end

local function ResolveSpell(value)
    local id = tonumber(value)
    if id and (id <= 0 or id ~= math.floor(id)) then return end
    local info = C_Spell.GetSpellInfo(id or value)
    if info then return info.spellID, info.name end
end

local function PrintSpells()
    local ids = {}
    for id in pairs(db.spells) do ids[#ids+1] = id end
    table.sort(ids)
    Say(db.all and "Mode: all timed matching effects." or "Mode: selected effects.")
    for _, id in ipairs(ids) do
        local info = C_Spell.GetSpellInfo(id)
        Say(id .. " - " .. (info and info.name or "not found in this client"))
    end
end

local function Scan()
    Say(config.enemy and "Your current target debuffs (available names/IDs):" or "Active player buffs (available names/IDs):")
    for i = 1, 255 do
        local aura = config.enemy and C_UnitAuras.GetDebuffDataByIndex("target",i,"PLAYER") or (not config.enemy and C_UnitAuras.GetBuffDataByIndex("player",i))
        if not aura then break end
        if not Secret(aura.name) and not Secret(aura.spellId) and aura.name and aura.spellId then
            Say(aura.spellId .. " - " .. aura.name)
        end
    end
end

local function CopyChat()
    local window=_G[config.prefix .. "CopyChat"]
    if not window then
        window=CreateFrame("Frame","ForeverClassTimersCopyChat",UIParent,"BasicFrameTemplateWithInset")
        window:SetSize(620,420);window:SetPoint("CENTER");window:SetFrameStrata("DIALOG")
        window:SetClampedToScreen(true)
        window.TitleText:SetText("Copy chat - Ctrl+C, then paste into Codex")
        local scroll=CreateFrame("ScrollFrame",nil,window,"UIPanelScrollFrameTemplate")
        scroll:SetPoint("TOPLEFT",16,-40);scroll:SetPoint("BOTTOMRIGHT",-34,45)
        local edit=CreateFrame("EditBox",nil,scroll)
        edit:SetMultiLine(true);edit:SetAutoFocus(false)
        edit:SetFont(FONT,12,"");edit:SetWidth(560);edit:SetHeight(310)
        edit:SetScript("OnEscapePressed",function() window:Hide() end)
        scroll:SetScrollChild(edit);window.edit=edit
        local hint=Font(window,11);hint:SetPoint("BOTTOMLEFT",16,18)
        hint:SetText("Text is selected. Ctrl+C to copy. Escape to close.")
    end
    local lines={}
    local chat=DEFAULT_CHAT_FRAME
    local count=chat:GetNumMessages()
    for i=math.max(1,count-149),count do
        local text=chat:GetMessageInfo(i)
        if type(text)=="string" and not (issecretvalue and issecretvalue(text)) then
            text=text:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r","")
            text=text:gsub("|H.-|h(.-)|h","%1"):gsub("|T.-|t","")
            lines[#lines+1]=text
        end
    end
    window:Show();window.edit:SetText(table.concat(lines,"\n"))
    window.edit:SetFocus();window.edit:HighlightText()
end

local function Help()
    Say(("/fct nativewarning [off] - enable or disable saved icon/text reminders"):gsub("/fct",config.command))
    Say(("/fct racials - discover/list racial buff timers"):gsub("/fct",config.command))
    Say(("/fct copychat - copy the last 150 lines from your General chat tab"):gsub("/fct",config.command))
    Say(("/fct reminderadd <ID or name> | reminderremove <ID or name> | reminderlist"):gsub("/fct",config.command))
    Say(("/fct reminder on|off | reminderspell <ID or name> | reminderscale 1.5"):gsub("/fct",config.command))
    Say(("/fct reminderreset - reset reminder position; /fct reminderposition to position it"):gsub("/fct",config.command))
    Say(("/fct options - colors, time order and low-time pulse settings"):gsub("/fct",config.command))
    Say(("/fct unlock or lock - move / hide the drag handle"):gsub("/fct",config.command))
    Say(("/fct test - toggle animated sample bars; no real buff required"):gsub("/fct",config.command))
    Say(("/fct add <ID/name> restores; remove <ID/name> hides; excluded lists hidden IDs"):gsub("/fct",config.command))
    Say(("/fct all or selected - choose which timed effects appear"):gsub("/fct",config.command))
    Say(("/fct scan - show active effect IDs, outside combat"):gsub("/fct",config.command))
    Say(("/fct width 280 | scale 1 | reset - reset position only"):gsub("/fct",config.command))
    Say(("/fct style flat, rounded or beveled - choose bar appearance"):gsub("/fct",config.command))
    Say(("/fct barcolor 29A31F | textcolor FFFFFF | warningcolor FF5533"):gsub("/fct",config.command))
    Say(("/fct sort shortest or longest | flash 5 or off"):gsub("/fct",config.command))
end

_G["SLASH_" .. config.slashKey .. "1"]=config.command
if not config.enemy then SLASH_FOREVERCLASSTIMERS2="/frt" end
SlashCmdList[config.slashKey] = function(message)
    local command, value = message:match("^%s*(%S*)%s*(.-)%s*$")
    command = command:lower()
    if not ready then Say(failure or "Waiting for login."); return end
    if command == "" or command == "help" then Help(); return end
    if InCombatLockdown() then Say("Leave combat before changing settings or scanning buffs."); return end
    if command == "nativewarning" then
        db.reminder=value:lower()~="off";UpdateReminder()
        if optionsWindow then optionsWindow:Refresh() end
    elseif command == "copychat" then CopyChat()
    elseif command == "options" then OpenOptions()
    elseif command == "reminder" then
        value=value:lower()
        if value~="on" and value~="off" then Say(("Use /fct reminder on or off."):gsub("/fct",config.command));return end
        db.reminder=value=="on";if not db.reminder then positioningReminder=false end;UpdateReminder()
        if optionsWindow then optionsWindow:Refresh() end
    elseif command == "racials" then
        DiscoverRacials();container:SetAuraGroupCandidateFilters("buffs",Filters())
        Say("Racial buff tracking (timed player buffs only):")
        local ids={};for id in pairs(db.racialSeen) do if db.spells[id] then ids[#ids+1]=id end end;table.sort(ids)
        for _,id in ipairs(ids) do local info=C_Spell.GetSpellInfo(id);if info then Say(id .. " - " .. info.name) end end
    elseif command == "reminderdebug" then
        Say("Version " .. VERSION .. "; enabled=" .. tostring(db.reminder) .. "; preview=" .. tostring(testing) .. "; threshold=" .. db.threshold)
        Say("Live reminders: native icon/text binding; full-bar pulse unavailable.")
        Say("Last opacity error: " .. (opacityLastError or "none"))
        local ids={};for id in pairs(ReminderFilters().includeSpellIDs) do ids[#ids+1]=id end;table.sort(ids)
        local text={};for _,id in ipairs(ids) do text[#text+1]=tostring(id) end
        Say("Reminder buff IDs: " .. table.concat(text,", "))
    elseif command == "reminderlist" then
        local ids={};for id in pairs(db.reminderSpells) do ids[#ids+1]=id end;table.sort(ids)
        Say("Reminder selection: " .. #ids .. " spell IDs")
        for _,id in ipairs(ids) do local info=C_Spell.GetSpellInfo(id);Say(id .. " - " .. (info and info.name or "unknown")) end
    elseif command == "reminderremove" then
        local id=tonumber(value)
        if id then db.reminderSpells[id]=nil
        else
            local needle=value:lower()
            for selected in pairs(db.reminderSpells) do
                local info=C_Spell.GetSpellInfo(selected)
                if info and info.name:lower()==needle then db.reminderSpells[selected]=nil end
            end
        end
        UpdateReminder();if optionsWindow then optionsWindow:Refresh() end
    elseif command == "reminderspell" or command == "reminderadd" then
        local id=ResolveSpell(value)
        if not id then Say(("Spell not found. Use its buff ID; /fct scan lists active buffs."):gsub("/fct",config.command));return end
        db.reminderSpell=id;db.reminderSpells[id]=true;UpdateReminder()
        if optionsWindow then optionsWindow:Refresh() end
    elseif command == "reminderscale" then
        local size=Bounded(value,nil,1,3)
        if not size then Say("Reminder scale must be 1-3.");return end
        db.reminderScale=size;UpdateReminder()
        if optionsWindow then optionsWindow:Refresh() end
    elseif command == "reminderposition" then
        positioningReminder=true;db.reminder=true;SetPreview(true);UpdateReminder()
        Say(("Drag LARGE REMINDER, then /fct lock to finish."):gsub("/fct",config.command))
    elseif command == "reminderreset" then
        db.reminderX,db.reminderY=-140,config.enemy and -40 or 100;PlaceReminder()
    elseif command == "barcolor" or command == "textcolor" or command == "warningcolor" then
        local hex = ColorValue(value)
        if not hex then Say("Use six hexadecimal digits, for example FF8800.");return end
        local key = command == "barcolor" and "barColor" or command == "textcolor" and "textColor" or "warningColor"
        db[key]=hex;ApplyAppearance()
        if optionsWindow then optionsWindow:Refresh() end
    elseif command == "style" then
        value=value:lower()
        if not styles[value] then Say(("Use /fct style flat, rounded or beveled."):gsub("/fct",config.command));return end
        db.style=value;ApplyAppearance()
        if optionsWindow then optionsWindow:Refresh() end
    elseif command == "sort" then
        value=value:lower()
        if value ~= "shortest" and value ~= "longest" then Say(("Use /fct sort shortest or /fct sort longest."):gsub("/fct",config.command));return end
        db.sort=value;ApplyAppearance()
        if optionsWindow then optionsWindow:Refresh() end
    elseif command == "flash" then
        if value:lower() == "off" then db.flash=false
        elseif value:lower() == "on" then db.flash=true
        else
            local threshold=Bounded(value,nil,1,30)
            if not threshold then Say(("Use /fct flash 1-30, on, or off."):gsub("/fct",config.command));return end
            db.threshold=threshold;db.flash=true
        end
        ApplyAppearance()
        if optionsWindow then optionsWindow:Refresh() end
    elseif command == "lock" then
        db.locked = true; SetPreview(false); UpdateLock()
    elseif command == "unlock" then
        db.locked = false; UpdateLock()
    elseif command == "test" then
        if not testing then db.locked = false; UpdateLock() end
        SetPreview(not testing)
        Say(testing and ("Preview ON. /fct test or /fct lock returns to live buffs."):gsub("/fct",config.command) or "Preview OFF; showing live buffs.")
    elseif command == "all" or command == "selected" then
        db.all = command == "all"
        container:SetAuraGroupCandidateFilters("buffs", Filters())
        Say(db.all and "Showing all timed matching effects." or "Showing selected effects.")
    elseif command == "list" then PrintSpells()
    elseif command == "scan" then Scan()
    elseif command == "excluded" then
        local ids={};for id in pairs(db.excluded) do ids[#ids+1]=id end;table.sort(ids)
        Say("Hidden effects: " .. #ids)
        for _,id in ipairs(ids) do local info=C_Spell.GetSpellInfo(id);Say(id .. " - " .. (info and info.name or "unknown")) end
    elseif command == "add" or command == "remove" then
        local id,name=ResolveSpell(value)
        local numeric=tonumber(value)
        if numeric and numeric>0 and numeric==math.floor(numeric) then id=numeric end
        if not id then Say("Effect not found. Enter its exact name or aura spell ID; use " .. config.command .. " scan outside combat.");return end
        db.excluded[id]=command=="remove" and true or nil
        db.spells[id]=command=="add" and true or nil
        container:SetAuraGroupCandidateFilters("buffs",Filters())
        UpdateReminder()
        Say((command=="add" and "Restored " or "Hidden ") .. (name or tostring(id)) .. " (" .. id .. ").")
    elseif command == "growth" then
        if value~="up" and value~="down" then Say("Use " .. config.command .. " growth up or down.");return end
        db.growth=value;ApplyGrowth()
        if optionsWindow then optionsWindow:Refresh() end
        Say("List grows " .. value .. " from its anchor.")
    elseif command == "width" or command == "scale" then
        local low, high = command == "width" and 180 or 0.5, command == "width" and 600 or 2
        local number = Bounded(value, nil, low, high)
        if not number then Say("Enter a number from " .. low .. " to " .. high .. "."); return end
        db[command] = number; Resize()
        if optionsWindow then optionsWindow:Refresh() end
    elseif command == "reset" then
        db.x, db.y = 180, config.enemy and -220 or -80; db.locked = false; PlaceAnchor(); UpdateLock()
    else Help() end
end

events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("SPELLS_CHANGED")
events:RegisterEvent("SPELL_TEXT_UPDATE")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:RegisterEvent("PLAYER_REGEN_DISABLED")
events:SetScript("OnEvent", function(self, event)
    if event=="SPELLS_CHANGED" or event=="SPELL_TEXT_UPDATE" or event=="PLAYER_REGEN_ENABLED" then
        if ready and event=="PLAYER_REGEN_ENABLED" and resizeGrip then resizeGrip:SetShown(not db.locked) end
        if ready and not InCombatLockdown() and DiscoverRacials()>0 then
            container:SetAuraGroupCandidateFilters("buffs",Filters())
        end
        return
    end
    if event == "PLAYER_REGEN_DISABLED" then
        if ready then
            if resizeGrip then resizeGrip:Hide() end
            if minimapButton then minimapButton:SetScript("OnUpdate",nil) end
            if optionsWindow then optionsWindow:StopMovingOrSizing();optionsWindow:Hide();if optionsWindow.reminderEditor then optionsWindow.reminderEditor:Hide() end end
            if ColorPickerFrame and ColorPickerFrame:GetExtraInfo() == ADDON then ColorPickerFrame:Hide() end
            anchor:StopMovingOrSizing()
            reminderAnchor:StopMovingOrSizing()
            positioningReminder=false;reminderHandle:Hide();reminderHandle:EnableMouse(false)
            -- Preview never masks real combat buffs.
            if testing then SetPreview(false) end
        end
        return
    end
    if ready then return end
    local interface = select(4, GetBuildInfo())
    if interface < 16000 or interface >= 20000 then
        failure = "This build is for WoW Forever 1.60.x."
        Say(failure); return
    end
    NormalizeSaved()
    DiscoverRacials()
    local ok, err = pcall(CreateUI)
    if not ok then
        failure = "Could not initialize. Send the first Lua error and your client build."
        if anchor then anchor:Hide() end
        if reminderAnchor then reminderAnchor:Hide() end
        Say(failure)
        geterrorhandler()(ADDON .. " " .. VERSION .. ": " .. tostring(err))
        return
    end
    ready = true
    if not config.enemy then
    local minimapOK,minimapError=true,nil -- FBUFF uses its own minimap button
    if not minimapOK then geterrorhandler()(ADDON .. " minimap button: " .. tostring(minimapError)) end
    local registered,registrationError=true,nil -- FBUFF uses its own settings panel
    if not registered then
        Say(("Options menu registration failed; /fct options still works."):gsub("/fct",config.command))
        geterrorhandler()(ADDON .. " settings registration: " .. tostring(registrationError))
    end
    end
    -- FBUFF shell handles user-facing startup UI.
end)

local function RefreshLiveFilters()
   if not container or InCombatLockdown() then return end
   container:SetAuraGroupCandidateFilters("buffs",Filters())
   -- Force the AuraContainer to rebuild immediately. This is important for
   -- effects such as Weak Soul that otherwise can remain as a stale native row.
   container:SetEnabled(false)
   container:SetUnit(config.unit)
   container:SetEnabled(true)
   if config.persistMulti and not config.enemy then container:SetAlpha(0) end
end

return {
 open=OpenOptions,
 setSize=function(width,height)
   if not ready or InCombatLockdown() then return end
   local scale=math.max(0.5,math.min(2,(height or 24)/HEIGHT))
   db.scale=scale
   db.width=math.max(180,math.min(600,(width or 200)/scale))
   Resize()
 end,
 getSize=function() return ready and db.width*db.scale or 200, ready and HEIGHT*db.scale or 24 end,
 position=function(show)
   if not ready or InCombatLockdown() then return end
   db.locked=not show
   SetPreview(show)
   UpdateLock()
 end,
 resetPosition=function()
   if not ready or InCombatLockdown() then return end
   db.x=300;db.y=config.defaultShellY or (config.enemy and -80 or 80);PlaceAnchor()
 end,
 getAnchor=function() return anchor end,
 getDB=function() return db end,
 excluded=function() return db and db.excluded or {} end,
 currentEffects=function()
   local out={}
   if not ready or InCombatLockdown() then return out end
   if config.persistMulti and not config.enemy and config.unit=="target" and UnitExists("target") and UnitIsUnit("target","player") then return out end
   for i=1,255 do
     local ok,aura=pcall(function()
       if config.enemy then return C_UnitAuras.GetDebuffDataByIndex(config.unit or "target",i,"PLAYER") end
       return C_UnitAuras.GetBuffDataByIndex(config.unit or "player",i,"PLAYER")
     end)
     if not ok or not aura then break end
     local id,name=aura.spellId,aura.name
     if id and name and not Secret(id) and not Secret(name) and not db.excluded[id] then
       out[#out+1]={id=id,name=name}
     end
   end
   table.sort(out,function(a,b) return tostring(a.name)<tostring(b.name) end)
   return out
 end,
 restore=function(id)
   if db and db.excluded then db.excluded[id]=nil;RefreshLiveFilters() end
 end,
 hide=function(value)
   if not db or InCombatLockdown() then return false end
   local id,name=ResolveSpell(value or "")
   local numeric=tonumber(value)
   if numeric and numeric>0 and numeric==math.floor(numeric) then id=numeric end
   if not id then return false end
   db.excluded[id]=true
   RefreshLiveFilters()
   UpdateReminder()
   return true,id,name
 end,
}
end
trackers.buffs=CreateTracker({enemy=false,savedKey="FBUFF_BuffDB",prefix="FBUFFBuff",slashKey="FBUFFBUFFCORE",command="/fbuffbuff",unit="player",filter="HELPFUL|PLAYER",label="自己BUFF"})
trackers.friendbuffs=CreateTracker({enemy=false,savedKey="FBUFF_FriendBuffDB",prefix="FBUFFFriendBuff",slashKey="FBUFFFRIENDBUFFCORE",command="/fbufffriend",unit="target",filter="HELPFUL|PLAYER",label="友方BUFF",defaultY=45,defaultShellY=45,persistMulti=true})
trackers.debuffs=CreateTracker({enemy=true,savedKey="FBUFF_DotDB",prefix="FBUFFDot",slashKey="FBUFFDOTCORE",command="/fbuffdot",unit="target",filter="HARMFUL|PLAYER",label="敵方身上DOT",persistMulti=true})


-- ===== FBUFF shell: BY 老哥 =====
local FBUFFPanel, FBUFFPage1, FBUFFPage2
local positioning=false
local function CoreReady() return trackers.buffs and trackers.debuffs end
local function SetBothSize(w,h)
    if not CoreReady() or InCombatLockdown() then return end
    trackers.buffs.setSize(w,h);trackers.friendbuffs.setSize(w,h);trackers.debuffs.setSize(w,h)
end
local function SetPositioning(show)
    positioning=show and true or false
    if not CoreReady() or InCombatLockdown() then return end
    trackers.buffs.position(positioning);trackers.friendbuffs.position(positioning);trackers.debuffs.position(positioning)
end
local function IgnoreNameSet()
    if type(FBUFF_UI_DB)~="table" then FBUFF_UI_DB={} end
    if type(FBUFF_UI_DB.ignoreNames)~="table" then FBUFF_UI_DB.ignoreNames={} end
    return FBUFF_UI_DB.ignoreNames
end
local function IgnoreEverywhere(id,name)
    if not id then return false end
    if name and name~="" then IgnoreNameSet()[name]=true end
    local changed=false
    -- Hide the selected ID in every tracker first.
    for _,tr in pairs(trackers) do if tr.hide(id) then changed=true end end
    -- Some visible auras (notably 虛弱靈魂 / Weakened Soul) can use a rank/variant
    -- spell ID different from the ID returned by a generic name lookup.  While the
    -- unit is inspectable, collect every public aura with the same visible name and
    -- exclude those exact IDs too.  This stays outside combat and never touches a
    -- secret value.
    if name and name~="" and not InCombatLockdown() then
        local function scan(unit,harmful)
            if not UnitExists(unit) then return end
            for i=1,255 do
                local ok,a=pcall(function()
                    if harmful then return C_UnitAuras.GetDebuffDataByIndex(unit,i) end
                    return C_UnitAuras.GetBuffDataByIndex(unit,i)
                end)
                if not ok or not a then break end
                local aid,aname=a.spellId,a.name
                if aid and aname and (not issecretvalue or (not issecretvalue(aid) and not issecretvalue(aname))) and aname==name then
                    for _,tr in pairs(trackers) do if tr.hide(aid) then changed=true end end
                end
            end
        end
        scan("player",false); scan("player",true); scan("target",false); scan("target",true)
    end
    return changed
end
local function RestoreEverywhere(id,name)
    for _,tr in pairs(trackers) do tr.restore(id) end
    if name and type(FBUFF_UI_DB)=="table" and type(FBUFF_UI_DB.ignoreNames)=="table" then FBUFF_UI_DB.ignoreNames[name]=nil end
end



-- FBUFF multi-target supplement. Blizzard AuraContainer can only stay bound to a
-- live unit token (target/player). We cache public timer data for targets we have
-- actually inspected, then keep those rows visible after changing/clearing target.
-- If a timer is secret, we leave it to Blizzard's native AuraContainer instead of
-- touching protected values.
local multi = { friendbuffs={cache={},rows={}}, debuffs={cache={},rows={}} }
local function IsSecretValue(v) return issecretvalue and issecretvalue(v) end
local function MultiIgnored(kind,id,name)
    if name and IgnoreNameSet()[name] then return true end
    local tr=trackers[kind]
    return tr and tr.excluded and tr.excluded()[id] == true
end
local function MultiMakeRow(kind,index)
    local m=multi[kind]; local anchor=trackers[kind].getAnchor(); if not anchor then return end
    -- Enemy DOT rows are FBUFF-owned frames and must never become children of any
    -- AuraContainer/BUFF layout tree.  Parenting them to UIParent keeps DOT layout
    -- completely isolated from the already-working self/friend BUFF anchors.
    local rowParent = (kind=="debuffs") and UIParent or anchor
    local f=CreateFrame("Frame",nil,rowParent); f:SetHeight(24); f:EnableMouse(false)
    if kind=="debuffs" then f:SetFrameStrata("MEDIUM") end
    local background=f:CreateTexture(nil,"BACKGROUND"); background:SetAllPoints(); background:SetColorTexture(0,0,0,.95)
    local icon=f:CreateTexture(nil,"ARTWORK"); icon:SetPoint("TOPLEFT",0,-1); icon:SetSize(23,22); icon:SetTexCoord(.08,.92,.08,.92)
    local bar=CreateFrame("StatusBar",nil,f); bar:SetPoint("TOPLEFT",f,"TOPLEFT",23,-1); bar:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-1,1)
    -- This supplement lives outside CreateTracker(), so its local helpers
    -- (StyleTexture/RGB/FONT) are not in scope here.  Build the same visual
    -- values locally instead of calling nil functions.
    local tdb=trackers[kind].getDB()
    local style=(tdb and tdb.style) or "flat"
    local texture = style == "flat" and "Interface\\Buttons\\WHITE8X8" or ("Interface\\AddOns\\FBUFF\\" .. (style == "rounded" and "Rounded" or "Beveled"))
    local function MultiRGB(hex)
        hex=tostring(hex or "FFFFFF"):gsub("#","")
        local r=tonumber(hex:sub(1,2),16) or 255
        local g=tonumber(hex:sub(3,4),16) or 255
        local b=tonumber(hex:sub(5,6),16) or 255
        return r/255,g/255,b/255
    end
    local multiFont = GameFontNormal:GetFont()
    bar:SetStatusBarTexture(texture)
    if kind=="debuffs" then bar:SetStatusBarColor(MultiRGB("C62828")) elseif tdb and tdb.barColor then bar:SetStatusBarColor(MultiRGB(tdb.barColor)) else bar:SetStatusBarColor(.12,.70,.20,1) end
    local empty=bar:CreateTexture(nil,"BACKGROUND"); empty:SetAllPoints(); empty:SetTexture(texture); empty:SetVertexColor(.07,.08,.07,.9)
    local name=bar:CreateFontString(nil,"OVERLAY"); name:SetFont(multiFont,13,"OUTLINE"); name:SetPoint("LEFT",bar,"LEFT",5,0); name:SetPoint("RIGHT",bar,"RIGHT",-53,0); name:SetJustifyH("LEFT"); name:SetWordWrap(false)
    local tm=bar:CreateFontString(nil,"OVERLAY"); tm:SetFont(multiFont,14,"OUTLINE"); tm:SetPoint("RIGHT",bar,"RIGHT",-4,0); tm:SetWidth(48); tm:SetJustifyH("RIGHT")
    if tdb and tdb.textColor then name:SetTextColor(MultiRGB(tdb.textColor)); tm:SetTextColor(MultiRGB(tdb.textColor)) else name:SetTextColor(1,1,1); tm:SetTextColor(1,1,1) end
    m.rows[index]={frame=f,icon=icon,bar=bar,name=name,time=tm,empty=empty,background=background}; return m.rows[index]
end
local function MultiScan(kind)
    -- Friendly BUFF path is the already-tested FBUFF implementation.
    -- Enemy DOTs deliberately do NOT call C_UnitAuras here: Forever makes
    -- combat aura payloads secret.  DOT cache entries are created from our
    -- own successful casts further below (DoesItDie-style tracking).
    if kind=="debuffs" then return end
    if InCombatLockdown() or not UnitExists("target") then return end
    if UnitIsUnit("target","player") or not UnitIsFriend("player","target") then return end
    local guid=UnitGUID("target"); if not guid or IsSecretValue(guid) then return end
    local m=multi[kind]; local seen={}
    for i=1,255 do
        local ok,a=pcall(function() return C_UnitAuras.GetBuffDataByIndex("target",i,"PLAYER") end)
        if not ok or not a then break end
        local id,name=a.spellId,a.name
        if id and name and not IsSecretValue(id) and not IsSecretValue(name) and not MultiIgnored(kind,id,name) then
            local exp,dur=a.expirationTime,a.duration
            if exp and dur and not IsSecretValue(exp) and not IsSecretValue(dur) and tonumber(exp) and tonumber(dur) and dur>0 then
                local key=guid..":"..tostring(id); seen[key]=true
                m.cache[key]={guid=guid,id=id,name=name,icon=a.icon or C_Spell.GetSpellTexture(id),expiration=exp,duration=dur}
            end
        end
    end
    for key,e in pairs(m.cache) do if e.guid==guid and not seen[key] then m.cache[key]=nil end end
end

local function MultiRender(kind)
    local m=multi[kind]; local tr=trackers[kind]; local anchor=tr.getAnchor(); if not anchor then return end
    local now=GetTime(); local nativeCount=0
    local arr={}
    for key,e in pairs(m.cache) do
        if MultiIgnored(kind,e.id,e.name) or now>=e.expiration then
            m.cache[key]=nil
        else
            arr[#arr+1]=e
        end
    end
    table.sort(arr,function(a,b)
        if a.expiration==b.expiration then return tostring(a.key or a.id)<tostring(b.key or b.id) end
        return a.expiration<b.expiration
    end)
    local db=tr.getDB(); local logicalWidth=db and db.width or 200
    for i,e in ipairs(arr) do
        local r=m.rows[i] or MultiMakeRow(kind,i)
        r.frame:ClearAllPoints(); r.frame:SetPoint("TOPLEFT",anchor,"TOPLEFT",0,-(nativeCount+i-1)*26)
        r.frame:SetWidth(logicalWidth); r.frame:SetHeight(24); r.frame:Show()
        r.icon:SetTexture(e.icon or 134400); r.name:SetText(e.name)
        local rem=math.max(0,e.expiration-now); r.bar:SetMinMaxValues(0,e.duration); r.bar:SetValue(rem); r.time:SetFormattedText("%.1f",rem)
    end
    for i=#arr+1,#m.rows do m.rows[i].frame:Hide() end
end

-- WoW Forever enemy DOT tracking.  Based on the safe strategy used by the
-- Forever-only DoesItDie addon: successful player casts + spell description
-- duration + target GUID.  No combat-log registration and no combat aura reads.
local PAIN_DURATION = { [589]=18,[594]=18,[970]=18,[992]=18,[2767]=18,[10892]=18,[10893]=18,[10894]=18 }
local function SafePlain(v) return v~=nil and not IsSecretValue(v) end
local function DotDurationFromDescription(id,desc,name)
    if PAIN_DURATION[id] then return PAIN_DURATION[id] end
    if type(desc)~="string" or IsSecretValue(desc) then return nil end
    -- English clients.
    local d=desc:match("over%s+(%d+%.?%d*)%s+sec") or desc:match("[Ll]asts%s+(%d+%.?%d*)%s+sec")
    -- Traditional / Simplified Chinese Forever clients.  Periodic damage tooltips
    -- commonly describe either 'within N seconds' or 'lasts N seconds'.
    d=d or desc:match("在%s*(%d+%.?%d*)%s*秒[內内]") or desc:match("持續%s*(%d+%.?%d*)%s*秒") or desc:match("持续%s*(%d+%.?%d*)%s*秒")
    d=tonumber(d)
    if not d or d<=0 or d>300 then return nil end
    -- Whether the spell belongs in the hostile-effect tracker is decided with
    -- C_Spell.IsSpellHarmful() in TrackEnemyDotCast().  Do not infer hostility
    -- from words such as "damage": helpful spells like Power Word: Shield also
    -- mention absorbed damage in their tooltip and were therefore false positives.
    return d
end
local function TrackEnemyDotCast(spellID)
    if not SafePlain(spellID) or type(spellID)~="number" then return end
    -- Forever 1.60.1 exposes this predicate as an allowed spell API.  Only spells
    -- that can be cast on hostile targets belong in 敵方身上DOT.  This keeps
    -- hostile debuffs such as Shadow Word: Pain / Psychic Scream while excluding
    -- helpful spells such as Power Word: Shield, even if an enemy is still targeted
    -- when a self-cast macro succeeds.
    local okHarmful,isHarmful=pcall(C_Spell.IsSpellHarmful,spellID)
    if not okHarmful or not SafePlain(isHarmful) or not isHarmful then return end
    local okExists,exists=pcall(UnitExists,"target"); if not okExists or not exists then return end
    local okAttack,attack=pcall(UnitCanAttack,"player","target"); if not okAttack or not attack or IsSecretValue(attack) then return end
    local okGuid,guid=pcall(UnitGUID,"target"); if not okGuid or not SafePlain(guid) or type(guid)~="string" then return end
    local okName,name=pcall(C_Spell.GetSpellName,spellID); if not okName or not SafePlain(name) or type(name)~="string" then return end
    local okDesc,desc=pcall(C_Spell.GetSpellDescription,spellID); if not okDesc then desc=nil end
    local duration=DotDurationFromDescription(spellID,desc,name); if not duration then return end
    -- Remember every confirmed DOT spell outside the live aura system.  Forever
    -- blocks opening/updating the settings UI in combat, so this persistent list
    -- lets the player ignore the DOT after combat has ended.
    if type(FBUFF_UI_DB)~="table" then FBUFF_UI_DB={} end
    if type(FBUFF_UI_DB.seenDots)~="table" then FBUFF_UI_DB.seenDots={} end
    FBUFF_UI_DB.seenDots[spellID]={name=name,icon=C_Spell.GetSpellTexture(spellID)}
    if MultiIgnored("debuffs",spellID,name) then return end
    local now=GetTime(); local key=guid..":"..tostring(spellID)
    multi.debuffs.cache[key]={key=key,guid=guid,id=spellID,name=name,icon=C_Spell.GetSpellTexture(spellID),expiration=now+duration,duration=duration}
end

-- Keep the name-based ignore list synchronized with the *actual* aura spell ID.
-- This matters for effects such as Weak Soul, where the visible aura can use an
-- ID/rank variant different from the ID returned by a generic spell-name lookup.
local function SyncIgnoredAuraIDs()
    if InCombatLockdown() then return end
    local ignored=IgnoreNameSet()
    local function scan(unit,harmful)
        if not UnitExists(unit) then return end
        for i=1,255 do
            local ok,a=pcall(function()
                if harmful then return C_UnitAuras.GetDebuffDataByIndex(unit,i) end
                return C_UnitAuras.GetBuffDataByIndex(unit,i)
            end)
            if not ok or not a then break end
            local id,name=a.spellId,a.name
            if id and name and not IsSecretValue(id) and not IsSecretValue(name) and ignored[name] then
                for _,tr in pairs(trackers) do
                    if not tr.excluded()[id] then tr.hide(id) end
                end
                for _,m in pairs(multi) do
                    for key,e in pairs(m.cache) do
                        if e.id==id or e.name==name then m.cache[key]=nil end
                    end
                end
            end
        end
    end
    scan("player",false)
    scan("player",true)
    scan("target",false)
    scan("target",true)
end

local multiFrame=CreateFrame("Frame")
multiFrame:RegisterEvent("PLAYER_TARGET_CHANGED"); multiFrame:RegisterEvent("UNIT_AURA"); multiFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
multiFrame:RegisterUnitEvent("UNIT_SPELLCAST_SUCCEEDED","player")
multiFrame:SetScript("OnEvent",function(_,event,unit,castGUID,spellID)
    if event=="UNIT_SPELLCAST_SUCCEEDED" then
        TrackEnemyDotCast(spellID)
        return
    end
    if event=="UNIT_AURA" and unit~="target" then return end
    SyncIgnoredAuraIDs()
    MultiScan("friendbuffs")
end)
multiFrame:SetScript("OnUpdate",function(self,elapsed) self.t=(self.t or 0)+elapsed; if self.t<0.08 then return end; self.t=0; MultiRender("friendbuffs"); MultiRender("debuffs") end)

local function MakeFBUFFPanel()
 if FBUFFPanel then return FBUFFPanel end
 local p=CreateFrame("Frame","FBUFF_Settings",UIParent,"BackdropTemplate");FBUFFPanel=p
 p:SetSize(590,455);p:SetFrameStrata("DIALOG");p:SetMovable(true);p:SetClampedToScreen(true);p:SetPoint("CENTER")
 p:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background-Dark",edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",tile=true,tileSize=32,edgeSize=32,insets={left=8,right=8,top=8,bottom=8}})
 p:SetBackdropColor(.02,.025,.03,.99);p:EnableMouse(true);p:RegisterForDrag("LeftButton");p:Hide()
 p:SetScript("OnDragStart",function(self) if not InCombatLockdown() then self:StartMoving() end end);p:SetScript("OnDragStop",p.StopMovingOrSizing)
 local logo=p:CreateTexture(nil,"ARTWORK");logo:SetSize(62,62);logo:SetPoint("TOPLEFT",20,-22);logo:SetTexture("Interface\\AddOns\\FBUFF\\FBUFF_B.tga")
 local ttl=p:CreateFontString(nil,"OVERLAY","GameFontNormalHuge");ttl:SetPoint("LEFT",p,"TOPLEFT",103,-40);ttl:SetScale(1.18);ttl:SetText("|cffffd200FBUFF｜自我BUFF監控 - BY老哥|r")
 local line=p:CreateTexture(nil,"ARTWORK");line:SetColorTexture(1,.82,0,.9);line:SetPoint("TOPLEFT",100,-76);line:SetPoint("TOPRIGHT",-20,-76);line:SetHeight(1)
 local xb=CreateFrame("Button",nil,p,"UIPanelCloseButton");xb:SetPoint("TOPRIGHT",-8,-8);xb:SetScript("OnClick",function() SetPositioning(false);p:Hide() end)
 local pages={};for i=1,2 do pages[i]=CreateFrame("Frame",nil,p);pages[i]:SetPoint("TOPLEFT",185,-100);pages[i]:SetPoint("BOTTOMRIGHT",-25,48) end;FBUFFPage1,FBUFFPage2=pages[1],pages[2]
 local tabs={}
 local function Select(n)
   for i=1,2 do pages[i]:SetShown(i==n);if tabs[i] then tabs[i]:SetEnabled(i~=n) end end
   SetPositioning(n==1 and p:IsShown())
   if n==2 and p.RefreshIgnore then p:RefreshIgnore() end
 end
 local function Side(text,y,n) local b=CreateFrame("Button",nil,p,"UIPanelButtonTemplate");b:SetSize(135,34);b:SetPoint("TOPLEFT",28,y);b:SetText(text);b:SetScript("OnClick",function() Select(n) end);tabs[n]=b end
 Side("監視條設定",-118,1);Side("忽略效果名單",-162,2)
 local function Heading(parent,text,y) local t=parent:CreateFontString(nil,"OVERLAY","GameFontNormalLarge");t:SetPoint("TOPLEFT",14,y);t:SetText("|cffffd200"..text.."|r") end
 Heading(pages[1],"監視條尺寸",-18)
 local values={width=200,height=25};local refs={}
 local function Slider(label,y,minv,maxv,step,key)
   local l=pages[1]:CreateFontString(nil,"OVERLAY","GameFontHighlight");l:SetPoint("TOPLEFT",18,y);l:SetText(label.."：")
   local val=pages[1]:CreateFontString(nil,"OVERLAY","GameFontNormal");val:SetPoint("LEFT",l,"RIGHT",12,0);val:SetText(values[key])
   local range=pages[1]:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");range:SetPoint("LEFT",val,"RIGHT",12,0);range:SetText("("..minv.." – "..maxv..")")
   local sl=CreateFrame("Slider",nil,pages[1],"UISliderTemplate");sl:SetOrientation("HORIZONTAL");sl:SetPoint("TOPLEFT",70,y-26);sl:SetSize(230,17);sl:SetMinMaxValues(minv,maxv);sl:SetValueStep(step);if sl.SetObeyStepOnDrag then sl:SetObeyStepOnDrag(true) end
   local left=CreateFrame("Button",nil,pages[1],"UIPanelScrollUpButtonTemplate");left:SetSize(22,22);left:SetPoint("RIGHT",sl,"LEFT",-7,0)
   local right=CreateFrame("Button",nil,pages[1],"UIPanelScrollDownButtonTemplate");right:SetSize(22,22);right:SetPoint("LEFT",sl,"RIGHT",7,0)
   for _,b in ipairs({left,right}) do for _,m in ipairs({"GetNormalTexture","GetPushedTexture","GetDisabledTexture"}) do local tx=b[m] and b[m](b);if tx then tx:SetRotation(math.pi/2) end end end
   local function set(v) v=math.max(minv,math.min(maxv,math.floor(v/step+.5)*step));sl:SetValue(v) end
   left:SetScript("OnClick",function() set(values[key]-step) end);right:SetScript("OnClick",function() set(values[key]+step) end)
   sl:SetScript("OnValueChanged",function(_,v) v=math.floor(v/step+.5)*step;values[key]=v;val:SetText(v);SetBothSize(values.width,values.height) end)
   sl:SetValue(values[key]);refs[key]={slider=sl,value=val}
 end
 Slider("長度",-58,150,250,5,"width");Slider("高度",-123,20,40,1,"height")
 local tip=pages[1]:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");tip:SetPoint("TOPLEFT",18,-178);tip:SetWidth(330);tip:SetJustifyH("LEFT");tip:SetText("開啟此頁時，自己BUFF、友方BUFF、敵方身上DOT 三個定位框會同時顯示。\n三個表頭都可左鍵拖曳；位置就是各自實際監視條位置。")
 Heading(pages[2],"忽略效果名單",-18)
 local currentTitle=pages[2]:CreateFontString(nil,"OVERLAY","GameFontNormal");currentTitle:SetPoint("TOPLEFT",18,-42);currentTitle:SetText("|cffffd200目前效果|r")
 local currentScroll=CreateFrame("ScrollFrame","FBUFF_CurrentEffectsScroll",pages[2],"UIPanelScrollFrameTemplate");currentScroll:SetPoint("TOPLEFT",14,-61);currentScroll:SetPoint("TOPRIGHT",-28,-61);currentScroll:SetHeight(103)
 local currentChild=CreateFrame("Frame",nil,currentScroll);currentChild:SetSize(305,103);currentScroll:SetScrollChild(currentChild);local currentRows={}
 local divider=pages[2]:CreateTexture(nil,"ARTWORK");divider:SetColorTexture(.48,.48,.48,.8);divider:SetPoint("TOPLEFT",14,-174);divider:SetPoint("TOPRIGHT",-8,-174);divider:SetHeight(1)
 local ignoredTitle=pages[2]:CreateFontString(nil,"OVERLAY","GameFontNormal");ignoredTitle:SetPoint("TOPLEFT",18,-187);ignoredTitle:SetText("|cffffd200已忽略效果|r")
 local scroll=CreateFrame("ScrollFrame","FBUFF_IgnoreScroll",pages[2],"UIPanelScrollFrameTemplate");scroll:SetPoint("TOPLEFT",14,-208);scroll:SetPoint("BOTTOMRIGHT",-28,8)
 local child=CreateFrame("Frame",nil,scroll);child:SetSize(305,120);scroll:SetScrollChild(child);local rows={}
 local function ClearRows(t) for _,r in ipairs(t) do r:Hide() end;wipe(t) end
 local function EffectRow(parent,y,item,buttonText,callback)
   local row=CreateFrame("Frame",nil,parent);row:SetSize(296,30);row:SetPoint("TOPLEFT",4,y)
   local tx=row:CreateFontString(nil,"OVERLAY","GameFontHighlight");tx:SetPoint("LEFT",4,0);tx:SetWidth(188);tx:SetJustifyH("LEFT");tx:SetText(item.name..(item.kind=="debuffs" and " |cffff5555[DOT]|r" or " |cff55ff55[BUFF]|r"))
   local b=CreateFrame("Button",nil,row,"UIPanelButtonTemplate");b:SetSize(88,23);b:SetPoint("RIGHT",-4,0);b:SetText(buttonText);b:SetScript("OnClick",callback)
   return row
 end
 function p:RefreshIgnore()
   ClearRows(currentRows);ClearRows(rows)
   if InCombatLockdown() then
     local t=currentChild:CreateFontString(nil,"OVERLAY","GameFontDisable");t:SetPoint("TOPLEFT",12,-8);t:SetText("戰鬥中暫停更新效果清單");table.insert(currentRows,t)
   else
     local active,activeSeen={},{ }
     for _,kind in ipairs({"buffs","friendbuffs","debuffs"}) do
       for _,e in ipairs(trackers[kind].currentEffects()) do
         if IgnoreNameSet()[e.name] then
           IgnoreEverywhere(e.id,e.name)
         else
           local key=kind..":"..tostring(e.id)
           if not activeSeen[key] then activeSeen[key]=true;e.kind=kind;active[#active+1]=e end
         end
       end
     end
     -- DOTs learned from successful casts remain available here after combat, even
     -- though the actual target aura has expired and cannot safely be scanned.
     if type(FBUFF_UI_DB)=="table" and type(FBUFF_UI_DB.seenDots)=="table" then
       -- v0.78 migration: older event tracking could remember helpful spells
       -- (for example Power Word: Shield) as DOTs.  Re-check Blizzard's spell
       -- classification before exposing a remembered hostile effect.  Invalid
       -- historical entries are deleted so they do not return after /reload.
       local stale={}
       for id,info in pairs(FBUFF_UI_DB.seenDots) do
         local spellID=tonumber(id) or id
         local okH,harmful=pcall(C_Spell.IsSpellHarmful,spellID)
         if not okH or not SafePlain(harmful) or not harmful then
           stale[#stale+1]=id
         else
           local name=(type(info)=="table" and info.name) or C_Spell.GetSpellName(spellID) or tostring(spellID)
           if not IgnoreNameSet()[name] and not trackers.debuffs.excluded()[spellID] then
             local key="debuffs:"..tostring(spellID)
             if not activeSeen[key] then activeSeen[key]=true;active[#active+1]={kind="debuffs",id=spellID,name=name} end
           end
         end
       end
       for _,id in ipairs(stale) do FBUFF_UI_DB.seenDots[id]=nil end
     end
     table.sort(active,function(a,b)return tostring(a.name)<tostring(b.name) end)
     currentChild:SetHeight(math.max(92,#active*32+8))
     if #active==0 then
       local t=currentChild:CreateFontString(nil,"OVERLAY","GameFontDisable");t:SetPoint("TOPLEFT",12,-8);t:SetText("目前沒有可加入忽略的 BUFF／DOT");table.insert(currentRows,t)
     else
       for i,item in ipairs(active) do
         local captured=item
         local row=EffectRow(currentChild,-4-(i-1)*32,item,"忽略",function()
           local changed=IgnoreEverywhere(captured.id,captured.name)
           SyncIgnoredAuraIDs()
           if changed then p:RefreshIgnore() end
         end)
         table.insert(currentRows,row)
       end
     end
   end
   local arr,seen={},{ }
   -- One shared ignore policy: if an effect is ignored anywhere, hide it from every tracker.
   if not InCombatLockdown() then
     local union={}
     for _,tr in pairs(trackers) do for id in pairs(tr.excluded()) do union[id]=true end end
     for id in pairs(union) do for _,tr in pairs(trackers) do if not tr.excluded()[id] then tr.hide(id) end end end
   end
   for _,tr in pairs(trackers) do
     for id in pairs(tr.excluded()) do
       if not seen[id] then seen[id]=true;arr[#arr+1]={kind="buffs",id=id,name=C_Spell.GetSpellName(id) or tostring(id)} end
     end
   end
   table.sort(arr,function(a,b)return tostring(a.name)<tostring(b.name) end);child:SetHeight(math.max(120,#arr*32+8))
   if #arr==0 then
     local t=child:CreateFontString(nil,"OVERLAY","GameFontDisable");t:SetPoint("TOPLEFT",12,-8);t:SetText("目前沒有忽略的效果");table.insert(rows,t)
   else
     for i,item in ipairs(arr) do
       local captured=item
       local row=EffectRow(child,-4-(i-1)*32,item,"取消忽略",function()
         RestoreEverywhere(captured.id,captured.name)
         p:RefreshIgnore()
       end)
       table.insert(rows,row)
     end
   end
 end
 local auraRefresh=CreateFrame("Frame",nil,pages[2]);auraRefresh:RegisterEvent("UNIT_AURA");auraRefresh:RegisterEvent("PLAYER_TARGET_CHANGED");auraRefresh:RegisterEvent("PLAYER_REGEN_ENABLED");auraRefresh:SetScript("OnEvent",function(_,event,unit)
   if not p:IsShown() or not pages[2]:IsShown() then return end
   if event=="UNIT_AURA" and unit~="player" and unit~="target" then return end
   p:RefreshIgnore()
 end)
 local reset=CreateFrame("Button",nil,p,"UIPanelButtonTemplate");reset:SetSize(135,34);reset:SetPoint("BOTTOMLEFT",28,18);reset:SetText("恢復預設");reset:SetScript("OnClick",function() if InCombatLockdown() then return end;values.width=200;values.height=25;refs.width.slider:SetValue(200);refs.height.slider:SetValue(25);SetBothSize(200,25);trackers.buffs.resetPosition();trackers.friendbuffs.resetPosition();trackers.debuffs.resetPosition();SetPositioning(true) end)
 p:SetScript("OnShow",function() Select(1);local w,h=trackers.buffs.getSize();values.width=math.floor(w+.5);values.height=math.floor(h+.5);refs.width.slider:SetValue(math.max(150,math.min(250,values.width)));refs.height.slider:SetValue(math.max(20,math.min(40,values.height))) end)
 p:SetScript("OnHide",function() SetPositioning(false) end);table.insert(UISpecialFrames,"FBUFF_Settings");Select(1);return p
end
local function OpenFBUFF() if InCombatLockdown() then print("|cffffd24aFBUFF:|r 戰鬥中無法調整設定。") return end;MakeFBUFFPanel():Show() end
SLASH_FBUFF1="/fbuff";SlashCmdList.FBUFF=OpenFBUFF
local function InitFBUFFUI()
 if type(FBUFF_UI_DB)~="table" then FBUFF_UI_DB={} end
 if FBUFF_UI_DB.friendBuffLayoutVersion ~= 61 then
   if type(FBUFF_FriendBuffDB)=="table" then FBUFF_FriendBuffDB.y=40; FBUFF_FriendBuffDB.x=(type(FBUFF_BuffDB)=="table" and FBUFF_BuffDB.x) or FBUFF_FriendBuffDB.x end
   FBUFF_UI_DB.friendBuffLayoutVersion=61
 end
 if type(FBUFF_UI_DB.minimap)~="table" then FBUFF_UI_DB.minimap={hide=false,minimapPos=165,radius=80} end
 if type(FBUFF_UI_DB.minimapAngle)~="number" then FBUFF_UI_DB.minimapAngle=165 end
end
local mini
local function SetupStandardMinimap()
 local LibStub=_G.LibStub;if not LibStub then return false end
 local LDB=LibStub("LibDataBroker-1.1",true);local DBIcon=LibStub("LibDBIcon-1.0",true)
 if not LDB or not DBIcon then return false end
 local obj=LDB:NewDataObject("FBUFF",{type="launcher",text="FBUFF",icon="Interface\\AddOns\\FBUFF\\FBUFF_B.tga",
  OnClick=function(_,button) if button=="LeftButton" then OpenFBUFF() end end,
  OnTooltipShow=function(tt)tt:AddLine("FBUFF - BY 老哥");tt:AddLine("左鍵：開啟設定",1,1,1)end})
 if not DBIcon:IsRegistered("FBUFF") then DBIcon:Register("FBUFF",obj,FBUFF_UI_DB.minimap) end
 return true
end
local function SetupFallbackMinimap()
 mini=CreateFrame("Button","FBUFFMinimapButton",Minimap);mini:SetSize(38,38);mini:SetFrameStrata("MEDIUM");mini:SetFrameLevel((Minimap:GetFrameLevel()or 0)+8)
 mini:RegisterForClicks("LeftButtonUp");mini:RegisterForDrag("LeftButton")
 local ic=mini:CreateTexture(nil,"ARTWORK");ic:SetAllPoints();ic:SetTexture("Interface\\AddOns\\FBUFF\\FBUFF_B.tga")
 local function Pos() local r=math.max(Minimap:GetWidth()or 140,Minimap:GetHeight()or 140)/2+18;local a=math.rad(FBUFF_UI_DB.minimapAngle or 165);mini:ClearAllPoints();mini:SetPoint("CENTER",Minimap,"CENTER",math.cos(a)*r,math.sin(a)*r) end
 local dragging=false
 mini:SetScript("OnDragStart",function(self) dragging=true;self:SetScript("OnUpdate",function() local mx,my=Minimap:GetCenter();if not mx then return end;local x,y=GetCursorPosition();local sc=UIParent:GetEffectiveScale();x,y=x/sc,y/sc;FBUFF_UI_DB.minimapAngle=math.deg(math.atan2(y-my,x-mx));Pos() end) end)
 mini:SetScript("OnDragStop",function(self)self:SetScript("OnUpdate",nil);Pos();C_Timer.After(.1,function()dragging=false end)end)
 mini:SetScript("OnClick",function()if not dragging then OpenFBUFF() end end)
 mini:SetScript("OnEnter",function(self)GameTooltip:SetOwner(self,"ANCHOR_LEFT");GameTooltip:SetText("FBUFF - BY 老哥");GameTooltip:AddLine("左鍵：開啟設定",1,1,1);GameTooltip:Show()end);mini:SetScript("OnLeave",function()GameTooltip:Hide()end);Pos()
end
local shellEvents=CreateFrame("Frame");shellEvents:RegisterEvent("PLAYER_LOGIN");shellEvents:SetScript("OnEvent",function() InitFBUFFUI();if not SetupStandardMinimap() then SetupFallbackMinimap() end;print("|cff00ff00FBUFF｜自我BUFF監控 - BY老哥：已載入|r") end)
