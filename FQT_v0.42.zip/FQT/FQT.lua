local ADDON="FQT"
local defaults={progressSound=true,completeSound=true,sendSelf=true,sendSay=true,sendParty=true,monsterDistance="normal",monsterArc="90",monsterBubble=true,monsterSense=true,monsterTargetBubble=true,alertWidth=220,alertBgMode=2,alertPoint="TOP",alertRelPoint="TOP",alertX=0,alertY=-245,minimap={hide=false,minimapPos=165},minimapAngle=165,panelX=-400,panelY=0}
local function InitDB()
 FQTDB=FQTDB or {}
if not FQTDB.FQTDefaultsMigrated020 then
 FQTDB.monsterDistance="normal"
 FQTDB.monsterArc="90"
 FQTDB.monsterBubble=true
 FQTDB.monsterSense=true
 FQTDB.FQTDefaultsMigrated020=true
end
if not FQTDB.FQTDefaultsMigrated027 then
 FQTDB.monsterTargetBubble=true
 FQTDB.FQTDefaultsMigrated027=true
end
if not FQTDB.FQTDefaultsMigrated030 then
 FQTDB.FQTDefaultsMigrated030=true
end
if not FQTDB.FQTDefaultsMigrated032 then
 FQTDB.FQTDefaultsMigrated032=true
end
if not FQTDB.FQTDefaultsMigrated033 then
 FQTDB.monsterTargetBubble=true
 FQTDB.FQTDefaultsMigrated033=true
end
 for k,v in pairs(defaults) do
  if FQTDB[k]==nil then
   if type(v)=="table" then FQTDB[k]={};for a,b in pairs(v)do FQTDB[k][a]=b end else FQTDB[k]=v end
  end
 end
 FQTDB.minimap=FQTDB.minimap or {hide=false,minimapPos=FQTDB.minimapAngle or 165}
end

-- 設定 UI 建立前先初始化 SavedVariables，避免 FQTDB 為 nil
InitDB()

local function ProgressSound(force)
 if not force and not FQTDB.progressSound then return end
 -- Stable built-in UI sound; fallback kept for Forever builds with a smaller SOUNDKIT table.
 PlaySound(618,"Master")
end
local function CompleteSound(force)
 if not force and not FQTDB.completeSound then return end
 PlaySound(619,"Master")
end

local snapshot={}
local function ReadObjectives(questID,logIndex)
 local out={}
 if not questID then return out end
 if C_QuestLog and C_QuestLog.GetQuestObjectives then
  local ok,objs=pcall(C_QuestLog.GetQuestObjectives,questID)
  if ok and type(objs)=="table" and #objs>0 then
   for i,o in ipairs(objs) do
    out[i]={num=tonumber(o.numFulfilled) or 0,need=tonumber(o.numRequired) or 0,finished=o.finished and true or false,text=o.text or ""}
   end
   return out
  end
 end
 if logIndex and GetNumQuestLeaderBoards and GetQuestLogLeaderBoard then
  local n=GetNumQuestLeaderBoards(logIndex) or 0
  for i=1,n do
   local text,objectiveType,finished,numFulfilled,numRequired=GetQuestLogLeaderBoard(i,logIndex)
   out[i]={num=tonumber(numFulfilled) or 0,need=tonumber(numRequired) or 0,finished=finished and true or false,text=text or ""}
  end
 end
 return out
end
local function BuildSnapshot()
 local s={}
 local n=(C_QuestLog and C_QuestLog.GetNumQuestLogEntries and C_QuestLog.GetNumQuestLogEntries()) or (GetNumQuestLogEntries and GetNumQuestLogEntries()) or 0
 for i=1,n do
  local info=C_QuestLog and C_QuestLog.GetInfo and C_QuestLog.GetInfo(i)
  if info and info.questID and not info.isHeader then
   local qid=info.questID
   local complete=(C_QuestLog.IsComplete and C_QuestLog.IsComplete(qid)) and true or false
   s[qid]={complete=complete,objectives=ReadObjectives(qid,i)}
  end
 end
 return s
end
local function QuestTitle(qid)
 if C_QuestLog and C_QuestLog.GetTitleForQuestID then
  local ok,t=pcall(C_QuestLog.GetTitleForQuestID,qid);if ok and t and t~="" then return t end
 end
 return qid and ("任務 #"..qid) or "任務"
end
local primed=false
local updateSerial=0
local function PartyChannel()
 if not IsInGroup or not IsInGroup() then return nil end
 if IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then return "INSTANCE_CHAT" end
 return "PARTY"
end
local function SendSelfLine(line)
 local msg="|cffffd200老哥UI｜|r"..line
 -- Write directly to the primary player chat frame.  This is local-only; it is not /say.
 local frame=_G.ChatFrame1 or _G.DEFAULT_CHAT_FRAME or _G.SELECTED_CHAT_FRAME
 if frame and frame.AddMessage then
  frame:AddMessage(msg,1,0.82,0)
 else
  print(msg)
 end
end
-- v0.40：附近(SAY)採 MessageQueue 類硬體事件佇列。
-- 任務事件只排隊；下一次真實滑鼠/鍵盤/滑輪/手把操作時才送出。
local FQT_SayQueue={}
local FQT_SayQueueFrame=CreateFrame("Frame","FQTSayQueueFrame",UIParent)
FQT_SayQueueFrame:SetPoint("TOPLEFT")
FQT_SayQueueFrame:SetPoint("BOTTOMRIGHT")
FQT_SayQueueFrame:SetFrameStrata("TOOLTIP")
FQT_SayQueueFrame:SetFrameLevel((UIParent:GetFrameLevel() or 0)+1000)
FQT_SayQueueFrame:EnableMouse(true)
FQT_SayQueueFrame:EnableMouseWheel(true)
if FQT_SayQueueFrame.SetMouseMotionEnabled then FQT_SayQueueFrame:SetMouseMotionEnabled(true) end
if FQT_SayQueueFrame.EnableGamePadButton then FQT_SayQueueFrame:EnableGamePadButton(true) end
if FQT_SayQueueFrame.EnableGamePadStick then FQT_SayQueueFrame:EnableGamePadStick(true) end
FQT_SayQueueFrame:EnableKeyboard(true)
if FQT_SayQueueFrame.SetPropagateKeyboardInput then FQT_SayQueueFrame:SetPropagateKeyboardInput(true) end
FQT_SayQueueFrame:Hide()

local function FQT_RawSendChat(msg,channel)
 if C_ChatInfo and C_ChatInfo.SendChatMessage then
  C_ChatInfo.SendChatMessage(msg,channel)
 else
  SendChatMessage(msg,channel)
 end
end

local function FQT_UpdateSayQueueFrame()
 if #FQT_SayQueue>0 then FQT_SayQueueFrame:Show() else FQT_SayQueueFrame:Hide() end
end

local function FQT_RunSayQueue()
 if #FQT_SayQueue==0 then FQT_UpdateSayQueueFrame(); return end
 -- 與 MessageQueue 相同概念：hardware event 到來時送出目前排隊訊息。
 while #FQT_SayQueue>0 do
  local msg=table.remove(FQT_SayQueue,1)
  FQT_RawSendChat(msg,"SAY")
 end
 FQT_UpdateSayQueueFrame()
end

FQT_SayQueueFrame:SetScript("OnMouseDown",FQT_RunSayQueue)
FQT_SayQueueFrame:SetScript("OnMouseUp",FQT_RunSayQueue)
FQT_SayQueueFrame:SetScript("OnMouseWheel",FQT_RunSayQueue)
FQT_SayQueueFrame:SetScript("OnKeyDown",FQT_RunSayQueue)
FQT_SayQueueFrame:SetScript("OnKeyUp",FQT_RunSayQueue)
if FQT_SayQueueFrame.SetScript then
 pcall(FQT_SayQueueFrame.SetScript,FQT_SayQueueFrame,"OnGamePadButtonDown",FQT_RunSayQueue)
 pcall(FQT_SayQueueFrame.SetScript,FQT_SayQueueFrame,"OnGamePadButtonUp",FQT_RunSayQueue)
 pcall(FQT_SayQueueFrame.SetScript,FQT_SayQueueFrame,"OnGamePadStick",FQT_RunSayQueue)
end

local function FQT_QueueSay(msg)
 table.insert(FQT_SayQueue,msg)
 FQT_UpdateSayQueueFrame()
end

local function FQT_SendChat(msg,channel)
 if channel=="SAY" then
  FQT_QueueSay(msg)
 else
  FQT_RawSendChat(msg,channel)
 end
end

local function SendProgressLine(line)
 if FQTDB.sendSelf then SendSelfLine(line) end
 if FQTDB.sendSay then FQT_SendChat("老哥UI｜"..line,"SAY") end
 if FQTDB.sendParty then
  local ch=PartyChannel()
  if ch then FQT_SendChat("老哥UI｜"..line,ch) end
 end
end
local function CheckQuestChanges(serial)
 if serial and serial~=updateSerial then return end
 local now=BuildSnapshot()
 if not primed then snapshot=now;primed=true;return end
 local anyProgress=false
 local anyComplete=false
 for qid,q in pairs(now) do
  local old=snapshot[qid]
  if old then
   local questJustCompleted=q.complete and not old.complete
   local completionLine=nil
   for i,o in ipairs(q.objectives) do
    local prev=old.objectives and old.objectives[i]
    if prev and o.num>prev.num then
     anyProgress=true
     local suffix=tostring(o.num).."/"..tostring(o.need)
     local line="[任務] "..QuestTitle(qid).."："..suffix
     if questJustCompleted then
      completionLine=line.."【完成】"
     else
      SendProgressLine(line)
     end
    end
   end
   if questJustCompleted then
    anyComplete=true
    SendProgressLine(completionLine or ("[任務] "..QuestTitle(qid).."：【完成】"))
   end
  end
 end
 snapshot=now
 if anyComplete then CompleteSound(false) elseif anyProgress then ProgressSound(false) end
end
local function QueueCheck()
 updateSerial=updateSerial+1
 local serial=updateSerial
 if C_Timer and C_Timer.After then C_Timer.After(.35,function()CheckQuestChanges(serial)end) else CheckQuestChanges(serial) end
end
local function AnnounceAccepted(qid)
 local line="[任務] 接取："..QuestTitle(qid)
 SendProgressLine(line)
end

-- 提醒視窗共用控制（後面建立實體）
local FQTMonsterAlert, FQT_ApplyAlertSize, FQT_ApplyAlertLook, FQT_RestoreAlertPosition, FQT_ApplySenseCVars, FQT_ShowAlertPreview, FQT_HideAlertPreview

-- ===== 老哥UI 標準母版設定視窗：母版外觀固定，只換 FQT 功能內容 =====
local function FQT_Load(name)
 if C_AddOns and C_AddOns.LoadAddOn then pcall(C_AddOns.LoadAddOn,name)
 elseif LoadAddOn then pcall(LoadAddOn,name) end
end
FQT_Load("Blizzard_GroupFinder")
FQT_Load("Blizzard_LFGVanilla")

local cfg=CreateFrame("Frame","FQTSettingsFrame",UIParent,"PortraitFrameTemplate")
cfg:SetSize(530,540)
cfg:SetPoint("CENTER",UIParent,"CENTER",FQTDB.panelX or -400,FQTDB.panelY or 0)
cfg:SetFrameStrata("DIALOG");cfg:SetClampedToScreen(true);cfg:SetMovable(true);cfg:EnableMouse(true);cfg:RegisterForDrag("LeftButton")
cfg:SetScript("OnDragStart",cfg.StartMoving)
cfg:SetScript("OnDragStop",function(self)
 self:StopMovingOrSizing();local x,y=self:GetCenter();local ux,uy=UIParent:GetCenter()
 if x and y and ux and uy then FQTDB.panelX=x-ux;FQTDB.panelY=y-uy end
end)

local portrait=(cfg.PortraitContainer and cfg.PortraitContainer.portrait) or cfg.portrait or cfg.Portrait
if portrait then portrait:SetTexture(3586269) end
local builtInTitle=(cfg.TitleContainer and cfg.TitleContainer.TitleText) or cfg.TitleText
if builtInTitle then builtInTitle:SetText("") end
if cfg.Inset then cfg.Inset:Hide() end
if cfg.Bg and cfg.Bg.Hide then cfg.Bg:Hide() end
local function FQT_Atlas(tex,name) if not tex or not tex.SetAtlas then return false end return pcall(tex.SetAtlas,tex,name,false) end

local top=CreateFrame("Frame",nil,cfg);top:SetPoint("TOPLEFT",cfg,"TOPLEFT",2,-23);top:SetPoint("TOPRIGHT",cfg,"TOPRIGHT",-2,-23);top:SetHeight(76)
local topBG=top:CreateTexture(nil,"BACKGROUND");topBG:SetAllPoints(top);if not FQT_Atlas(topBG,"groupfinder-roles-background") then topBG:SetTexture(8373327) end
local streak=top:CreateTexture(nil,"BORDER");streak:SetPoint("TOPLEFT",top,"TOPLEFT",0,0);streak:SetPoint("TOPRIGHT",top,"TOPRIGHT",0,0);streak:SetHeight(43);if not FQT_Atlas(streak,"UI-Frame-TopTileStreaks") then streak:SetTexture(1723833) end

local body=CreateFrame("Frame",nil,cfg,"InsetFrameTemplate");body:SetPoint("TOPLEFT",cfg,"TOPLEFT",3,-100);body:SetPoint("BOTTOMRIGHT",cfg,"BOTTOMRIGHT",-3,3)
if body.Bg and body.Bg.SetAlpha then body.Bg:SetAlpha(.90) end;if body.TopEdge then body.TopEdge:Hide() end
local inside=body:CreateTexture(nil,"BORDER",nil,1);inside:SetPoint("TOPLEFT",body,"TOPLEFT",0,5);inside:SetPoint("TOPRIGHT",body,"TOPRIGHT",0,5);inside:SetPoint("BOTTOMLEFT",body,"BOTTOMLEFT",0,0);inside:SetPoint("BOTTOMRIGHT",body,"BOTTOMRIGHT",0,0);if not FQT_Atlas(inside,"common-insideframe") then inside:SetTexture(8124462) end
local dividerLayer=CreateFrame("Frame",nil,cfg);dividerLayer:SetAllPoints(cfg);dividerLayer:SetFrameStrata(cfg:GetFrameStrata());dividerLayer:SetFrameLevel(math.max(cfg:GetFrameLevel(),body:GetFrameLevel())+20)
local divider=dividerLayer:CreateTexture(nil,"OVERLAY",nil,7);divider:SetSize(16,524);divider:SetPoint("CENTER",cfg,"TOP",0,-95);if not FQT_Atlas(divider,"common-framedivider") then divider:SetTexture(8245174) end;divider:SetTexCoord(0,1,0,1);if divider.SetRotation then divider:SetRotation(math.pi/2) end
local titleLayer=CreateFrame("Frame",nil,cfg);titleLayer:SetAllPoints(cfg);titleLayer:SetFrameStrata(cfg:GetFrameStrata());titleLayer:SetFrameLevel(math.max(cfg:GetFrameLevel(),body:GetFrameLevel())+30)
local mainTitle=titleLayer:CreateFontString(nil,"OVERLAY","GameFontNormalLarge");local tf,ts,tflags=mainTitle:GetFont();if tf and ts then mainTitle:SetFont(tf,ts+2,tflags) end;mainTitle:SetPoint("CENTER",cfg,"TOP",0,-58);mainTitle:SetText("老哥UI｜任務提醒｜FQT")

local function CreateRecipeMenu(parent,text)
 local b=CreateFrame("Button",nil,parent);b:SetSize(150,48);local bg=b:CreateTexture(nil,"BACKGROUND");b.bg=bg;bg:SetAllPoints();if not pcall(bg.SetAtlas,bg,"Professions_Recipe_Active") then bg:SetTexture(4417031) end
 local label=b:CreateFontString(nil,"OVERLAY","GameFontNormal");b.label=label;label:SetPoint("CENTER",b,"CENTER",0,0);local mf,ms,mflags=label:GetFont();if mf and ms then label:SetFont(mf,ms+2,mflags or "") end;label:SetText(text);return b
end
local menu1=CreateRecipeMenu(cfg,"任務通知");menu1:SetPoint("TOPLEFT",body,"TOPLEFT",17,-28)
local menu2=CreateRecipeMenu(cfg,"任務感應");menu2:SetPoint("TOPLEFT",menu1,"BOTTOMLEFT",0,-15)
local menu3=CreateRecipeMenu(cfg,"提醒視窗");menu3:SetPoint("TOPLEFT",menu2,"BOTTOMLEFT",0,-15)
local verticalDivider=cfg:CreateTexture(nil,"OVERLAY",nil,7);verticalDivider:SetSize(2,405);verticalDivider:SetPoint("TOP",body,"TOPLEFT",183,-35);if not pcall(verticalDivider.SetAtlas,verticalDivider,"Talents-divider-vertical-c60") then verticalDivider:SetTexture(8116735) end

local pages={};local selectedPage=1
local function MakePage() local p=CreateFrame("Frame",nil,cfg);p:SetPoint("TOPLEFT",body,"TOPLEFT",205,-24);p:SetPoint("BOTTOMRIGHT",body,"BOTTOMRIGHT",-24,54);return p end
local page1=MakePage();pages[1]=page1;local page2=MakePage();pages[2]=page2;local page3=MakePage();pages[3]=page3
local function SetMenuState(button,selected) if selected then button.bg:SetAlpha(1);button.label:SetTextColor(1,.82,0) else button.bg:SetAlpha(.18);button.label:SetTextColor(.90,.88,.82) end end
local function SelectPage(index)
 selectedPage=index;for i,p in ipairs(pages) do p:SetShown(i==index) end;SetMenuState(menu1,index==1);SetMenuState(menu2,index==2);SetMenuState(menu3,index==3)
 if index==3 then if FQT_ShowAlertPreview then FQT_ShowAlertPreview() end else if FQT_HideAlertPreview then FQT_HideAlertPreview() end end
end
for _,b in ipairs({menu1,menu2,menu3}) do
 b:SetScript("OnEnter",function(self) if (self==menu1 and selectedPage~=1) or (self==menu2 and selectedPage~=2) or (self==menu3 and selectedPage~=3) then self.bg:SetAlpha(.60) end end)
 b:SetScript("OnLeave",function(self) SetMenuState(self,(self==menu1 and selectedPage==1) or (self==menu2 and selectedPage==2) or (self==menu3 and selectedPage==3)) end)
end
menu1:SetScript("OnClick",function()PlaySound(856);SelectPage(1)end);menu2:SetScript("OnClick",function()PlaySound(856);SelectPage(2)end);menu3:SetScript("OnClick",function()PlaySound(856);SelectPage(3)end)

local function EditLabel(parent,text,x,y,gold)
 local t=parent:CreateFontString(nil,"OVERLAY","GameFontNormal");t:SetPoint("TOPLEFT",x,y);t:SetText(text);local f,s,fl=t:GetFont();if f and s then t:SetFont(f,s+1,fl or "") end
 if gold then t:SetTextColor(1,.82,0,1) else t:SetTextColor(1,1,1,1) end;t:SetShadowColor(0,0,0,0);t:SetShadowOffset(0,0);return t
end
local function NativeCheck(parent,label,x,y,key)
 local c=CreateFrame("CheckButton",nil,parent,"UICheckButtonTemplate");c:SetPoint("TOPLEFT",x,y);c.text:ClearAllPoints();c.text:SetPoint("LEFT",c,"RIGHT",4,1);c.text:SetText(label)
 local fs=c.Text or c.text;if fs then local f,s,fl=fs:GetFont();if f and s then fs:SetFont(f,s+1,fl or "") end;fs:SetTextColor(1,1,1,1);fs:SetShadowColor(0,0,0,0);fs:SetShadowOffset(0,0) end
 c:SetScript("OnClick",function(self)PlaySound(856);FQTDB[key]=self:GetChecked() and true or false;if key=="monsterBubble" then FQTDB.monsterSense=FQTDB.monsterBubble and true or false;if not FQTDB.monsterSense and FQTMonsterAlert then FQTMonsterAlert:Hide() end;if FQT_EnableMonsterSense then FQT_EnableMonsterSense() end;if FQT_ApplySenseCVars then FQT_ApplySenseCVars() end elseif key=="monsterTargetBubble" then if not FQTDB.monsterTargetBubble and FQTMonsterAlert then FQTMonsterAlert:Hide() end end end)
 c.Refresh=function()c:SetChecked(FQTDB[key] and true or false)end;return c
end
local function NativeRadio(parent,label,x,y,key,value,group)
 local c=CreateFrame("CheckButton",nil,parent,"UICheckButtonTemplate");c:SetPoint("TOPLEFT",x,y);c.text:ClearAllPoints();c.text:SetPoint("LEFT",c,"RIGHT",4,1);c.text:SetText(label);local fs=c.Text or c.text;if fs then local f,s,fl=fs:GetFont();if f and s then fs:SetFont(f,s+1,fl or "") end;fs:SetTextColor(1,1,1,1);fs:SetShadowColor(0,0,0,0);fs:SetShadowOffset(0,0) end
 group[#group+1]=c;c:SetScript("OnClick",function()PlaySound(856);FQTDB[key]=value;for _,b in ipairs(group) do b:SetChecked(b==c) end;if FQT_ApplySenseCVars then FQT_ApplySenseCVars() end end);c.Refresh=function()c:SetChecked(FQTDB[key]==value)end;return c
end
local function WhiteButtonText(b) local fs=b:GetFontString();if fs then local f,s=fs:GetFont();if f and s then fs:SetFont(f,s,"") end;fs:SetTextColor(1,1,1,1);fs:SetShadowColor(0,0,0,0);fs:SetShadowOffset(0,0) end end
local function NativeButton(parent,label,x,y,w,onClick) local b=CreateFrame("Button",nil,parent,"MainMenuFrameButtonTemplate");b:SetSize(w or 95,32);b:SetPoint("TOPLEFT",x,y);b:SetText(label);WhiteButtonText(b);b:SetScript("OnClick",function(self)PlaySound(856);if onClick then onClick(self) end end);return b end

-- 第一頁：任務通知
EditLabel(page1,"文字通知方式",0,-4,true)
local cSelf=NativeCheck(page1,"自己",0,-38,"sendSelf")
local cSay=NativeCheck(page1,"附近",95,-38,"sendSay")
local cParty=NativeCheck(page1,"隊友",190,-38,"sendParty")
EditLabel(page1,"聲音通知方式",0,-92,true)
local cProgress=NativeCheck(page1,"任務進度",0,-126,"progressSound")
local cComplete=NativeCheck(page1,"任務完成",145,-126,"completeSound")

-- 第二頁：任務感應
EditLabel(page2,"感應距離",0,-4,true)
local dg={};local d1=NativeRadio(page2,"5碼",0,-38,"monsterDistance","near",dg);local d2=NativeRadio(page2,"20碼",95,-38,"monsterDistance","normal",dg);local d3=NativeRadio(page2,"30碼",190,-38,"monsterDistance","far",dg)
EditLabel(page2,"感應角度",0,-82,true)
local ag={};local a1=NativeRadio(page2,"5度",0,-116,"monsterArc","15",ag);local a2=NativeRadio(page2,"90度",95,-116,"monsterArc","90",ag);local a3=NativeRadio(page2,"160度",190,-116,"monsterArc","160",ag)
-- 第三頁：提醒視窗
EditLabel(page3,"提醒視窗",0,-4,true)
local cBubble=NativeCheck(page3,"附近有任務怪跳提醒",0,-38,"monsterBubble")
local cTarget=NativeCheck(page3,"點選任務怪時跳提醒",0,-72,"monsterTargetBubble")
EditLabel(page3,"背景",0,-116,true)
local function SetAlertBgMode(mode)FQTDB.alertBgMode=mode;if FQT_ApplyAlertLook then FQT_ApplyAlertLook() end end
NativeButton(page3,"全黑",0,-144,95,function()SetAlertBgMode(1)end);NativeButton(page3,"半透明",100,-144,95,function()SetAlertBgMode(2)end);NativeButton(page3,"透明",200,-144,95,function()SetAlertBgMode(3)end)
EditLabel(page3,"大小",0,-190,true)
local alertSlider=CreateFrame("Frame","FQTAlertSizeSlider",page3,"MinimalSliderWithSteppersTemplate")
alertSlider:SetSize(295,30);alertSlider:SetPoint("TOPLEFT",0,-214)
local alertSliderReady=false
alertSlider:Init(tonumber(FQTDB.alertWidth) or 220,220,350,130,nil)
alertSlider:RegisterCallback(MinimalSliderWithSteppersMixin.Event.OnValueChanged,function(_,v)
 if not alertSliderReady then return end;FQTDB.alertWidth=math.max(220,math.min(350,math.floor((tonumber(v) or 220)+.5)));if FQT_ApplyAlertSize then FQT_ApplyAlertSize() end
end)
alertSliderReady=true

local function RefreshUI()
 cSelf.Refresh();cSay.Refresh();cParty.Refresh();cProgress.Refresh();cComplete.Refresh();d1.Refresh();d2.Refresh();d3.Refresh();a1.Refresh();a2.Refresh();a3.Refresh();cBubble.Refresh();cTarget.Refresh()
 local w=math.max(220,math.min(350,math.floor((tonumber(FQTDB.alertWidth) or 220)+.5)));if alertSlider.SetValue then alertSlider:SetValue(w) end
end
cfg.Refresh=RefreshUI

local resetButton=CreateFrame("Button",nil,cfg,"MainMenuFrameButtonTemplate");resetButton:SetSize(155,32);resetButton:SetPoint("BOTTOMLEFT",body,"BOTTOMLEFT",14.5,33);resetButton:SetText("恢復預設");WhiteButtonText(resetButton)
resetButton:SetScript("OnClick",function()
 PlaySound(856);FQTDB.progressSound=true;FQTDB.completeSound=true;FQTDB.sendSelf=true;FQTDB.sendSay=true;FQTDB.sendParty=true;FQTDB.monsterDistance="normal";FQTDB.monsterArc="90";FQTDB.monsterBubble=true;FQTDB.monsterSense=true;FQTDB.monsterTargetBubble=true;FQTDB.alertWidth=220;FQTDB.alertBgMode=2
 if FQT_ApplySenseCVars then FQT_ApplySenseCVars() end;if FQT_ApplyAlertSize then FQT_ApplyAlertSize() end;if FQT_ApplyAlertLook then FQT_ApplyAlertLook() end;if FQT_RestoreAlertPosition then FQT_RestoreAlertPosition() end
 FQTDB.panelX=-400;FQTDB.panelY=0;cfg:ClearAllPoints();cfg:SetPoint("CENTER",UIParent,"CENTER",-400,0);RefreshUI()
end)
local doneButton=CreateFrame("Button",nil,cfg,"MainMenuFrameButtonTemplate");doneButton:SetSize(155,32);doneButton:SetPoint("BOTTOMRIGHT",body,"BOTTOMRIGHT",-25,33);doneButton:SetText("設定完成");WhiteButtonText(doneButton);doneButton:SetScript("OnClick",function()PlaySound(856);cfg:Hide()end)

cfg:Hide();table.insert(UISpecialFrames,"FQTSettingsFrame")
cfg:SetScript("OnShow",function()PlaySound(850);RefreshUI();SelectPage(1)end)
cfg:SetScript("OnHide",function()PlaySound(850);if FQTMonsterAlert then FQTMonsterAlert:Hide() end end)
SelectPage(1)


-- ===== 任務怪感應核心 v0.10 =====
-- 已在 Forever 實機驗證：
-- SoftTargetEnemy 可在靠近怪物時提供 softenemy。
-- 正式版採「任務變動時建立快取；softenemy 換怪時只查快取」，
-- 不使用 0.2 秒全任務掃描。

local FQTQuestMonster = {
    objectiveRows = {},
    directMap = {},
    negativeNames = {},
    lastGUID = nil,
    oldEnemy = nil,
}

local function FQT_Secret(v)
    return type(issecretvalue) == "function" and issecretvalue(v)
end

local function FQT_Safe(fn, ...)
    if type(fn) ~= "function" then return nil end
    local ok, a, b, c, d = pcall(fn, ...)
    if ok then return a, b, c, d end
end

local function FQT_GetEnemyCVar()
    if C_CVar and C_CVar.GetCVar then return C_CVar.GetCVar("SoftTargetEnemy") end
    if GetCVar then return GetCVar("SoftTargetEnemy") end
end

local function FQT_SetEnemyCVar(v)
    if C_CVar and C_CVar.SetCVar then C_CVar.SetCVar("SoftTargetEnemy", tostring(v))
    elseif SetCVar then SetCVar("SoftTargetEnemy", tostring(v)) end
end

local function FQT_EnableMonsterSense()
    if FQTQuestMonster.oldEnemy == nil then
        FQTQuestMonster.oldEnemy = FQT_GetEnemyCVar()
    end
    if FQTDB.monsterSense then
        FQT_SetEnemyCVar(3)
    elseif FQTQuestMonster.oldEnemy ~= nil then
        FQT_SetEnemyCVar(FQTQuestMonster.oldEnemy)
    end
end

local function FQT_BuildObjectiveCache()
    wipe(FQTQuestMonster.objectiveRows)
    wipe(FQTQuestMonster.directMap)
    wipe(FQTQuestMonster.negativeNames)

    if C_QuestLog and C_QuestLog.GetNumQuestLogEntries and C_QuestLog.GetInfo and C_QuestLog.GetQuestObjectives then
        local n = FQT_Safe(C_QuestLog.GetNumQuestLogEntries)
        if type(n) == "number" and not FQT_Secret(n) then
            for i = 1, n do
                local info = FQT_Safe(C_QuestLog.GetInfo, i)
                if info and not info.isHeader and info.questID then
                    local objs = FQT_Safe(C_QuestLog.GetQuestObjectives, info.questID)
                    if type(objs) == "table" then
                        for _, o in ipairs(objs) do
                            if o and o.text and not FQT_Secret(o.text) then
                                FQTQuestMonster.objectiveRows[#FQTQuestMonster.objectiveRows + 1] = {
                                    text = o.text, finished = o.finished, questID = info.questID
                                }
                            end
                        end
                    end
                end
            end
        end
    end

    -- Forever 若新 API 沒回 objectives，保留舊 API fallback。
    if #FQTQuestMonster.objectiveRows == 0 and GetNumQuestLogEntries and GetQuestLogTitle and GetNumQuestLeaderBoards and GetQuestLogLeaderBoard then
        local n = FQT_Safe(GetNumQuestLogEntries)
        if type(n) == "number" then
            for i = 1, n do
                local title, _, _, isHeader = FQT_Safe(GetQuestLogTitle, i)
                if title and not isHeader then
                    local m = FQT_Safe(GetNumQuestLeaderBoards, i) or 0
                    for j = 1, m do
                        local desc, typ, done = FQT_Safe(GetQuestLogLeaderBoard, j, i)
                        if desc and not FQT_Secret(desc) then
                            FQTQuestMonster.objectiveRows[#FQTQuestMonster.objectiveRows + 1] = {
                                text = desc, finished = done, questTitle = title, type = typ
                            }
                        end
                    end
                end
            end
        end
    end
end

local function FQT_FindMonsterObjective(name)
    if not name or name == "" then return nil end

    local cached = FQTQuestMonster.directMap[name]
    if cached then return cached end
    if FQTQuestMonster.negativeNames[name] then return nil end

    -- 只在第一次遇到「這個怪名」時掃一次已快取的 objectiveRows。
    -- 之後同名怪直接 O(1) table lookup。
    for _, row in ipairs(FQTQuestMonster.objectiveRows) do
        if not row.finished and row.text and row.text:find(name, 1, true) then
            FQTQuestMonster.directMap[name] = row.text
            return row.text
        end
    end

    FQTQuestMonster.negativeNames[name] = true
    return nil
end

FQTMonsterAlert = CreateFrame("Frame", "FQTMonsterAlert", UIParent)
FQTMonsterAlert:SetFrameStrata("HIGH")
FQTMonsterAlert:SetClampedToScreen(true)
FQTMonsterAlert:SetMovable(true)
FQTMonsterAlert:EnableMouse(true)
FQTMonsterAlert:RegisterForDrag("LeftButton")

local mbg = FQTMonsterAlert:CreateTexture(nil, "BACKGROUND")
mbg:SetAllPoints()
mbg:SetColorTexture(0,0,0,0.5)

local m1 = FQTMonsterAlert:CreateFontString(nil, "OVERLAY")
m1:SetTextColor(1,.82,.12,1)
m1:SetJustifyH("CENTER")
m1:SetJustifyV("TOP")
m1:SetWordWrap(true)

local m2 = FQTMonsterAlert:CreateFontString(nil, "OVERLAY")
m2:SetTextColor(1,1,1,1)
m2:SetJustifyH("CENTER")
m2:SetJustifyV("TOP")
m2:SetWordWrap(true)

FQT_ApplySenseCVars=function()
 if not FQTDB then return end

 -- 任務怪：只有總開關啟用時才開 Enemy soft-target。
 if FQTDB.monsterSense then SetCVar("SoftTargetEnemy",3) end
 local enemyRange={near=10,normal=25,far=45}
 local enemyArc={["15"]=0,["90"]=1,["160"]=2}
 SetCVar("SoftTargetEnemyRange",enemyRange[FQTDB.monsterDistance] or 45)
 SetCVar("SoftTargetEnemyArc",enemyArc[FQTDB.monsterArc] or 2)
end

local function FQT_AlertWidth()
 return math.max(220,math.min(350,math.floor((tonumber(FQTDB.alertWidth) or 220)+.5)))
end

local function FQT_ResizeMonsterAlert()
 local scale=FQT_AlertWidth()/220
 local top=10*scale
 local gap=3*scale
 local bottom=10*scale
 local h1=math.max(18*scale,m1:GetStringHeight() or 18*scale)
 local h2=math.max(14*scale,m2:GetStringHeight() or 14*scale)
 FQTMonsterAlert:SetHeight(top+h1+gap+h2+bottom)
end

FQT_ApplyAlertSize=function()
 local w=FQT_AlertWidth()
 local scale=w/220
 FQTMonsterAlert:SetWidth(w)
 m1:SetFont(STANDARD_TEXT_FONT,18*scale,"THICKOUTLINE")
 m2:SetFont(STANDARD_TEXT_FONT,14*scale,"THICKOUTLINE")
 m1:SetWidth(w-(20*scale))
 m2:SetWidth(w-(20*scale))
 m1:ClearAllPoints()
 m1:SetPoint("TOP",FQTMonsterAlert,"TOP",0,-10*scale)
 m2:ClearAllPoints()
 m2:SetPoint("TOP",m1,"BOTTOM",0,-3*scale)
 FQT_ResizeMonsterAlert()
end

FQT_ApplyAlertLook=function()
 local mode=tonumber(FQTDB.alertBgMode) or 2
 local a=1
 if mode==2 then a=.5
 elseif mode==3 then a=0 end
 mbg:SetColorTexture(0,0,0,a)
end

FQT_RestoreAlertPosition=function()
 FQTDB.alertPoint="TOP";FQTDB.alertRelPoint="TOP";FQTDB.alertX=0;FQTDB.alertY=-245
 FQTMonsterAlert:ClearAllPoints()
 FQTMonsterAlert:SetPoint("TOP",UIParent,"TOP",0,-245)
end

FQTMonsterAlert:SetScript("OnDragStart",function(self)
 self:StartMoving()
end)
FQTMonsterAlert:SetScript("OnDragStop",function(self)
 self:StopMovingOrSizing()
 local point,_,relPoint,x,y=self:GetPoint(1)
 FQTDB.alertPoint=point or "TOP"
 FQTDB.alertRelPoint=relPoint or FQTDB.alertPoint
 FQTDB.alertX=x or 0
 FQTDB.alertY=y or -245
end)

FQTMonsterAlert:ClearAllPoints()
FQTMonsterAlert:SetPoint(FQTDB.alertPoint or "TOP",UIParent,FQTDB.alertRelPoint or FQTDB.alertPoint or "TOP",tonumber(FQTDB.alertX) or 0,tonumber(FQTDB.alertY) or -245)
FQT_ApplyAlertSize()
FQT_ApplyAlertLook()
FQTMonsterAlert:Hide()

-- 視窗設定頁模擬預覽：不需要附近有任務怪／任務物品即可調整。
FQT_ShowAlertPreview=function()
 m1:SetText("視窗設定")
 m2:SetText("任務進度：4/10")
 FQT_ApplyAlertSize()
 FQT_ApplyAlertLook()
 FQTMonsterAlert:Show()
end
FQT_HideAlertPreview=function()
 if cfg and cfg:IsShown() and pages and pages[4] and pages[4]:IsShown() then return end
 FQTMonsterAlert:Hide()
end

-- ===== 任務怪感應提醒 =====
local FQTAlertSource=nil

local function FQT_ShowSenseAlert(source,name,objective)
 FQTAlertSource=source
 m1:SetText(name or "任務目標")
 m2:SetText(objective or "")
 FQT_ResizeMonsterAlert()
 FQTMonsterAlert:Show()
end
local function FQT_HideSenseAlert(source)
 if not source or FQTAlertSource==source then
  FQTMonsterAlert:Hide()
  if not source or FQTAlertSource==source then FQTAlertSource=nil end
 end
end

local function FQT_CheckSoftEnemy(force)
    -- 玩家操作優先：戰鬥中或已有任何目標時，不做附近任務怪自動感應。
    if InCombatLockdown and InCombatLockdown() then
        return
    end
    local hasTarget=FQT_Safe(UnitExists,"target")
    if hasTarget and not FQT_Secret(hasTarget) then
        return
    end
    if not FQTDB.monsterSense then
        FQT_HideSenseAlert("monster")
        return
    end

    local exists = FQT_Safe(UnitExists, "softenemy")
    if not exists or FQT_Secret(exists) then
        FQTQuestMonster.lastGUID = nil
        FQT_HideSenseAlert("monster")
        return
    end

    local guid = FQT_Safe(UnitGUID, "softenemy")
    if FQT_Secret(guid) then guid = nil end
    if not force and guid and guid == FQTQuestMonster.lastGUID then return end
    FQTQuestMonster.lastGUID = guid

    local name = FQT_Safe(UnitName, "softenemy")
    if FQT_Secret(name) then name = nil end
    local objective = FQT_FindMonsterObjective(name)

    if objective and FQTDB.monsterBubble then
        FQT_ShowSenseAlert("monster",name or "任務目標",objective)
    else
        FQT_HideSenseAlert("monster")
    end
end

local FQTMonsterEvents = CreateFrame("Frame")
FQTMonsterEvents:RegisterEvent("PLAYER_LOGIN")
FQTMonsterEvents:RegisterEvent("PLAYER_SOFT_ENEMY_CHANGED")
FQTMonsterEvents:RegisterEvent("PLAYER_TARGET_CHANGED")
FQTMonsterEvents:RegisterEvent("PLAYER_REGEN_ENABLED")
FQTMonsterEvents:RegisterEvent("PLAYER_REGEN_DISABLED")
FQTMonsterEvents:RegisterEvent("QUEST_LOG_UPDATE")
FQTMonsterEvents:RegisterEvent("QUEST_WATCH_UPDATE")
FQTMonsterEvents:RegisterEvent("UNIT_QUEST_LOG_CHANGED")
FQTMonsterEvents:RegisterEvent("QUEST_ACCEPTED")
FQTMonsterEvents:RegisterEvent("QUEST_REMOVED")
FQTMonsterEvents:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        FQT_EnableMonsterSense()
        FQT_BuildObjectiveCache()
    elseif event == "PLAYER_SOFT_ENEMY_CHANGED" then
        FQT_CheckSoftEnemy(false)
    elseif event == "PLAYER_TARGET_CHANGED" then
        -- target 任何變化都先清除上一個自動感應／點選提醒，避免舊資訊殘留。
        FQT_HideSenseAlert()
        local exists=FQT_Safe(UnitExists,"target")
        if exists and not FQT_Secret(exists) then
            -- 任何 target 存在時，自動感應由 FQT_CheckSoftEnemy 暫停。
            -- 只有玩家點到任務怪時，才顯示該怪任務進度。
            local attack=FQT_Safe(UnitCanAttack,"player","target")
            if attack and not FQT_Secret(attack) then
                local name=FQT_Safe(UnitName,"target")
                if FQT_Secret(name) then name=nil end
                if name and name~="" then
                    local objective=FQT_FindMonsterObjective(name)
                    if objective and FQTDB.monsterTargetBubble then
                        FQT_ShowSenseAlert("monster",name,objective)
                    end
                end
            end
        else
            -- 清除目標時只關閉舊提醒。
            -- 自動感應保留啟用狀態，但等下一次 softenemy 真正重新偵測後再顯示。
        end
    elseif event == "PLAYER_REGEN_DISABLED" then
        -- 一進入戰鬥立即清除提醒，戰鬥期間 FQT_CheckSoftEnemy 也會停止自動感應。
        FQT_HideSenseAlert()
    elseif event == "PLAYER_REGEN_ENABLED" then
        -- 離開戰鬥只解除停止條件，不重顯舊資訊；等下一次 softenemy 重新偵測。
        FQT_HideSenseAlert()
    else
        -- 任務表變動時更新任務怪目標比對快取。
        FQT_BuildObjectiveCache()
        if FQTDB.monsterSense then FQT_CheckSoftEnemy(true) end
    end
end)


local mini
local function OpenSettings() if cfg:IsShown()then cfg:Hide()else cfg:Show()end end
local function SetupStandardMinimap()
 local LibStub=_G.LibStub;if not LibStub then return false end
 local LDB=LibStub("LibDataBroker-1.1",true);local DBIcon=LibStub("LibDBIcon-1.0",true);if not LDB or not DBIcon then return false end
 local obj=LDB:NewDataObject("FQT",{type="launcher",text="FQT",icon=3586269,OnClick=function(_,button)if button=="LeftButton"then OpenSettings()end end,OnTooltipShow=function(tt)tt:AddLine("老哥UI｜任務提醒｜FQT");tt:AddLine("左鍵：開啟/關閉設定",1,1,1)end})
 if not DBIcon:IsRegistered("FQT")then DBIcon:Register("FQT",obj,FQTDB.minimap)end
 local b=DBIcon.GetMinimapButton and DBIcon:GetMinimapButton("FQT")
 if b and not b.LaogeUIStandardRing then
  b:SetSize(31,31);if b.icon then b.icon:ClearAllPoints();b.icon:SetSize(20,20);b.icon:SetPoint("CENTER",b,"CENTER",1,0);b.icon:SetTexCoord(.07,.93,.07,.93) end
  local bg=b:CreateTexture(nil,"BACKGROUND");bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background");bg:SetSize(20,20);bg:SetPoint("CENTER");bg:Hide()
  local ring=b:CreateTexture(nil,"OVERLAY");ring:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder");ring:SetSize(53,53);ring:SetPoint("TOPLEFT",b,"TOPLEFT",0,0)
  b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight");b.LaogeUIStandardRing=true
 end
 return true
end
local function SetupFallbackMinimap()
 mini=CreateFrame("Button","FQTMinimapButton",Minimap);mini:SetSize(31,31);mini:SetFrameStrata("MEDIUM");mini:SetFrameLevel((Minimap:GetFrameLevel()or 0)+8);mini:RegisterForClicks("LeftButtonUp");mini:RegisterForDrag("LeftButton")
 local ic=mini:CreateTexture(nil,"ARTWORK");ic:SetSize(20,20);ic:SetPoint("CENTER",mini,"CENTER",1,0);ic:SetTexture(3586269);ic:SetTexCoord(.07,.93,.07,.93)
 local border=mini:CreateTexture(nil,"OVERLAY");border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder");border:SetSize(53,53);border:SetPoint("TOPLEFT",mini,"TOPLEFT",0,0)
 local hl=mini:CreateTexture(nil,"HIGHLIGHT");hl:SetTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight");hl:SetBlendMode("ADD");hl:SetSize(31,31);hl:SetPoint("CENTER")
 local function Pos()local r=math.max(Minimap:GetWidth()or 140,Minimap:GetHeight()or 140)/2+18;local a=math.rad(FQTDB.minimapAngle or 165);mini:ClearAllPoints();mini:SetPoint("CENTER",Minimap,"CENTER",math.cos(a)*r,math.sin(a)*r)end
 mini:SetScript("OnDragStart",function(self)self:SetScript("OnUpdate",function()local mx,my=Minimap:GetCenter();if not mx then return end;local x,y=GetCursorPosition();local sc=UIParent:GetEffectiveScale();x,y=x/sc,y/sc;FQTDB.minimapAngle=math.deg(math.atan2(y-my,x-mx));Pos()end)end)
 mini:SetScript("OnDragStop",function(self)self:SetScript("OnUpdate",nil)end);mini:SetScript("OnClick",function(_,button)if button=="LeftButton"then OpenSettings()end end)
 mini:SetScript("OnEnter",function(self)GameTooltip:SetOwner(self,"ANCHOR_LEFT");GameTooltip:SetText("老哥UI｜任務提醒｜FQT");GameTooltip:AddLine("左鍵：開啟/關閉設定",1,1,1);GameTooltip:Show()end);mini:SetScript("OnLeave",function()GameTooltip:Hide()end);Pos()
end

local ev=CreateFrame("Frame")
for _,e in ipairs({"PLAYER_LOGIN","PLAYER_ENTERING_WORLD","QUEST_LOG_UPDATE","QUEST_WATCH_UPDATE","UNIT_QUEST_LOG_CHANGED","QUEST_ACCEPTED","QUEST_REMOVED","QUEST_TURNED_IN"})do ev:RegisterEvent(e)end
ev:SetScript("OnEvent",function(_,e,...)
 if e=="PLAYER_LOGIN"then
  InitDB()
  FQTDB.monsterSense=FQTDB.monsterBubble and true or false
  if FQTDB.monsterDistance=="medium" then FQTDB.monsterDistance="normal" end
  if FQTDB.monsterArc=="30" then FQTDB.monsterArc="15" elseif FQTDB.monsterArc=="180" then FQTDB.monsterArc="160" end
  if FQT_ApplySenseCVars then FQT_ApplySenseCVars() end
  cfg:ClearAllPoints();cfg:SetPoint("CENTER",UIParent,"CENTER",FQTDB.panelX or -400,FQTDB.panelY or 0)
  if not SetupStandardMinimap()then SetupFallbackMinimap()end
  snapshot=BuildSnapshot();primed=true
  print("|cffffd200FQT｜任務提醒 - BY老哥|r")
 elseif e=="PLAYER_ENTERING_WORLD"then snapshot=BuildSnapshot();primed=true
 elseif e=="QUEST_ACCEPTED"then
  local a,b=...
  local qid=(type(b)=="number" and b) or (type(a)=="number" and a) or nil
  if qid then C_Timer.After(.15,function()AnnounceAccepted(qid);snapshot=BuildSnapshot();primed=true end) end
 elseif e=="QUEST_REMOVED" or e=="QUEST_TURNED_IN"then
  C_Timer.After(.2,function()snapshot=BuildSnapshot();primed=true end)
 elseif e=="UNIT_QUEST_LOG_CHANGED"then
  local unit=...;if not unit or unit=="player" then QueueCheck() end
 else QueueCheck() end
end)
SLASH_FQT1="/fqt";SlashCmdList["FQT"]=function()OpenSettings()end
