local ADDON = ...
FEASY_DB = FEASY_DB or {}
FMAIL_DB = FMAIL_DB or {}
FWMDB = FWMDB or {}

local defaults = {
    sellJunk=true, autoRepair=true, mailEnhance=true,
    movableWindows=true, movableBag=true, minimapCollector=true,
    minimap={hide=false,minimapPos=225}, collector={hide=false,minimapPos=200},
}
local function InitDB()
    for k,v in pairs(defaults) do
        if FEASY_DB[k] == nil then
            if type(v)=="table" then FEASY_DB[k]={}; for a,b in pairs(v) do FEASY_DB[k][a]=b end
            else FEASY_DB[k]=v end
        end
    end
    FEASY_DB.minimap=FEASY_DB.minimap or {hide=false,minimapPos=225}
    FEASY_DB.collector=FEASY_DB.collector or {hide=false,minimapPos=200}
end
local function Chat(s) if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cffffcc55FEASY：|r"..s) end end
local function MoneyText(copper)
    copper=tonumber(copper) or 0
    local g=math.floor(copper/10000); local s=math.floor((copper%10000)/100); local c=copper%100
    local t={}; if g>0 then t[#t+1]=g.."金" end; if s>0 or g>0 then t[#t+1]=s.."銀" end; t[#t+1]=c.."銅"
    return table.concat(t," ")
end

-- FAR v0.04：保留既有安全灰物判斷，拆成兩個可獨立開關。
local function IsSafeGrayItem(bag,slot)
    if not C_Container or not C_Container.GetContainerItemInfo then return false end
    local info=C_Container.GetContainerItemInfo(bag,slot)
    if not info or not info.itemID or not info.stackCount or info.quality~=0 or info.hasNoValue then return false end
    if C_Container.GetContainerItemQuestInfo then
        local q=C_Container.GetContainerItemQuestInfo(bag,slot)
        if q and (q.isQuestItem or q.questID or q.isActive) then return false end
    end
    return true,info.stackCount
end
local function SellSafeGrayItems()
    if not FEASY_DB.sellJunk or not C_Container or not C_Container.PickupContainerItem then return end
    local sold=0; local before=GetMoney(); local maxBag=NUM_TOTAL_EQUIPPED_BAG_SLOTS or 4
    for bag=0,maxBag do
        local slots=C_Container.GetContainerNumSlots and C_Container.GetContainerNumSlots(bag) or 0
        for slot=slots,1,-1 do
            local safe,count=IsSafeGrayItem(bag,slot)
            if safe and not CursorHasItem() then
                C_Container.PickupContainerItem(bag,slot)
                if CursorHasItem() then
                    if SellCursorItem then SellCursorItem() else ClearCursor() end
                    if not CursorHasItem() then sold=sold+(count or 1) else ClearCursor() end
                end
            end
        end
    end
    if sold>0 then local gain=math.max(0,GetMoney()-before); Chat("已出售灰色物品 "..sold.." 件"..(gain>0 and ("，收入 "..MoneyText(gain).."。") or "。")) end
end
local function Repair()
    if not FEASY_DB.autoRepair or not CanMerchantRepair or not CanMerchantRepair() then return end
    local cost,ok=GetRepairAllCost(); cost=tonumber(cost) or 0
    if not ok or cost<=0 then return end
    if GetMoney()<cost then Chat("金錢不足，無法自動修理；需要 "..MoneyText(cost).."。") return end
    RepairAllItems(false); Chat("已用自己的金錢自動修理，花費 "..MoneyText(cost).."。")
end

-- FMAIL v0.08：常用收件人 + 右鍵領件。只有勾選時啟用。
local mailPanel,mailToggle; local hookedInbox={}
local function NormalizeMail() if type(FMAIL_DB.favorites)~="table" then FMAIL_DB.favorites={} end end
local function RecipientBox() return _G.SendMailNameEditBox or _G.SendMailNameEditBoxRecipient or (_G.SendMailFrame and _G.SendMailFrame.NameEditBox) end
local function Trim(s) return ((s or ""):gsub("^%s+",""):gsub("%s+$","")) end
local function CreateMailPanel()
    if mailPanel or not SendMailFrame then return end
    mailPanel=CreateFrame("Frame","FEASYMailFavoritePanel",SendMailFrame,"BackdropTemplate"); mailPanel:SetSize(210,80); mailPanel:SetFrameStrata("DIALOG"); mailPanel:SetClampedToScreen(true)
    mailPanel:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",tile=true,tileSize=32,edgeSize=24,insets={left=7,right=7,top=7,bottom=7}}); mailPanel:Hide()
    local title=mailPanel:CreateFontString(nil,"OVERLAY","GameFontNormal"); title:SetPoint("TOPLEFT",14,-13); title:SetText("常用收件人")
    local close=CreateFrame("Button",nil,mailPanel,"UIPanelCloseButton"); close:SetPoint("TOPRIGHT",2,2)
    mailPanel.rows={}
    local add=CreateFrame("Button",nil,mailPanel,"UIPanelButtonTemplate"); add:SetSize(170,22); add:SetText("＋ 新增目前收件人"); mailPanel.addButton=add
    function mailPanel:Refresh()
        NormalizeMail(); for _,r in ipairs(self.rows) do r:Hide() end
        local y=-38
        for i,name in ipairs(FMAIL_DB.favorites) do
            local row=self.rows[i]
            if not row then
                row=CreateFrame("Frame",nil,self); row:SetSize(180,24)
                row.pick=CreateFrame("Button",nil,row,"UIPanelButtonTemplate"); row.pick:SetSize(145,22); row.pick:SetPoint("LEFT")
                row.del=CreateFrame("Button",nil,row,"UIPanelButtonTemplate"); row.del:SetSize(26,22); row.del:SetPoint("LEFT",row.pick,"RIGHT",4,0); row.del:SetText("X")
                self.rows[i]=row
            end
            row:ClearAllPoints(); row:SetPoint("TOPLEFT",14,y); row.pick:SetText(name)
            row.pick:SetScript("OnClick",function() local b=RecipientBox(); if b then b:SetText(name); if b.ClearFocus then b:ClearFocus() end end; mailPanel:Hide() end)
            row.del:SetScript("OnClick",function() table.remove(FMAIL_DB.favorites,i); mailPanel:Refresh() end)
            row:Show(); y=y-26
        end
        self.addButton:ClearAllPoints(); self.addButton:SetPoint("TOPLEFT",19,y-3); self:SetHeight(math.max(88,(-y)+43))
    end
    add:SetScript("OnClick",function()
        local b=RecipientBox(); local name=Trim(b and b:GetText() or ""); if name=="" then Chat("請先輸入收件人名稱。") return end
        for _,v in ipairs(FMAIL_DB.favorites) do if string.lower(v)==string.lower(name) then return end end
        table.insert(FMAIL_DB.favorites,name); mailPanel:Refresh()
    end)
end
local function SetupMailToggle()
    if mailToggle or not SendMailFrame then return end
    local box=RecipientBox(); mailToggle=CreateFrame("Button","FEASYMailFavoriteButton",SendMailFrame,"UIPanelButtonTemplate"); mailToggle:SetSize(20,20); mailToggle:SetText("+")
    if box then mailToggle:SetPoint("RIGHT",box,"RIGHT",-78,0) else mailToggle:SetPoint("TOPRIGHT",SendMailFrame,"TOPRIGHT",-31,-35) end
    mailToggle:SetScript("OnClick",function() if not FEASY_DB.mailEnhance then return end; CreateMailPanel(); mailPanel:Refresh(); mailPanel:ClearAllPoints(); mailPanel:SetPoint("TOPLEFT",mailToggle,"BOTTOMLEFT",-6,-4); if mailPanel:IsShown() then mailPanel:Hide() else mailPanel:Show() end end)
    CreateMailPanel()
end
local function InboxIndex(b) if type(b.index)=="number" then return b.index end; local id=b.GetID and b:GetID(); if not id or id<1 then return end; return (((_G.InboxFrame and _G.InboxFrame.pageNum or 1)-1)*(_G.INBOXITEMS_TO_DISPLAY or 7))+id end
local function LootMail(i)
    if not FEASY_DB.mailEnhance or not i or not GetInboxHeaderInfo then return end
    local _,_,_,_,money,cod,_,hasItem=GetInboxHeaderInfo(i); if (tonumber(cod) or 0)>0 then Chat("這封是 C.O.D. 郵件，請用原本郵件視窗確認後領取。") return end
    if money and money>0 and TakeInboxMoney then TakeInboxMoney(i) end
    if hasItem and TakeInboxItem then for a=1,(_G.ATTACHMENTS_MAX_RECEIVE or 16) do if GetInboxItem and GetInboxItem(i,a) then TakeInboxItem(i,a); break end end end
end
local function HookInbox()
    for i=1,(_G.INBOXITEMS_TO_DISPLAY or 7) do local b=_G["MailItem"..i.."Button"] or _G["MailItem"..i]; if b and not hookedInbox[b] then hookedInbox[b]=true; b:RegisterForClicks("LeftButtonUp","RightButtonUp"); b:HookScript("OnClick",function(self,btn) if btn=="RightButton" then LootMail(InboxIndex(self)) end end) end end
end

-- FWM v0.06：保留合併背包拖曳與 Ctrl+滾輪縮放。
local bagHooked=false
local function SaveBag(f) local p,_,rp,x,y=f:GetPoint(1); if p then FWMDB.point=p;FWMDB.relativePoint=rp or p;FWMDB.x=x or 0;FWMDB.y=y or 0 end end
local function ApplyBag(f) local s=tonumber(FWMDB.scale) or 1; s=math.max(.60,math.min(1.50,s));FWMDB.scale=s;f:SetScale(s); if FWMDB.point then f:ClearAllPoints();f:SetPoint(FWMDB.point,UIParent,FWMDB.relativePoint or FWMDB.point,FWMDB.x or 0,FWMDB.y or 0) end end
local function SetupBag()
    local f=_G.ContainerFrameCombinedBags; if not f or bagHooked then return false end; bagHooked=true
    f:SetMovable(true);f:EnableMouse(true);f:EnableMouseWheel(true);if f.SetClampedToScreen then f:SetClampedToScreen(true) end;if f.SetUserPlaced then f:SetUserPlaced(true) end
    local function scale(delta) if not FEASY_DB.movableBag then return end; local s=(tonumber(FWMDB.scale) or 1)+(delta>0 and .05 or -.05);FWMDB.scale=math.max(.60,math.min(1.50,s));f:SetScale(FWMDB.scale) end
    f:HookScript("OnMouseWheel",function(_,d) if FEASY_DB.movableBag and IsControlKeyDown() then scale(d) end end)
    local drag=CreateFrame("Frame",nil,f);drag:SetPoint("TOPLEFT",f,"TOPLEFT",8,-3);drag:SetPoint("TOPRIGHT",f,"TOPRIGHT",-38,-3);drag:SetHeight(42);drag:SetFrameLevel((f:GetFrameLevel() or 1)+20);drag:EnableMouse(true);drag:EnableMouseWheel(true);drag:RegisterForDrag("LeftButton")
    drag:SetScript("OnMouseWheel",function(_,d) if FEASY_DB.movableBag and IsControlKeyDown() then scale(d) end end)
    drag:SetScript("OnDragStart",function() if FEASY_DB.movableBag then f:StartMoving() end end);drag:SetScript("OnDragStop",function() f:StopMovingOrSizing();if FEASY_DB.movableBag then SaveBag(f) end end)
    f:HookScript("OnShow",function(self) if FEASY_DB.movableBag then C_Timer.After(0,function() if self:IsShown() then ApplyBag(self) end end) end end)
    if FEASY_DB.movableBag then ApplyBag(f) end; return true
end

-- FMV v0.01 擴充：商人及常用 Blizzard 原生視窗，上方標題區拖曳。
local movableNames={"MerchantFrame","CharacterFrame","SpellBookFrame","QuestLogFrame","FriendsFrame","PVEFrame","CollectionsJournal","AuctionHouseFrame","BankFrame","GuildBankFrame","MailFrame","GossipFrame","QuestFrame","ClassTrainerFrame","TradeSkillFrame","TradeFrame","InspectFrame"}
local hookedMove={}
local function PosKey(f) return (f.GetName and f:GetName()) or tostring(f) end
local function SaveWindow(f) FEASY_DB.windowPos=FEASY_DB.windowPos or {};local p,_,rp,x,y=f:GetPoint(1);if p then FEASY_DB.windowPos[PosKey(f)]={p,rp or p,x or 0,y or 0} end end
local function RestoreWindow(f) local t=FEASY_DB.windowPos and FEASY_DB.windowPos[PosKey(f)];if t then f:ClearAllPoints();f:SetPoint(t[1],UIParent,t[2],t[3],t[4]) end end
local function MakeWindowMovable(f)
    if not f or hookedMove[f] then return end;hookedMove[f]=true
    if f.SetMovable then f:SetMovable(true) end;if f.SetClampedToScreen then f:SetClampedToScreen(true) end;if f.EnableMouse then f:EnableMouse(true) end;if f.RegisterForDrag then f:RegisterForDrag("LeftButton") end
    f:HookScript("OnDragStart",function(self) if not FEASY_DB.movableWindows or (InCombatLockdown and InCombatLockdown()) then return end;local sc=self:GetEffectiveScale() or 1;local _,cy=GetCursorPosition();cy=cy/sc;local top=self:GetTop();if top and cy>=top-35 then self:StartMoving();self.__FEASYMoving=true end end)
    f:HookScript("OnDragStop",function(self) if self.__FEASYMoving then self:StopMovingOrSizing();self.__FEASYMoving=nil;SaveWindow(self) end end)
    f:HookScript("OnShow",function(self) if FEASY_DB.movableWindows then C_Timer.After(0,function() if self:IsShown() then RestoreWindow(self) end end) end end)
end
local function ScanMovableWindows() for _,n in ipairs(movableNames) do MakeWindowMovable(_G[n]) end end

-- FUI v0.02：保留 U 收納器；FEASY 自己的設定鈕不收納。
local LDB=LibStub("LibDataBroker-1.1",true);local DBIcon=LibStub("LibDBIcon-1.0",true);local collected,seen={},{};local expanded=false;local UButton;local GAP=4
local deny={FEASYCollector=true,GameTimeFrame=true,TimeManagerClockButton=true,QueueStatusMinimapButton=true,MiniMapMailFrame=true,MiniMapTracking=true,MinimapZoomIn=true,MinimapZoomOut=true,MinimapZoneTextButton=true,ExpansionLandingPageMinimapButton=true,AddonCompartmentFrame=true}
local function AddMini(name,b) if not b or b==UButton or deny[name] or seen[b] or not b.IsObjectType or not b:IsObjectType("Button") then return end;local w,h=b:GetSize();if not w or not h or w<16 or h<16 or w>64 or h>64 then return end;seen[b]=true;collected[#collected+1]={name=name,button=b};if not expanded then b:Hide() end end
local function LayoutMini() if not UButton then return end;for i,it in ipairs(collected) do local b=it.button;if b then if expanded and FEASY_DB.minimapCollector then b:ClearAllPoints();b:SetPoint("RIGHT",UButton,"LEFT",-GAP-(i-1)*(31+GAP),0);b:Show() else b:Hide() end end end end
local function ScanMini() if not FEASY_DB.minimapCollector then return end;if DBIcon and DBIcon.objects then for n,b in pairs(DBIcon.objects) do AddMini(n,b) end end;local ch={Minimap:GetChildren()};for _,b in ipairs(ch) do local n=b.GetName and b:GetName();if n and not n:match("^Minimap") and not n:match("^MiniMap") and (b.dataObject or b.db or n:match("LibDBIcon")) then AddMini(n,b) end end;LayoutMini() end
local function SetupCollector()
    if not LDB or not DBIcon then return end
    local o=LDB:NewDataObject("FEASYCollector",{type="launcher",text="U",icon=3586269,OnClick=function(_,btn) if btn=="LeftButton" and FEASY_DB.minimapCollector then expanded=not expanded;ScanMini() end end,OnTooltipShow=function(tt) tt:AddLine("老哥UI｜小地圖按鈕收納｜FEASY");tt:AddLine("左鍵：展開/收起",1,1,1) end})
    if not DBIcon:IsRegistered("FEASYCollector") then DBIcon:Register("FEASYCollector",o,FEASY_DB.collector) end;UButton=DBIcon:GetMinimapButton("FEASYCollector");if UButton and UButton.icon then UButton.icon:SetTexture(3586269) end
end
local function SetCollectorEnabled(on) FEASY_DB.minimapCollector=on;if DBIcon then if on then DBIcon:Show("FEASYCollector");C_Timer.After(.2,ScanMini) else expanded=false;LayoutMini();DBIcon:Hide("FEASYCollector") end end end

-- 老哥UI｜便利工具｜FEASY：視窗外觀完整沿用 FXP v0.63 成功母版。
local main,pages={},{}
local checkboxes={}

local function MakeCheck(parent,text,key,y)
    local c=CreateFrame("CheckButton",nil,parent,"UICheckButtonTemplate")
    c:SetPoint("TOPLEFT",0,y)
    c.text:ClearAllPoints();c.text:SetPoint("LEFT",c,"RIGHT",4,1);c.text:SetText(text)
    local fs=c.Text or c.text
    if fs then
        local font,size,flags=fs:GetFont();if font and size then fs:SetFont(font,size+1,flags or "") end
        fs:SetTextColor(1,1,1,1);fs:SetShadowColor(0,0,0,0);fs:SetShadowOffset(0,0)
    end
    c.Refresh=function() c:SetChecked(FEASY_DB[key] and true or false) end
    c:SetScript("OnClick",function(self)
        PlaySound(856);FEASY_DB[key]=self:GetChecked() and true or false
        if key=="mailEnhance" and mailToggle then mailToggle:SetShown(FEASY_DB.mailEnhance) end
        if key=="minimapCollector" then SetCollectorEnabled(FEASY_DB[key]) end
    end)
    checkboxes[#checkboxes+1]=c;c.Refresh();return c
end

local function SetButtonWhiteText(b)
    local fs=b:GetFontString();if not fs then return end
    local font,size=fs:GetFont();fs:SetFont(font,size,"");fs:SetTextColor(1,1,1,1);fs:SetShadowColor(0,0,0,0);fs:SetShadowOffset(0,0)
end

local function CreateMain()
    if main.frame then return end
    local f=CreateFrame("Frame","FEASY_MainFrame",UIParent,"PortraitFrameTemplate");main.frame=f
    f:SetSize(530,540);f:SetPoint("CENTER",UIParent,"CENTER",FEASY_DB.panelX or -400,FEASY_DB.panelY or 0)
    f:SetFrameStrata("DIALOG");f:SetClampedToScreen(true);f:SetMovable(true);f:EnableMouse(true);f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart",f.StartMoving)
    f:SetScript("OnDragStop",function(self)
        self:StopMovingOrSizing()
        local x,y=self:GetCenter();local ux,uy=UIParent:GetCenter()
        if x and y and ux and uy then FEASY_DB.panelX=x-ux;FEASY_DB.panelY=y-uy end
    end)
    local portrait=(f.PortraitContainer and f.PortraitContainer.portrait) or f.portrait or f.Portrait
    if portrait then portrait:SetTexture(3586269) end
    local nativeTitle=(f.TitleContainer and f.TitleContainer.TitleText) or f.TitleText
    if nativeTitle then nativeTitle:SetText("") end
    if f.Inset then f.Inset:Hide() end
    if f.Bg and f.Bg.Hide then f.Bg:Hide() end

    local function atlas(tex,name) if not tex or not tex.SetAtlas then return false end;return pcall(tex.SetAtlas,tex,name,false) end
    local top=CreateFrame("Frame",nil,f);top:SetPoint("TOPLEFT",f,"TOPLEFT",2,-23);top:SetPoint("TOPRIGHT",f,"TOPRIGHT",-2,-23);top:SetHeight(76)
    local topBG=top:CreateTexture(nil,"BACKGROUND");topBG:SetAllPoints(top);if not atlas(topBG,"groupfinder-roles-background") then topBG:SetTexture(8373327) end
    local streak=top:CreateTexture(nil,"BORDER");streak:SetPoint("TOPLEFT",top,"TOPLEFT",0,0);streak:SetPoint("TOPRIGHT",top,"TOPRIGHT",0,0);streak:SetHeight(43);if not atlas(streak,"UI-Frame-TopTileStreaks") then streak:SetTexture(1723833) end
    local body=CreateFrame("Frame",nil,f,"InsetFrameTemplate");main.body=body;body:SetPoint("TOPLEFT",f,"TOPLEFT",3,-100);body:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-3,3)
    if body.Bg and body.Bg.SetAlpha then body.Bg:SetAlpha(.90) end;if body.TopEdge then body.TopEdge:Hide() end
    local inside=body:CreateTexture(nil,"BORDER",nil,1);inside:SetPoint("TOPLEFT",body,"TOPLEFT",0,5);inside:SetPoint("TOPRIGHT",body,"TOPRIGHT",0,5);inside:SetPoint("BOTTOMLEFT",body,"BOTTOMLEFT",0,0);inside:SetPoint("BOTTOMRIGHT",body,"BOTTOMRIGHT",0,0);if not atlas(inside,"common-insideframe") then inside:SetTexture(8124462) end
    local dividerLayer=CreateFrame("Frame",nil,f);dividerLayer:SetAllPoints(f);dividerLayer:SetFrameStrata(f:GetFrameStrata());dividerLayer:SetFrameLevel(math.max(f:GetFrameLevel(),body:GetFrameLevel())+20)
    local divider=dividerLayer:CreateTexture(nil,"OVERLAY",nil,7);divider:SetSize(16,524);divider:SetPoint("CENTER",f,"TOP",0,-95);if not atlas(divider,"common-framedivider") then divider:SetTexture(8245174) end;divider:SetTexCoord(0,1,0,1);if divider.SetRotation then divider:SetRotation(math.pi/2) end
    local titleLayer=CreateFrame("Frame",nil,f);titleLayer:SetAllPoints(f);titleLayer:SetFrameStrata(f:GetFrameStrata());titleLayer:SetFrameLevel(math.max(f:GetFrameLevel(),body:GetFrameLevel())+30)
    local mainTitle=titleLayer:CreateFontString(nil,"OVERLAY","GameFontNormalLarge");local tf,ts,tfl=mainTitle:GetFont();if tf and ts then mainTitle:SetFont(tf,ts+2,tfl) end;mainTitle:SetPoint("CENTER",f,"TOP",0,-58);mainTitle:SetText("老哥UI｜便利工具｜FEASY")

    local function CreateRecipeMenu(text)
        local b=CreateFrame("Button",nil,f);b:SetSize(150,48)
        local bg=b:CreateTexture(nil,"BACKGROUND");b.bg=bg;bg:SetAllPoints();if not pcall(bg.SetAtlas,bg,"Professions_Recipe_Active") then bg:SetTexture(4417031) end
        local label=b:CreateFontString(nil,"OVERLAY","GameFontNormal");b.label=label;label:SetPoint("CENTER");local mf,ms,mfl=label:GetFont();if mf and ms then label:SetFont(mf,ms+2,mfl or "") end;label:SetText(text)
        return b
    end
    local menu1=CreateRecipeMenu("遊戲便利");menu1:SetPoint("TOPLEFT",body,"TOPLEFT",17,-28)
    local menu2=CreateRecipeMenu("畫面功能");menu2:SetPoint("TOPLEFT",menu1,"BOTTOMLEFT",0,-15)
    main.menu={menu1,menu2}
    local vdiv=f:CreateTexture(nil,"OVERLAY",nil,7);vdiv:SetSize(2,405);vdiv:SetPoint("TOP",body,"TOPLEFT",183,-35);if not pcall(vdiv.SetAtlas,vdiv,"Talents-divider-vertical-c60") then vdiv:SetTexture(8116735) end

    local selectedPage=1
    local function SetMenuState(b,on) b.bg:SetAlpha(on and 1 or .18);b.label:SetTextColor(on and 1 or .90,on and .82 or .88,on and 0 or .82) end
    local function SelectPage(i) selectedPage=i;for n,p in ipairs(pages) do p:SetShown(n==i) end;SetMenuState(menu1,i==1);SetMenuState(menu2,i==2) end
    for i,b in ipairs(main.menu) do
        b:SetScript("OnEnter",function(self) if selectedPage~=i then self.bg:SetAlpha(.60) end end)
        b:SetScript("OnLeave",function(self) SetMenuState(self,selectedPage==i) end)
        b:SetScript("OnClick",function() PlaySound(856);SelectPage(i) end)
    end
    local function MakePage() local p=CreateFrame("Frame",nil,f);p:SetPoint("TOPLEFT",body,"TOPLEFT",205,-24);p:SetPoint("BOTTOMRIGHT",body,"BOTTOMRIGHT",-24,54);return p end
    local p1=MakePage();pages[1]=p1;MakeCheck(p1,"自動賣垃圾","sellJunk",-4);MakeCheck(p1,"自動修理","autoRepair",-42);MakeCheck(p1,"郵箱加強","mailEnhance",-80)
    local p2=MakePage();pages[2]=p2;MakeCheck(p2,"商人／其他視窗可移動","movableWindows",-4);MakeCheck(p2,"背包可移動／放大／縮小","movableBag",-42);MakeCheck(p2,"地圖上小按鈕收納","minimapCollector",-80)

    local reset=CreateFrame("Button",nil,f,"MainMenuFrameButtonTemplate");reset:SetSize(155,32);reset:SetPoint("BOTTOMLEFT",body,"BOTTOMLEFT",14.5,33);reset:SetText("恢復預設");SetButtonWhiteText(reset)
    reset:SetScript("OnClick",function()
        PlaySound(856);for k,v in pairs(defaults) do if type(v)~="table" then FEASY_DB[k]=v end end
        FEASY_DB.panelX=-400;FEASY_DB.panelY=0;f:ClearAllPoints();f:SetPoint("CENTER",UIParent,"CENTER",-400,0)
        for _,c in ipairs(checkboxes) do c.Refresh() end;SetCollectorEnabled(true);if mailToggle then mailToggle:Show() end
    end)
    local done=CreateFrame("Button",nil,f,"MainMenuFrameButtonTemplate");done:SetSize(155,32);done:SetPoint("BOTTOMRIGHT",body,"BOTTOMRIGHT",-25,33);done:SetText("設定完成");SetButtonWhiteText(done);done:SetScript("OnClick",function() PlaySound(856);f:Hide() end)
    f:SetScript("OnShow",function() PlaySound(850);for _,c in ipairs(checkboxes) do c.Refresh() end;SelectPage(1) end);f:SetScript("OnHide",function() PlaySound(850) end)
    f:Hide();tinsert(UISpecialFrames,"FEASY_MainFrame");SelectPage(1)
end
local function ToggleMain() CreateMain();if main.frame:IsShown() then main.frame:Hide() else main.frame:Show() end end

-- FXP v0.63 標準小地圖按鈕外觀：31x31、20x20 圖示、53x53 原生外框。
local function ApplyFXPMinimapStyle(b)
    if not b or b.FEASYFXPStyle then return end
    b:SetSize(31,31)
    if b.icon then b.icon:ClearAllPoints();b.icon:SetSize(20,20);b.icon:SetPoint("CENTER",b,"CENTER",1,0);b.icon:SetTexture(3586269);b.icon:SetTexCoord(.07,.93,.07,.93) end
    local ring=b:CreateTexture(nil,"OVERLAY");ring:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder");ring:SetSize(53,53);ring:SetPoint("TOPLEFT",b,"TOPLEFT",0,0)
    b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight");local hl=b:GetHighlightTexture();if hl then hl:SetSize(31,31);hl:ClearAllPoints();hl:SetPoint("CENTER") end
    b.FEASYFXPStyle=true
end
local function SetupMainMini()
    if not LDB or not DBIcon then return end
    local o=LDB:NewDataObject("FEASY",{type="launcher",text="FEASY",icon=3586269,OnClick=function(_,btn) if btn=="LeftButton" then ToggleMain() end end,OnTooltipShow=function(tt) tt:AddLine("老哥UI｜便利工具｜FEASY");tt:AddLine("左鍵：開啟/關閉設定",1,1,1) end})
    if not DBIcon:IsRegistered("FEASY") then DBIcon:Register("FEASY",o,FEASY_DB.minimap) end;ApplyFXPMinimapStyle(DBIcon:GetMinimapButton("FEASY"))
end

local E=CreateFrame("Frame");E:RegisterEvent("ADDON_LOADED");E:RegisterEvent("PLAYER_LOGIN");E:RegisterEvent("MERCHANT_SHOW");E:RegisterEvent("MAIL_SHOW");E:RegisterEvent("MAIL_CLOSED")
E:SetScript("OnEvent",function(_,event,arg)
    if event=="ADDON_LOADED" and arg==ADDON then InitDB();NormalizeMail();CreateMain()
    elseif event=="PLAYER_LOGIN" then
        InitDB();SetupMainMini();SetupCollector();ApplyFXPMinimapStyle(UButton);SetCollectorEnabled(FEASY_DB.minimapCollector);ScanMovableWindows();SetupBag();C_Timer.After(2,function() ScanMovableWindows();SetupBag();ScanMini() end);C_Timer.After(6,function() ScanMovableWindows();ScanMini() end)
    elseif event=="MERCHANT_SHOW" then SellSafeGrayItems();Repair();ScanMovableWindows();if MerchantFrame and FEASY_DB.movableWindows then RestoreWindow(MerchantFrame);C_Timer.After(0,function() RestoreWindow(MerchantFrame) end) end
    elseif event=="MAIL_SHOW" then
        if FEASY_DB.mailEnhance then SetupMailToggle();if mailToggle then mailToggle:Show() end;HookInbox() else if mailToggle then mailToggle:Hide() end end
        ScanMovableWindows();if MailFrame and FEASY_DB.movableWindows then RestoreWindow(MailFrame);C_Timer.After(0,function() RestoreWindow(MailFrame) end) end
    elseif event=="MAIL_CLOSED" then if mailPanel then mailPanel:Hide() end
    end
end)
SLASH_FEASY1="/feasy";SlashCmdList.FEASY=function() ToggleMain() end
