FXP v0.11
1. 修正 v0.10 標準 DBIcon 按鈕半徑過小，X 現在定位於 Minimap 外圈。
2. FXP 設定視窗加入 WoW 原生 UISpecialFrames，按 ESC 可關閉。
3. 保留 v0.10 LDB / DBIcon 標準註冊與其餘全部功能。
