local MAJOR,MINOR="LibStub",2
local L=_G[MAJOR]
if not L or (L.minor or 0)<MINOR then
 L=L or {libs={},minors={}};_G[MAJOR]=L;L.minor=MINOR
 function L:NewLibrary(major,minor)
  minor=tonumber(tostring(minor):match("%d+")) or 0
  local old=self.minors[major];if old and old>=minor then return nil end
  self.minors[major]=minor;self.libs[major]=self.libs[major] or {};return self.libs[major],old
 end
 function L:GetLibrary(major,silent)
  if not self.libs[major] and not silent then error("Cannot find library "..tostring(major),2) end
  return self.libs[major],self.minors[major]
 end
 function L:IterateLibraries() return pairs(self.libs) end
 setmetatable(L,{__call=L.GetLibrary})
end
