local I=LibStub:NewLibrary("LibDBIcon-1.0",100)
if not I then return end
I.objects=I.objects or {};I.data=I.data or {}
local function place(b,db)
 local a=math.rad((db and db.minimapPos) or 225);local r=math.max(Minimap:GetWidth() or 140,Minimap:GetHeight() or 140)/2+18
 b:ClearAllPoints();b:SetPoint("CENTER",Minimap,"CENTER",math.cos(a)*r,math.sin(a)*r)
end
local function make(name,obj,db)
 local b=CreateFrame("Button","LibDBIcon10_"..name,Minimap)
 b:SetSize(31,31);b:SetFrameStrata("MEDIUM");b:SetFrameLevel((Minimap:GetFrameLevel() or 0)+5)
 b:RegisterForClicks("anyUp");b:RegisterForDrag("LeftButton");b.dataObject=obj;b.db=db
 local icon=b:CreateTexture(nil,"ARTWORK");icon:SetAllPoints();icon:SetTexture(obj.icon);b.icon=icon
 b:SetScript("OnClick",function(self,button) if obj.OnClick then obj.OnClick(self,button) end end)
 b:SetScript("OnEnter",function(self)
  if obj.OnTooltipShow then GameTooltip:SetOwner(self,"ANCHOR_LEFT");obj.OnTooltipShow(GameTooltip);GameTooltip:Show()
  elseif obj.OnEnter then obj.OnEnter(self) end
 end)
 b:SetScript("OnLeave",function(self) GameTooltip:Hide();if obj.OnLeave then obj.OnLeave(self) end end)
 b:SetScript("OnDragStart",function(self)
  if db and db.lock then return end
  self:SetScript("OnUpdate",function()
   local mx,my=Minimap:GetCenter();local x,y=GetCursorPosition();local s=UIParent:GetEffectiveScale()
   x,y=x/s,y/s;local a=math.deg(math.atan2(y-my,x-mx))%360
   if db then db.minimapPos=a end;place(self,db)
  end)
 end)
 b:SetScript("OnDragStop",function(self) self:SetScript("OnUpdate",nil) end)
 place(b,db);if db and db.hide then b:Hide() else b:Show() end;I.objects[name]=b;return b
end
function I:Register(name,obj,db) if not self.objects[name] then self.data[name]={obj=obj,db=db};make(name,obj,db) end end
function I:IsRegistered(name) return self.objects[name]~=nil end
function I:GetMinimapButton(name) return self.objects[name] end
function I:Hide(name) if self.objects[name] then self.objects[name]:Hide() end end
function I:Show(name) if self.objects[name] then self.objects[name]:Show();place(self.objects[name],self.objects[name].db) end end
function I:Refresh(name,db)
 local b=self.objects[name];if not b then return end;if db then b.db=db;self.data[name].db=db end
 place(b,b.db);if b.db and b.db.hide then b:Hide() else b:Show() end
end
function I:Lock(name) local b=self.objects[name];if b and b.db then b.db.lock=true end end
function I:Unlock(name) local b=self.objects[name];if b and b.db then b.db.lock=nil end end
