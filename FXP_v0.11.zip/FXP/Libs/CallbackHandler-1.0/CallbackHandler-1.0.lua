local C=LibStub:NewLibrary("CallbackHandler-1.0",8)
if not C then return end
function C:New(target,reg,unreg,unregall)
 reg=reg or "RegisterCallback";unreg=unreg or "UnregisterCallback";unregall=unregall or "UnregisterAllCallbacks"
 local events={};local registry={}
 target[reg]=function(self,event,method)
  events[event]=events[event] or {}
  if type(method)=="string" then events[event][self]=function(...) return self[method](self,...) end
  elseif type(method)=="function" then events[event][self]=method
  else events[event][self]=function(...) return self[event](self,...) end end
 end
 target[unreg]=function(self,event) if events[event] then events[event][self]=nil end end
 target[unregall]=function(self) for _,t in pairs(events) do t[self]=nil end end
 function registry:Fire(event,...)
  local t=events[event];if not t then return end
  for _,fn in pairs(t) do if type(fn)=="function" then fn(event,...) end end
 end
 return registry
end
