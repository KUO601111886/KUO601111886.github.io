local L=LibStub:NewLibrary("LibDataBroker-1.1",4)
if not L then return end
L.objects=L.objects or {};L.callbacks=L.callbacks or LibStub("CallbackHandler-1.0"):New(L)
function L:NewDataObject(name,obj)
 if self.objects[name] then return self.objects[name] end
 obj=obj or {};self.objects[name]=obj;self.callbacks:Fire("LibDataBroker_DataObjectCreated",name,obj);return obj
end
function L:GetDataObjectByName(name) return self.objects[name] end
function L:DataObjectIterator() return pairs(self.objects) end
function L:GetNameByDataObject(o) for n,v in pairs(self.objects) do if v==o then return n end end end
