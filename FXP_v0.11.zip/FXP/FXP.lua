local ADDON=...
FXPDB=FXPDB or {}

local DEF={
 shown=true,locked=false,bgMode=1,halfAlpha=.55,border=true,
 showXP=true,showBonus=true,minimapAngle=165,sizeMode=1,
 minimap={hide=false,minimapPos=165}
}
local function InitDB()
 for k,v in pairs(DEF) do
  if FXPDB[k]==nil then
   if type(v)=="table" then FXPDB[k]={} for a,b in pairs(v) do FXPDB[k][a]=b end
   else FXPDB[k]=v end
  end
 end
 FXPDB.minimap=FXPDB.minimap or {hide=false,minimapPos=FXPDB.minimapAngle or 165}
end

local function comma(n)
 local s=tostring(math.floor(tonumber(n) or 0)); local o=""
 while #s>3 do o=","..s:sub(-3)..o;s=s:sub(1,-4) end
 return s..o
end

-- ===== 主資訊框 =====
local f=CreateFrame("Frame","FXPFrame",UIParent,"BackdropTemplate")
f:SetFrameStrata("MEDIUM");f:SetClampedToScreen(true);f:SetMovable(true);f:EnableMouse(true);f:RegisterForDrag("LeftButton")
f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})

local text=f:CreateFontString(nil,"OVERLAY","GameFontNormal")
text:SetPoint("CENTER");text:SetJustifyH("CENTER")

local SIZES={
 [1]={h=36,font=15,pad=30},
 [2]={h=40,font=16,pad=34},
 [3]={h=50,font=20,pad=44},
}

local function ApplySize()
 local s=SIZES[tonumber(FXPDB.sizeMode) or 1] or SIZES[1]
 f:SetHeight(s.h)
 local fontPath,_,flags=text:GetFont()
 text:SetFont(fontPath,s.font,flags)
end

local function ApplyLook()
 local mode=tonumber(FXPDB.bgMode) or 1
 local a=1
 if mode==2 then a=.55
 elseif mode==3 then a=0 end
 -- 全黑就是 RGB 0,0,0 + Alpha 1.0
 f:SetBackdropColor(0,0,0,a)
 if FXPDB.border then f:SetBackdropBorderColor(.47,.43,.26,.78)
 else f:SetBackdropBorderColor(0,0,0,0) end
end

local function UpdateText()
 local p={}
 if FXPDB.showXP then p[#p+1]="|cffffffff"..comma(UnitXP("player") or 0).." / "..comma(UnitXPMax("player") or 0).."|r" end
 if FXPDB.showBonus then
  local rested=GetXPExhaustion and GetXPExhaustion()
  local pct=(rested and rested>0) and 200 or 100
  p[#p+1]="|cffffd100FXP|r |cff40ff40"..pct.."%|r"
 end
 if #p==0 then p[1]="|cffaaaaaaFXP|r" end
 text:SetText(table.concat(p,"  |cff777777│|r  "))
 local s=SIZES[tonumber(FXPDB.sizeMode) or 1] or SIZES[1]
 f:SetWidth(math.max(165,text:GetStringWidth()+s.pad))
end

f:SetScript("OnDragStart",function(s)if not FXPDB.locked then s:StartMoving()end end)
f:SetScript("OnDragStop",function(s)
 s:StopMovingOrSizing()
 local p,_,rp,x,y=s:GetPoint(1);FXPDB.point=p;FXPDB.relPoint=rp;FXPDB.x=x;FXPDB.y=y
end)
local function RestoreMain()
 f:ClearAllPoints()
 if FXPDB.point then f:SetPoint(FXPDB.point,UIParent,FXPDB.relPoint or FXPDB.point,FXPDB.x or 0,FXPDB.y or 0)
 else f:SetPoint("CENTER",UIParent,"CENTER",0,160) end
end

-- ===== FWT風格設定視窗 =====
local cfg=CreateFrame("Frame","FXPSettingsFrame",UIParent,"BackdropTemplate")
table.insert(UISpecialFrames,"FXPSettingsFrame")
cfg:SetSize(430,405);cfg:SetPoint("CENTER");cfg:SetFrameStrata("DIALOG");cfg:SetMovable(true);cfg:EnableMouse(true);cfg:RegisterForDrag("LeftButton");cfg:Hide()
cfg:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
cfg:SetBackdropColor(.045,.055,.06,.98);cfg:SetBackdropBorderColor(.48,.43,.18,.95)
cfg:SetScript("OnDragStart",cfg.StartMoving);cfg:SetScript("OnDragStop",cfg.StopMovingOrSizing)
local title=cfg:CreateFontString(nil,"OVERLAY","GameFontNormalLarge");title:SetPoint("TOPLEFT",20,-18);title:SetText("|cffffd100FXP 經驗顯示 - BY 老哥|r")
local close=CreateFrame("Button",nil,cfg,"UIPanelCloseButton");close:SetPoint("TOPRIGHT",-3,-3)

local function section(label,y)
 local t=cfg:CreateTexture(nil,"ARTWORK");t:SetColorTexture(.16,.27,.38,1);t:SetPoint("TOPLEFT",18,y);t:SetPoint("TOPRIGHT",-18,y);t:SetHeight(26)
 local s=cfg:CreateFontString(nil,"OVERLAY","GameFontNormal");s:SetPoint("LEFT",t,"LEFT",11,0);s:SetText("|cffffd100"..label.."|r")
end
section("顯示設定",-52)

local function Check(label,y,key,fn)
 local c=CreateFrame("CheckButton",nil,cfg,"UICheckButtonTemplate");c:SetPoint("TOPLEFT",22,y);c.text:SetText(label)
 c:SetScript("OnClick",function(self)FXPDB[key]=self:GetChecked() and true or false;if fn then fn()end end)
 c.Refresh=function()c:SetChecked(FXPDB[key] and true or false)end
 return c
end
local cShown=Check("顯示 FXP 資訊框",-90,"shown",function()if FXPDB.shown then f:Show()else f:Hide()end end)
local cXP=Check("顯示目前經驗值 / 升級經驗值",-122,"showXP",UpdateText)
local cBonus=Check("顯示經驗加成百分比",-154,"showBonus",UpdateText)
local cBorder=Check("顯示淡色細邊框",-186,"border",ApplyLook)
local cLock=Check("鎖定資訊框位置",-218,"locked")

section("外觀設定",-254)

local bgLab=cfg:CreateFontString(nil,"OVERLAY","GameFontNormal");bgLab:SetPoint("TOPLEFT",24,-294);bgLab:SetText("|cffffd100背景：|r")
local function Button(label,x,y,w,fn)
 local b=CreateFrame("Button",nil,cfg,"UIPanelButtonTemplate");b:SetSize(w or 88,25);b:SetPoint("TOPLEFT",x,y);b:SetText(label);b:SetScript("OnClick",fn);return b
end
Button("全黑",88,-286,88,function()FXPDB.bgMode=1;ApplyLook()end)
Button("半透明",182,-286,88,function()FXPDB.bgMode=2;ApplyLook()end)
Button("透明",276,-286,88,function()FXPDB.bgMode=3;ApplyLook()end)

local szLab=cfg:CreateFontString(nil,"OVERLAY","GameFontNormal");szLab:SetPoint("TOPLEFT",24,-330);szLab:SetText("|cffffd100資訊框大小：|r")
local function setSize(n)FXPDB.sizeMode=n;ApplySize();UpdateText()end
Button("小",122,-322,70,function()setSize(1)end)
Button("中",198,-322,70,function()setSize(2)end)
Button("大",274,-322,70,function()setSize(3)end)

local reset=Button("重設位置",22,-365,105,function()FXPDB.point=nil;FXPDB.relPoint=nil;FXPDB.x=nil;FXPDB.y=nil;RestoreMain()end)
local done=Button("完成",318,-365,90,function()cfg:Hide()end)

local function RefreshCfg()
 cShown.Refresh();cXP.Refresh();cBonus.Refresh();cBorder.Refresh();cLock.Refresh()
end
cfg:SetScript("OnShow",RefreshCfg)

-- ===== Minimap button =====
-- 優先使用 LibDataBroker + LibDBIcon 標準註冊。
-- 這是常見 Minimap Button Bag / 收納器相容路徑。
-- 若永恆服沒有這些函式庫，才回退成 FWT 同款本機小地圖按鈕，不報錯。
local mini

local function OpenSettings()
 if cfg:IsShown()then cfg:Hide()else cfg:Show()end
end
local function ToggleFrame()
 FXPDB.shown=not FXPDB.shown;if FXPDB.shown then f:Show()else f:Hide()end
end

local function SetupStandardMinimap()
 local LibStub=_G.LibStub
 if not LibStub then return false end
 local LDB=LibStub("LibDataBroker-1.1",true)
 local DBIcon=LibStub("LibDBIcon-1.0",true)
 if not LDB or not DBIcon then return false end
 local obj=LDB:NewDataObject("FXP",{
  type="launcher",
  text="FXP",
  icon="Interface\\AddOns\\FXP\\FXP_X.tga",
  OnClick=function(_,button)if button=="RightButton"then ToggleFrame()else OpenSettings()end end,
  OnTooltipShow=function(tt)
   tt:AddLine("FXP - BY 老哥")
   tt:AddLine("左鍵：開啟設定",1,1,1);tt:AddLine("右鍵：顯示 / 隱藏資訊框",1,1,1)
  end
 })
 if not DBIcon:IsRegistered("FXP") then DBIcon:Register("FXP",obj,FXPDB.minimap) end
 return true
end

local function SetupFallbackMinimap()
 mini=CreateFrame("Button","FXPMinimapButton",Minimap)
 mini:SetSize(38,38);mini:SetFrameStrata("MEDIUM");mini:SetFrameLevel((Minimap:GetFrameLevel()or 0)+8)
 mini:RegisterForClicks("LeftButtonUp","RightButtonUp");mini:RegisterForDrag("LeftButton")
 local ic=mini:CreateTexture(nil,"ARTWORK");ic:SetAllPoints();ic:SetTexture("Interface\\AddOns\\FXP\\FXP_X.tga")
 local function Pos()
  local r=math.max(Minimap:GetWidth()or 140,Minimap:GetHeight()or 140)/2+18
  local a=math.rad(FXPDB.minimapAngle or 165);mini:ClearAllPoints();mini:SetPoint("CENTER",Minimap,"CENTER",math.cos(a)*r,math.sin(a)*r)
 end
 local dragging=false
 mini:SetScript("OnDragStart",function(self)
  dragging=true;self:SetScript("OnUpdate",function()
   local mx,my=Minimap:GetCenter();if not mx then return end
   local x,y=GetCursorPosition();local sc=UIParent:GetEffectiveScale();x,y=x/sc,y/sc
   FXPDB.minimapAngle=math.deg(math.atan2(y-my,x-mx));Pos()
  end)
 end)
 mini:SetScript("OnDragStop",function(self)self:SetScript("OnUpdate",nil);Pos();C_Timer.After(.1,function()dragging=false end)end)
 mini:SetScript("OnClick",function(_,button)if dragging then return end;if button=="RightButton"then ToggleFrame()else OpenSettings()end end)
 mini:SetScript("OnEnter",function(self)GameTooltip:SetOwner(self,"ANCHOR_LEFT");GameTooltip:SetText("FXP - BY 老哥");GameTooltip:AddLine("左鍵：開啟設定",1,1,1);GameTooltip:AddLine("右鍵：顯示 / 隱藏資訊框",1,1,1);GameTooltip:Show()end)
 mini:SetScript("OnLeave",function()GameTooltip:Hide()end)
 Pos()
end

local ev=CreateFrame("Frame")
for _,e in ipairs({"PLAYER_LOGIN","PLAYER_XP_UPDATE","UPDATE_EXHAUSTION","PLAYER_LEVEL_UP"})do ev:RegisterEvent(e)end
ev:SetScript("OnEvent",function(_,e)
 if e=="PLAYER_LOGIN"then
  InitDB();RestoreMain();ApplySize();ApplyLook()
  if FXPDB.shown then f:Show()else f:Hide()end
  if not SetupStandardMinimap() then SetupFallbackMinimap() end
 end
 UpdateText()
end)

SLASH_FXP1="/fxp"
SlashCmdList["FXP"]=function(msg)
 msg=(msg or ""):lower():match("^%s*(.-)%s*$")
 if msg=="show"then FXPDB.shown=true;f:Show()
 elseif msg=="hide"then FXPDB.shown=false;f:Hide()
 elseif msg=="reset"then FXPDB.point=nil;FXPDB.relPoint=nil;FXPDB.x=nil;FXPDB.y=nil;RestoreMain()
 else OpenSettings()end
end
