local ADDON=...
FXPDB=FXPDB or {}

local DEF={
 shown=true,locked=false,bgMode=1,halfAlpha=.55,border=true,
 showXP=true,showBonus=true,showLayer=true,minimapAngle=165,sizeMode=1,
 minimap={hide=false,minimapPos=165}
}
local function InitDB()
 for k,v in pairs(DEF) do
  if FXPDB[k]==nil then
   if type(v)=="table" then FXPDB[k]={} for a,b in pairs(v) do FXPDB[k][a]=b end
   else FXPDB[k]=v end
  end
 end
 FXPDB.minimap=FXPDB.minimap or {hide=false,minimapPos=FXPDB.minimapAngle or 165}
end

local function comma(n)
 local s=tostring(math.floor(tonumber(n) or 0)); local o=""
 while #s>3 do o=","..s:sub(-3)..o;s=s:sub(1,-4) end
 return s..o
end

-- ===== 主資訊框 =====
local f=CreateFrame("Frame","FXPFrame",UIParent,"BackdropTemplate")
f:SetFrameStrata("MEDIUM");f:SetClampedToScreen(true);f:SetMovable(true);f:EnableMouse(true);f:RegisterForDrag("LeftButton")
f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})

local text=f:CreateFontString(nil,"OVERLAY","GameFontNormal")
text:SetPoint("CENTER");text:SetJustifyH("CENTER")

local function BarHeight()
 return math.max(30,math.min(45,math.floor((tonumber(FXPDB.barHeight) or 30)+.5)))
end

local function ApplySize()
 local h=BarHeight()
 f:SetHeight(h)
 local fontPath,_,flags=text:GetFont()
 text:SetFont(fontPath,math.floor(h*.4+.5),flags)
end

local function ApplyLook()
 local mode=tonumber(FXPDB.bgMode) or 1
 local a=1
 if mode==2 then a=.55
 elseif mode==3 then a=0 end
 -- 全黑就是 RGB 0,0,0 + Alpha 1.0
 f:SetBackdropColor(0,0,0,a)
 if FXPDB.border then f:SetBackdropBorderColor(.47,.43,.26,.78)
 else f:SetBackdropBorderColor(0,0,0,0) end
end

local currentLayer
local latencyHome,latencyWorld,fps,addonMemory,addonCPU=0,0,0,"--","無資料"
local nextFPSAlertAt=0
local function YellowNotice(message)
 if DEFAULT_CHAT_FRAME then
  DEFAULT_CHAT_FRAME:AddMessage("[FXP] "..message,1,.82,0)
 else
  print("|cffffd100[FXP] "..message.."|r")
 end
end
local function CheckFPSAlert()
 if fps<=0 or fps>=30 then return end
 local now=GetTime and GetTime() or 0
 if now>=nextFPSAlertAt then
  YellowNotice("幀數低於 30，請注意")
  nextFPSAlertAt=now+60
 end
end
local function RefreshPerformance()
 if GetNetStats then
  local _,_,home,world=GetNetStats()
  latencyHome=tonumber(home) or 0;latencyWorld=tonumber(world) or 0
 end
 if GetFramerate then fps=math.floor((tonumber(GetFramerate()) or 0)+.5) end
 if UpdateAddOnMemoryUsage and GetAddOnMemoryUsage then
  local ok,total=pcall(function()
   UpdateAddOnMemoryUsage()
   local count=(C_AddOns and C_AddOns.GetNumAddOns and C_AddOns.GetNumAddOns())
    or (GetNumAddOns and GetNumAddOns()) or 0
   local n=0
   for i=1,count do n=n+(tonumber(GetAddOnMemoryUsage(i)) or 0) end
   return n
  end)
  if ok then
   addonMemory=(total>=1024) and string.format("%.1f MB",total/1024)
    or string.format("%.0f KB",total)
  end
 end
 -- Prefer the same already-formatted overall percentage used by Blizzard's
 -- performance tooltip. This API may not be present on every Forever build.
 addonCPU="無資料"
 if AddonList and AddonList.GetOverallMetric and Enum and Enum.AddOnProfilerMetric
  and ADDON_LIST_PERFORMANCE_AVERAGE_CPU then
  local ok,result=pcall(AddonList.GetOverallMetric,AddonList,
   ADDON_LIST_PERFORMANCE_AVERAGE_CPU,Enum.AddOnProfilerMetric.SessionAverageTime)
  if ok and type(result)=="string" then
   local percent=result:match("([%d%.]+)%s*%%")
   if percent then addonCPU=percent.."%" end
  end
 end
 if addonCPU=="無資料" and C_AddOnProfiler and C_AddOnProfiler.GetOverallMetric
  and Enum and Enum.AddOnProfilerMetric then
  local ok,ms=pcall(C_AddOnProfiler.GetOverallMetric,
   Enum.AddOnProfilerMetric.SessionAverageTime)
  if ok and type(ms)=="number" then
   addonCPU=string.format("%.2f ms/幀",ms)
  end
 end
end
local function LayerFromGUID(guid)
 if not guid or type(guid)~="string" then return nil end
 local kind,_,_,_,zoneUID=strsplit("-",guid)
 if (kind~="Creature" and kind~="Vehicle") or not zoneUID then return nil end
 return tonumber(zoneUID)
end

local function DetectLayer()
 if IsInInstance and IsInInstance() then
  currentLayer=nil
  return
 end
 local units={"target","mouseover","focus","softenemy","softfriend","softinteract"}
 local layer
 for _,unit in ipairs(units) do
  if UnitExists(unit) and not UnitIsPlayer(unit) then
   layer=LayerFromGUID(UnitGUID(unit))
   if layer then break end
  end
 end
 if not layer then return end
 if currentLayer and currentLayer~=layer then
  YellowNotice("位面變更："..tostring(currentLayer).." → "..tostring(layer))
 end
 currentLayer=layer
end

local function UpdateText()
 local parts={
  "|cffffd100延遲|r |cffffffff（本地"..latencyHome.." ms）（世界"..latencyWorld.." ms）|r",
  "|cffffd100幀數|r |cffffffff"..fps.."|r",
  "|cffffd100記憶體|r |cffffffff"..addonMemory.."|r",
  "|cffffd100插件CPU|r |cffffffff"..addonCPU.."|r"
 }
 if FXPDB.showXP then
  parts[#parts+1]="|cffffd100經驗|r |cffffffff"..comma(UnitXP("player") or 0).." / "..comma(UnitXPMax("player") or 0).."|r"
 end
 if FXPDB.showBonus then
  local rested=GetXPExhaustion and GetXPExhaustion()
  local pct=(rested and rested>0) and 200 or 100
  parts[#parts+1]="|cffffd100加成|r |cff40ff40"..pct.."%|r"
 end
 if FXPDB.showLayer then
  local layer=currentLayer and tostring(currentLayer) or "請點NPC或怪"
  parts[#parts+1]="|cffffd100位面|r |cffffffff"..layer.."|r"
 end
 local localTime=date and date("%H:%M") or "--:--"
 parts[#parts+1]="|cffffd100時間|r |cffffffff"..localTime.."|r"
 text:SetText(table.concat(parts,"  |cffaaaaaa｜|r  "))
 local h=BarHeight()
 local fontSize=math.floor(h*.4+.5)
 local pad=math.floor(h*.8+.5)
 local fontPath,_,flags=text:GetFont()
 local maxWidth=math.max(250,UIParent:GetWidth()-24)
 for font=fontSize,9,-1 do
  text:SetFont(fontPath,font,flags)
  if text:GetStringWidth()+pad<=maxWidth then break end
 end
 f:SetWidth(math.min(maxWidth,text:GetStringWidth()+pad))
end

f:SetScript("OnDragStart",function(s)if not FXPDB.locked then s:StartMoving()end end)
f:SetScript("OnDragStop",function(s)
 s:StopMovingOrSizing()
 local p,_,rp,x,y=s:GetPoint(1);FXPDB.point=p;FXPDB.relPoint=rp;FXPDB.x=x;FXPDB.y=y
end)
local function RestoreMain()
 f:ClearAllPoints()
 if FXPDB.point then f:SetPoint(FXPDB.point,UIParent,FXPDB.relPoint or FXPDB.point,FXPDB.x or 0,FXPDB.y or 0)
 else f:SetPoint("TOP",UIParent,"TOP",0,-5) end
end

local function Load(name)
    if C_AddOns and C_AddOns.LoadAddOn then
        pcall(C_AddOns.LoadAddOn, name)
    elseif LoadAddOn then
        pcall(LoadAddOn, name)
    end
end
Load("Blizzard_GroupFinder")
Load("Blizzard_LFGVanilla")

local cfg = CreateFrame("Frame", "FXPSettingsFrame", UIParent, "PortraitFrameTemplate")
cfg:SetSize(530, 540)
cfg:SetPoint("CENTER", UIParent, "CENTER", FXPDB.panelX or -400, FXPDB.panelY or 0)
cfg:SetFrameStrata("DIALOG")
cfg:SetClampedToScreen(true)
cfg:SetMovable(true)
cfg:EnableMouse(true)
cfg:RegisterForDrag("LeftButton")
cfg:SetScript("OnDragStart", cfg.StartMoving)
cfg:SetScript("OnDragStop", cfg.StopMovingOrSizing)

local portrait = (cfg.PortraitContainer and cfg.PortraitContainer.portrait) or cfg.portrait or cfg.Portrait
if portrait then portrait:SetTexture(3586269) end
local title = (cfg.TitleContainer and cfg.TitleContainer.TitleText) or cfg.TitleText
if title then title:SetText("ABC") end
if cfg.Inset then cfg.Inset:Hide() end
-- 隱藏 ABCFrame 自身全框底圖，讓 body.Bg 的 85% 真正透出遊戲畫面。
if cfg.Bg and cfg.Bg.Hide then
    cfg.Bg:Hide()
end

local function atlas(tex, name)
    if not tex or not tex.SetAtlas then return false end
    return pcall(tex.SetAtlas, tex, name, false)
end

-- 上方原生棕色區（原版職責區背景）
local top = CreateFrame("Frame", nil, cfg)
top:SetPoint("TOPLEFT", cfg, "TOPLEFT", 2, -23)
top:SetPoint("TOPRIGHT", cfg, "TOPRIGHT", -2, -23)
-- 上方只保留 UI 名稱／資訊區
top:SetHeight(76)

local topBG = top:CreateTexture(nil, "BACKGROUND")
topBG:SetAllPoints(top)
if not atlas(topBG, "groupfinder-roles-background") then
    topBG:SetTexture(8373327)
end

local streak = top:CreateTexture(nil, "BORDER")
streak:SetPoint("TOPLEFT", top, "TOPLEFT", 0, 0)
streak:SetPoint("TOPRIGHT", top, "TOPRIGHT", 0, 0)
streak:SetHeight(43)
if not atlas(streak, "UI-Frame-TopTileStreaks") then
    streak:SetTexture(1723833)
end

-- 下方主要區域：直接使用 AutoLayer 同款的 WoW 原生 InsetFrameTemplate。
-- 不再使用人物背景拼圖，也不再使用 groupfinder-background。
local body = CreateFrame("Frame", nil, cfg, "InsetFrameTemplate")
body:SetPoint("TOPLEFT", cfg, "TOPLEFT", 3, -100)
body:SetPoint("BOTTOMRIGHT", cfg, "BOTTOMRIGHT", -3, 3)
-- /fstack 實機確認：InsetFrameTemplate 真正石紋背景為 body.Bg。
-- 只調石紋到 95%，不動框線、四角花紋與分隔線。
if body.Bg and body.Bg.SetAlpha then
    body.Bg:SetAlpha(0.90)
if body.TopEdge then
    body.TopEdge:Hide()
end
end

-- 疊回 LFG 原生內框裝飾：四角小花紋
local inside = body:CreateTexture(nil, "BORDER", nil, 1)
-- 保留 common-insideframe 四角花紋；頂端往上 5 UI，讓原本的頂線藏在主分隔線下。
inside:SetPoint("TOPLEFT", body, "TOPLEFT", 0, 5)
inside:SetPoint("TOPRIGHT", body, "TOPRIGHT", 0, 5)
inside:SetPoint("BOTTOMLEFT", body, "BOTTOMLEFT", 0, 0)
inside:SetPoint("BOTTOMRIGHT", body, "BOTTOMRIGHT", 0, 0)
if not atlas(inside, "common-insideframe") then
    inside:SetTexture(8124462)
end

-- 分隔線：位置、厚度完全不動；只提高圖層，讓上半部不再被 body 遮住。
local dividerLayer = CreateFrame("Frame", nil, cfg)
dividerLayer:SetAllPoints(cfg)
dividerLayer:SetFrameStrata(cfg:GetFrameStrata())
dividerLayer:SetFrameLevel(math.max(cfg:GetFrameLevel(), body:GetFrameLevel()) + 20)

local divider = dividerLayer:CreateTexture(nil, "OVERLAY", nil, 7)
divider:SetSize(16, 524)
divider:SetPoint("CENTER", cfg, "TOP", 0, -95)
local dividerAtlasOK = atlas(divider, "common-framedivider")
if not dividerAtlasOK then divider:SetTexture(8245174) end
divider:SetTexCoord(0, 1, 0, 1)
if divider.SetRotation then
    divider:SetRotation(math.pi / 2)
end


-- =========================================================
-- FXP 版型：只放已經由遊戲實機抓到的原生元件
-- =========================================================

-- 正式標題（與網站名稱一致）
local title = (cfg.TitleContainer and cfg.TitleContainer.TitleText) or cfg.TitleText
if title then
    title:SetText("")
end

local titleLayer = CreateFrame("Frame", nil, cfg)
titleLayer:SetAllPoints(cfg)
titleLayer:SetFrameStrata(cfg:GetFrameStrata())
titleLayer:SetFrameLevel(math.max(cfg:GetFrameLevel(), body:GetFrameLevel()) + 30)

local mainTitle = titleLayer:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
local titleFont, titleSize, titleFlags = mainTitle:GetFont()
if titleFont and titleSize then
    mainTitle:SetFont(titleFont, titleSize + 2, titleFlags)
end
mainTitle:SetPoint("CENTER", cfg, "TOP", 0, -58)
mainTitle:SetText("老哥UI｜遊戲延遲及位面顯示｜FXP")

-- 左側選單：
-- Blizzard Professions 選取列
-- Atlas: Professions_Recipe_Active / FileID: 4417031
-- 實機抓到原生約 267x19；這裡依版面測試放大高度。
local function CreateRecipeMenu(parent, text)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(150, 48)

    local bg = b:CreateTexture(nil, "BACKGROUND")
    b.bg = bg
    bg:SetAllPoints()
    local ok = pcall(bg.SetAtlas, bg, "Professions_Recipe_Active")
    if not ok then
        bg:SetTexture(4417031)
    end

    local label = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    b.label = label
    label:SetPoint("CENTER", b, "CENTER", 0, 0)
    local menuFont, menuSize, menuFlags = label:GetFont()
    if menuFont and menuSize then
        label:SetFont(menuFont, menuSize + 2, menuFlags or "")
    end
    label:SetText(text)

    return b
end

local menu1 = CreateRecipeMenu(cfg, "監視顯示")
menu1:SetPoint("TOPLEFT", body, "TOPLEFT", 17, -28)

local menu2 = CreateRecipeMenu(cfg, "外觀設定")
menu2:SetPoint("TOPLEFT", menu1, "BOTTOMLEFT", 0, -15)

-- 天賦介面原生垂直分隔線
-- Atlas: Talents-divider-vertical-c60 / FileID: 8116735
-- 實機原生約 2x468；依老哥標示版面縮短。
local verticalDivider = cfg:CreateTexture(nil, "OVERLAY", nil, 7)
verticalDivider:SetSize(2, 405)
verticalDivider:SetPoint("TOP", body, "TOPLEFT", 183, -35)
local vOK = pcall(verticalDivider.SetAtlas, verticalDivider, "Talents-divider-vertical-c60")
if not vOK then
    verticalDivider:SetTexture(8116735)
end
-- 不覆寫 Atlas 自己的 TexCoord，避免上一版把素材壓成不可見。



cfg:Hide()
table.insert(UISpecialFrames, "FXPSettingsFrame")
cfg:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local x,y=self:GetCenter(); local ux,uy=UIParent:GetCenter()
    if x and y and ux and uy then FXPDB.panelX=x-ux; FXPDB.panelY=y-uy end
end)

-- ===== FXP 真實功能套入 ABC v0.34 外觀 =====
local pages = {}
local selectedPage = 1

local function SetMenuState(button, selected)
    if not button or not button.bg then return end
    if selected then
        button.bg:SetAlpha(1)
        button.label:SetTextColor(1, .82, 0)
    else
        button.bg:SetAlpha(.18)
        button.label:SetTextColor(.90, .88, .82)
    end
end

local function SelectPage(index)
    selectedPage=index
    for i,p in ipairs(pages) do p:SetShown(i==index) end
    SetMenuState(menu1,index==1)
    SetMenuState(menu2,index==2)
end

-- Give the tested recipe rows actual normal/hover/selected behavior.
for _,b in ipairs({menu1,menu2}) do
    b:SetScript("OnEnter",function(self)
        if (self==menu1 and selectedPage~=1) or (self==menu2 and selectedPage~=2) then
            self.bg:SetAlpha(.60)
        end
    end)
    b:SetScript("OnLeave",function(self)
        SetMenuState(self,(self==menu1 and selectedPage==1) or (self==menu2 and selectedPage==2))
    end)
end
menu1:SetScript("OnClick",function() PlaySound(856); SelectPage(1) end)
menu2:SetScript("OnClick",function() PlaySound(856); SelectPage(2) end)

local function MakePage()
    local p=CreateFrame("Frame",nil,cfg)
    p:SetPoint("TOPLEFT",body,"TOPLEFT",205,-24)
    p:SetPoint("BOTTOMRIGHT",body,"BOTTOMRIGHT",-24,54)
    return p
end
local display=MakePage(); pages[1]=display
local appearance=MakePage(); pages[2]=appearance

local function Label(parent,content,x,y,template)
    local t=parent:CreateFontString(nil,"OVERLAY",template or "GameFontNormal")
    t:SetPoint("TOPLEFT",x,y);t:SetText(content);return t
end
local function Button(label,parent,x,y,w,fn)
    local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
    b:SetSize(w or 92,32);b:SetPoint("TOPLEFT",x,y);b:SetText(label);b:SetScript("OnClick",fn);return b
end
local function Check(parent,label,x,y,key,fn)
    local c=CreateFrame("CheckButton",nil,parent,"UICheckButtonTemplate")
    c:SetPoint("TOPLEFT",x,y);c.text:ClearAllPoints();c.text:SetPoint("LEFT",c,"RIGHT",4,1);c.text:SetText(label)
    c:SetScript("OnClick",function(self)
        PlaySound(856)
        FXPDB[key]=self:GetChecked() and true or false
        if fn then fn() end
    end)
    c.Refresh=function() c:SetChecked(FXPDB[key] and true or false) end
    return c
end

-- 監視顯示
local cShown=Check(display,"顯示資訊框",0,-4,"shown",function()f:SetShown(FXPDB.shown)end)
local cXP=Check(display,"顯示經驗值 / 升級經驗值",0,-42,"showXP",UpdateText)
local cBonus=Check(display,"顯示經驗加成百分比",0,-80,"showBonus",UpdateText)
local cLayer=Check(display,"顯示目前位面",0,-118,"showLayer",UpdateText)
local cLock=Check(display,"鎖定資訊框位置",0,-156,"locked")

-- 第一頁固定模板：五個選項文字改為純白；座標、行距、勾選框完全不動。
for _,cb in ipairs({cShown,cXP,cBonus,cLayer,cLock}) do
    local fs=cb.Text or cb.text
    if fs then
        local font,size,flags=fs:GetFont()
        if font and size then fs:SetFont(font,size+1,flags or "") end
        fs:SetTextColor(1,1,1,1)
        fs:SetShadowColor(0,0,0,0)
        fs:SetShadowOffset(0,0)
    end
end

-- 外觀設定
-- 座標直接依「老哥UI_FXP_版面配置.json」換算：
-- appearance 的 TOPLEFT = cfg(208,124)
local cBorder=Check(appearance,"顯示淡色細邊框",0,-4,"border",ApplyLook)
do
    local font,size,flags=cBorder.text:GetFont()
    if font and size then cBorder.text:SetFont(font,size+1,flags or "") end
end
cBorder.text:SetTextColor(1,1,1,1)
cBorder.text:SetShadowColor(0,0,0,0)
cBorder.text:SetShadowOffset(0,0)

local bgLabel=Label(appearance,"背景：",5,-71)
do local font,size,flags=cBorder.text:GetFont(); bgLabel:SetFont(font,size,flags or "") end

-- 第二頁背景按鍵：使用 WoW 遊戲選單原生 MainMenuFrameButtonTemplate。
-- 選取：原生正常狀態（紅底、古銅色框、白字）
-- 未選：原生 Disabled 狀態（灰色按鍵、灰字）
-- 位置限制在既有 appearance 可編輯區內；第一行與其他元件不動。
local function AppearanceNativeButton(label,x)
    local b=CreateFrame("Button",nil,appearance,"MainMenuFrameButtonTemplate")
    b:SetSize(95,32)
    b:SetPoint("TOPLEFT",appearance,"TOPLEFT",x,-106)
    b:SetText(label)

    -- 視覺按鍵在未選取時直接使用 Blizzard 原生 Disabled 狀態。
    -- 另放透明點擊層，讓灰色未選按鍵仍可切換。
    local hit=CreateFrame("Button",nil,appearance)
    hit:SetAllPoints(b)
    hit:SetFrameLevel(b:GetFrameLevel()+5)
    b.HitButton=hit
    return b
end

-- 既有可編輯區寬度 295；三顆 110 寬按鍵全部限制在區域內。
-- 不改第一行、背景標題、大小標題與滑桿位置。
local blackButton=AppearanceNativeButton("全黑",0)
local halfButton=AppearanceNativeButton("半透明",100)
local clearButton=AppearanceNativeButton("透明",200)

local function SetAppearanceButtonState(b,selected)
    if selected then
        b:Enable()
    else
        b:Disable()
    end
end
function RefreshAppearanceButtons()
    SetAppearanceButtonState(blackButton,FXPDB.bgMode==1)
    SetAppearanceButtonState(halfButton,FXPDB.bgMode==2)
    SetAppearanceButtonState(clearButton,FXPDB.bgMode==3)
end

blackButton.HitButton:SetScript("OnClick",function() PlaySound(856); FXPDB.bgMode=1;ApplyLook();RefreshAppearanceButtons()end)
halfButton.HitButton:SetScript("OnClick",function() PlaySound(856); FXPDB.bgMode=2;ApplyLook();RefreshAppearanceButtons()end)
clearButton.HitButton:SetScript("OnClick",function() PlaySound(856); FXPDB.bgMode=3;ApplyLook();RefreshAppearanceButtons()end)

local sizeLabel=Label(appearance,"大小：",5,-166)
do local font,size,flags=cBorder.text:GetFont(); sizeLabel:SetFont(font,size,flags or "") end

-- WoW 內建原生 MinimalSliderWithSteppersTemplate
-- 來源：Blizzard_SharedXML/Shared/Slider/MinimalSlider.xml
-- JSON：stage x=215 y=320 w=280 h=30
local heightSlider=CreateFrame("Frame","FXPHeightSlider",appearance,"MinimalSliderWithSteppersTemplate")
heightSlider:SetSize(295,30)
heightSlider:SetPoint("TOPLEFT",appearance,"TOPLEFT",0,-196)

local sliderReady=false
heightSlider:Init(tonumber(FXPDB.barHeight) or 30,30,45,15,nil)
heightSlider:RegisterCallback(MinimalSliderWithSteppersMixin.Event.OnValueChanged,function(_,v)
    if not sliderReady then return end
    local h=math.max(30,math.min(45,math.floor(v+.5)))
    FXPDB.barHeight=h
    ApplySize()
    UpdateText()
end)
sliderReady=true

-- 底部按鈕：依 JSON 的 stage 座標直接定位，不改其他元件。
-- 固定區：原生金邊紅底按鍵；禁止 SetScale。
local function SetButtonWhiteText(b)
    local fs=b:GetFontString()
    if fs then
        local font,size=fs:GetFont()
        fs:SetFont(font,size,"")
        fs:SetTextColor(1,1,1,1)
        fs:SetShadowColor(0,0,0,0)
        fs:SetShadowOffset(0,0)
    end
end
local resetButton=CreateFrame("Button",nil,cfg,"MainMenuFrameButtonTemplate")
resetButton:SetSize(155,32)
resetButton:SetPoint("BOTTOMLEFT",body,"BOTTOMLEFT",14.5,33)
resetButton:SetText("恢復預設")
SetButtonWhiteText(resetButton)
resetButton:SetScript("OnClick",function()
    PlaySound(856)
    FXPDB.point=nil;FXPDB.relPoint=nil;FXPDB.x=nil;FXPDB.y=nil;RestoreMain()
    FXPDB.panelX=-400;FXPDB.panelY=0
    cfg:ClearAllPoints();cfg:SetPoint("CENTER",UIParent,"CENTER",-400,0)
end)
local doneButton=CreateFrame("Button",nil,cfg,"MainMenuFrameButtonTemplate")
doneButton:SetSize(155,32)
doneButton:SetPoint("BOTTOMRIGHT",body,"BOTTOMRIGHT",-25,33)
doneButton:SetText("設定完成")
SetButtonWhiteText(doneButton)
doneButton:SetScript("OnClick",function() PlaySound(856); cfg:Hide() end)

local function RefreshCfg()
    cShown.Refresh();cXP.Refresh();cBonus.Refresh();cLayer.Refresh();cBorder.Refresh();cLock.Refresh()
    RefreshAppearanceButtons()
    if heightSlider.Slider:GetValue()~=BarHeight() then heightSlider:SetValue(BarHeight()) end
    SelectPage(1)
end
cfg:SetScript("OnShow",function()
    PlaySound(850)
    RefreshCfg()
end)
cfg:SetScript("OnHide",function()
    PlaySound(850)
end)
SelectPage(1)

-- ===== Minimap button =====
-- 優先使用 LibDataBroker + LibDBIcon 標準註冊。
-- 這是常見 Minimap Button Bag / 收納器相容路徑。
-- 若永恆服沒有這些函式庫，才回退成 FWT 同款本機小地圖按鈕，不報錯。
local mini

local function OpenSettings()
 if cfg:IsShown()then cfg:Hide()else cfg:Show()end
end
local function ToggleFrame()
 FXPDB.shown=not FXPDB.shown;if FXPDB.shown then f:Show()else f:Hide()end
end

local function SetupStandardMinimap()
 local LibStub=_G.LibStub
 if not LibStub then return false end
 local LDB=LibStub("LibDataBroker-1.1",true)
 local DBIcon=LibStub("LibDBIcon-1.0",true)
 if not LDB or not DBIcon then return false end
 local obj=LDB:NewDataObject("FXP",{
  type="launcher",
  text="FXP",
  icon=3586269,
  OnClick=function(_,button)if button=="RightButton"then ToggleFrame()else OpenSettings()end end,
  OnTooltipShow=function(tt)
   tt:AddLine("老哥UI｜遊戲延遲及位面顯示｜FXP")
   tt:AddLine("左鍵：開啟/關閉設定",1,1,1)
  end
 })
 if not DBIcon:IsRegistered("FXP") then DBIcon:Register("FXP",obj,FXPDB.minimap) end
 local b=DBIcon.GetMinimapButton and DBIcon:GetMinimapButton("FXP")
 if b and not b.FXPStandardRing then
  b:SetSize(31,31)
  if b.icon then b.icon:ClearAllPoints();b.icon:SetSize(20,20);b.icon:SetPoint("CENTER");b.icon:SetTexCoord(.07,.93,.07,.93) end
  local bg=b:CreateTexture(nil,"BACKGROUND");bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background");bg:SetSize(20,20);bg:SetPoint("CENTER");bg:Hide()
  if b.icon then b.icon:ClearAllPoints();b.icon:SetPoint("CENTER",b,"CENTER",1,0) end
  local ring=b:CreateTexture(nil,"OVERLAY");ring:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder");ring:SetSize(53,53);ring:SetPoint("TOPLEFT",b,"TOPLEFT",0,0)
  b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
  local hl=b:GetHighlightTexture();if hl then hl:SetSize(31,31);hl:ClearAllPoints();hl:SetPoint("CENTER") end
  b.FXPStandardRing=true
 end
 return true
end

local function SetupFallbackMinimap()
 mini=CreateFrame("Button","FXPMinimapButton",Minimap)
 mini:SetSize(31,31);mini:SetFrameStrata("MEDIUM");mini:SetFrameLevel((Minimap:GetFrameLevel()or 0)+8)
 mini:RegisterForClicks("LeftButtonUp","RightButtonUp");mini:RegisterForDrag("LeftButton")
 local bg=mini:CreateTexture(nil,"BACKGROUND")
 bg:SetSize(20,20);bg:SetPoint("CENTER");bg:SetColorTexture(0,0,0,0)
 local ic=mini:CreateTexture(nil,"ARTWORK")
 ic:SetSize(20,20);ic:SetPoint("CENTER",mini,"CENTER",1,0);ic:SetTexture(3586269);ic:SetTexCoord(.07,.93,.07,.93)
 local border=mini:CreateTexture(nil,"OVERLAY")
 border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder");border:SetSize(53,53);border:SetPoint("TOPLEFT",mini,"TOPLEFT",0,0)
 local hl=mini:CreateTexture(nil,"HIGHLIGHT")
 hl:SetTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight");hl:SetBlendMode("ADD");hl:SetSize(31,31);hl:SetPoint("CENTER")
 local function Pos()
  local r=math.max(Minimap:GetWidth()or 140,Minimap:GetHeight()or 140)/2+18
  local a=math.rad(FXPDB.minimapAngle or 165);mini:ClearAllPoints();mini:SetPoint("CENTER",Minimap,"CENTER",math.cos(a)*r,math.sin(a)*r)
 end
 local dragging=false
 mini:SetScript("OnDragStart",function(self)
  dragging=true;self:SetScript("OnUpdate",function()
   local mx,my=Minimap:GetCenter();if not mx then return end
   local x,y=GetCursorPosition();local sc=UIParent:GetEffectiveScale();x,y=x/sc,y/sc
   FXPDB.minimapAngle=math.deg(math.atan2(y-my,x-mx));Pos()
  end)
 end)
 mini:SetScript("OnDragStop",function(self)self:SetScript("OnUpdate",nil);Pos();C_Timer.After(.1,function()dragging=false end)end)
 mini:SetScript("OnClick",function(_,button)if dragging then return end;if button=="RightButton"then ToggleFrame()else OpenSettings()end end)
 mini:SetScript("OnEnter",function(self)GameTooltip:SetOwner(self,"ANCHOR_LEFT");GameTooltip:SetText("老哥UI｜遊戲延遲及位面顯示｜FXP");GameTooltip:AddLine("左鍵：開啟/關閉設定",1,1,1);GameTooltip:Show()end)
 mini:SetScript("OnLeave",function()GameTooltip:Hide()end)
 Pos()
end

local ev=CreateFrame("Frame")
for _,e in ipairs({"PLAYER_LOGIN","PLAYER_XP_UPDATE","UPDATE_EXHAUSTION","PLAYER_LEVEL_UP","PLAYER_TARGET_CHANGED","PLAYER_ENTERING_WORLD"})do ev:RegisterEvent(e)end
ev:SetScript("OnEvent",function(_,e)
 if e=="PLAYER_LOGIN"then
  InitDB()
  if FXPDB.barHeight==nil then
   local legacy=tonumber(FXPDB.sizeMode) or 1
   FXPDB.barHeight=(legacy==3 and 45) or (legacy==2 and 37) or 30
  end
  if not FXPDB.topBarMigrated then
   FXPDB.point=nil;FXPDB.relPoint=nil;FXPDB.x=nil;FXPDB.y=nil
   FXPDB.topBarMigrated=true
  end
  RestoreMain();ApplySize();ApplyLook()
  if FXPDB.shown then f:Show()else f:Hide()end
  if not SetupStandardMinimap() then SetupFallbackMinimap() end
  RefreshPerformance()
  if C_Timer and C_Timer.NewTicker then
   C_Timer.NewTicker(2,function()
    RefreshPerformance();CheckFPSAlert()
    if FXPDB.shown then UpdateText() end
   end)
  end
 end
 if e=="PLAYER_TARGET_CHANGED" or e=="PLAYER_ENTERING_WORLD" then DetectLayer() end
 UpdateText()
end)

SLASH_FXP1="/fxp"
SlashCmdList["FXP"]=function(msg)
 msg=(msg or ""):lower():match("^%s*(.-)%s*$")
 if msg=="show"then FXPDB.shown=true;f:Show()
 elseif msg=="hide"then FXPDB.shown=false;f:Hide()
 elseif msg=="reset"then FXPDB.point=nil;FXPDB.relPoint=nil;FXPDB.x=nil;FXPDB.y=nil;RestoreMain()
 else OpenSettings()end
end
