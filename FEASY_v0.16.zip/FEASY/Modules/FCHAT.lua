local ADDON = ...
local F = CreateFrame("Frame")
local DB

local defaults = {
  say = {enabled=true, sound=1},
  whisper = {enabled=true, sound=2},
  guild = {enabled=true, sound=3},
  party = {enabled=true, sound=4},
  minimap = {}, minimapAngle = 145,
  panelPoint="CENTER", panelX=-300, panelY=80,
}
local function InitDB()
  FCHAT_DB = FCHAT_DB or {}
  for k,v in pairs(defaults) do
    if FCHAT_DB[k] == nil then
      if type(v)=="table" then local t={} for a,b in pairs(v) do t[a]=b end FCHAT_DB[k]=t else FCHAT_DB[k]=v end
    end
  end
  for _,k in ipairs({"say","whisper","guild","party"}) do
    FCHAT_DB[k]=FCHAT_DB[k] or {}
    if FCHAT_DB[k].enabled==nil then FCHAT_DB[k].enabled=defaults[k].enabled end
    local n=tonumber(FCHAT_DB[k].sound) or defaults[k].sound
    if n<1 or n>5 then n=defaults[k].sound end
    FCHAT_DB[k].sound=n
  end
  DB=FCHAT_DB
end
local function PlayAlert(n)
  n=tonumber(n) or 1
  PlaySoundFile("Interface\\AddOns\\FEASY\\audio\\"..n..".mp3", "Master")
end

-- FCHAT v0.04 聊天偵測及聲音邏輯沿用；設定元件嵌入 FEASY 第三頁。
local rows={}
local defs={{"say","附近"},{"whisper","密語"},{"guild","公會"},{"party","隊伍"}}
local function Refresh()
  if not DB then return end
  for _,d in ipairs(defs) do local k=d[1]; if rows[k] then rows[k].cb:SetChecked(DB[k].enabled); rows[k].val:SetText("聲音 "..DB[k].sound) end end
end
function FEASY_FCHAT_CreatePage(cfg)
  local sub=cfg:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
  sub:SetPoint("TOPLEFT",cfg,"TOPLEFT",0,-2); sub:SetText("勾選聊天提醒，各自選擇聲音")
  for i,d in ipairs(defs) do
    local key,label=d[1],d[2]
    local y=-39-(i-1)*66
    local cb=CreateFrame("CheckButton",nil,cfg,"UICheckButtonTemplate")
    cb:SetPoint("TOPLEFT",cfg,"TOPLEFT",-5,y); cb:SetSize(26,26)
    local tx=cfg:CreateFontString(nil,"OVERLAY","GameFontHighlight")
    tx:SetWidth(44);tx:SetJustifyH("LEFT");tx:SetPoint("LEFT",cb,"RIGHT",2,0);tx:SetText(label)
    local prev=CreateFrame("Button",nil,cfg,"UIPanelButtonTemplate")
    prev:SetSize(25,24);prev:SetPoint("LEFT",tx,"RIGHT",3,0);prev:SetText("<")
    local val=cfg:CreateFontString(nil,"OVERLAY","GameFontNormal")
    val:SetWidth(52);val:SetJustifyH("CENTER");val:SetPoint("LEFT",prev,"RIGHT",2,0)
    local nextb=CreateFrame("Button",nil,cfg,"UIPanelButtonTemplate")
    nextb:SetSize(25,24);nextb:SetPoint("LEFT",val,"RIGHT",2,0);nextb:SetText(">")
    local test=CreateFrame("Button",nil,cfg,"UIPanelButtonTemplate")
    test:SetSize(44,24);test:SetPoint("LEFT",nextb,"RIGHT",4,0);test:SetText("試聽")
    rows[key]={cb=cb,val=val}
    cb:SetScript("OnClick",function(self) if DB then DB[key].enabled=self:GetChecked() and true or false end end)
    prev:SetScript("OnClick",function() if not DB then return end local n=DB[key].sound-1 if n<1 then n=5 end DB[key].sound=n val:SetText("聲音 "..n) PlayAlert(n) end)
    nextb:SetScript("OnClick",function() if not DB then return end local n=DB[key].sound+1 if n>5 then n=1 end DB[key].sound=n val:SetText("聲音 "..n) PlayAlert(n) end)
    test:SetScript("OnClick",function() if DB then PlayAlert(DB[key].sound) end end)
  end
  cfg:SetScript("OnShow",Refresh)
  Refresh()
end
function FEASY_FCHAT_Reset()
  if not DB then return end
  for _,k in ipairs({"say","whisper","guild","party"}) do DB[k].enabled=defaults[k].enabled;DB[k].sound=defaults[k].sound end
  Refresh()
end

local eventMap={CHAT_MSG_SAY="say",CHAT_MSG_WHISPER="whisper",CHAT_MSG_GUILD="guild",CHAT_MSG_PARTY="party",CHAT_MSG_PARTY_LEADER="party"}
for e in pairs(eventMap) do F:RegisterEvent(e) end
F:RegisterEvent("ADDON_LOADED"); F:RegisterEvent("PLAYER_LOGIN")
F:SetScript("OnEvent",function(_,event,...)
  if event=="ADDON_LOADED" then
    local name=...
    if name==ADDON then InitDB() end
  elseif event=="PLAYER_LOGIN" then
    -- FEASY 小地圖入口統一管理，不另外建立 FCHAT 按鈕。
  else
    if not DB then return end
    local key=eventMap[event]; if not key or not DB[key].enabled then return end
    local msg,sender=...
    local me=UnitName("player")
    if sender and me then local short=sender:match("^[^-]+") or sender; if short==me then return end end
    PlayAlert(DB[key].sound)
  end
end)
