-- Lueur : textes en anglais
-- C'est la langue de repli : un texte absent d'une autre langue s'affiche en anglais, et un
-- client dont la langue n'a pas de fichier ici reçoit l'anglais.

local ns = FEASY_LueurNS

local L = {}
ns.LOCALES.enUS = L

L.LANGUAGE_NAME = "English"   -- le nom que cette langue se donne : c'est ainsi que le menu la propose
L.PREFIX = "|cffffd200Lueur|r: "
L.YES = "yes"
L.NO = "no"
L.SETTING = "%s: %s"          -- un réglage et sa valeur
L.FORMAT_PERCENT = "%d%%"
L.FORMAT_RANGE = "%d yd"
L.CONFIRM = "Confirm?"       -- sur un bouton qui attend un second geste

-- Adjectifs trop répandus pour rapprocher à eux seuls un objet d'un objectif de quête
L.COMMON_WORDS = "small little large great giant ancient"

-- Mots de commande propres à cette langue -> nom anglais de la commande. Les noms anglais
-- répondent partout ; les accents sont facultatifs.
L.COMMANDS = {}

---------------------------------------------------------------------------
-- Catégories, états, effets
---------------------------------------------------------------------------

L.CATEGORY_ORE = "Ore"
L.CATEGORY_ORE_TIP = "Mineral veins and deposits."
L.CATEGORY_HERB = "Herbs"
L.CATEGORY_HERB_TIP = "Plants you can gather."
L.CATEGORY_QUEST = "Quests"
L.CATEGORY_QUEST_TIP = "Objects tied to one of your current quests."
L.CATEGORY_OTHER = "Other objects"
L.CATEGORY_OTHER_TIP = "Everyday objects: doors, chests, mailboxes…"

-- la catégorie d'un objet, dans une phrase du diagnostic
L.NAME_ORE = "ore"
L.NAME_HERB = "herb"
L.NAME_QUEST = "quest"
L.NAME_OTHER = "other"
L.NAME_NONE = "none"

L.STATE_FAR = "out of reach"
L.STATE_READY = "within reach"
L.STATE_LOCKED = "unavailable"

L.EFFECT_AURA = "Aura"
L.EFFECT_AURA_TIP = "A halo of light with a fine ring, comets and fireflies."
L.EFFECT_RETICLE = "Reticle"
L.EFFECT_RETICLE_TIP = "A crisp ring and its comets over a fainter glow."
L.EFFECT_SUBTLE = "Subtle"
L.EFFECT_SUBTLE_TIP = "A soft glow, with no ring or comets."
L.EFFECT_SIGIL = "Sigil"
L.EFFECT_SIGIL_TIP = "A circle of runes turns slowly around the object."
L.EFFECT_BRACKETS = "Brackets"
L.EFFECT_BRACKETS_TIP = "Four corners frame the object and lock onto it once it is within reach."
L.EFFECT_BEAM = "Beam"
L.EFFECT_BEAM_TIP = "A column of light rises from the object, sparks drifting up along it."
L.EFFECT_BEACON = "Beacon"
L.EFFECT_BEACON_TIP = "A crystal hovers above the object, tied to it by a thread of light."
L.EFFECT_ORBIT = "Orbit"
L.EFFECT_ORBIT_TIP = "Wisps circle the object, trailing light behind them."
L.EFFECT_RIPPLE = "Ripple"
L.EFFECT_RIPPLE_TIP = "Ripples spread across the ground around the object."
L.EFFECT_SPARKLE = "Sparkles"
L.EFFECT_SPARKLE_TIP = "Glints twinkle around the object, with no circle at all."

---------------------------------------------------------------------------
-- Menu
---------------------------------------------------------------------------

L.HEADER_EFFECT = "Effect"
L.HEADER_LOOK = "Appearance"
L.HEADER_SILHOUETTE = "Silhouette"
L.HEADER_OBJECTS = "Highlighted objects"
L.HEADER_DETECTION = "Detection"
L.HEADER_GENERAL = "General"

L.SIZE = "Size"
L.SIZE_TIP = "How large the effect is."
L.INTENSITY = "Intensity"
L.INTENSITY_TIP = "How bright the effect is."
L.OFFSET = "Vertical offset"
L.OFFSET_TIP = "Moves the effect up or down from the object's nameplate. Adjust it in front of a real object: the preview ignores it."
L.FADE = "Fade with the nameplate"
L.FADE_TIP = "The effect fades along with the object's nameplate, for instance when the scenery hides it."

L.SILHOUETTE = "Pass behind my character"
L.SILHOUETTE_TIP = "The effect is cut out around your character, so it seems to pass behind you instead of covering you."
L.ZONE_SIZE = "Cut-out size"
L.ZONE_SIZE_TIP = "Raise it if the effect bites into your character, lower it if the effect stays too far away."
L.ZONE_HEIGHT = "Cut-out height"
L.ZONE_HEIGHT_TIP = "Moves the cut-out up or down."
L.ZONE_SHOW = "Show the cut-out"
L.ZONE_SHOW_TIP = "Outlines the cut-out in red: it should hug your character. It goes away when this window closes."

L.RANGE = "Range"
L.RANGE_TIP = "How far away the game may pick an object to highlight."
L.DIRECTION = "Direction"
L.DIRECTION_TIP = "Where the game looks for an object to pick."
L.ARC_0 = "Dead ahead"
L.ARC_0_TIP = "Only what stands right in front of you."
L.ARC_1 = "In front"
L.ARC_1_TIP = "Anything in front of you."
L.ARC_2 = "Everywhere"
L.ARC_2_TIP = "In every direction, even behind your back."
L.EXCLUSIVE = "Only show highlighted targets"
L.EXCLUSIVE_TIP = "The game only shows the name and icon of targets that get an effect. Unchecked, it shows them for every interaction target: NPCs, world objects…"

L.KEY = "Interact key"
L.KEY_TIP = "The key that picks up, gathers or uses the highlighted object once it is within reach. It is the game's own interact key: it works on NPCs too, and can also be changed in the game's key bindings."
L.KEY_NONE = "Not bound"
L.KEY_LISTEN = "Press a key"
L.KEY_LISTEN_TIP = "Press the key, mouse button or mouse wheel direction to use. Escape cancels."
L.KEY_TAKEN = "%s is already used for “%s”. Press it again to give it to the interact key instead, or press another key."
L.TIP_KEY_SET = "Left-click: choose a key"
L.TIP_KEY_CLEAR = "Right-click: remove the key"

L.LANGUAGE = "Language"
L.LANGUAGE_TIP = "The language of Lueur's texts and commands."
L.LANGUAGE_AUTO = "Automatic"
L.LANGUAGE_AUTO_TIP = "Follows the language of the game."

L.ENABLE = "Enable Lueur"
L.ENABLE_TIP = "When disabled, Lueur hands your original targeting settings back to the game."
L.MINIMAP = "Minimap button"
L.MINIMAP_TIP = "Shows Lueur's button on the edge of the minimap."
L.DEBUG = "Diagnostics in chat"
L.DEBUG_TIP = "Describes in the chat window each object targeted and what Lueur makes of it."

L.PREVIEW = "Preview"
L.PREVIEW_STOP = "Stop preview"
L.PREVIEW_TIP = "Shows the effect next to this window, in each category and each of its states, until you stop it."
L.DEFAULTS = "Defaults"
L.DEFAULTS_TIP = "Puts the effect and detection settings back to their original values. A second click confirms."
L.FOOTER = "Lueur %s  ·  /lueur help: all commands"

L.TIP_ENABLED = "Enabled"
L.TIP_DISABLED = "Disabled"
L.TIP_LEFT_CLICK = "Left-click: open the settings"
L.TIP_RIGHT_CLICK = "Right-click: enable or disable"
L.TIP_DRAG = "Drag: move this button"

---------------------------------------------------------------------------
-- Messages des commandes
---------------------------------------------------------------------------

L.MSG_ENABLED = "enabled."
L.MSG_DISABLED = "disabled, your original settings are restored."
L.MSG_PREVIEW = "preview (%s): out of reach, then within reach, then unavailable."
L.MSG_EXCLUSIVE_ON = "the game now only shows the name and icon of targets that get an effect."
L.MSG_EXCLUSIVE_OFF = "the game shows the name and icon of every interaction target (NPCs, world objects…)."
L.MSG_SILHOUETTE_ON = "the effect passes behind your character."
L.MSG_SILHOUETTE_OFF = "the effect covers your character."
L.MSG_CUTOUT_UNAVAILABLE = "cut-out unavailable: %s."
L.MSG_ZONE_SHOWN = "cut-out outlined in red: it should hug your character."
L.MSG_ZONE_HIDDEN = "cut-out outline hidden."
L.MSG_SILHOUETTE_VALUES = "silhouette: size %d%%, height %d%%"
L.MSG_SILHOUETTE_USAGE = "usage: /lueur silhouette | show | <size {bodyScale}> [height {bodyShift}]"
L.MSG_EFFECTS = "available effects: %s (current: %s)"
L.MSG_RANGE = "range: %d yd"
L.MSG_RANGE_COMBAT = "range: %d yd, applied once you leave combat."
L.MSG_RANGE_CLIENT = "range: %d yd requested, the client kept %s."
L.MSG_KEY_COMBAT = "key bindings cannot be changed in combat."
L.MSG_KEY_REFUSED = "the game refused the key “%s”."
L.MSG_KEY_REPLACED = "%s no longer triggers “%s”."

L.FAIL_NO_MASK = "this client does not support masks"
L.FAIL_MASK_TEXTURE = "mask texture not found (fully restart the game)"
L.FAIL_MASK_REFUSED = "the client refused the mask"

L.STATUS_CLIENT = "client %s (%s), language %s; Lueur's texts: %s. Values in effect:"
L.STATUS_CVAR_UNKNOWN = "unknown to this client"
L.STATUS_CVAR_DEFAULT = " (default %s)"
L.STATUS_EXPECTED = "expected by Lueur: range %d, arc %d"
L.STATUS_GATE = "name and icon kept for highlighted targets: %s | native display right now: %s"
L.GATE_OPEN = "open"
L.GATE_CLOSED = "closed"
L.STATUS_SILHOUETTE = "effect behind the character: %s"
L.STATUS_UNAVAILABLE = "unavailable, %s"
L.STATUS_DIRECT = "target read straight from “softinteract”: %s"
L.STATUS_NOT_YET = "not seen yet"
L.STATUS_RANGE_API = "interaction range readable: %s"
L.STATUS_EFFECT = "effect: %s | textures: %s"
L.STATUS_KEY = "interact key: %s"
L.TEXTURES_PENDING = "not loaded yet"
L.TEXTURES_MISSING = "missing, fallback effect shown (fully restart the game)"
L.TEXTURES_LOADED = "loaded"

L.OBJECTIVES_HEADER = "%d quest objective(s) in progress:"
L.OBJECTIVES_NOT_ITEM = "  (not an object: only compared to the whole name)"
L.OBJECTIVES_LEARNED = "learned from a tooltip: %s (%s)"

---------------------------------------------------------------------------
-- Diagnostic (/lueur debug)
---------------------------------------------------------------------------

L.DEBUG_NO_TARGET = "no interaction target any more"
L.DEBUG_IGNORED = "%s ignored (not a world object)"
L.DEBUG_HIDDEN = "%s → %s, no effect (category hidden or unknown)"
L.DEBUG_NO_PLATE = "%s → %s, detected but without a nameplate: no effect possible"
L.DEBUG_SHOWN = "%s → %s, %s"
L.DEBUG_CURSOR = "cursor: %s"
L.DEBUG_VIA = "target: %s"
L.VIA_DIRECT = "direct"
L.VIA_SWEEP = "sweep"
L.DEBUG_RANGE = "in interaction range: %s"
L.DEBUG_QUEST = "quest-related: %s"
L.DEBUG_MATCH = "tied to an objective by: %s (%d objectives in progress)"
L.MATCH_NONE = "nothing"
L.MATCH_TOOLTIP = "its tooltip"
L.MATCH_NAME = "its name"
L.MATCH_WORD = "the word “%s”"
L.DEBUG_SECRET = "secret identity: %s"
L.DEBUG_BEHIND = "behind the camera: %s"

---------------------------------------------------------------------------
-- Aide (/lueur help). {réglage} : ses bornes ; {réglage=} : sa valeur par défaut
---------------------------------------------------------------------------

L.HELP_HEADER = "commands:"
L.HELP = {
	"/lueur — opens or closes the settings window (like a click on the minimap button)",
	"/lueur minimap — shows or hides the minimap button",
	"/lueur on | off — enables or disables Lueur (off restores your settings)",
	"/lueur preview — shows the effect next to your character, in each of its states",
	"/lueur effect <name> — picks the effect; without a name, lists them",
	"/lueur size <{size}> — size of the effect (default {size=})",
	"/lueur intensity <{intensity}> — brightness of the effect, in % (default {intensity=})",
	"/lueur offset <{offsetY}> — vertical offset of the effect (default {offsetY=})",
	"/lueur fade — whether the effect fades with the nameplate (object hidden by the scenery)",
	"/lueur silhouette — whether the effect passes behind your character instead of covering it",
	"/lueur silhouette show | <size %> [height %] — shows and adjusts the cut-out",
	"/lueur range <{range}> — how far the game picks objects, in yards (default {range=})",
	"/lueur arc <{arc}> — 0 dead ahead, 1 in front, 2 every direction (default {arc=})",
	"/lueur exclusive — whether the game only shows the name and icon of targets that get an effect",
	"/lueur key <KEY> | none — binds the key that picks up the highlighted object (F, SHIFT-E, BUTTON4…); without a key, shows it",
	"/lueur ore | herb | quest | other — shows or hides a category",
	"/lueur language <auto | en | fr> — language of Lueur's texts and commands",
	"/lueur debug — describes each object targeted and what Lueur makes of it",
	"/lueur objectives — lists the quest objectives that object names are compared to",
	"/lueur status — shows the values the client actually applies",
	"/lueur help — shows this list",
}
