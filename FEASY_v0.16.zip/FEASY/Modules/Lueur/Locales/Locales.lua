-- Lueur : choix de la langue
-- Chaque autre fichier de ce dossier range ses textes dans ns.LOCALES, sous le code de sa
-- langue. ns.L les sert dans la langue choisie (celle du client tant que rien n'est choisi),
-- à défaut en anglais ; une clé qui manquerait partout s'affiche telle quelle plutôt que de
-- lever une erreur. Les textes sont relus à chaque usage : la langue se change en cours de jeu.

local ns = FEASY_LueurNS

local LOCALES = {}
ns.LOCALES = LOCALES

local chosen  -- textes de la langue choisie ; nil : ceux de la langue du client

-- Textes de la langue du client, ou de l'anglais s'il n'a pas de fichier ici
local function ClientTexts()
	return LOCALES[GetLocale()] or LOCALES.enUS
end

ns.L = setmetatable({}, { __index = function(_, key)
	local text = (chosen or ClientTexts())[key]
	if text == nil then text = LOCALES.enUS[key] end
	if text == nil then return key end
	return text
end })

-- Sert désormais les textes de cette langue ; "auto", ou un code inconnu : celle du client
function ns.UseLanguage(code)
	chosen = LOCALES[code]
end

-- Un texte dans la langue du client, quelle que soit la langue choisie : ce qui se compare aux
-- noms d'objets et aux objectifs de quête, que le client donne dans la sienne
function ns.ClientText(key)
	local text = ClientTexts()[key]
	if text == nil then text = LOCALES.enUS[key] end
	return text
end
