-- Lueur : textes en français

local ns = FEASY_LueurNS

local L = {}
ns.LOCALES.frFR = L

L.LANGUAGE_NAME = "Français"
L.PREFIX = "|cffffd200Lueur|r : "
L.YES = "oui"
L.NO = "non"
L.SETTING = "%s : %s"
L.FORMAT_PERCENT = "%d %%"
L.FORMAT_RANGE = "%d m"
L.CONFIRM = "Confirmer ?"

L.COMMON_WORDS = "petit petite grand grande vieux vieille ancien ancienne"

L.COMMANDS = {
	["aperçu"] = "preview", effet = "effect", taille = "size", ["intensité"] = "intensity", ["décalage"] = "offset",
	fondu = "fade", montrer = "show", ["portée"] = "range", exclusif = "exclusive", minerai = "ore", herbe = "herb",
	["quête"] = "quest", autre = "other", objectifs = "objectives", ["état"] = "status", aide = "help",
	touche = "key", aucune = "none", langue = "language",
}

---------------------------------------------------------------------------
-- Catégories, états, effets
---------------------------------------------------------------------------

L.CATEGORY_ORE = "Minerais"
L.CATEGORY_ORE_TIP = "Filons de minerai."
L.CATEGORY_HERB = "Herbes"
L.CATEGORY_HERB_TIP = "Plantes à cueillir."
L.CATEGORY_QUEST = "Quêtes"
L.CATEGORY_QUEST_TIP = "Objets liés à l'une de tes quêtes en cours."
L.CATEGORY_OTHER = "Autres objets"
L.CATEGORY_OTHER_TIP = "Objets du quotidien : portes, coffres, boîtes aux lettres…"

L.NAME_ORE = "minerai"
L.NAME_HERB = "herbe"
L.NAME_QUEST = "quête"
L.NAME_OTHER = "autre"
L.NAME_NONE = "aucune"

L.STATE_FAR = "hors de portée"
L.STATE_READY = "à portée"
L.STATE_LOCKED = "indisponible"

L.EFFECT_AURA = "Aura"
L.EFFECT_AURA_TIP = "Un halo de lumière, son anneau fin, ses comètes et ses lucioles."
L.EFFECT_RETICLE = "Réticule"
L.EFFECT_RETICLE_TIP = "Un anneau net et ses comètes, sur une lueur atténuée."
L.EFFECT_SUBTLE = "Discret"
L.EFFECT_SUBTLE_TIP = "Une lueur douce, sans anneau ni comètes."
L.EFFECT_SIGIL = "Sceau"
L.EFFECT_SIGIL_TIP = "Un cercle de runes tourne lentement autour de l'objet."
L.EFFECT_BRACKETS = "Viseur"
L.EFFECT_BRACKETS_TIP = "Quatre coins encadrent l'objet et se verrouillent sur lui dès qu'il est à portée."
L.EFFECT_BEAM = "Faisceau"
L.EFFECT_BEAM_TIP = "Une colonne de lumière s'élève de l'objet, parcourue d'étincelles."
L.EFFECT_BEACON = "Balise"
L.EFFECT_BEACON_TIP = "Un cristal flotte au-dessus de l'objet, relié à lui par un fil de lumière."
L.EFFECT_ORBIT = "Orbite"
L.EFFECT_ORBIT_TIP = "Des feux follets tournent autour de l'objet en laissant une traînée de lumière."
L.EFFECT_RIPPLE = "Onde"
L.EFFECT_RIPPLE_TIP = "Des ondes s'étalent sur le sol autour de l'objet."
L.EFFECT_SPARKLE = "Étincelles"
L.EFFECT_SPARKLE_TIP = "Des éclats scintillent autour de l'objet, sans aucun cercle."

---------------------------------------------------------------------------
-- Menu
---------------------------------------------------------------------------

L.HEADER_EFFECT = "Effet"
L.HEADER_LOOK = "Apparence"
L.HEADER_SILHOUETTE = "Silhouette"
L.HEADER_OBJECTS = "Objets mis en lumière"
L.HEADER_DETECTION = "Détection"
L.HEADER_GENERAL = "Général"

L.SIZE = "Taille"
L.SIZE_TIP = "Taille de l'effet."
L.INTENSITY = "Intensité"
L.INTENSITY_TIP = "Luminosité de l'effet."
L.OFFSET = "Décalage vertical"
L.OFFSET_TIP = "Monte ou descend l'effet par rapport à la nameplate de l'objet. À régler devant un vrai objet : l'aperçu n'en tient pas compte."
L.FADE = "S'estompe avec la nameplate"
L.FADE_TIP = "L'effet s'efface en même temps que la nameplate de l'objet, par exemple quand le décor le masque."

L.SILHOUETTE = "Passe derrière mon personnage"
L.SILHOUETTE_TIP = "L'effet est découpé autour de ton personnage, et semble passer derrière lui au lieu de le recouvrir."
L.ZONE_SIZE = "Taille de la zone découpée"
L.ZONE_SIZE_TIP = "À agrandir si l'effet mord sur ton personnage, à réduire s'il s'en tient trop loin."
L.ZONE_HEIGHT = "Hauteur de la zone découpée"
L.ZONE_HEIGHT_TIP = "Monte ou descend la zone découpée."
L.ZONE_SHOW = "Montrer la zone découpée"
L.ZONE_SHOW_TIP = "Trace en rouge le contour de la zone découpée : il doit épouser ton personnage. Disparaît à la fermeture de cette fenêtre."

L.RANGE = "Portée"
L.RANGE_TIP = "Distance jusqu'à laquelle le jeu peut désigner un objet à mettre en lumière."
L.DIRECTION = "Direction"
L.DIRECTION_TIP = "Où le jeu cherche l'objet à désigner."
L.ARC_0 = "Pile devant"
L.ARC_0_TIP = "Seulement ce qui se trouve juste en face de toi."
L.ARC_1 = "Devant"
L.ARC_1_TIP = "Tout ce qui se trouve devant toi."
L.ARC_2 = "Partout"
L.ARC_2_TIP = "Dans toutes les directions, même dans ton dos."
L.EXCLUSIVE = "Ne montrer que les cibles éclairées"
L.EXCLUSIVE_TIP = "Le jeu n'affiche le nom et l'icône que des cibles qui reçoivent un effet. Décoché, il met en avant toutes les cibles d'interaction : PNJ, objets du décor…"

L.KEY = "Touche d'interaction"
L.KEY_TIP = "La touche qui ramasse, cueille ou active l'objet mis en lumière dès qu'il est à portée. C'est la touche d'interaction du jeu : elle sert aussi avec les PNJ, et se change également dans les raccourcis du jeu."
L.KEY_NONE = "Non assignée"
L.KEY_LISTEN = "Presse une touche"
L.KEY_LISTEN_TIP = "Appuie sur la touche, le bouton de souris ou le cran de molette à utiliser. Échap annule."
L.KEY_TAKEN = "%s sert déjà à « %s ». Appuie de nouveau dessus pour la donner à l'interaction, ou choisis une autre touche."
L.TIP_KEY_SET = "Clic gauche : choisir une touche"
L.TIP_KEY_CLEAR = "Clic droit : retirer la touche"

L.LANGUAGE = "Langue"
L.LANGUAGE_TIP = "La langue des textes et des commandes de Lueur."
L.LANGUAGE_AUTO = "Automatique"
L.LANGUAGE_AUTO_TIP = "Suit la langue du jeu."

L.ENABLE = "Activer Lueur"
L.ENABLE_TIP = "Désactivé, Lueur rend au jeu tes réglages de ciblage d'origine."
L.MINIMAP = "Bouton de la minimap"
L.MINIMAP_TIP = "Affiche le bouton de Lueur au bord de la minimap."
L.DEBUG = "Diagnostic dans la discussion"
L.DEBUG_TIP = "Décrit dans la fenêtre de discussion chaque objet ciblé et ce que Lueur en déduit."

L.PREVIEW = "Aperçu"
L.PREVIEW_STOP = "Arrêter l'aperçu"
L.PREVIEW_TIP = "Montre l'effet à côté de cette fenêtre, dans chaque catégorie et chacun de ses états, jusqu'à ce que tu l'arrêtes."
L.DEFAULTS = "Par défaut"
L.DEFAULTS_TIP = "Remet les réglages de l'effet et de la détection à leurs valeurs d'origine. Un second clic le confirme."
L.FOOTER = "Lueur %s  ·  /lueur aide : toutes les commandes"

L.TIP_ENABLED = "Activé"
L.TIP_DISABLED = "Désactivé"
L.TIP_LEFT_CLICK = "Clic gauche : ouvrir les réglages"
L.TIP_RIGHT_CLICK = "Clic droit : activer ou désactiver"
L.TIP_DRAG = "Glisser : déplacer ce bouton"

---------------------------------------------------------------------------
-- Messages des commandes
---------------------------------------------------------------------------

L.MSG_ENABLED = "activé."
L.MSG_DISABLED = "désactivé, tes réglages d'origine sont restaurés."
L.MSG_PREVIEW = "aperçu (%s) : hors de portée, puis à portée, puis indisponible."
L.MSG_EXCLUSIVE_ON = "le jeu ne met plus en avant que les cibles qui reçoivent un effet."
L.MSG_EXCLUSIVE_OFF = "le jeu met en avant toutes les cibles d'interaction (PNJ, objets du décor…)."
L.MSG_SILHOUETTE_ON = "l'effet passe derrière ton personnage."
L.MSG_SILHOUETTE_OFF = "l'effet recouvre ton personnage."
L.MSG_CUTOUT_UNAVAILABLE = "découpe indisponible : %s."
L.MSG_ZONE_SHOWN = "zone découpée tracée en rouge : elle doit épouser ton personnage."
L.MSG_ZONE_HIDDEN = "contour de la zone découpée masqué."
L.MSG_SILHOUETTE_VALUES = "silhouette : taille %d %%, hauteur %d %%"
L.MSG_SILHOUETTE_USAGE = "usage : /lueur silhouette | montrer | <taille {bodyScale}> [hauteur {bodyShift}]"
L.MSG_EFFECTS = "effets disponibles : %s (actuel : %s)"
L.MSG_RANGE = "portée : %d m"
L.MSG_RANGE_COMBAT = "portée : %d m, appliquée à la sortie du combat."
L.MSG_RANGE_CLIENT = "portée : %d m demandés, le client a retenu %s."
L.MSG_KEY_COMBAT = "les raccourcis ne se changent pas en combat."
L.MSG_KEY_REFUSED = "le jeu a refusé la touche « %s »."
L.MSG_KEY_REPLACED = "%s ne sert plus à « %s »."

L.FAIL_NO_MASK = "ce client ne gère pas les masques"
L.FAIL_MASK_TEXTURE = "texture du masque introuvable (relance complètement le jeu)"
L.FAIL_MASK_REFUSED = "masque refusé par le client"

L.STATUS_CLIENT = "client %s (%s), langue %s ; textes de Lueur : %s. Valeurs effectives :"
L.STATUS_CVAR_UNKNOWN = "inconnue de ce client"
L.STATUS_CVAR_DEFAULT = " (défaut %s)"
L.STATUS_EXPECTED = "attendu par Lueur : portée %d, arc %d"
L.STATUS_GATE = "nom et icône réservés aux cibles éclairées : %s | affichage natif en ce moment : %s"
L.GATE_OPEN = "ouvert"
L.GATE_CLOSED = "fermé"
L.STATUS_SILHOUETTE = "effet derrière le personnage : %s"
L.STATUS_UNAVAILABLE = "indisponible, %s"
L.STATUS_DIRECT = "cible lue directement via « softinteract » : %s"
L.STATUS_NOT_YET = "pas encore observé"
L.STATUS_RANGE_API = "portée d'interaction lisible : %s"
L.STATUS_EFFECT = "effet : %s | textures : %s"
L.STATUS_KEY = "touche d'interaction : %s"
L.TEXTURES_PENDING = "pas encore chargées"
L.TEXTURES_MISSING = "introuvables, effet de secours affiché (relance complètement le jeu)"
L.TEXTURES_LOADED = "chargées"

L.OBJECTIVES_HEADER = "%d objectif(s) de quête en cours :"
L.OBJECTIVES_NOT_ITEM = "  (pas un objet : comparé au nom entier seulement)"
L.OBJECTIVES_LEARNED = "appris d'une infobulle : %s (%s)"

---------------------------------------------------------------------------
-- Diagnostic (/lueur debug)
---------------------------------------------------------------------------

L.DEBUG_NO_TARGET = "plus de cible d'interaction"
L.DEBUG_IGNORED = "%s ignoré (pas un objet du décor)"
L.DEBUG_HIDDEN = "%s → %s, pas d'effet (catégorie masquée ou inconnue)"
L.DEBUG_NO_PLATE = "%s → %s, détecté mais sans nameplate : pas d'effet possible"
L.DEBUG_SHOWN = "%s → %s, %s"
L.DEBUG_CURSOR = "curseur : %s"
L.DEBUG_VIA = "cible : %s"
L.VIA_DIRECT = "direct"
L.VIA_SWEEP = "balayage"
L.DEBUG_RANGE = "portée d'interaction : %s"
L.DEBUG_QUEST = "quête liée : %s"
L.DEBUG_MATCH = "rattaché à un objectif par : %s (%d objectifs en cours)"
L.MATCH_NONE = "rien"
L.MATCH_TOOLTIP = "son infobulle"
L.MATCH_NAME = "son nom"
L.MATCH_WORD = "le mot « %s »"
L.DEBUG_SECRET = "identité secrète : %s"
L.DEBUG_BEHIND = "derrière la caméra : %s"

---------------------------------------------------------------------------
-- Aide (/lueur aide)
---------------------------------------------------------------------------

L.HELP_HEADER = "commandes :"
L.HELP = {
	"/lueur — ouvre ou ferme la fenêtre des réglages (comme un clic sur le bouton de la minimap)",
	"/lueur minimap — affiche ou masque le bouton de la minimap",
	"/lueur on | off — active ou désactive Lueur (off restaure tes réglages)",
	"/lueur aperçu — montre l'effet à côté de ton personnage, dans chacun de ses états",
	"/lueur effet <nom> — choisit l'effet ; sans nom, en donne la liste",
	"/lueur taille <{size}> — taille de l'effet (défaut {size=})",
	"/lueur intensité <{intensity}> — luminosité de l'effet, en % (défaut {intensity=})",
	"/lueur décalage <{offsetY}> — décalage vertical de l'effet (défaut {offsetY=})",
	"/lueur fondu — l'effet s'estompe ou non avec la nameplate (objet masqué par le décor)",
	"/lueur silhouette — l'effet passe derrière ton personnage au lieu de le recouvrir, ou non",
	"/lueur silhouette montrer | <taille %> [hauteur %] — affiche et ajuste la zone découpée",
	"/lueur portée <{range}> — distance jusqu'à laquelle le jeu désigne un objet, en mètres (défaut {range=})",
	"/lueur arc <{arc}> — 0 pile devant, 1 devant, 2 toutes directions (défaut {arc=})",
	"/lueur exclusif — le jeu ne met en avant (nom, icône) que les cibles qui reçoivent un effet, ou toutes",
	"/lueur touche <TOUCHE> | aucune — assigne la touche qui ramasse l'objet mis en lumière (F, SHIFT-E, BUTTON4…) ; sans touche, l'affiche",
	"/lueur minerai | herbe | quête | autre — affiche ou masque une catégorie",
	"/lueur langue <auto | en | fr> — langue des textes et des commandes de Lueur",
	"/lueur debug — décrit chaque objet ciblé et ce que Lueur en déduit",
	"/lueur objectifs — liste les objectifs de quête auxquels le nom des objets est comparé",
	"/lueur état — affiche les valeurs réellement appliquées par le client",
	"/lueur aide — affiche cette liste",
}
