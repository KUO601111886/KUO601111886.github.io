-- Lueur : met en lumière l'objet interactif visé (filons, plantes, objets de quête)
-- Principe : le "soft targeting" officiel de Blizzard désigne à tout instant une seule cible
-- d'interaction (l'unité "softinteract") et lui donne une nameplate. Lueur accroche à cette
-- nameplate une lueur unique, colorée selon le type d'objet (lu depuis son icône de curseur)
-- et animée selon son état : hors de portée, à portée, indisponible. L'effet choisi
-- (Effects.lua) décide de son dessin ; les textes viennent du dossier Locales.

local ADDON_NAME, ns = "FEASY", FEASY_LueurNS
local L = ns.L
local EFFECTS = ns.EFFECTS
local Lerp, Sized, Tint, Place = ns.Lerp, ns.Sized, ns.Tint, ns.Place

local SOFT = "softinteract"
local MEDIA = "Interface\\AddOns\\FEASY\\Modules\\Lueur\\Media\\"
local FALLBACK_TEXTURE = "Interface\\Cooldown\\star4"
local SCHEMA = 4 -- version des réglages sauvegardés

local DEFAULTS = {
	enabled     = true,
	range       = 15,     -- portée du soft targeting (mètres)
	arc         = 2,      -- 0 = pile devant, 1 = devant, 2 = toutes directions
	offsetY     = -45,    -- décalage vertical de la lueur par rapport à la nameplate (pixels)
	size        = 120,    -- taille de la lueur (pixels, à l'échelle de la nameplate)
	effect      = "aura",
	intensity   = 100,    -- luminosité de la lueur (%)
	followAlpha = false,  -- la lueur s'estompe avec la nameplate (objet masqué par le décor…)
	silhouette  = true,   -- la lueur passe derrière le personnage au lieu de le recouvrir
	bodyScale   = 100,    -- taille de la zone découpée autour du personnage (%)
	bodyShift   = 0,      -- décalage vertical de cette zone (% de la hauteur du personnage)
	exclusive   = true,   -- le jeu ne met en avant (nameplate, icône) que les cibles mises en lumière
	showOther   = false,  -- briller aussi sur les objets "génériques" (portes, coffres, boîtes aux lettres…)
	debug       = false,
	language    = "auto",   -- langue des textes : "auto" (celle du client) ou le code d'une langue du dossier Locales
	categories  = { ore = true, herb = true, quest = true },
	questObjects = {},    -- nom d'objet -> titre de sa quête, appris de son infobulle
	minimap     = { hide = false, angle = 205 }, -- bouton de la minimap : masqué ou non, position (degrés)
}

-- Bornes des réglages numériques, communes aux commandes et aux curseurs du menu
local LIMITS = {
	range     = { 5, 15 },  -- mesuré sur Forever 1.60.1 : la cible d'interaction se perd à 15 m, même avec 60 demandés
	arc       = { 0, 2 },
	offsetY   = { -200, 200 },
	size      = { 40, 300 },
	intensity = { 30, 150 },
	bodyScale = { 40, 300 },
	bodyShift = { -100, 100 },
}

local COLORS = {
	ore   = { 1.00, 0.60, 0.18 },
	herb  = { 0.40, 1.00, 0.42 },
	quest = { 1.00, 0.84, 0.15 },
	other = { 0.90, 0.90, 0.94 },
}

local CATEGORY_ORDER = { "ore", "herb", "quest", "other" }

-- Styles du halo d'avant la version 0.5 -> effet qui les remplace
local LEGACY_STYLES = { aura = "aura", reticule = "reticle", discret = "subtle" }

local POLL_INTERVAL = 0.12   -- réévaluation de la cible et de son état (secondes)
local APPEAR_TIME   = 0.45   -- la lueur arrive
local BLEND_TIME    = 0.30   -- fondu entre deux états
local FLASH_TIME    = 0.50   -- éclair du passage "à portée"
local GHOST_TIME    = 0.40   -- dissipation quand la cible disparaît
local STATE_DELAY   = 0.15   -- un état doit tenir ce temps avant d'être affiché (anti-scintillement)
local LOCK_DELAY    = 0.60   -- idem pour "indisponible", confirmé plus prudemment

-- Fichiers de curseur du jeu (Interface\Cursor\*.blp) -> catégorie
local CURSOR_CATEGORY = {
	Mine = "ore",
	GatherHerbs = "herb",
	Quest = "quest", QuestRepeatable = "quest", QuestTurnIn = "quest",
	Interact = "other", PickLock = "other", LootAll = "other", Pickup = "other",
}

-- CVars que Lueur modifie (valeurs d'origine sauvegardées puis restaurées par /lueur off)
local MANAGED_CVARS = {
	"SoftTargetInteract", "SoftTargetNameplateInteract", "SoftTargetInteractRange", "SoftTargetInteractArc",
	"SoftTargetInteractOnlyInRange", "SoftTargetIconInteract", "SoftTargetIconGameObject",
}
-- Parmi elles, l'icône que le jeu pose sur la cible d'interaction
-- SoftTargetIconGameObject est forcé à 1 quand la gate s'ouvre : sans icône, le jeu ne
-- crée pas de nameplate pour les objets interactibles en soft target (Classic)
local ICON_CVARS = { "SoftTargetIconInteract", "SoftTargetIconGameObject" }

local db
local Evaluate               -- défini plus bas : met la lueur en accord avec la cible courante
local UseLanguage            -- défini plus bas : sert textes et commandes dans la langue réglée
local gateOpen               -- l'affichage natif de la cible est-il ouvert ? nil = à réappliquer
local cursorLookup = {}      -- fileID -> { catégorie, grisé }
local activeUnits = {}       -- jeton nameplateN -> true
local probe                  -- texture cachée servant à lire l'icône de curseur
local pendingCVars = false
local directWorks = false    -- GetNamePlateForUnit("softinteract") a déjà abouti pour un objet
local lastReport             -- dernière ligne de debug affichée (évite les répétitions)
local previewIndex = 0

local glow = { layers = {} }  -- cadre unique de la lueur, état de son animation, couches de tous ses effets
local ghost                   -- cadre de dissipation

local sin, min, max = math.sin, math.min, math.max
local TWO_PI = 2 * math.pi

local function Print(msg)
	print(L.PREFIX .. msg)
end

local function IsSecret(value)
	return issecretvalue ~= nil and issecretvalue(value)
end

local function SafeCall(func, ...)
	if not func then return nil end
	local ok, result = pcall(func, ...)
	if not ok or IsSecret(result) then return nil end
	return result
end

local function CopyDefaults(src, dst)
	for k, v in pairs(src) do
		if type(v) == "table" then
			if type(dst[k]) ~= "table" then dst[k] = {} end
			CopyDefaults(v, dst[k])
		elseif dst[k] == nil then
			dst[k] = v
		end
	end
end

local function Clamp(value, low, high)
	return max(low, min(high, value))
end

local function Approach(value, target, step)
	if value < target then return min(value + step, target) end
	return max(value - step, target)
end

-- Noms affichés, relus à chaque usage : la langue peut changer en cours de jeu
local function EffectLabel(key)
	return L["EFFECT_" .. key:upper()]
end

-- Nom d'une catégorie dans le menu
local function CategoryLabel(category)
	return L["CATEGORY_" .. category:upper()]
end

-- Nom d'une catégorie, ou de son absence, dans une phrase du diagnostic
local function CategoryName(category)
	return L["NAME_" .. (category or "none"):upper()]
end

local function StateName(state)
	return L["STATE_" .. state:upper()]
end

---------------------------------------------------------------------------
-- CVars
---------------------------------------------------------------------------

local function GetCVarValue(name)
	local ok, value = pcall(C_CVar and C_CVar.GetCVar or GetCVar, name)
	if ok then return value end
end

-- Ne touche qu'aux CVars que ce client connaît (la liste varie d'une version à l'autre)
local function SetCVarValue(name, value)
	if GetCVarValue(name) == nil then return end
	pcall(C_CVar and C_CVar.SetCVar or SetCVar, name, tostring(value))
end

-- Affichage natif de la cible d'interaction : sa nameplate, où s'accroche la lueur, et son
-- icône. En mode exclusif, Lueur ne l'ouvre que pour une cible mise en lumière : PNJ,
-- cadavres, boîtes aux lettres et autres restent utilisables avec la touche d'interaction,
-- mais le jeu ne les met plus en avant.
local function EnsureIconCVars()
	-- Le client beta écrase SoftTargetIconGameObject à 0 après PLAYER_ENTERING_WORLD
	-- On le répare ici, avant que Evaluate() ne cherche la nameplate
	if gateOpen == true then
		local current = GetCVarValue("SoftTargetIconGameObject")
		if current ~= "1" then SetCVarValue("SoftTargetIconGameObject", 1) end
	end
end

local function SetGate(open)
	open = open or not db.exclusive
	if open == gateOpen or InCombatLockdown() then
		EnsureIconCVars()
		return
	end
	gateOpen = open
	SetCVarValue("SoftTargetNameplateInteract", open and 1 or 0)
	-- SoftTargetIconGameObject doit être 1 pour que le jeu crée des nameplates pour les game objects
	if open then SetCVarValue("SoftTargetIconGameObject", 1) end
	for _, name in ipairs(ICON_CVARS) do
		if name ~= "SoftTargetIconGameObject" then
			local original = db.savedCVars and db.savedCVars[name]
			if original ~= false then SetCVarValue(name, open and original or 0) end
		end
	end
end

local function ApplyCVars()
	if InCombatLockdown() then pendingCVars = "apply" return end
	db.savedCVars = db.savedCVars or {}
	for _, name in ipairs(MANAGED_CVARS) do
		if db.savedCVars[name] == nil then
			db.savedCVars[name] = GetCVarValue(name) or false
		end
	end
	SetCVarValue("SoftTargetInteract", 3)          -- soft target d'interaction toujours actif
	SetCVarValue("SoftTargetInteractRange", db.range)
	SetCVarValue("SoftTargetInteractArc", db.arc)    -- angle de recherche autour du joueur
	SetCVarValue("SoftTargetInteractOnlyInRange", 0) -- détecter aussi hors de portée d'interaction
	-- la nameplate et l'icône de la cible dépendent de ce qui est visé
	gateOpen = nil
	Evaluate()
end

local function RestoreCVars()
	if InCombatLockdown() then pendingCVars = "restore" return end
	if not db.savedCVars then return end
	for name, value in pairs(db.savedCVars) do
		if value ~= false then SetCVarValue(name, value) end
	end
	db.savedCVars = nil
	gateOpen = nil
end

-- Les versions 0.1.x pouvaient mémoriser comme valeurs d'origine celles que Lueur venait
-- lui-même d'appliquer : /lueur off ne rendait alors rien. Quand la sauvegarde porte cette
-- signature, on lui substitue les valeurs par défaut du client.
local function RepairSavedCVars()
	local saved = db.savedCVars
	if not saved or not (C_CVar and C_CVar.GetCVarDefault) then return end
	if saved.SoftTargetInteract ~= "3" or saved.SoftTargetNameplateInteract ~= "1" or saved.SoftTargetInteractArc ~= "2"
		or (saved.SoftTargetInteractRange ~= "20" and saved.SoftTargetInteractRange ~= tostring(db.range)) then
		return
	end
	for _, name in ipairs({ "SoftTargetInteract", "SoftTargetNameplateInteract", "SoftTargetInteractArc", "SoftTargetInteractRange" }) do
		local default = SafeCall(C_CVar.GetCVarDefault, name)
		if default ~= nil then saved[name] = default end
	end
end

---------------------------------------------------------------------------
-- Classification
---------------------------------------------------------------------------

local function BuildCursorLookup()
	if not GetFileIDFromPath then return end
	for name, category in pairs(CURSOR_CATEGORY) do
		for _, prefix in ipairs({ "", "Unable" }) do
			local path = "Interface\\Cursor\\" .. prefix .. name
			local id = SafeCall(GetFileIDFromPath, path) or SafeCall(GetFileIDFromPath, path .. ".blp")
			if id then cursorLookup[id] = { category, prefix ~= "" } end
		end
	end
end

local QUEST_LINE_TYPE = Enum and Enum.TooltipDataLineType and Enum.TooltipDataLineType.QuestObjective

-- Un objet à ramasser pour une quête porte un curseur générique, et l'API de quête par unité
-- ne les reconnaît pas tous. On le rattache donc à une quête en cours par, dans l'ordre : ce
-- que son infobulle a déjà révélé, son nom dans le texte d'un objectif ("Scie détrempée :
-- 0/1"), ou un mot marquant en commun avec un objet à ramasser ("Tas de camelote" pour
-- "Camelote rutilante"). Noms et objectifs sont ceux du client, dans sa langue.
local questTexts = {}      -- objectifs inachevés : { text = minuscules sans compteur, pickable = objet à ramasser ou à utiliser }
local questTitles = {}     -- titre normalisé de chaque quête en cours -> true
local questsDirty = true

-- Adjectifs trop répandus pour rapprocher à eux seuls un objet d'un objectif : ceux de la
-- langue du client, qui est celle des noms et des objectifs, pas ceux de la langue affichée
local COMMON_WORDS = {}
for word in ns.ClientText("COMMON_WORDS"):gmatch("%S+") do COMMON_WORDS[word] = true end

local function NormalizeText(text)
	text = text:lower():gsub("\194\160", " ")  -- espace insécable (typographie française)
	text = text:gsub("\226\128\153", "'")      -- apostrophe typographique
	text = text:gsub("%d+%s*/%s*%d+", "")
	text = text:gsub("^[%s:%-]+", ""):gsub("[%s:%-]+$", "")
	return text
end

local function RebuildQuestTexts()
	questsDirty = false
	for i = #questTexts, 1, -1 do questTexts[i] = nil end
	for title in pairs(questTitles) do questTitles[title] = nil end
	if not (C_QuestLog and C_QuestLog.GetQuestObjectives) then return end
	local modern = C_QuestLog.GetNumQuestLogEntries and C_QuestLog.GetQuestIDForLogIndex
	for index = 1, SafeCall(modern and C_QuestLog.GetNumQuestLogEntries or GetNumQuestLogEntries) or 0 do
		local questID, title
		if modern then
			questID = SafeCall(C_QuestLog.GetQuestIDForLogIndex, index)
			title = type(questID) == "number" and SafeCall(C_QuestLog.GetTitleForQuestID, questID)
		elseif GetQuestLogTitle then
			local ok, name, _, _, isHeader, _, _, _, id = pcall(GetQuestLogTitle, index)
			if ok and not isHeader then questID, title = id, name end
		end
		if type(title) == "string" then questTitles[NormalizeText(title)] = true end
		local objectives = type(questID) == "number" and SafeCall(C_QuestLog.GetQuestObjectives, questID)
		if type(objectives) == "table" then
			for _, objective in ipairs(objectives) do
				local text = objective.text
				if not objective.finished and type(text) == "string" and not IsSecret(text) then
					text = NormalizeText(text)
					if #text >= 4 then
						local kind = objective.type
						questTexts[#questTexts + 1] = { text = text, pickable = kind == nil or kind == "item" or kind == "object" }
					end
				end
			end
		end
	end
end

-- Renvoie un mot marquant de `source` qui commence aussi un mot de `target`
local function SharedWord(source, target)
	target = " " .. target:gsub("%p", " ")
	for word in source:gmatch("[^%s%p]+") do
		if #word >= 5 and not COMMON_WORDS[word] and target:find(" " .. word, 1, true) then return word end
	end
end

-- Renvoie ce qui rattache ce nom d'objet à une quête en cours (affiché par le debug), ou nil
local function MatchQuestObjective(name)
	if type(name) ~= "string" or #name < 4 then return nil end
	if questsDirty then RebuildQuestTexts() end
	name = NormalizeText(name)
	if questTitles[db.questObjects[name]] then return L.MATCH_TOOLTIP end
	for _, objective in ipairs(questTexts) do
		local text = objective.text
		-- "scie détrempée" dans l'objectif, ou l'objectif ("fournitures") dans le nom de l'objet
		if text:find(name, 1, true) or (#text >= 5 and name:find(text, 1, true)) then return L.MATCH_NAME end
	end
	for _, objective in ipairs(questTexts) do
		-- jamais avec un objectif d'élimination : "Hutte murloc" n'est pas un "Murloc tué"
		if objective.pickable then
			local word = SharedWord(name, objective.text) or SharedWord(objective.text, name)
			if word then return L.MATCH_WORD:format(word) end
		end
	end
end

-- L'infobulle d'un objet de quête nomme sa quête. Quand le jeu en montre une (survol à la
-- souris, ou infobulle de la cible d'interaction si tu l'as activée), on retient le nom de
-- l'objet : c'est le seul lien sûr quand ce nom n'a rien de commun avec l'objectif.
local function LearnFromTooltip()
	if not (C_TooltipInfo and C_TooltipInfo.GetWorldCursor) then return false end
	local data = SafeCall(C_TooltipInfo.GetWorldCursor)
	local lines = type(data) == "table" and data.lines
	if type(lines) ~= "table" or not lines[1] then return false end
	if Enum and Enum.TooltipDataType and data.type == Enum.TooltipDataType.Unit then return false end
	local name = lines[1].leftText
	if IsSecret(name) or type(name) ~= "string" then return false end
	if questsDirty then RebuildQuestTexts() end
	for index = 2, #lines do
		local text = lines[index].leftText
		if not IsSecret(text) and type(text) == "string" then
			local title = NormalizeText(text)
			if questTitles[title] then
				name = NormalizeText(name)
				if db.questObjects[name] == title then return false end
				db.questObjects[name] = title
				return true
			end
		end
	end
	return false
end

local function IsQuestRelated(unit, name)
	-- API ajoutées dans Forever ; absentes de Classic Era (on retombe alors sur le curseur)
	if C_QuestLog and C_QuestLog.UnitIsRelatedToActiveQuest then
		if SafeCall(C_QuestLog.UnitIsRelatedToActiveQuest, unit) == true then return true end
	end
	if QUEST_LINE_TYPE and C_TooltipInfo and C_TooltipInfo.GetUnit then
		local data = SafeCall(C_TooltipInfo.GetUnit, unit)
		if data and data.lines then
			for _, line in ipairs(data.lines) do
				if line.type == QUEST_LINE_TYPE then return true end
			end
		end
	end
	return MatchQuestObjective(name) ~= nil
end

-- Le client renvoie selon les cas un fileID, un chemin (Interface\Cursor\Mine) ou un nom
-- d'atlas (Cursor_Crosshair_UnableMine_64) : on cherche donc des mots-clés dans la chaîne.
local CURSOR_KEYWORDS = {
	{ "gather",   "herb" },
	{ "mine",     "ore" },
	{ "quest",    "quest" },
	{ "lootall",  "other" },
	{ "pickup",   "other" },
	{ "picklock", "other" },
	{ "interact", "other" },
}

-- Renvoie la catégorie et l'indicateur "grisé" (variante Unable : interaction impossible
-- pour l'instant) lus dans un nom de curseur
local function ReadCursorName(name)
	if type(name) ~= "string" then return nil end
	name = name:lower()
	local blocked = name:find("unable", 1, true) ~= nil
	for _, entry in ipairs(CURSOR_KEYWORDS) do
		if name:find(entry[1], 1, true) then return entry[2], blocked end
	end
	return nil, blocked
end

-- Renvoie : l'objet a-t-il une icône de curseur, sa catégorie, grisée ou non, et le nom
-- brut du curseur (pour le debug)
local function ReadCursor(unit)
	if not SafeCall(SetUnitCursorTexture, probe, unit, nil, true) then return false end
	local texture = probe:GetTexture()
	local atlas = probe.GetAtlas and probe:GetAtlas()
	if IsSecret(texture) then texture = nil end
	if IsSecret(atlas) then atlas = nil end

	local category, blocked
	local known = type(texture) == "number" and cursorLookup[texture]
	if known then
		category, blocked = known[1], known[2]
	else
		category, blocked = ReadCursorName(texture)
		if not category then
			local fromAtlas, atlasBlocked = ReadCursorName(atlas)
			category, blocked = fromAtlas, blocked or atlasBlocked
		end
	end
	return true, category, blocked or false, atlas or texture
end

-- Renvoie la catégorie de l'objet, l'indicateur "grisé" et le nom de curseur brut
local function Classify(unit, name)
	local hasCursor, category, blocked, cursor = ReadCursor(unit)
	if category ~= "ore" and category ~= "herb" and IsQuestRelated(unit, name) then
		category = "quest"
	end
	if not category and (hasCursor or (UnitIsInteractable and SafeCall(UnitIsInteractable, unit) == true)) then
		category = "other"
	end
	return category, blocked, cursor
end

-- "ready" : on peut interagir ; "far" : trop loin ; "locked" : à portée mais le jeu refuse
-- (compétence insuffisante, objet verrouillé…). Sans l'API de portée (Classic Era), un
-- curseur grisé est simplement considéré comme trop loin.
local function ReadState(unit, blocked)
	local inRange
	if UnitIsInInteractRange then inRange = SafeCall(UnitIsInInteractRange, unit) end
	if inRange == false then return "far", inRange end
	if blocked then return inRange == true and "locked" or "far", inRange end
	return "ready", inRange
end

---------------------------------------------------------------------------
-- Cible
---------------------------------------------------------------------------

local function GetNamePlate(unit)
	return C_NamePlate and SafeCall(C_NamePlate.GetNamePlateForUnit, unit)
end

-- Y a-t-il une cible d'interaction ? true, false, ou nil si le client ne le dit pas
-- (valeurs secrètes). Un objet du décor n'"existe" pas au sens de UnitExists.
local function SoftTargetExists()
	local isUnit, isObject = SafeCall(UnitExists, SOFT), SafeCall(UnitIsGameObject, SOFT)
	if isUnit == true or isObject == true then return true end
	if isUnit == false and isObject == false then return false end
	return nil
end

-- Renvoie le jeton d'unité à interroger, sa nameplate (nil si le jeu ne l'affiche pas, ou
-- pas encore) et le chemin suivi (pour le debug). Le jeton "softinteract" suffit en général ;
-- tant qu'il n'a jamais donné la nameplate d'un objet du décor sur ce client, on la cherche
-- aussi en balayant les nameplates visibles. Sans cible lisible, la quatrième valeur dit si
-- c'est faute de le savoir.
local function ResolveTarget()
	local exists = SoftTargetExists()
	if exists == false then return nil end
	local plate = GetNamePlate(SOFT)
	if plate then
		if not directWorks and SafeCall(UnitIsGameObject, SOFT) == true then directWorks = true end
		return SOFT, plate, L.VIA_DIRECT
	end
	if not directWorks then
		for unit in pairs(activeUnits) do
			if SafeCall(UnitIsGameObject, unit) == true or SafeCall(UnitIsUnit, unit, SOFT) == true then
				plate = GetNamePlate(unit)
				if plate then return unit, plate, L.VIA_SWEEP end
			end
		end
	end
	if exists then return SOFT, nil, L.VIA_DIRECT end
	return nil, nil, nil, true
end

---------------------------------------------------------------------------
-- Lueur
---------------------------------------------------------------------------

-- Donne à une couche une image de l'addon ; à défaut, une texture du jeu. Renvoie false si
-- l'image manque.
local function LoadImage(texture, file)
	if texture:SetTexture(MEDIA .. file .. ".tga") == false then
		texture:SetTexture(FALLBACK_TEXTURE)
		return false
	end
	return true
end

-- Renvoie la couche, et si son image a été trouvée
local function NewLayer(parent, file, drawLayer, subLevel, blendMode)
	local texture = parent:CreateTexture(nil, drawLayer, nil, subLevel)
	local found = LoadImage(texture, file)
	texture:SetBlendMode(blendMode or "ADD")
	texture:SetPoint("CENTER")
	texture:SetVertexColor(1, 1, 1, 0)
	-- positions et tailles animées au sous-pixel : pas d'accrochage à la grille
	if texture.SetSnapToPixelGrid then texture:SetSnapToPixelGrid(false) end
	if texture.SetTexelSnappingBias then texture:SetTexelSnappingBias(0) end
	return texture, found
end

local silhouette = {}     -- owner, mask, outline, applied, show, failed (nom du texte qui dit pourquoi elle est indisponible)

-- Crée les couches d'un effet, et celles de ses ondes
local function BuildEffect(effect)
	local fx = { waves = {} }
	effect.fx, effect.layers = fx, {}
	local function Layer(...)
		local texture, found = NewLayer(glow.frame, ...)
		if not found then effect.missing = true end
		effect.layers[#effect.layers + 1] = texture
		glow.layers[#glow.layers + 1] = texture
		if silhouette.applied then pcall(texture.AddMaskTexture, texture, silhouette.mask) end
		return texture
	end
	effect.Build(fx, Layer)
	if effect.wave then
		for i = 1, 2 do fx.waves[i] = { texture = Layer(effect.wave, "BORDER") } end
	end
end

-- Renvoie l'effet à dessiner : celui du réglage, construit à son premier usage, ou l'effet
-- de secours si ses images manquent. Quand il change, ses couches remplacent celles du précédent.
local function UseEffect()
	local effect = EFFECTS[db.effect]
	if not effect.fx then BuildEffect(effect) end
	if effect.missing then
		effect = EFFECTS.fallback
		if not effect.fx then BuildEffect(effect) end
	end
	if effect ~= glow.effect then
		if glow.effect then
			for _, texture in ipairs(glow.effect.layers) do texture:Hide() end
		end
		for _, texture in ipairs(effect.layers) do texture:Show() end
		for _, wave in ipairs(effect.fx.waves) do
			wave.age = nil
			Tint(wave.texture, 1, 1, 1, 0)
		end
		glow.effect = effect
	end
	return effect
end

-- Lance une onde : un anneau qui s'élargit en s'éteignant, ou qui se resserre sur la lueur
local function StartWave(from, to, duration, peak, inward)
	local chosen
	for _, wave in ipairs(glow.effect.fx.waves) do
		if not wave.age then chosen = wave break end
		if not chosen or wave.age > chosen.age then chosen = wave end
	end
	if not chosen then return end
	chosen.age, chosen.from, chosen.to = 0, from, to
	chosen.duration, chosen.peak, chosen.inward = duration, peak, inward
end

local function SetState(state)
	if state == glow.state then return end
	if state == "ready" then
		-- verrouillage : un anneau se resserre sur la lueur, qui s'illumine un instant
		glow.flash = 1
		StartWave(1.50, 1.00, 0.35, 0.9, true)
	end
	glow.state = state
end

-- Mémorise la position de la lueur à l'écran, pour pouvoir la dissiper sur place quand sa
-- nameplate disparaît. Certaines mesures sont interdites ou secrètes selon le contexte.
local function CachePosition(frame)
	glow.gx = nil
	if glow.measureFailed then return end
	local ok, x, y = pcall(frame.GetCenter, frame)
	local okScale, scale = pcall(frame.GetEffectiveScale, frame)
	if not ok or not okScale then glow.measureFailed = true return end
	local uiScale = UIParent:GetEffectiveScale()
	-- une valeur secrète ne se teste même pas : on l'écarte avant tout autre examen
	if IsSecret(x) or IsSecret(y) or IsSecret(scale) or IsSecret(uiScale) then return end
	if not x or not y or not scale or uiScale == 0 then return end
	local ratio = scale / uiScale
	glow.gx, glow.gy, glow.gscale = x * ratio, y * ratio, ratio
end

local context = {}  -- ce que l'effet reçoit à chaque image, réutilisé de l'une à l'autre

local function Animate(self, elapsed)
	if elapsed > 0.1 then elapsed = 0.1 end -- pas de saut après un gel d'image
	local effect = UseEffect()
	local fx, c = effect.fx, context

	glow.appear = Approach(glow.appear, 1, elapsed / APPEAR_TIME)
	glow.ready  = Approach(glow.ready, glow.state == "ready" and 1 or 0, elapsed / BLEND_TIME)
	glow.locked = Approach(glow.locked, glow.state == "locked" and 1 or 0, elapsed / BLEND_TIME)
	glow.flash  = max(glow.flash - elapsed / FLASH_TIME, 0)
	local blend = min(elapsed * 8, 1)
	glow.r = Lerp(glow.r, glow.targetR, blend)
	glow.g = Lerp(glow.g, glow.targetG, blend)
	glow.b = Lerp(glow.b, glow.targetB, blend)

	local ready, locked = glow.ready, glow.locked
	-- respiration et mouvement, plus vifs à portée, ralentis sur un objet indisponible
	glow.phase = glow.phase + elapsed * TWO_PI / Lerp(3.4, 1.7, ready)
	glow.spin = glow.spin - elapsed * Lerp(0.55, 1.6, ready) * (1 - 0.7 * locked)

	c.frame, c.elapsed, c.size = self, elapsed, db.size
	c.arrive = 1 - (1 - glow.appear) ^ 3            -- 0 -> 1 en décélérant
	c.alpha = c.arrive * db.intensity / 100 * (1 - 0.5 * locked)
	c.ready, c.locked, c.flash, c.phase, c.spin = ready, locked, glow.flash, glow.phase, glow.spin
	c.breath = 0.5 + 0.5 * sin(glow.phase)
	c.twinkle = 0.5 + 0.5 * sin(glow.phase * 2.3 + 1.3)
	-- couleur : éteinte vers le gris sur un objet indisponible, tirée vers le blanc pour les
	-- traits fins (h) et plus encore pour le cœur des éclats (w)
	local r = Lerp(glow.r, 0.62, 0.75 * locked)
	local g = Lerp(glow.g, 0.62, 0.75 * locked)
	local b = Lerp(glow.b, 0.62, 0.75 * locked)
	c.r, c.g, c.b = r, g, b
	c.hr, c.hg, c.hb = Lerp(r, 1, 0.55), Lerp(g, 1, 0.55), Lerp(b, 1, 0.55)
	c.wr, c.wg, c.wb = Lerp(r, 1, 0.75), Lerp(g, 1, 0.75), Lerp(b, 1, 0.75)

	effect.Update(fx, c)

	-- ondes : un "ping" régulier vers l'extérieur, qui se tait sur un objet indisponible
	glow.nextPing = glow.nextPing - elapsed
	if glow.nextPing <= 0 then
		glow.nextPing = Lerp(2.4, 3.8, ready)
		if glow.state ~= "locked" and effect.ping ~= false then StartWave(0.55, 1.45, 1.0, 0.55) end
	end
	local base, flat, gain = fx.waveSize or c.size, effect.flat or 1, c.alpha * (effect.waveGain or 1)
	for _, wave in ipairs(fx.waves) do
		if wave.age then
			wave.age = wave.age + elapsed
			local progress = wave.age / wave.duration
			if progress >= 1 then
				wave.age = nil
				Tint(wave.texture, 1, 1, 1, 0)
			else
				local fade
				if wave.inward then
					fade = progress < 0.7 and progress / 0.7 or (1 - progress) / 0.3
				else
					fade = (1 - progress) ^ 1.5
				end
				local width = base * Lerp(wave.from, wave.to, 1 - (1 - progress) ^ 2)
				Sized(wave.texture, width, width * flat)
				if fx.waveY then Place(wave.texture, self, 0, fx.waveY) end
				if fx.waveAngle then wave.texture:SetRotation(fx.waveAngle) end
				Tint(wave.texture, c.hr, c.hg, c.hb, gain * wave.peak * fade)
			end
		end
	end

	CachePosition(self)
end

local function CreateGlow()
	local frame = CreateFrame("Frame")
	frame:SetSize(1, 1)
	frame:Hide()
	frame:SetScript("OnUpdate", Animate)
	glow.frame = frame
	return frame
end

local function CreateGhost()
	ghost = CreateFrame("Frame", nil, UIParent)
	ghost:SetFrameStrata("BACKGROUND")
	ghost:SetSize(1, 1)
	ghost:Hide()
	ghost.band = NewLayer(ghost, "halo", "BACKGROUND")
	ghost.ring = NewLayer(ghost, "ring", "BORDER")
	ghost:SetScript("OnUpdate", function(self, elapsed)
		self.age = self.age + elapsed
		local progress = self.age / GHOST_TIME
		if progress >= 1 then self:Hide() return end
		local size = self.size * (1 + 0.35 * (1 - (1 - progress) ^ 3))
		local fade = self.alpha * (1 - progress) ^ 2
		Sized(self.band, size * self.spread, size * self.spread * self.flat)
		Tint(self.band, self.r, self.g, self.b, 0.7 * fade)
		Sized(self.ring, size, size * self.flat)
		Tint(self.ring, Lerp(self.r, 1, 0.55), Lerp(self.g, 1, 0.55), Lerp(self.b, 1, 0.55), self.ringed and fade or 0)
	end)
	return ghost
end

-- Dissipation sur place : la lueur s'élargit et s'éteint là où elle se trouvait, sous les
-- traits de son effet (sa lueur, l'anneau de ses ondes)
local function PlayGhost()
	local effect = glow.effect
	if not glow.gx or effect == EFFECTS.fallback or glow.appear < 0.3 then return end
	local frame = ghost or CreateGhost()
	if frame.effect ~= effect then
		frame.effect = effect
		LoadImage(frame.band, effect.band or "glow")
		LoadImage(frame.ring, effect.wave or "ring")
	end
	local fx = effect.fx
	frame.spread = effect.band and 1 or 1.5  -- une simple lueur n'occupe que le centre de son image
	frame.flat, frame.ringed = effect.flat or 1, effect.wave ~= nil
	frame.ring:SetRotation(fx.waveAngle or 0)
	frame:ClearAllPoints()
	frame:SetPoint("CENTER", UIParent, "BOTTOMLEFT", glow.gx, glow.gy + (fx.waveY or 0) * glow.gscale)
	frame.size = (fx.waveSize or db.size) * glow.gscale
	frame.r, frame.g, frame.b = glow.r, glow.g, glow.b
	frame.alpha = db.intensity / 100 * (1 - 0.5 * glow.locked)
	frame.age = 0
	frame:Show()
end

---------------------------------------------------------------------------
-- Silhouette
---------------------------------------------------------------------------

-- L'interface se dessine toujours par-dessus le monde : un addon ne peut rien faire passer
-- derrière un modèle 3D. On triche pour le personnage du joueur, seul modèle dont la place
-- à l'écran se déduit sans mesure : la caméra vise sa tête, et sa taille ne dépend que du
-- zoom. Un masque en ellipse y découpe la lueur, qui semble alors passer derrière lui.
local BODY_HEIGHT = 1.9   -- hauteur du personnage en hauteurs d'écran, caméra à 1 m, champ de vision par défaut

local function Smoothstep(low, high, value)
	local t = Clamp((value - low) / (high - low), 0, 1)
	return t * t * (3 - 2 * t)
end

-- Renvoie la largeur et la hauteur du personnage à l'écran, et la position de ses pieds par
-- rapport au centre de l'écran (unités de l'interface) ; nil en vue subjective
local function MeasureBody()
	local zoom = GetCameraZoom and SafeCall(GetCameraZoom)
	if not zoom or zoom < 2 then return nil end
	local fov = tonumber(GetCVarValue("cameraFov")) or 90
	local height = BODY_HEIGHT * UIParent:GetHeight() / zoom / math.tan(math.rad(fov / 2)) * db.bodyScale / 100
	local width = height * 0.45
	if IsMounted and SafeCall(IsMounted) == true then
		height = height * 1.3
		width = height * 0.8
	end
	-- vu d'en haut, le corps paraît raccourci et tient presque entier sous le centre de l'écran
	height = height * 0.9
	return width, height, (db.bodyShift / 100 - 0.92) * height
end

local function UpdateSilhouette()
	local mask, outline = silhouette.mask, silhouette.outline
	local width, height, feet = MeasureBody()
	if not width then
		mask:SetSize(0.01, 0.01)
		outline:Hide()
		return
	end
	-- la découpe ne vaut que si l'objet est plus loin que le personnage, donc plus haut à
	-- l'écran que ses pieds ; plus près de la caméra, c'est à la lueur de le recouvrir
	local strength = 1
	if glow.anchor and glow.gx then
		strength = Smoothstep(feet - 0.10 * height, feet + 0.20 * height, glow.gy - UIParent:GetHeight() / 2)
	end
	local centerY = feet + height / 2
	local maskWidth, maskHeight = width * 1.9, height * 1.5
	mask:SetSize(max(maskWidth * strength, 0.01), max(maskHeight * strength, 0.01))
	mask:SetPoint("CENTER", silhouette.owner, "CENTER", 0, centerY)
	if silhouette.show then
		-- contour de la zone entièrement masquée : le cœur du masque en occupe 55 %, et
		-- l'anneau qui le dessine est à 74 % de sa texture
		outline:SetSize(maskWidth * 0.55 / 0.74, maskHeight * 0.55 / 0.74)
		outline:SetPoint("CENTER", silhouette.owner, "CENTER", 0, centerY)
		outline:Show()
	else
		outline:Hide()
	end
end

local function CreateSilhouette()
	local owner = CreateFrame("Frame", nil, UIParent)
	owner:SetSize(1, 1)
	owner:SetPoint("CENTER", WorldFrame or UIParent, "CENTER", 0, 0)
	owner:Hide()
	local ok, mask = pcall(owner.CreateMaskTexture, owner)
	if not ok or not mask then
		silhouette.failed = "FAIL_NO_MASK"
		return
	end
	-- hors du masque, "blanc" : la lueur n'est entamée que dans l'ellipse
	local set, loaded = pcall(mask.SetTexture, mask, MEDIA .. "hole.tga", "CLAMPTOWHITE", "CLAMPTOWHITE")
	if not set or loaded == false then
		silhouette.failed = "FAIL_MASK_TEXTURE"
		return
	end
	mask:SetSize(0.01, 0.01)
	mask:SetPoint("CENTER", owner, "CENTER", 0, 0)
	local outline = owner:CreateTexture(nil, "OVERLAY")
	outline:SetTexture(MEDIA .. "ring.tga")
	outline:SetVertexColor(1, 0.25, 0.25, 0.9)
	outline:Hide()
	silhouette.owner, silhouette.mask, silhouette.outline = owner, mask, outline
	owner:SetScript("OnUpdate", UpdateSilhouette)
end

-- Pose ou retire la découpe sur les couches de la lueur, selon le réglage et son état
local function ApplySilhouette()
	local wanted = db.silhouette and not silhouette.failed
	if not (wanted or silhouette.show or silhouette.applied) then return end
	if not silhouette.owner and not silhouette.failed then CreateSilhouette() end
	if not silhouette.owner then return end
	if glow.frame and wanted ~= (silhouette.applied == true) then
		local method = wanted and "AddMaskTexture" or "RemoveMaskTexture"
		for _, texture in ipairs(glow.layers) do
			if not pcall(texture[method], texture, silhouette.mask) then
				silhouette.failed = "FAIL_MASK_REFUSED"
				break
			end
		end
		if silhouette.failed then
			for _, texture in ipairs(glow.layers) do pcall(texture.RemoveMaskTexture, texture, silhouette.mask) end
			wanted = false
		end
		silhouette.applied = wanted
	end
	if (silhouette.applied and glow.anchor) or silhouette.show then
		silhouette.owner:Show()
	else
		silhouette.owner:Hide()
	end
end

local function Release()
	if not glow.anchor then return end
	PlayGhost()
	glow.frame:Hide()
	glow.frame:ClearAllPoints()
	glow.frame:SetParent(nil)
	glow.anchor, glow.preview, glow.retarget, glow.gx = nil, nil, nil, nil
	ApplySilhouette()
end

-- Accroche la lueur à un cadre (la nameplate de la cible, ou l'écran pour l'aperçu) et
-- relance son animation d'arrivée
local function Attach(anchor, offsetX, offsetY, category, state)
	local frame = glow.frame or CreateGlow()
	frame:SetParent(anchor)
	if anchor ~= UIParent then
		-- sous le contenu de la nameplate, pour ne pas laver son texte
		local ok, level = pcall(anchor.GetFrameLevel, anchor)
		if ok and not IsSecret(level) and level then frame:SetFrameLevel(max(level - 1, 0)) end
	end
	frame:ClearAllPoints()
	frame:SetPoint("CENTER", anchor, "CENTER", offsetX, offsetY)
	frame:SetIgnoreParentAlpha(anchor ~= UIParent and not db.followAlpha)

	local color = COLORS[category] or COLORS.other
	glow.anchor = anchor
	glow.state, glow.pending = state, nil
	glow.ready  = state == "ready" and 1 or 0
	glow.locked = state == "locked" and 1 or 0
	glow.r, glow.g, glow.b = color[1], color[2], color[3]
	glow.targetR, glow.targetG, glow.targetB = color[1], color[2], color[3]
	glow.appear, glow.flash, glow.phase, glow.nextPing = 0, 0, 0, 1.6
	glow.spin = math.random() * TWO_PI
	for _, wave in ipairs(UseEffect().fx.waves) do
		wave.age = nil
		Tint(wave.texture, 1, 1, 1, 0)
	end
	StartWave(0.50, 1.50, 0.9, 0.8)
	frame:Show()
	ApplySilhouette()
end

-- Un nouvel état n'est affiché qu'une fois stable, pour ne pas scintiller à la limite de portée
local function ProposeState(state)
	if state == glow.state then glow.pending = nil return end
	local now = GetTime()
	if glow.pending ~= state then
		glow.pending, glow.pendingSince = state, now
	elseif now - glow.pendingSince >= (state == "locked" and LOCK_DELAY or STATE_DELAY) then
		glow.pending = nil
		SetState(state)
	end
end

local function Present(plate, category, state)
	if glow.anchor ~= plate or glow.retarget then
		Release()
		Attach(plate, 0, db.offsetY, category, state)
		return
	end
	local color = COLORS[category] or COLORS.other
	glow.targetR, glow.targetG, glow.targetB = color[1], color[2], color[3]
	ProposeState(state)
end

---------------------------------------------------------------------------
-- Évaluation
---------------------------------------------------------------------------

local function Flag(value)
	if value == nil then return "?" end
	return value and L.YES or L.NO
end

local function Report(line, detail)
	if not db.debug or line == lastReport then return end
	lastReport = line
	Print(line)
	local text = detail and detail()
	if text and text ~= "" then print("    " .. text) end
end

local function DescribeTarget(unit, name, via, cursor, inRange)
	local parts = { L.DEBUG_CURSOR:format(tostring(cursor)), L.DEBUG_VIA:format(via), L.DEBUG_RANGE:format(Flag(inRange)) }
	if C_QuestLog and C_QuestLog.UnitIsRelatedToActiveQuest then
		parts[#parts + 1] = L.DEBUG_QUEST:format(Flag(SafeCall(C_QuestLog.UnitIsRelatedToActiveQuest, unit)))
	end
	parts[#parts + 1] = L.DEBUG_MATCH:format(MatchQuestObjective(name) or L.MATCH_NONE, #questTexts)
	if C_Secrets and C_Secrets.ShouldUnitIdentityBeSecret then
		parts[#parts + 1] = L.DEBUG_SECRET:format(Flag(SafeCall(C_Secrets.ShouldUnitIdentityBeSecret, unit)))
	end
	if C_NamePlateManager and C_NamePlateManager.IsNamePlateUnitBehindCamera then
		parts[#parts + 1] = L.DEBUG_BEHIND:format(Flag(SafeCall(C_NamePlateManager.IsNamePlateUnitBehindCamera, unit)))
	end
	return table.concat(parts, " | ")
end

-- Détermine la cible d'interaction courante, puis met en accord avec elle l'affichage natif
-- du jeu (ouvert seulement si elle mérite d'être mise en lumière) et la lueur elle-même
function Evaluate()
	if glow.preview then return end
	if not db.enabled then Release() return end

	local unit, plate, via, unknown = ResolveTarget()
	if plate or not unit then glow.plateMissingSince = nil end
	if not unit then
		if lastReport then Report(L.DEBUG_NO_TARGET) end
		SetGate(unknown == true) -- faute de savoir, on laisse le jeu montrer sa cible
		Release()
		return
	end
	local name = SafeCall(UnitName, unit)
	local label = name or "?"
	-- seuls les objets du décor sont mis en lumière : ni PNJ, ni cadavres
	if SafeCall(UnitIsGameObject, unit) ~= true then
		Report(L.DEBUG_IGNORED:format(label))
		SetGate(false)
		Release()
		return
	end

	local category, blocked, cursor = Classify(unit, name)
	local state, inRange = ReadState(unit, blocked)
	local wanted = category and ((category == "other" and db.showOther) or db.categories[category]) or false
	SetGate(wanted)
	if not wanted then
		Report(L.DEBUG_HIDDEN:format(label, CategoryName(category)),
			function() return DescribeTarget(unit, name, via, cursor, inRange) end)
		Release()
		return
	end
	if not plate then
		-- la nameplate vient d'être demandée au jeu : la lueur s'y posera à son arrivée.
		-- Si elle tarde, c'est que le jeu connaît la cible sans vouloir l'afficher.
		Release()
		local now = GetTime()
		glow.plateMissingSince = glow.plateMissingSince or now
		if now - glow.plateMissingSince > 0.5 then
			Report(L.DEBUG_NO_PLATE:format(label, CategoryName(category)),
				function() return DescribeTarget(unit, name, via, cursor, inRange) end)
		end
		return
	end

	Present(plate, category, state)
	Report(L.DEBUG_SHOWN:format(label, CategoryName(category), StateName(glow.state)),
		function() return DescribeTarget(unit, name, via, cursor, inRange) end)
end

---------------------------------------------------------------------------
-- Aperçu
---------------------------------------------------------------------------

-- Déroulé de l'aperçu : chaque état, puis la dissipation
local PREVIEW_STAGES = { { "far", 3.0 }, { "ready", 4.5 }, { "locked", 2.5 } }

-- Montre la lueur à l'écran, dans la catégorie suivante, et renvoie celle-ci. La position se
-- compte depuis le centre de l'écran ; sans elle, la lueur se place à côté du personnage,
-- pour la voir en entier. En boucle, l'aperçu enchaîne les catégories jusqu'à StopPreview.
local function StartPreview(offsetX, offsetY, loop)
	Release()
	previewIndex = previewIndex % #CATEGORY_ORDER + 1
	local category = CATEGORY_ORDER[previewIndex]
	Attach(UIParent, offsetX or 220, offsetY or 0, category, "far")
	glow.preview = { stage = 1, left = PREVIEW_STAGES[1][2], x = offsetX, y = offsetY, loop = loop }
	return category
end

local function StopPreview()
	if glow.preview then Release() end
end

local function UpdatePreview(elapsed)
	local preview = glow.preview
	preview.left = preview.left - elapsed
	if preview.left > 0 then return end
	preview.stage = preview.stage + 1
	local stage = PREVIEW_STAGES[preview.stage]
	if not stage then
		if preview.loop then StartPreview(preview.x, preview.y, true) else Release() end
		return
	end
	SetState(stage[1])
	preview.left = stage[2]
end

---------------------------------------------------------------------------
-- Événements
---------------------------------------------------------------------------

local events = CreateFrame("Frame")
local sincePoll = 0

events:SetScript("OnUpdate", function(_, elapsed)
	if not db then return end
	if glow.preview then
		UpdatePreview(elapsed)
		return
	end
	sincePoll = sincePoll + elapsed
	if sincePoll >= POLL_INTERVAL then
		sincePoll = 0
		EnsureIconCVars()
		Evaluate()
	end
end)

local handlers = {}

function handlers.ADDON_LOADED(name)
	if name ~= ADDON_NAME then return end
	LueurDB = LueurDB or {}
	db = LueurDB
	if db.schema ~= SCHEMA then
		local from = db.schema or 1
		if from < 2 then db.size = nil end -- le halo a changé de nature : l'ancienne taille n'a plus le même sens
		if from < 3 then RepairSavedCVars() end
		if from < 4 then
			-- les styles du halo sont devenus des effets parmi d'autres ; cadavres à dépecer et
			-- butin ne sont plus mis en lumière
			db.effect, db.style = db.effect or LEGACY_STYLES[db.style], nil
			if type(db.categories) == "table" then db.categories.skin, db.categories.loot = nil, nil end
		end
		db.schema = SCHEMA
	end
	CopyDefaults(DEFAULTS, db)
	if not EFFECTS[db.effect] or db.effect == "fallback" then db.effect = DEFAULTS.effect end
	if not ns.LOCALES[db.language] then db.language = DEFAULTS.language end
	UseLanguage()
	for key, limits in pairs(LIMITS) do
		db[key] = type(db[key]) == "number" and Clamp(db[key], limits[1], limits[2]) or DEFAULTS[key]
	end
	probe = UIParent:CreateTexture(nil, "BACKGROUND")
	probe:Hide()
	BuildCursorLookup()
	events:UnregisterEvent("ADDON_LOADED")
	ns.db = db
	if ns.SetupInterface then ns.SetupInterface() end -- Menu.lua : bouton de la minimap
end

function handlers.PLAYER_LOGIN()
	if db.enabled then ApplyCVars() end
end

-- Les réglages synchronisés avec le compte peuvent arriver après PLAYER_LOGIN et
-- écraser nos valeurs : on les réapplique à ces moments-là.
function handlers.VARIABLES_LOADED()
	if db.enabled then ApplyCVars() end
end

function handlers.PLAYER_ENTERING_WORLD()
	if db.enabled then ApplyCVars() end
end

-- Les CVars ne se touchent plus une fois en combat : juste avant, on rouvre l'affichage
-- natif pour que la lueur continue d'apparaître sur les objets croisés pendant le combat.
function handlers.PLAYER_REGEN_DISABLED()
	if db.enabled then SetGate(true) end
end

function handlers.PLAYER_REGEN_ENABLED()
	if pendingCVars == "apply" then ApplyCVars()
	elseif pendingCVars == "restore" then RestoreCVars() end
	pendingCVars = false
	Evaluate()
end

function handlers.NAME_PLATE_UNIT_ADDED(unit)
	activeUnits[unit] = true
	Evaluate()
end

function handlers.NAME_PLATE_UNIT_REMOVED(unit)
	activeUnits[unit] = nil
	-- la nameplate de la lueur s'en va : on la dissipe tout de suite, là où elle était
	local plate = GetNamePlate(unit)
	if plate and plate == glow.anchor then Release() end
end

function handlers.PLAYER_SOFT_INTERACT_CHANGED(oldTarget, newTarget)
	-- une nameplate recyclée d'une cible à l'autre ne suffit pas à voir le changement
	if not IsSecret(oldTarget) and not IsSecret(newTarget) and oldTarget and newTarget and oldTarget ~= newTarget then
		glow.retarget = glow.anchor ~= nil and not glow.preview
	end
	Evaluate()
end

function handlers.QUEST_LOG_UPDATE()
	questsDirty = true
end

function handlers.WORLD_CURSOR_TOOLTIP_UPDATE()
	if LearnFromTooltip() then Evaluate() end
end

events:SetScript("OnEvent", function(_, event, ...)
	local handler = handlers[event]
	if handler and (db or event == "ADDON_LOADED") then handler(...) end
end)
for event in pairs(handlers) do
	pcall(events.RegisterEvent, events, event)
end

---------------------------------------------------------------------------
-- Réglages
---------------------------------------------------------------------------

-- Replace la lueur après un changement de réglage qui touche son accroche
local function Reattach()
	if glow.anchor and not glow.preview then
		glow.retarget = true
		Evaluate()
	end
end

-- Ce qu'un réglage oblige à refaire quand il change ; ceux qui n'y figurent pas sont relus
-- à chaque image par l'animation
local APPLY = { offsetY = Reattach, followAlpha = Reattach, silhouette = ApplySilhouette }

function APPLY.enabled()
	if db.enabled then
		ApplyCVars()
		Evaluate()
	else
		Release()
		RestoreCVars()
	end
end

function APPLY.range()
	if db.enabled then ApplyCVars() end
end
APPLY.arc = APPLY.range

function APPLY.exclusive()
	gateOpen = nil
	Evaluate()
end

function APPLY.debug()
	lastReport = nil
end

function APPLY.language()
	UseLanguage()
	lastReport = nil
	if ns.Retext then ns.Retext() end -- Menu.lua : les textes de la fenêtre
end

-- Prévient Menu.lua qu'un réglage a changé, que ce soit par le menu ou par une commande
local function Notify()
	if ns.Refresh then ns.Refresh() end
end

-- Change un réglage, borné s'il est numérique, et en applique les conséquences
local function SetOption(key, value)
	local limits = LIMITS[key]
	if limits then value = Clamp(math.floor(value + 0.5), limits[1], limits[2]) end
	db[key] = value
	if APPLY[key] then APPLY[key]() end
	Notify()
end

-- Les objets génériques ("other") se règlent comme une catégorie, mais sont rangés à part
local function IsCategoryShown(key)
	if key == "other" then return db.showOther end
	return db.categories[key]
end

local function SetCategory(key, shown)
	if key == "other" then db.showOther = shown else db.categories[key] = shown end
	Evaluate()
	Notify()
end

-- Affiche ou masque le contour de la zone découpée autour du personnage (jamais sauvegardé)
local function ShowZone(shown)
	silhouette.show = shown
	ApplySilhouette()
	Notify()
end

-- L'activation, la langue, le bouton de la minimap et ce que Lueur a appris des infobulles ne
-- sont pas des réglages de la lueur : la remise à zéro n'y touche pas
local KEPT_ON_RESET = { enabled = true, language = true, minimap = true, questObjects = true }

local function ResetOptions()
	for key, value in pairs(DEFAULTS) do
		if not KEPT_ON_RESET[key] then
			if type(value) == "table" then
				for subKey, subValue in pairs(value) do db[key][subKey] = subValue end
			else
				db[key] = value
			end
		end
	end
	silhouette.show = false
	ApplySilhouette()
	gateOpen, lastReport = nil, nil
	if db.enabled then ApplyCVars() end
	Reattach()
	Notify()
end

-- Active ou désactive Lueur en l'annonçant : sans le menu sous les yeux, rien d'autre ne le dit
local function Toggle(enabled)
	SetOption("enabled", enabled)
	Print(enabled and L.MSG_ENABLED or L.MSG_DISABLED)
end

-- Ce dont Menu.lua se sert
ns.LIMITS, ns.COLORS, ns.Print = LIMITS, COLORS, Print
ns.SetOption, ns.IsCategoryShown, ns.SetCategory = SetOption, IsCategoryShown, SetCategory
ns.Toggle, ns.ResetOptions, ns.ShowZone = Toggle, ResetOptions, ShowZone
ns.StartPreview, ns.StopPreview = StartPreview, StopPreview

function ns.IsPreviewing()
	return glow.preview ~= nil
end

function ns.IsZoneShown()
	return silhouette.show == true
end

-- Raison pour laquelle la découpe est indisponible sur ce client, ou nil
local function SilhouetteFailure()
	return silhouette.failed and L[silhouette.failed]
end
ns.SilhouetteFailure = SilhouetteFailure

---------------------------------------------------------------------------
-- Touche d'interaction
---------------------------------------------------------------------------

-- Ramasser, cueillir ou activer l'objet visé est une action protégée : seul un raccourci du
-- jeu peut la déclencher, pas le code d'un addon. Lueur n'a donc pas de raccourci à lui : il
-- donne accès à celui du jeu, "Interagir avec la cible", qui agit sur la cible d'interaction.
local INTERACT = "INTERACTTARGET"

local function BindingContext()
	return C_KeyBindings and C_KeyBindings.GetBindingContextForAction
		and SafeCall(C_KeyBindings.GetBindingContextForAction, INTERACT)
end

-- Renvoie la touche principale du raccourci d'interaction, ou nil
local function GetInteractKey()
	return (GetBindingKey(INTERACT, nil, BindingContext()))
end

-- Nom d'une touche tel que le jeu l'affiche
local function KeyText(key)
	return GetBindingText and GetBindingText(key) or key
end

-- Renvoie le nom du raccourci, autre que celui d'interaction, auquel cette touche sert déjà
local function KeyOwner(key)
	local action = GetBindingAction(key, nil, BindingContext())
	if type(action) ~= "string" or action == "" or action == INTERACT then return nil end
	return _G["BINDING_NAME_" .. action] or action
end

-- Donne cette touche au raccourci d'interaction, à la place de sa touche principale ; nil la
-- lui retire. Le raccourci qui s'en servait la perd. Renvoie false et la raison quand rien
-- n'a pu changer.
local function SetInteractKey(key)
	if InCombatLockdown() then return false, L.MSG_KEY_COMBAT end
	local context = BindingContext()
	local first, second = GetBindingKey(INTERACT, nil, context)
	-- comme le fait le jeu : tout retirer, puis remettre les touches dans l'ordre
	if first then SetBinding(first, nil, context) end
	if second then SetBinding(second, nil, context) end
	local bound = key == nil or SetBinding(key, INTERACT, context)
	if not bound and first then SetBinding(first, INTERACT, context) end
	if second and second ~= key then SetBinding(second, INTERACT, context) end
	local save = SaveBindings or AttemptToSaveBindings
	if save and GetCurrentBindingSet then pcall(save, GetCurrentBindingSet()) end
	Notify()
	if not bound then return false, L.MSG_KEY_REFUSED:format(key) end
	return true
end

ns.GetInteractKey, ns.SetInteractKey, ns.KeyOwner, ns.KeyText = GetInteractKey, SetInteractKey, KeyOwner, KeyText

---------------------------------------------------------------------------
-- Commandes
---------------------------------------------------------------------------

-- Minuscules sans accents : commandes et noms d'effets se tapent avec ou sans
local ACCENTS = {
	["à"] = "a", ["â"] = "a", ["ä"] = "a", ["ç"] = "c", ["é"] = "e", ["è"] = "e", ["ê"] = "e", ["ë"] = "e", ["î"] = "i",
	["ï"] = "i", ["ô"] = "o", ["ö"] = "o", ["ù"] = "u", ["û"] = "u", ["ü"] = "u", ["À"] = "a", ["Â"] = "a", ["Ç"] = "c",
	["É"] = "e", ["È"] = "e", ["Ê"] = "e", ["Î"] = "i", ["Ô"] = "o", ["Ù"] = "u", ["Û"] = "u",
}

local function Fold(text)
	return (text:gsub("[\195-\197][\128-\191]", ACCENTS):lower())
end

-- Mot tapé -> nom anglais de la commande ou de l'effet : ceux de la langue affichée, et le
-- nom affiché de chaque effet. Les noms anglais répondent toujours.
local ALIASES = {}

function UseLanguage()
	ns.UseLanguage(db.language)
	for word in pairs(ALIASES) do ALIASES[word] = nil end
	for word, command in pairs(L.COMMANDS) do ALIASES[Fold(word)] = command end
	for _, key in ipairs(ns.EFFECT_ORDER) do ALIASES[Fold(EffectLabel(key))] = key end
end

-- Remplace {réglage} par ses bornes et {réglage=} par sa valeur par défaut
local function Fill(text)
	return (text:gsub("{(%w+)(=?)}", function(key, default)
		if default == "=" then return tostring(DEFAULTS[key]) end
		return LIMITS[key][1] .. ".." .. LIMITS[key][2]
	end))
end

local function ShowHelp()
	Print(L.HELP_HEADER)
	for _, line in ipairs(L.HELP) do print("  " .. Fill(line)) end
end

-- Chaque commande reçoit son argument, et le nombre qu'il représente s'il en est un. Celle
-- qui renvoie false n'a pas su quoi en faire : l'aide s'affiche à sa place.
local COMMANDS = {}

function COMMANDS.menu()
	if ns.ToggleMenu then ns.ToggleMenu() end
end
COMMANDS[""] = COMMANDS.menu

function COMMANDS.minimap()
	if not ns.ShowMinimapButton then return end
	ns.ShowMinimapButton(db.minimap.hide)
	Print(L.SETTING:format(L.MINIMAP, Flag(not db.minimap.hide)))
end

function COMMANDS.on() Toggle(true) end
function COMMANDS.off() Toggle(false) end

function COMMANDS.preview()
	Print(L.MSG_PREVIEW:format(CategoryName(StartPreview())))
end

function COMMANDS.effect(arg)
	if arg ~= "fallback" and EFFECTS[arg] then
		SetOption("effect", arg)
		Print(L.SETTING:format(L.HEADER_EFFECT, EffectLabel(arg)))
	else
		local names = {}
		for index, key in ipairs(ns.EFFECT_ORDER) do names[index] = EffectLabel(key) end
		Print(L.MSG_EFFECTS:format(table.concat(names, ", "), EffectLabel(db.effect)))
	end
end

-- Commande d'un réglage numérique, annoncé sous le nom et le format qu'il a dans le menu :
-- `name` et `pattern` nomment des textes ("%d" à défaut de format)
local function NumberCommand(key, name, pattern)
	return function(_, number)
		if not number then return false end
		SetOption(key, number)
		Print(L.SETTING:format(L[name], (pattern and L[pattern] or "%d"):format(db[key])))
	end
end

COMMANDS.size = NumberCommand("size", "SIZE")
COMMANDS.intensity = NumberCommand("intensity", "INTENSITY", "FORMAT_PERCENT")
COMMANDS.offset = NumberCommand("offsetY", "OFFSET")

function COMMANDS.fade()
	SetOption("followAlpha", not db.followAlpha)
	Print(L.SETTING:format(L.FADE, Flag(db.followAlpha)))
end

function COMMANDS.exclusive()
	SetOption("exclusive", not db.exclusive)
	Print(db.exclusive and L.MSG_EXCLUSIVE_ON or L.MSG_EXCLUSIVE_OFF)
end

function COMMANDS.silhouette(arg)
	local size, shift = arg:match("^(%d+)%s*(%-?%d*)$")
	if arg == "" then
		SetOption("silhouette", not db.silhouette)
		Print(db.silhouette and L.MSG_SILHOUETTE_ON or L.MSG_SILHOUETTE_OFF)
		if db.silhouette and silhouette.failed then Print(L.MSG_CUTOUT_UNAVAILABLE:format(SilhouetteFailure())) end
	elseif arg == "show" then
		ShowZone(not silhouette.show)
		Print(silhouette.failed and L.MSG_CUTOUT_UNAVAILABLE:format(SilhouetteFailure())
			or silhouette.show and L.MSG_ZONE_SHOWN or L.MSG_ZONE_HIDDEN)
	elseif size then
		SetOption("bodyScale", tonumber(size))
		if shift ~= "" and shift ~= "-" then SetOption("bodyShift", tonumber(shift)) end
		Print(L.MSG_SILHOUETTE_VALUES:format(db.bodyScale, db.bodyShift))
	else
		Print(Fill(L.MSG_SILHOUETTE_USAGE))
	end
end

function COMMANDS.range(_, number)
	if not number then return false end
	SetOption("range", number)
	local applied = tonumber(GetCVarValue("SoftTargetInteractRange"))
	if pendingCVars == "apply" then
		Print(L.MSG_RANGE_COMBAT:format(db.range))
	elseif db.enabled and applied and applied ~= db.range then
		Print(L.MSG_RANGE_CLIENT:format(db.range, tostring(applied)))
	else
		Print(L.MSG_RANGE:format(db.range))
	end
end

function COMMANDS.arc(_, number)
	if not number then return false end
	SetOption("arc", number)
	Print(L.SETTING:format(L.DIRECTION, L["ARC_" .. db.arc]))
end

-- Sans argument, montre la touche d'interaction ; sinon l'assigne ("SHIFT-E"), ou la retire
function COMMANDS.key(arg)
	if arg ~= "" then
		local key
		if arg ~= "none" then key = arg:upper() end
		local owner = key and KeyOwner(key)
		local changed, reason = SetInteractKey(key)
		if not changed then Print(reason) return end
		if owner then Print(L.MSG_KEY_REPLACED:format(KeyText(key), owner)) end
	end
	local key = GetInteractKey()
	Print(L.SETTING:format(L.KEY, key and KeyText(key) or L.KEY_NONE))
end

for _, category in ipairs(CATEGORY_ORDER) do
	COMMANDS[category] = function()
		SetCategory(category, not IsCategoryShown(category))
		Print(L.SETTING:format(CategoryLabel(category), Flag(IsCategoryShown(category))))
	end
end

-- Nom de la langue réglée, tel que le menu le montre
local function LanguageName()
	return db.language == "auto" and L.LANGUAGE_AUTO or ns.LOCALES[db.language].LANGUAGE_NAME
end

-- La langue se désigne par "auto", par son code ("frFR"), ses deux premières lettres ou son nom
function COMMANDS.language(arg)
	local choice
	if arg == "auto" or arg == Fold(L.LANGUAGE_AUTO) then choice = "auto" end
	for code, texts in pairs(ns.LOCALES) do
		if arg == code:lower() or arg == code:sub(1, 2) or arg == Fold(texts.LANGUAGE_NAME) then choice = code end
	end
	if choice then SetOption("language", choice) end
	Print(L.SETTING:format(L.LANGUAGE, LanguageName()))
end

function COMMANDS.debug()
	SetOption("debug", not db.debug)
	Print(L.SETTING:format(L.DEBUG, Flag(db.debug)))
end

-- Ce à quoi le nom d'un objet est comparé pour le reconnaître comme objet de quête
function COMMANDS.objectives()
	RebuildQuestTexts()
	Print(L.OBJECTIVES_HEADER:format(#questTexts))
	for _, objective in ipairs(questTexts) do
		print("  " .. objective.text .. (objective.pickable and "" or L.OBJECTIVES_NOT_ITEM))
	end
	for name, title in pairs(db.questObjects) do
		if questTitles[title] then print("  " .. L.OBJECTIVES_LEARNED:format(name, title)) end
	end
end

function COMMANDS.status()
	local version, build = GetBuildInfo()
	Print(L.STATUS_CLIENT:format(tostring(version), tostring(build), tostring(GetLocale()), LanguageName()))
	for _, name in ipairs(MANAGED_CVARS) do
		local value = GetCVarValue(name)
		local default
		if C_CVar and C_CVar.GetCVarDefault then default = SafeCall(C_CVar.GetCVarDefault, name) end
		print(("  %s = %s%s"):format(name, value == nil and L.STATUS_CVAR_UNKNOWN or tostring(value),
			default and L.STATUS_CVAR_DEFAULT:format(tostring(default)) or ""))
	end
	print("  " .. L.STATUS_EXPECTED:format(db.range, db.arc))
	print("  " .. L.STATUS_GATE:format(Flag(db.exclusive), gateOpen == nil and "?" or gateOpen and L.GATE_OPEN or L.GATE_CLOSED))
	print("  " .. L.STATUS_SILHOUETTE:format(silhouette.failed and L.STATUS_UNAVAILABLE:format(SilhouetteFailure())
		or Flag(db.silhouette)))
	print("  " .. L.STATUS_DIRECT:format(directWorks and L.YES or L.STATUS_NOT_YET))
	print("  " .. L.STATUS_RANGE_API:format(Flag(UnitIsInInteractRange ~= nil)))
	local key = GetInteractKey()
	print("  " .. L.STATUS_KEY:format(key and KeyText(key) or L.KEY_NONE))
	local effect = EFFECTS[db.effect]
	print("  " .. L.STATUS_EFFECT:format(EffectLabel(db.effect),
		effect.missing and L.TEXTURES_MISSING or effect.fx and L.TEXTURES_LOADED or L.TEXTURES_PENDING))
end

COMMANDS.help = ShowHelp

SLASH_LUEUR1 = "/lueur"
SlashCmdList.LUEUR = function(input)
	local cmd, arg = Fold(input or ""):match("^%s*(%S*)%s*(.-)%s*$")
	local command = COMMANDS[ALIASES[cmd] or cmd]
	if not command or command(ALIASES[arg] or arg, tonumber(arg)) == false then ShowHelp() end
end
