-- Lueur v0.7.1 embedded inside FEASY. Preserve original copyright/attribution.
FEASY_LueurNS = FEASY_LueurNS or {}
