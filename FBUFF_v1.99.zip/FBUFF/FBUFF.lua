-- Original standalone addon. All rights reserved. See LICENSE.txt.
-- Target API: WoW Forever 1.60.1.69977.
local ADDON = ...
local trackers={}

-- FBUFF v1.27：完整移植 FCASTNATIVE v0.33 的 CastingBarFrameTemplate 視覺。
-- FBUFF 的 Aura/快取/計時邏輯不變；只讓實際 StatusBar 使用 Blizzard 原生施法條模板與 v0.33 尾光規則。
local function FBUFF_V033Color(kind)
    if kind=="self" or kind=="selfcustom" then return 1.000,0.843,0.000 end
    if kind=="friend" then return 0.15,0.90,0.28 end
    return 1.00,0.18,0.16
end

local function FBUFF_SetupV033Bar(bar, kind)
    if not bar then return end
    local r,g,b=FBUFF_V033Color(kind)
    bar:SetStatusBarColor(r,g,b,1)
    bar.FBUFFV033Kind=kind

    if bar.Text then bar.Text:SetText("") end
    if bar.CastTimeText then bar.CastTimeText:SetText("") end
    if bar.Icon then bar.Icon:Hide() end
    if bar.BorderShield then bar.BorderShield:Hide() end
    if bar.InterruptGlow then bar.InterruptGlow:Hide() end
    if bar.TextBorder then bar.TextBorder:Hide() end
    if bar.StandardFinish then bar.StandardFinish:Stop() end
    if bar.ChannelFinish then bar.ChannelFinish:Stop() end
    if bar.CraftFinish then bar.CraftFinish:Stop() end

    for _,n in ipairs({"EnergyGlow","Flakes01","Flakes02","Flakes03","ChannelShadow","CraftGlow","Flash"}) do
        local x=bar[n]
        if x then x:Hide(); if x.SetAlpha then x:SetAlpha(0) end end
    end
    if bar.Background then bar.Background:Show() end
    if bar.Border then bar.Border:Show() end

    -- 綠色友人BUFF母版：外框回到 FBUFF 原本可伸縮結構。
    -- 保留 CastingBar 的色條材質 / StandardGlow / Spark，
    -- 但不使用會隨高度變粗的 Blizzard Border / Background。
    if kind=="friend" or kind=="dot" or kind=="selfcustom" then
        if bar.Border then bar.Border:Hide() end
        if bar.Background then bar.Background:Hide() end
        if bar.rowBackground then
            bar.rowBackground:Show()
            bar.rowBackground:SetColorTexture(0.055,0.055,0.055,0.94)
        end
    end

    if bar.Spark then bar.Spark:Show();bar.Spark:SetAlpha(1) end
    if bar.StandardGlow then bar.StandardGlow:Show();bar.StandardGlow:SetAlpha(1) end

    local function RemoveAllMasks(region)
        if not region or not region.GetNumMaskTextures or not region.GetMaskTexture then return end
        for i=region:GetNumMaskTextures(),1,-1 do
            local mask=region:GetMaskTexture(i)
            if mask and region.RemoveMaskTexture then region:RemoveMaskTexture(mask) end
        end
    end
    RemoveAllMasks(bar.StandardGlow)
    RemoveAllMasks(bar.Spark)
    if bar.BorderMask then bar.BorderMask:Hide() end
    if bar.CastingMask then bar.CastingMask:Hide() end

    if not bar.FBUFFV033NativeGlowW and bar.StandardGlow then
        local w,h=bar.StandardGlow:GetSize()
        bar.FBUFFV033NativeGlowW=w
        bar.FBUFFV033NativeGlowH=h
    end

    -- v0.33 深黑灰「已消耗區」遮罩：右側向左增加。
    if not bar.FBUFFV033Cover then
        local cover=CreateFrame("Frame",nil,bar,"BackdropTemplate")
        cover:SetPoint("TOPRIGHT",bar,"TOPRIGHT",0,0)
        cover:SetPoint("BOTTOMRIGHT",bar,"BOTTOMRIGHT",0,0)
        cover:SetWidth(0.001)
        cover:SetFrameLevel(bar:GetFrameLevel()+15)
        cover:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8"})
        cover:SetBackdropColor(0.055,0.055,0.055,0.94)
        cover:EnableMouse(false)
        bar.FBUFFV033Cover=cover
    end

    if (kind=="friend" or kind=="dot" or kind=="selfcustom") and bar.FBUFFV033Cover then
        bar.FBUFFV033Cover:ClearAllPoints()
        bar.FBUFFV033Cover:SetPoint("TOPRIGHT",bar,"TOPRIGHT",0,-1)
        bar.FBUFFV033Cover:SetPoint("BOTTOMRIGHT",bar,"BOTTOMRIGHT",0,1)
    end

    if not bar.FBUFFV033Driver then
        local driver=CreateFrame("Frame",nil,bar)
        driver:SetScript("OnUpdate",function()
            if not bar:IsShown() then return end
            local mn,mx=bar:GetMinMaxValues()
            local value=bar:GetValue()
            if type(mn)~="number" or type(mx)~="number" or type(value)~="number" or mx<=mn then return end
            local ratio=(value-mn)/(mx-mn)
            if ratio<0 then ratio=0 elseif ratio>1 then ratio=1 end
            local width=bar:GetWidth() or 0
            local x=width*ratio

            if bar.FBUFFV033Cover then
                bar.FBUFFV033Cover:SetWidth(math.max(0.001,width*(1-ratio)))
            end

            if bar.Spark then
                bar.Spark:ClearAllPoints()
                if bar.FBUFFV033Kind=="friend" then
                    local fill=bar:GetStatusBarTexture()
                    if fill then
                        bar.Spark:SetPoint("CENTER",fill,"RIGHT",0,0)
                    else
                        bar.Spark:SetPoint("CENTER",bar,"LEFT",x,0)
                    end
                else
                    bar.Spark:SetPoint("CENTER",bar,"LEFT",x,0)
                end
                bar.Spark:SetShown(ratio>0)
                bar.Spark:SetAlpha(ratio>0 and 1 or 0)
            end

            if bar.StandardGlow and bar.Spark then
                bar.StandardGlow:ClearAllPoints()
                bar.StandardGlow:SetPoint("RIGHT",bar.Spark,"LEFT",2,0)
                local scaleX=1
                if ratio<=0.20 then scaleX=math.max(0,ratio/0.20) end
                local gw=bar.FBUFFV033NativeGlowW or 0
                local gh=bar.FBUFFV033NativeGlowH or 0
                if gw>0 and gh>0 then
                    local glowH=gh
                    if bar.FBUFFV033Kind=="friend" or bar.FBUFFV033Kind=="dot" or bar.FBUFFV033Kind=="selfcustom" then
                        glowH=bar:GetHeight() or gh
                    end
                    bar.StandardGlow:SetSize(math.max(0.01,gw*scaleX),glowH)
                end
                bar.StandardGlow:SetShown(ratio>0)
                bar.StandardGlow:SetAlpha(ratio>0 and 1 or 0)
            end
        end)
        bar.FBUFFV033Driver=driver
    end
end

local function FBUFF_ClassicCastbarsSpark(bar)
    if not bar or bar.FBUFFCCBSpark then return end

    local spark=bar:CreateTexture(nil,"OVERLAY")
    if spark.SetAtlas then pcall(spark.SetAtlas,spark,nil) end
    spark:SetTexture("Interface\\CastingBar\\UI-CastingBar-Spark")
    spark:SetBlendMode("ADD")
    spark:SetSize(32,32)
    spark:SetDrawLayer("OVERLAY",2)
    spark:ClearAllPoints()
    spark:SetPoint("CENTER",bar,"LEFT",0,0)
    spark:Show()
    bar.FBUFFCCBSpark=spark

    local driver=CreateFrame("Frame",nil,bar)
    driver:SetScript("OnUpdate",function()
        if not bar:IsShown() then spark:Hide(); return end

        local mn,mx=bar:GetMinMaxValues()
        local value=bar:GetValue()
        if type(mn)~="number" or type(mx)~="number" or type(value)~="number" or mx<=mn then
            spark:Hide(); return
        end

        local pct=(value-mn)/(mx-mn)
        if pct<0 then pct=0 elseif pct>1 then pct=1 end
        local sparkPosition=pct*(bar:GetWidth() or 0)

        spark:SetHeight(math.max((bar:GetHeight() or 20)*2.39,32))
        spark:ClearAllPoints()
        spark:SetPoint("CENTER",bar,"LEFT",sparkPosition,0)
        spark:Show()
    end)
    bar.FBUFFCCBSparkDriver=driver
end


local function FBUFF_AttachNativeSpark(bar)
    if not bar or bar.FBUFFNativeSpark then return end
    local fill=bar:GetStatusBarTexture()
    if not fill then return end

    local spark=bar:CreateTexture(nil,"OVERLAY")
    if spark.SetAtlas then pcall(spark.SetAtlas,spark,nil) end
    spark:SetTexture("Interface\\CastingBar\\UI-CastingBar-Spark")
    spark:SetBlendMode("ADD")
    spark:SetAlpha(1)
    spark:SetSize(32,math.max((bar:GetHeight() or 20)*2.39,32))
    spark:SetDrawLayer("OVERLAY",2)
    spark:SetPoint("CENTER",fill,"RIGHT",0,0)
    spark:Show()
    bar.FBUFFNativeSpark=spark

    local driver=CreateFrame("Frame",nil,bar)
    driver:SetScript("OnUpdate",function()
        if bar:IsShown() and fill:IsShown() then
            spark:SetWidth(32)
            spark:SetHeight(math.max((bar:GetHeight() or 20)*2.39,32))
            spark:Show()
        else
            spark:Hide()
        end
    end)
    bar.FBUFFNativeSparkDriver=driver
end

local function CreateTracker(config)
local GlobalCreateFrame=CreateFrame
local function CreateFrame(kind,name,parent,template)
    if name then name=name:gsub("^ForeverClassTimers",config.prefix) end
    if kind=="StatusBar" and not template then
        return GlobalCreateFrame(kind,name,parent,"CastingBarFrameTemplate")
    end
    return GlobalCreateFrame(kind,name,parent,template)
end
local VERSION = "0.65"
local HEIGHT, GAP = 24, 3
local TEXTURE = "Interface\\Buttons\\WHITE8X8"
local styles = {flat="Flat", rounded="Rounded", beveled="Beveled"}
local function StyleTexture(style)
    return style == "flat" and TEXTURE or "Interface\\AddOns\\FBUFF\\" .. styles[style]
end
local FONT = GameFontNormal:GetFont()
local defaults = {
    -- Classic ranks plus common later rogue buffs, if available in Forever.
    [5171] = true, [6774] = true, -- Slice and Dice
    [5277] = true, [26669] = true, -- Evasion
    [2983] = true, [8696] = true, [11305] = true, -- Sprint
    [13750] = true, -- Adrenaline Rush
    [13877] = true, -- Blade Flurry
    [32645] = true, -- Envenom
    [31224] = true, -- Cloak of Shadows
    [51690] = true, -- Killing Spree
    [51713] = true, -- Shadow Dance
}
local racialDefaults = {
    [20572]=true, -- Blood Fury
    [20594]=true, -- Stoneform
    [26297]=true, -- Berserking
    [20580]=true, -- Shadowmeld (only if timed)
    [20577]=true, -- Cannibalize (only if represented by a timed buff)
    [7744]=true, -- Will of the Forsaken (only if it grants a timed buff)
}
if config.enemy then defaults={[1943]=true,[703]=true,[8647]=true} end
local resizeGrip
local db, anchor, handle, container, preview
local reminderAnchor, reminderHandle, reminderContainer, reminderPreview, reminderRow
local previewRows = {}
local liveRows = {}
local warningCurve, pulseCurve, durationBinding, optionsWindow
local reminderLiveBar, reminderOpacityCurve
local reminderLiveRows, reminderPreviewRows = {}, {}
local opacityFailed = false
local opacityLastError, opacityRetry = nil, 0
local nativeWarningContainers={}
local nativeWarningAnchor
local minimapButton
local ready = false
local testing = false
local positioningReminder = false
local failure
local events = CreateFrame("Frame")

local function Say(text)
    print("|cffffd24aFBUFF:|r " .. text)
end

local function Copy(t)
    local result = {}
    for k, v in pairs(t) do result[k] = v end
    return result
end

local function Bounded(value, fallback, low, high)
    value = tonumber(value)
    if not value or value ~= value or value < low or value > high then return fallback end
    return value
end

local function ColorValue(value, fallback)
    if type(value) == "string" then
        value = value:gsub("^#", ""):upper()
        if #value == 6 and value:match("^%x+$") then return value end
    end
    return fallback
end

local function RGB(hex)
    return tonumber(hex:sub(1,2),16)/255, tonumber(hex:sub(3,4),16)/255, tonumber(hex:sub(5,6),16)/255
end

local function SortDirection()
    return db.sort == "longest" and AuraContainerSortDirection.Reverse or AuraContainerSortDirection.Normal
end

local function BuildReminderOpacityCurve()
    reminderOpacityCurve=C_CurveUtil.CreateCurve()
    reminderOpacityCurve:SetType(Enum.LuaCurveType.Linear)
    -- Transparent at zero/expired and at/above the threshold. A one
    -- millisecond edge avoids depending on step-curve boundary semantics.
    reminderOpacityCurve:AddPoint(0,0)
    reminderOpacityCurve:AddPoint(0.001,1)
    if db.flash then
        for i=1,math.ceil((db.threshold-0.001)/0.4)-1 do
            reminderOpacityCurve:AddPoint(i*0.4,i%2==1 and 0.35 or 1)
        end
    end
    reminderOpacityCurve:AddPoint(db.threshold-0.001,1)
    reminderOpacityCurve:AddPoint(db.threshold,0)
    reminderOpacityCurve:AddPoint(86401,0)
end

local function BuildDurationBinding()
    BuildReminderOpacityCurve()
    local normal = CreateColor(RGB(db.textColor))
    local warning = CreateColor(RGB(db.warningColor))
    warningCurve = C_CurveUtil.CreateColorCurve()
    warningCurve:SetType(Enum.LuaCurveType.Linear)
    warningCurve:AddPoint(0, normal)
    pulseCurve=C_CurveUtil.CreateCurve()
    pulseCurve:SetType(Enum.LuaCurveType.Linear)
    pulseCurve:AddPoint(0,1)
    -- This is a presentation curve, evaluated by Blizzard against remaining
    -- time. No secret duration is ever returned to addon Lua. Alternate colors
    -- every 0.4 seconds (a complete pulse takes 0.8 seconds).
    if db.flash and db.threshold > 0 then
        for i = 1, math.ceil(db.threshold / 0.4)-1 do
            warningCurve:AddPoint(i * 0.4, i % 2 == 1 and warning or normal)
            pulseCurve:AddPoint(i * 0.4, i % 2 == 1 and 0.35 or 1)
        end
        warningCurve:AddPoint(db.threshold, normal)
        pulseCurve:AddPoint(db.threshold,1)
    end
    warningCurve:AddPoint(86401, normal)
    pulseCurve:AddPoint(86401,1)
    local formatter = C_StringUtil.CreateSecondsFormatter()
    formatter:SetDefaultAbbreviation(Enum.SecondsFormatterAbbreviation.OneLetter)
    formatter:SetMinInterval(Enum.SecondsFormatterInterval.Seconds)
    formatter:SetMillisecondsThreshold(60)
    durationBinding = C_DurationUtil.CreateDurationTextBinding()
    durationBinding:SetFormatter(formatter)
    durationBinding:SetUpdateInterval(0.05)
    durationBinding:SetTextColorCurve(warningCurve, Enum.DurationTextBindingProperty.RemainingDuration)
end

local function NormalizeSaved()
    -- SavedVariables are restored after addon files execute. Read them at login,
    -- not when the tracker factory runs, or persisted settings are lost.
    local ForeverClassTimersDB=_G[config.savedKey]
    local ForeverRogueTimersDB=not config.enemy and _G.ForeverRogueTimersDB or nil
    -- Import legacy settings when an upgrade copies the old SavedVariables file.
    if type(ForeverClassTimersDB) ~= "table" and type(ForeverRogueTimersDB) == "table" then
        ForeverClassTimersDB = ForeverRogueTimersDB
    end
    if not config.enemy then _G.ForeverRogueTimersDB = nil end
    if type(ForeverClassTimersDB) ~= "table" then ForeverClassTimersDB = {} end
    db = ForeverClassTimersDB
if config.unit=="player" and not config.enemy then db.barColor="2F6FE4" end
    db.width = Bounded(db.width, 280, 60, 1000)
    db.scale = Bounded(db.scale, 1, 0.5, 2)
    -- FBUFF v0.86: migrate the old scale-based size into independent width/height.
    if not db.independentSizeV86 then
        db.fbuffHeight = Bounded((db.fbuffHeight or HEIGHT) * db.scale, 25, 20, 40)
        db.width = Bounded(db.width * db.scale, 200, 150, 250)
        db.scale = 1
        db.independentSizeV86 = true
    end
    db.fbuffHeight = Bounded(db.fbuffHeight, 25, 20, 40)
    if db.showSkillName == nil then db.showSkillName = false end
    if db.showTargetID == nil then db.showTargetID = false end
    if db.showCountdown == nil then db.showCountdown = true end
    HEIGHT = db.fbuffHeight
    db.x = Bounded(db.x, 180, -10000, 10000)
    db.y = Bounded(db.y, config.defaultY or (config.enemy and -220 or -80), -10000, 10000)
    db.minimapAngle = Bounded(db.minimapAngle, 220, -360, 360)
    db.locked = db.locked == true
    -- One-time migration to automatic tracking for every class.
    if not db.automaticTrackingVersion then db.all=true;db.automaticTrackingVersion=1 end
    db.all = db.all ~= false
    local excluded={}
    if type(db.excluded)=="table" then
        for id,enabled in pairs(db.excluded) do
            if type(id)=="number" and id>0 and id==math.floor(id) and enabled==true then excluded[id]=true end
        end
    end
    db.excluded=excluded
    db.barColor = config.enemy and "C62828" or ColorValue(db.barColor, "29A31F")
    db.textColor = ColorValue(db.textColor, "FFFFFF")
    db.warningColor = ColorValue(db.warningColor, "FF5533")
    db.growth = db.growth=="up" and "up" or "down"
    db.sort = db.sort == "longest" and "longest" or "shortest"
    db.threshold = Bounded(db.threshold, 5, 1, 30)
    if config.unit=="player" and not config.enemy then
        db.threshold=5
        db.warningColor="FF331F"
    end
    db.flash = db.flash ~= false
    db.style = styles[db.style] and db.style or "flat"
    db.reminder = db.reminder == true
    db.reminderSpell = math.floor(Bounded(db.reminderSpell, config.enemy and 1943 or 5171, 1, 10000000))
    if type(db.reminderSpells)~="table" then db.reminderSpells={[db.reminderSpell]=true} end
    local reminderClean={}
    for id,enabled in pairs(db.reminderSpells) do
        if type(id)=="number" and id>0 and id==math.floor(id) and enabled==true then reminderClean[id]=true end
    end
    db.reminderSpells=reminderClean
    db.reminderScale = Bounded(db.reminderScale, 1.5, 1, 3)
    db.reminderX = Bounded(db.reminderX, -140, -10000, 10000)
    db.reminderY = Bounded(db.reminderY, config.enemy and -40 or 100, -10000, 10000)
    if type(db.spells) ~= "table" then db.spells = {} end
    local clean = {}
    for id, enabled in pairs(db.spells) do
        if type(id) == "number" and id > 0 and id == math.floor(id) and enabled == true then
            clean[id] = true
        end
    end
    db.spells = clean
    if type(db.racialSeen)~="table" then db.racialSeen={} end
    if not config.enemy and not db.racialDefaultsAdded then
        for id in pairs(racialDefaults) do db.spells[id]=true;db.racialSeen[id]=true end
        db.racialDefaultsAdded=true
    end
    _G[config.savedKey]=db
end

local function DiscoverRacials()
    if config.enemy then return 0 end
    if not C_SpellBook or not C_SpellBook.GetNumSpellBookSkillLines then return 0 end
    local added=0
    for lineIndex=1,C_SpellBook.GetNumSpellBookSkillLines() do
        local line=C_SpellBook.GetSpellBookSkillLineInfo(lineIndex)
        if line then
            for slot=line.itemIndexOffset+1,line.itemIndexOffset+line.numSpellBookItems do
                local info=C_SpellBook.GetSpellBookItemInfo(slot,Enum.SpellBookSpellBank.Player)
                if info and info.spellID and not info.isPassive then
                    local sub=info.subName
                    local racial=sub=="Racial" or (RACIAL and sub==RACIAL) or (SPELL_RACIAL and sub==SPELL_RACIAL)
                    if racial and not db.racialSeen[info.spellID] then
                        db.racialSeen[info.spellID]=true;db.spells[info.spellID]=true;added=added+1
                    end
                end
            end
        end
    end
    return added
end

local function Filters()
    -- A finite maximum also excludes permanent auras. The engine filters and
    -- sorts actual aura data; addon Lua never inspects combat aura payloads.
    local result = {maxDuration = 86400, excludeSpellIDs=Copy(db.excluded)}
    if not db.all then result.includeSpellIDs = Copy(db.spells) end
    return result
end

local function Font(parent, size)
    local text = parent:CreateFontString(nil, "OVERLAY")
    text:SetFont(FONT, size, "OUTLINE")
    text:SetTextColor(1, 1, 1)
    return text
end

local function ApplyRowStyle(bar)
    local visualKind=config.enemy and "dot" or ((config.unit=="player") and "self" or "friend")
    FBUFF_SetupV033Bar(bar,visualKind)
    if bar.empty then bar.empty:Hide() end
    if bar.rowBackground then bar.rowBackground:Hide() end
end

local function DrawRow(button)
    button:SetSize(db.width, HEIGHT)
    button:EnableMouse(false)
    local background = button:CreateTexture(nil, "BACKGROUND")
    background:SetAllPoints()
    background:SetColorTexture(0, 0, 0, 0.95)

    local icon = button:CreateTexture(nil, "ARTWORK")
    icon:SetPoint("TOPLEFT", 0, -1)
    icon:SetSize(HEIGHT - 1, HEIGHT - 2)
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    local bar = CreateFrame("StatusBar", nil, button)
    bar:SetPoint("TOPLEFT", button, "TOPLEFT", HEIGHT - 1, -1)
    bar:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -1, 1)
    local empty = bar:CreateTexture(nil, "BACKGROUND")
    empty:SetAllPoints()
    bar.empty = empty
    bar.rowBackground = background
    ApplyRowStyle(bar)

    local time = Font(bar, 16)
    time:SetPoint("RIGHT", -4, 0)
    time:SetWidth(48)
    time:SetJustifyH("RIGHT")
    local name = Font(bar, 15)
    name:SetTextColor(RGB(db.textColor))
    time:SetTextColor(RGB(db.textColor))
    name:SetPoint("LEFT", 5, 0)
    name:SetPoint("RIGHT", time, "LEFT", -5, 0)
    name:SetJustifyH("LEFT")
    name:SetWordWrap(false)
    return icon, bar, name, time
end

local function InitializeAuraButton(button)
    local icon, bar, name, time = DrawRow(button)
    -- Preserve AuraButton's secure intrinsic hover scripts. The engine owns
    -- the active aura tooltip, including updates when this row is reused.
    button:EnableMouse(true)
    button:SetCancelAuraButtons(nil)
    button:SetTooltipAnchorPoint("ANCHOR_RIGHT", 8, 0)
    button:SetIcon(icon)
    button:SetSpellName(name)
    button:SetDurationBar(bar, {
        direction = Enum.StatusBarTimerDirection.RemainingTime,
        interpolation = Enum.StatusBarInterpolation.Immediate,
    })
    button:SetDurationText(time, {binding = durationBinding})
    liveRows[#liveRows+1] = {button=button, icon=icon, bar=bar, name=name, time=time}
end

local function ReminderFilters()
    local ids=Copy(db.reminderSpells)
    for selectedID in pairs(db.reminderSpells) do
        local selected=C_Spell.GetSpellInfo(selectedID)
        if selected then
            for id in pairs(defaults) do
                local info=C_Spell.GetSpellInfo(id)
                if info and info.name==selected.name then ids[id]=true end
            end
        end
    end
    return {maxDuration=86400,includeSpellIDs=ids,excludeSpellIDs=Copy(db.excluded)}
end

local function RefreshNativeWarnings()
    for _,entry in pairs(nativeWarningContainers) do entry.container:SetEnabled(false) end
    -- The native labels share the saved, draggable reminder anchor.
    nativeWarningAnchor=reminderAnchor
    local r,g,b=RGB(db.warningColor)
    local hidden=CreateColor(r,g,b,0)
    local visible=CreateColor(r,g,b,1)
    local dim=CreateColor(r,g,b,0.35)
    local curve=C_CurveUtil.CreateColorCurve()
    curve:SetType(Enum.LuaCurveType.Linear)
    curve:AddPoint(0,hidden);curve:AddPoint(0.001,visible)
    if db.flash then
        for i=1,math.ceil((db.threshold-0.001)/0.4)-1 do
            curve:AddPoint(i*0.4,i%2==1 and dim or visible)
        end
    end
    curve:AddPoint(db.threshold-0.001,visible)
    curve:AddPoint(db.threshold,hidden);curve:AddPoint(86401,hidden)
    local formatter=C_StringUtil.CreateSecondsFormatter()
    formatter:SetDefaultAbbreviation(Enum.SecondsFormatterAbbreviation.OneLetter)
    formatter:SetMinInterval(Enum.SecondsFormatterInterval.Seconds)
    formatter:SetMillisecondsThreshold(60)
    local ids={};for id in pairs(db.reminderSpells) do ids[#ids+1]=id end;table.sort(ids)
    local usedNames={};local index=0
    for _,id in ipairs(ids) do
        local info=C_Spell.GetSpellInfo(id)
        local name=info and info.name or tostring(id)
        if not usedNames[name] then
            usedNames[name]=true;index=index+1
            local entry=nativeWarningContainers[id]
            if not entry then
                entry={rows={}}
                local c=CreateFrame("AuraContainer",nil,nativeWarningAnchor,"CustomAuraContainerTemplate")
                entry.container=c;nativeWarningContainers[id]=entry
                c:SetEnabled(false)
                c:SetFlowLayoutAxis(AnchorUtil.FlowLayoutAxis.Vertical)
                c:SetFlowLayoutAnchorPoint("TOPLEFT")
                c:SetFlowLayoutGrowthDirection(AnchorUtil.FlowDirection.Right,AnchorUtil.FlowDirection.Down)
                c:SetFlowLayoutMaximumLineSize(nil)
                entry.initialize=function(button)
                    button:SetSize(db.width,HEIGHT);button:EnableMouse(false)
                    local text=Font(button,12)
                    text:SetAllPoints();text:SetJustifyH("LEFT");text:SetWordWrap(false)
                    entry.rows[#entry.rows+1]={button=button,text=text}
                    if entry.binding then button:SetDurationText(text,{binding=entry.binding}) end
                end
                local spellIDs={[id]=true}
                for rank in pairs(defaults) do
                    local rankInfo=C_Spell.GetSpellInfo(rank)
                    if rankInfo and rankInfo.name==name then spellIDs[rank]=true end
                end
                entry.spellIDs=spellIDs
                c:AddAuraGroup("warning",config.filter,{maxFrameCount=1,
                    candidateFilters={maxDuration=86400,includeSpellIDs=spellIDs},
                    sortMethod=AuraContainerSortMethod.ExpirationOnly,sortDirection=AuraContainerSortDirection.Normal,
                    layout={elementWidth=db.width,elementHeight=HEIGHT,elementSpacing=GAP},
                    initializeFrame=entry.initialize})
                c:SetUnit(config.unit)
            end
            entry.container:SetAuraGroupCandidateFilters("warning",{maxDuration=86400,includeSpellIDs=entry.spellIDs,excludeSpellIDs=Copy(db.excluded)})
            local binding=C_DurationUtil.CreateDurationTextBinding()
            binding:SetUpdateInterval(0.05)
            binding:SetTextColorCurve(curve,Enum.DurationTextBindingProperty.RemainingDuration)
            local icon=C_Spell.GetSpellTexture(id) or 134400
            binding:SetTextFormat("|T" .. icon .. ":22:22|t " .. name .. "  {}",{
                {property=Enum.DurationTextBindingProperty.RemainingDuration,formatter=formatter}})
            binding:SetExpiredText("");binding:SetZeroDurationText("")
            entry.container:SetAuraGroupLayout("warning",{elementWidth=db.width,elementHeight=HEIGHT,elementSpacing=GAP})
            entry.binding=binding
            for _,row in ipairs(entry.rows) do row.button:SetDurationText(row.text,{binding=binding}) end
            entry.container:ClearAllPoints()
            entry.container:SetPoint("TOPLEFT",nativeWarningAnchor,"TOPLEFT",0,-(index-1)*(HEIGHT+GAP))
            entry.container:SetEnabled(db.reminder and not testing)
        end
    end
end

local function UpdateReminder()
    if not reminderAnchor then return end
    reminderContainer:SetAlpha(0)
    reminderAnchor:SetShown(db.reminder)
    reminderAnchor:SetWidth(db.width)
    reminderAnchor:SetScale(db.reminderScale)
    reminderHandle:SetShown(positioningReminder)
    reminderHandle:EnableMouse(positioningReminder)
    reminderContainer:SetAuraGroupCandidateFilters("buffs", ReminderFilters())
    reminderContainer:SetAuraGroupLayout("buffs", {elementWidth=db.width, elementHeight=HEIGHT, elementSpacing=GAP})
    reminderContainer:SetEnabled(false)
    reminderPreview:SetShown(db.reminder and testing)
    reminderPreview:SetWidth(db.width)
    local ids={}
    for id in pairs(db.reminderSpells) do ids[#ids+1]=id end
    table.sort(ids)
    for i,id in ipairs(ids) do
        local row=reminderPreviewRows[i]
        if not row then
            local frame=CreateFrame("Frame",nil,reminderPreview)
            local icon,bar,name,time=DrawRow(frame)
            row={frame=frame,icon=icon,bar=bar,name=name,time=time}
            bar:Hide();icon:Hide();bar.rowBackground:Hide()
            row.nativeText=Font(frame,12)
            row.nativeText:SetAllPoints();row.nativeText:SetJustifyH("LEFT");row.nativeText:SetWordWrap(false)
            reminderPreviewRows[i]=row
        end
        row.frame:SetPoint("TOPLEFT",reminderPreview,"TOPLEFT",0,-(i-1)*(HEIGHT+GAP))
        row.frame:SetWidth(db.width);row.frame:Show();row.frame:SetAlpha(positioningReminder and 1 or 0)
        row.duration=12+(i-1)*2
        row.bar:SetMinMaxValues(0,row.duration)
        local info=C_Spell.GetSpellInfo(id)
        row.icon:SetTexture(C_Spell.GetSpellTexture(id) or 134400)
        local displayName=info and info.name or tostring(id)
        row.previewFormat="|T" .. (C_Spell.GetSpellTexture(id) or 134400) .. ":22:22|t " .. displayName:gsub("%%","%%%%") .. "  %.1f"
        row.nativeText:SetFormattedText(row.previewFormat,3)
        row.nativeText:SetTextColor(RGB(db.warningColor))
    end
    for i=#ids+1,#reminderPreviewRows do reminderPreviewRows[i].frame:Hide() end
    if db.reminder and testing then
        reminderPreview:SetScript("OnUpdate",function(self,elapsed)
            self.elapsed=(self.elapsed or 0)+elapsed
            for i=1,#ids do
                local row=reminderPreviewRows[i]
                local remaining=row.duration-(self.elapsed%row.duration)
                row.frame:SetAlpha(positioningReminder and 1 or reminderOpacityCurve:Evaluate(remaining))
                row.nativeText:SetFormattedText(row.previewFormat,remaining)
                row.bar:SetValue(remaining)
                row.time:SetFormattedText("%.1f",remaining)
                row.time:SetTextColor(warningCurve:EvaluateUnpacked(remaining))
            end
        end)
    else reminderPreview:SetScript("OnUpdate",nil) end
    RefreshNativeWarnings()
end

local function ApplyAppearance()
    BuildDurationBinding()
    if config.enemy then db.barColor="FF2929"
    elseif config.unit=="player" then db.barColor="FFD700"
    else db.barColor="26E647" end
    for _, row in ipairs(liveRows) do
        ApplyRowStyle(row.bar)
        row.name:SetTextColor(RGB(db.textColor))
        if config.unit~="player" and not config.enemy then row.name:Hide() else row.name:Show() end
        row.button:SetDurationText(row.time, {binding=durationBinding})
    end
    for _, row in ipairs(previewRows) do
        ApplyRowStyle(row.bar)
        row.name:SetTextColor(RGB(db.textColor))
        row.time:SetTextColor(RGB(db.textColor))
    end
    for _,row in ipairs(reminderPreviewRows) do
        row.bar:SetStatusBarColor(RGB(db.barColor));row.bar.rowBackground:Hide()
        row.name:SetTextColor(RGB(db.textColor));row.time:SetTextColor(RGB(db.textColor))
        if row.nativeText then row.nativeText:SetTextColor(RGB(db.warningColor)) end
    end
    container:SetAuraGroupSortMethod("buffs", AuraContainerSortMethod.ExpirationOnly, SortDirection())
    RefreshNativeWarnings()
end

local function PlaceAnchor()
    anchor:ClearAllPoints()
    anchor:SetPoint("TOPLEFT", UIParent, "CENTER", db.x, db.y)
end

local function UpdateLock()
    handle:SetShown(not db.locked)
    handle:EnableMouse(not db.locked)
    if resizeGrip then resizeGrip:SetShown(not db.locked and not InCombatLockdown()) end
    UpdateReminder()
end

local function SetPreview(show)
    testing = show
    if not show then positioningReminder=false;reminderHandle:Hide();reminderHandle:EnableMouse(false) end
    if InCombatLockdown() then
        -- Do not reconfigure filters/layout while leaving preview for combat.
        reminderContainer:SetAlpha(0)
        reminderPreview:Hide()
        reminderPreview:SetScript("OnUpdate", nil)
        reminderContainer:SetEnabled(false)
        for _,entry in pairs(nativeWarningContainers) do entry.container:SetEnabled(db.reminder) end
    else
        UpdateReminder()
    end
    preview:SetShown(show)
    container:SetEnabled(not show)
    if show then
        preview.elapsed = 0
        preview:SetScript("OnUpdate", function(self, elapsed)
            self.elapsed = self.elapsed + elapsed
            for i, row in ipairs(previewRows) do
                local duration = row.duration
                local remaining = duration - (self.elapsed % duration)
                row.remaining = remaining
                row.bar:SetValue(remaining)
                row.time:SetFormattedText("%.1f", remaining)
                -- Preview values are synthetic, public numbers, so this local
                -- evaluation is safe. Live timers use the native binding above.
                row.time:SetTextColor(warningCurve:EvaluateUnpacked(remaining))
                row.frame:SetAlpha(pulseCurve:Evaluate(remaining))
            end
            table.sort(previewRows, function(a,b)
                if a.remaining == b.remaining then return a.id < b.id end
                if db.sort == "longest" then return a.remaining > b.remaining end
                return a.remaining < b.remaining
            end)
            for i, row in ipairs(previewRows) do
                row.frame:ClearAllPoints()
                row.frame:SetPoint(db.growth=="up" and "BOTTOMLEFT" or "TOPLEFT", anchor, "TOPLEFT", 0, (db.growth=="up" and 1 or -1)*(i-1)*(HEIGHT+GAP))
            end
        end)
    else
        preview:SetScript("OnUpdate", nil)
    end
end

local function ApplyGrowth()
    local up=db.growth=="up"
    local point=up and "BOTTOMLEFT" or "TOPLEFT"
    container:ClearAllPoints()
    container:SetPoint(point,anchor,"TOPLEFT",0,0)
    container:SetFlowLayoutAnchorPoint(point)
    container:SetFlowLayoutGrowthDirection(AnchorUtil.FlowDirection.Right,up and AnchorUtil.FlowDirection.Up or AnchorUtil.FlowDirection.Down)
    handle:ClearAllPoints()
    handle:SetPoint(up and "TOPLEFT" or "BOTTOMLEFT",anchor,"TOPLEFT",0,up and -4 or 4)
    handle:SetPoint(up and "TOPRIGHT" or "BOTTOMRIGHT",anchor,"TOPRIGHT",0,up and -4 or 4)
    for i,row in ipairs(previewRows) do
        row.frame:ClearAllPoints()
        row.frame:SetPoint(point,anchor,"TOPLEFT",0,(up and 1 or -1)*(i-1)*(HEIGHT+GAP))
    end
end

local function Resize(skipReminders)
    HEIGHT = db.fbuffHeight or HEIGHT
    anchor:SetWidth(db.width)
    anchor:SetScale(1)
    container:SetAuraGroupLayout("buffs", {elementWidth = db.width, elementHeight = HEIGHT, elementSpacing = GAP})
    -- Width and height are deliberately independent in FBUFF.
    for _, row in ipairs(liveRows) do
        if row.button then row.button:SetSize(db.width, HEIGHT) end
        if row.icon then row.icon:SetSize(HEIGHT-1,HEIGHT-2) end
        if row.bar and row.button then
            row.bar:ClearAllPoints()
            row.bar:SetPoint("TOPLEFT",row.button,"TOPLEFT",HEIGHT-1,-1)
            row.bar:SetPoint("BOTTOMRIGHT",row.button,"BOTTOMRIGHT",-1,1)
        end
    end
    for _, row in ipairs(previewRows) do row.frame:SetWidth(db.width);row.frame:SetHeight(HEIGHT) end
    if not skipReminders then UpdateReminder() end
end

local function PlaceReminder()
    reminderAnchor:ClearAllPoints()
    reminderAnchor:SetPoint("TOPLEFT", UIParent, "CENTER", db.reminderX, db.reminderY)
end

local function CreateReminder()
    reminderAnchor=CreateFrame("Frame", "ForeverClassTimersReminderAnchor", UIParent)
    reminderAnchor:SetSize(db.width, HEIGHT)
    reminderAnchor:SetScale(db.reminderScale)
    reminderAnchor:SetMovable(true)
    reminderAnchor:SetClampedToScreen(true)
    reminderAnchor:SetFrameStrata("HIGH")
    PlaceReminder()
    reminderHandle=CreateFrame("Frame", "ForeverClassTimersReminderHandle", reminderAnchor)
    reminderHandle:SetPoint("BOTTOMLEFT", reminderAnchor, "TOPLEFT", 0, 4)
    reminderHandle:SetPoint("BOTTOMRIGHT", reminderAnchor, "TOPRIGHT", 0, 4)
    reminderHandle:SetHeight(24)
    reminderHandle:EnableMouse(true)
    reminderHandle:RegisterForDrag("LeftButton")
    local bg=reminderHandle:CreateTexture(nil,"BACKGROUND")
    bg:SetAllPoints();bg:SetColorTexture(0.15,0.08,0.03,0.95)
    local label=Font(reminderHandle,10)
    label:SetPoint("CENTER");label:SetText((config.enemy and "DEBUFF REMINDERS" or "BUFF REMINDERS") .. " | Drag | " .. config.command .. " lock")
    reminderHandle:SetScript("OnDragStart",function()
        if positioningReminder and not InCombatLockdown() then reminderAnchor:StartMoving() end
    end)
    reminderHandle:SetScript("OnDragStop",function()
        reminderAnchor:StopMovingOrSizing()
        if InCombatLockdown() then return end
        local left,top=reminderAnchor:GetLeft(),reminderAnchor:GetTop()
        if left and top then
            local ratio=reminderAnchor:GetEffectiveScale()/UIParent:GetEffectiveScale()
            db.reminderX=left-(UIParent:GetWidth()/2)/ratio
            db.reminderY=top-(UIParent:GetHeight()/2)/ratio
            PlaceReminder()
        end
    end)
    reminderContainer=CreateFrame("AuraContainer", "ForeverClassTimersReminderAuras", reminderAnchor,"CustomAuraContainerTemplate")
    reminderContainer:SetEnabled(false)
    reminderContainer:SetPoint("TOPLEFT",reminderAnchor,"TOPLEFT")
    reminderContainer:SetFlowLayoutAxis(AnchorUtil.FlowLayoutAxis.Vertical)
    reminderContainer:SetFlowLayoutAnchorPoint("TOPLEFT")
    reminderContainer:SetFlowLayoutGrowthDirection(AnchorUtil.FlowDirection.Right,AnchorUtil.FlowDirection.Down)
    reminderContainer:SetFlowLayoutMaximumLineSize(nil)
    reminderContainer:AddAuraGroup("buffs",config.filter,{
        maxFrameCount=math.huge, candidateFilters=ReminderFilters(),
        sortMethod=AuraContainerSortMethod.ExpirationOnly, sortDirection=AuraContainerSortDirection.Normal,
        layout={elementWidth=db.width,elementHeight=HEIGHT,elementSpacing=GAP},
        initializeFrame=function(button)
            InitializeAuraButton(button)
            local row=liveRows[#liveRows]
            row.isReminder=true;row.button:SetAlpha(0)
            reminderLiveRows[#reminderLiveRows+1]=row
        end,
    })
    reminderContainer:SetAlpha(0)
    reminderContainer:SetUnit(config.unit)
    -- Live threshold opacity cannot query these forbidden timer objects.
    -- Keep live reminders hidden until a supported native binding is available.
    reminderPreview=CreateFrame("Frame","ForeverClassTimersReminderPreview",reminderAnchor)
    reminderPreview:SetPoint("TOPLEFT",reminderAnchor,"TOPLEFT")
    reminderPreview:SetSize(db.width,1)
    UpdateReminder()
end

local function CreateResizeGrip()
    resizeGrip=CreateFrame("Frame","ForeverClassTimersResizeGrip",handle)
    resizeGrip:SetSize(22,22);resizeGrip:SetPoint("TOPRIGHT",handle,"TOPRIGHT",0,0)
    resizeGrip:EnableMouse(true)
    local mark=Font(resizeGrip,16);mark:SetPoint("CENTER");mark:SetText("+")
    local drag
    local function Stop()
        local wasDragging=drag~=nil
        drag=nil;resizeGrip:SetScript("OnUpdate",nil)
        if wasDragging and not InCombatLockdown() then
            Resize();PlaceAnchor()
            if optionsWindow then optionsWindow:Refresh() end
        end
    end
    resizeGrip:SetScript("OnMouseDown",function(_,button)
        if button~="RightButton" or db.locked or InCombatLockdown() then return end
        local x,y=GetCursorPosition()
        drag={x=x,y=y,width=db.width,scale=db.scale,px=db.x,py=db.y,parentScale=UIParent:GetEffectiveScale()}
        resizeGrip:SetScript("OnUpdate",function()
            if InCombatLockdown() or db.locked then Stop();return end
            local cx,cy=GetCursorPosition()
            local scale=math.max(0.5,math.min(2,drag.scale+(drag.y-cy)/(200*drag.parentScale)))
            local width=math.max(180,math.min(600,(drag.width*drag.scale+(cx-drag.x)/drag.parentScale)/scale))
            db.scale=scale;db.width=math.floor(width+0.5)
            -- Keep the list's screen anchor stationary as its scale changes.
            db.x=drag.px*drag.scale/scale;db.y=drag.py*drag.scale/scale
            Resize(true);PlaceAnchor()
        end)
    end)
    resizeGrip:SetScript("OnMouseUp",function(_,button) if button=="LeftButton" and IsControlKeyDown() then Stop() end end)
    resizeGrip:SetScript("OnHide",Stop)
    resizeGrip:SetScript("OnEnter",function()
        GameTooltip:SetOwner(resizeGrip,"ANCHOR_RIGHT")
        GameTooltip:SetText("Hold right-click and drag to resize")
        GameTooltip:AddLine("Left/right: width. Down/up: larger/smaller text and bars.",1,1,1,true)
        GameTooltip:Show()
    end)
    resizeGrip:SetScript("OnLeave",function() GameTooltip:Hide() end)
end

local function CreateUI()
    BuildDurationBinding()
    anchor = CreateFrame("Frame", "ForeverClassTimersAnchor", UIParent)
    anchor:SetSize(db.width, 1)
    anchor:SetScale(db.scale)
    anchor:SetMovable(true)
    anchor:SetClampedToScreen(true)
    anchor:SetFrameStrata("MEDIUM")
    PlaceAnchor()

    handle = CreateFrame("Frame", nil, anchor)
    handle:SetPoint("BOTTOMLEFT", anchor, "TOPLEFT", 0, 4)
    handle:SetPoint("BOTTOMRIGHT", anchor, "TOPRIGHT", 0, 4)
    handle:SetHeight(28)
    handle:EnableMouse(true)
    handle:RegisterForDrag("LeftButton")
    local bg = handle:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0.13, 0.12, 0.05, 0.95)
    local label = Font(handle, 10)
    label:SetPoint("CENTER")
    label:SetFont(FONT, 16, "OUTLINE")
    label:SetText(config.label or (config.enemy and "DOT" or "BUFF"))
    handle:SetScript("OnDragStart", function()
        if not db.locked and not InCombatLockdown() then anchor:StartMoving() end
    end)
    handle:SetScript("OnDragStop", function()
        anchor:StopMovingOrSizing()
        local left, top = anchor:GetLeft(), anchor:GetTop()
        if left and top then
            local ratio = anchor:GetEffectiveScale() / UIParent:GetEffectiveScale()
            -- SetPoint offsets are in the scaled anchor's coordinate space.
            db.x = left - (UIParent:GetWidth() / 2) / ratio
            db.y = top - (UIParent:GetHeight() / 2) / ratio
            PlaceAnchor()
        end
    end)

    container = CreateFrame("AuraContainer", config.prefix .. "Auras", anchor, "CustomAuraContainerTemplate")
    container:SetEnabled(false)
    container:SetPoint("TOPLEFT", anchor, "TOPLEFT")
    container:SetFlowLayoutAxis(AnchorUtil.FlowLayoutAxis.Vertical)
    container:SetFlowLayoutAnchorPoint("TOPLEFT")
    container:SetFlowLayoutGrowthDirection(AnchorUtil.FlowDirection.Right, AnchorUtil.FlowDirection.Down)
    container:SetFlowLayoutMaximumLineSize(nil)
    container:AddAuraGroup("buffs", config.filter, {
        maxFrameCount = 20,
        candidateFilters = Filters(),
        sortMethod = AuraContainerSortMethod.ExpirationOnly,
        sortDirection = SortDirection(),
        layout = {elementSpacing = GAP, elementWidth = db.width, elementHeight = HEIGHT},
        initializeFrame = InitializeAuraButton,
    })
    container:SetUnit(config.unit)
    container:SetEnabled(true)
    if config.unit=="player" and not config.enemy then container:SetAlpha(0) end
    -- FBUFF friend buffs are rendered only by the persistent multi-target cache.
    -- Keep Blizzard's target-bound AuraContainer alive for compatibility/filter APIs,
    -- but never let it draw a second copy of the current friendly target.
    if config.persistMulti then
        -- Multi-target rows are custom-rendered.  Friendly buffs keep their
        -- existing cache; enemy DoTs are fed by confirmed player casts so we
        -- never inspect secret combat aura payloads.
        container:SetAlpha(0)
    end
    -- Target-bound AuraContainers must be rebound when the target changes.
    -- This prevents an aura from the previous target remaining as a stale row.
    if config.unit == "target" then
        local targetRefresh = CreateFrame("Frame")
        targetRefresh:RegisterEvent("PLAYER_TARGET_CHANGED")
        targetRefresh:SetScript("OnEvent", function()
            if InCombatLockdown() then return end
            container:SetEnabled(false)
            container:SetUnit("target")
            container:SetEnabled(true)
            if config.persistMulti and not config.enemy then container:SetAlpha(0) end
        end)
    end

    preview = CreateFrame("Frame", nil, anchor)
    preview:SetAllPoints(anchor)
    for i, entry in ipairs(config.enemy and {{1943,"Rupture",16},{703,"Garrote",18},{8647,"Expose Armor",30}} or {{5171,"Slice and Dice",24},{5277,"Evasion",15},{2983,"Sprint",8}}) do
        local frame = CreateFrame("Frame", nil, preview)
        frame:SetPoint("TOPLEFT", anchor, "TOPLEFT", 0, -(i-1)*(HEIGHT+GAP))
        local icon, bar, name, time = DrawRow(frame)
        icon:SetTexture(C_Spell.GetSpellTexture(entry[1]) or 134400)
        name:SetText(entry[2])
        bar:SetMinMaxValues(0, entry[3])
        previewRows[i] = {frame = frame, bar = bar, name = name, time = time, duration = entry[3], id=entry[1]}
    end
    preview:Hide()
    ApplyGrowth()
    CreateReminder()
    -- FBUFF uses the settings sliders for size; do not create FCT's + resize grip.
    UpdateLock()
end

local function OpenOptions()
    if optionsWindow then optionsWindow:Show(); optionsWindow:Refresh(); return end
    local window = CreateFrame("Frame", "ForeverClassTimersOptions", UIParent)
    optionsWindow = window
    window:SetSize(780, 560)
    window:SetPoint("CENTER")
    window:SetScale(math.min(1,(UIParent:GetWidth()-40)/780,(UIParent:GetHeight()-40)/560))
    window:SetFrameStrata("DIALOG")
    window:SetClampedToScreen(true)
    window:SetMovable(true);window:EnableMouse(true)
    local function Surface(parent,r,g,b)
        local tex=parent:CreateTexture(nil,"BACKGROUND")
        tex:SetAllPoints();tex:SetColorTexture(r,g,b,1)
        return tex
    end
    Surface(window,0.055,0.065,0.085)
    local titlebar=CreateFrame("Frame",nil,window)
    titlebar:SetPoint("TOPLEFT");titlebar:SetPoint("TOPRIGHT");titlebar:SetHeight(66)
    Surface(titlebar,0.085,0.10,0.13)
    titlebar:EnableMouse(true);titlebar:RegisterForDrag("LeftButton")
    titlebar:SetScript("OnDragStart",function() if not InCombatLockdown() then window:StartMoving() end end)
    titlebar:SetScript("OnDragStop",function() window:StopMovingOrSizing() end)
    local heading=Font(titlebar,19);heading:SetPoint("TOPLEFT",22,-15);heading:SetText("Forever Class Timers")
    local subtitle=Font(titlebar,11);subtitle:SetPoint("TOPLEFT",23,-41);subtitle:SetText(config.enemy and "ENEMY DEBUFFS  /  YOUR CURRENT TARGET" or "PLAYER BUFFS  /  PERSONALIZE YOUR DISPLAY")
    subtitle:SetTextColor(0.57,0.69,0.77)
    local function ModernButton(parent,label,x,y,width,callback)
        local button=CreateFrame("Button",nil,parent)
        button:SetPoint("TOPLEFT",x,y);button:SetSize(width,34)
        local bg=Surface(button,0.12,0.15,0.19)
        local caption=Font(button,12);caption:SetPoint("CENTER");caption:SetWidth(width-16)
        button:SetFontString(caption);button:SetText(label)
        button:SetScript("OnEnter",function() bg:SetColorTexture(0.18,0.24,0.29,1) end)
        button:SetScript("OnLeave",function() bg:SetColorTexture(0.12,0.15,0.19,1) end)
        button:SetScript("OnClick",function() if not InCombatLockdown() then callback() end end)
        return button
    end
    ModernButton(titlebar,"Close",684,-16,74,function() window:Hide() end)
    local sidebar=CreateFrame("Frame",nil,window)
    sidebar:SetPoint("TOPLEFT",0,-66);sidebar:SetPoint("BOTTOMLEFT",0,0);sidebar:SetWidth(174)
    Surface(sidebar,0.075,0.085,0.11)
    local pages={}
    local scroll=CreateFrame("ScrollFrame",nil,window,"UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT",196,-84);scroll:SetSize(540,390)
    local content=CreateFrame("Frame",nil,scroll);content:SetSize(520,1430);scroll:SetScrollChild(content)
    for i,titleText in ipairs({"Appearance","Warnings","Reminders"}) do
        local section=CreateFrame("Frame",nil,content)
        section:SetPoint("TOPLEFT",0,-(i==1 and 0 or i==2 and 335 or 595))
        section:SetSize(520,320);pages[i]=section
        local title=Font(section,17);title:SetPoint("TOPLEFT");title:SetText(titleText)
    end
    local nav={}
    function window:SelectPage(index)
        -- Legacy section shortcuts now scroll within the selected tracker tab.
        self.page=index;scroll:SetVerticalScroll(index==2 and 335 or index==3 and 595 or 0)
    end
    for i,name in ipairs({"Player Buffs","Enemy Debuffs"}) do
        local key=i==1 and "buffs" or "debuffs"
        local selected=(config.enemy and i==2) or (not config.enemy and i==1)
        nav[i]=ModernButton(sidebar,(selected and "|cff71d5c7" or "|cffdddddd") .. name .. "|r",12,-18-(i-1)*44,150,function()
            local tracker=trackers[key]
            if tracker then
                window:Hide()
                if window.reminderEditor then window.reminderEditor:Hide() end
                tracker.open()
            end
        end)
    end
    local version=Font(sidebar,11);version:SetPoint("BOTTOMLEFT",18,22);version:SetText("VERSION " .. VERSION);version:SetTextColor(0.57,0.64,0.71)
    local footer=Font(window,11);footer:SetPoint("BOTTOMLEFT",196,67)
    footer:SetText("Changes save automatically. Configure outside combat.");footer:SetTextColor(0.64,0.70,0.77)
    ModernButton(window,"Finish positioning / lock",196,-508,265,function()
        db.locked=true;SetPreview(false);UpdateLock()
    end)
    local controls = {}
    ModernButton(content,"Move timer list",0,-938,250,function() db.locked=false;SetPreview(true);UpdateLock();window:Hide() end)
    ModernButton(content,"Reset timer position",270,-938,250,function() db.x=180;db.y=config.enemy and -220 or -80;PlaceAnchor() end)
    controls.mode=ModernButton(content,"",0,-982,520,function()
        db.all=not db.all;container:SetAuraGroupCandidateFilters("buffs",Filters());window:Refresh()
    end)
    local excludeTitle=Font(content,15);excludeTitle:SetPoint("TOPLEFT",0,-1040);excludeTitle:SetText("Hide unwanted effects (all classes)")
    local excludeEntry=CreateFrame("EditBox",nil,content,"InputBoxTemplate")
    excludeEntry:SetPoint("TOPLEFT",8,-1074);excludeEntry:SetSize(500,26);excludeEntry:SetAutoFocus(false)
    local function ExclusionAction(command)
        SlashCmdList[config.slashKey](command .. " " .. (excludeEntry:GetText() or ""))
        excludeEntry:ClearFocus()
    end
    ModernButton(content,"Hide effect",0,-1116,165,function() ExclusionAction("remove") end)
    ModernButton(content,"Restore effect",177,-1116,165,function() ExclusionAction("add") end)
    ModernButton(content,"List hidden",354,-1116,166,function() ExclusionAction("excluded") end)
    local excludeHelp=Font(content,11);excludeHelp:SetPoint("TOPLEFT",0,-1164);excludeHelp:SetWidth(520)
    excludeHelp:SetText("Enter the effect's spell ID or exact name. Hidden IDs stay hidden after reload.\nList hidden prints IDs in chat. Restore allows that effect to appear again.")
    local sizeTitle=Font(content,17);sizeTitle:SetPoint("TOPLEFT",0,-1230);sizeTitle:SetText("Bar size")
    local function SizeInput(key,label,x,defaultValue)
        local caption=Font(content,12);caption:SetPoint("TOPLEFT",x,-1265);caption:SetText(label)
        local entry=CreateFrame("EditBox",nil,content,"InputBoxTemplate")
        entry:SetPoint("TOPLEFT",x+8,-1288);entry:SetSize(220,26);entry:SetAutoFocus(false)
        local function Apply()
            if InCombatLockdown() then return end
            SlashCmdList[config.slashKey](key .. " " .. (entry:GetText() or ""))
            entry:ClearFocus();window:Refresh()
        end
        entry:SetScript("OnEnterPressed",Apply)
        ModernButton(content,"Apply " .. key,x,-1330,240,Apply)
        return entry
    end
    controls.widthInput=SizeInput("width","Width (180-600)",0)
    controls.scaleInput=SizeInput("scale","Overall size (0.5-2.0)",270)
    ModernButton(content,"Reset bar size",0,-1374,240,function()
        db.width=280;db.scale=1;Resize();window:Refresh()
    end)
    local sizeHelp=Font(content,11);sizeHelp:SetPoint("TOPLEFT",270,-1374);sizeHelp:SetWidth(240)
    sizeHelp:SetText("Overall size scales bar height, icons and text together. Changes save automatically.")
    controls.growth=ModernButton(pages[1],"",0,-295,520,function()
        db.growth=db.growth=="up" and "down" or "up";ApplyGrowth();window:Refresh()
    end)
    local placements={[-38]={1,-66},[-72]={1,-110},[-106]={1,-154},[-145]={1,-210},[-325]={1,-254},
        [-179]={2,-66},[-251]={2,-164},[-287]={0,-508},
        [-363]={3,-66},[-397]={3,-110},[-431]={3,-154},[-465]={3,-198}}
    local function Button(label,y,callback)
        local place=placements[y]
        return ModernButton(place[1]==0 and window or pages[place[1]],label,place[1]==0 and 477 or 0,place[2],place[1]==0 and 279 or 520,callback)
    end
    local function PickColor(key)
        local previous = db[key]
        local r,g,b = RGB(previous)
        local function SetColor(hex)
            if InCombatLockdown() then return end
            db[key] = hex; ApplyAppearance(); window:Refresh()
        end
        ColorPickerFrame:SetupColorPickerAndShow({r=r,g=g,b=b,hasOpacity=false,extraInfo=ADDON,
            swatchFunc=function()
                local cr,cg,cb = ColorPickerFrame:GetColorRGB()
                SetColor(string.format("%02X%02X%02X", math.floor(cr*255+0.5), math.floor(cg*255+0.5), math.floor(cb*255+0.5)))
            end,
            cancelFunc=function() SetColor(previous) end,
        })
    end
    for i, spec in ipairs({{"barColor","Bar color"},{"textColor","Text color"},{"warningColor","Warning color"}}) do
        local key, label = spec[1], spec[2]
        controls[key] = Button(label, -38-(i-1)*34, function() PickColor(key) end)
    end
    controls.sort = Button("", -145, function()
        db.sort = db.sort == "shortest" and "longest" or "shortest"
        ApplyAppearance(); window:Refresh()
    end)
    controls.flash = Button("", -179, function() db.flash=not db.flash;ApplyAppearance();window:Refresh() end)
    local label = Font(pages[2], 12)
    label:SetPoint("TOPLEFT", 0, -122)
    label:SetText("Flash below (seconds):")
    local input = CreateFrame("EditBox", nil, pages[2], "InputBoxTemplate")
    input:SetPoint("TOPLEFT", 290, -114)
    input:SetSize(65, 24)
    input:SetAutoFocus(false)
    input:SetMaxLetters(4)
    local function CommitThreshold()
        if InCombatLockdown() then return end
        local threshold = Bounded(input:GetText(), nil, 1, 30)
        if threshold then db.threshold=threshold;ApplyAppearance()
        else Say("Warning threshold must be 1-30 seconds.") end
        input:ClearFocus();window:Refresh()
    end
    input:SetScript("OnEnterPressed", CommitThreshold)
    input:SetScript("OnEscapePressed", function() input:ClearFocus();window:Refresh() end)
    Button("Apply threshold", -251, CommitThreshold)
    Button("Toggle preview bars", -287, function()
        if not testing then db.locked=false;UpdateLock() end
        SetPreview(not testing)
    end)
    controls.style = Button("", -325, function()
        local nextStyle = {flat="rounded", rounded="beveled", beveled="flat"}
        db.style = nextStyle[db.style]; ApplyAppearance(); window:Refresh()
    end)
    controls.reminder = Button("", -363, function()
        db.reminder=not db.reminder;if not db.reminder then positioningReminder=false end;UpdateReminder();window:Refresh()
    end)
    controls.reminderSpell = Button("Manage reminder abilities", -397, function()
        local editor=window.reminderEditor
        if not editor then
            editor=CreateFrame("Frame",nil,UIParent,"BasicFrameTemplateWithInset")
            window.reminderEditor=editor
            editor:SetSize(350,200);editor:SetPoint("CENTER");editor:SetFrameStrata("DIALOG")
            editor.TitleText:SetText("Reminder abilities - add or remove")
            local entry=CreateFrame("EditBox",nil,editor,"InputBoxTemplate")
            entry:SetSize(300,24);entry:SetPoint("TOPLEFT",24,-40);entry:SetAutoFocus(false)
            local function Action(text,x,command)
                local btn=CreateFrame("Button",nil,editor,"UIPanelButtonTemplate")
                btn:SetSize(94,28);btn:SetPoint("TOPLEFT",x,-78);btn:SetText(text)
                btn:SetScript("OnClick",function()
                    if InCombatLockdown() then return end
                    SlashCmdList[config.slashKey](command .. " " .. (entry:GetText() or ""))
                    entry:ClearFocus()
                end)
            end
            Action("Add",20,"reminderadd");Action("Remove",128,"reminderremove");Action("List",236,"reminderlist")
            local help=Font(editor,11);help:SetPoint("TOPLEFT",20,-122);help:SetWidth(310)
            help:SetText("Enter an ability name or buff ID. Add each ability you want. List prints your selection in chat.")
        end
        editor:Show()
    end)
    controls.reminderSize = Button("", -431, function()
        db.reminderScale=db.reminderScale+0.25
        if db.reminderScale>3 then db.reminderScale=1 end
        UpdateReminder();window:Refresh()
    end)
    Button("Position reminder (drag its handle)", -465, function()
        positioningReminder=true;db.reminder=true;SetPreview(true);UpdateLock();window:Refresh();window:Hide()
    end)
    local note=Font(pages[3],11)
    note:SetPoint("TOPLEFT",0,-256);note:SetWidth(520)
    note:SetText(("Icon and countdown reminders appear below the threshold.\nPosition moves the entire reminder group.\nUse /fct lock to finish; positions and choices are saved."):gsub("/fct",config.command))
    function window:Refresh()
        controls.widthInput:SetText(tostring(db.width))
        controls.scaleInput:SetText(string.format("%.2f",db.scale))
        controls.growth:SetText(db.growth=="up" and "List grows: UP (click to change)" or "List grows: DOWN (click to change)")
        controls.mode:SetText(db.all and "Tracking: all matching timed effects" or "Tracking: selected spell IDs")
        controls.reminder:SetText(db.reminder and "Large reminders: ON" or "Large reminders: OFF")
        local count=0;for _ in pairs(db.reminderSpells) do count=count+1 end
        controls.reminderSpell:SetText("Manage reminder abilities (" .. count .. " selected)")
        controls.reminderSize:SetText(string.format("Reminder size: %.2fx (click to change)",db.reminderScale))
        controls.style:SetText("Bar style: " .. styles[db.style] .. " (click to change)")
        controls.barColor:SetText("Bar color: |cff" .. db.barColor .. db.barColor .. "|r")
        controls.textColor:SetText("Text color: |cff" .. db.textColor .. db.textColor .. "|r")
        controls.warningColor:SetText("Warning color: |cff" .. db.warningColor .. db.warningColor .. "|r")
        controls.sort:SetText(db.sort == "shortest" and "From anchor: shortest to longest" or "From anchor: longest to shortest")
        controls.flash:SetText(db.flash and "Countdown color pulse: ON" or "Countdown color pulse: OFF")
        input:SetText(tostring(db.threshold))
    end
    window:SelectPage(1)
    window:Refresh()
end

local function CreateMinimapButton()
    local button=CreateFrame("Button","ForeverClassTimersMinimapButton",Minimap)
    minimapButton=button
    button:SetSize(32,32)
    button:SetFrameStrata("MEDIUM")
    button:SetFrameLevel(Minimap:GetFrameLevel()+8)
    button:RegisterForClicks("LeftButtonUp","RightButtonUp")
    button:RegisterForDrag("LeftButton")
    local icon=button:CreateTexture(nil,"ARTWORK")
    icon:SetPoint("CENTER");icon:SetSize(23,23)
    icon:SetTexture("Interface\\Icons\\INV_Misc_PocketWatch_01")
    local border=button:CreateTexture(nil,"OVERLAY")
    border:SetSize(54,54);border:SetPoint("TOPLEFT")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    local label=Font(button,9);label:SetPoint("BOTTOM",0,1);label:SetText("FCT")
    button:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    local function Place()
        local angle=math.rad(db.minimapAngle)
        local rx,ry=Minimap:GetWidth()/2+8,Minimap:GetHeight()/2+8
        button:ClearAllPoints()
        button:SetPoint("CENTER",Minimap,"CENTER",math.cos(angle)*rx,math.sin(angle)*ry)
    end
    Place()
    button:SetScript("OnClick",function()
        if button.wasDragged then button.wasDragged=false;return end
        if InCombatLockdown() then Say("Leave combat before opening settings.");return end
        OpenOptions()
    end)
    button:SetScript("OnEnter",function()
        GameTooltip:SetOwner(button,"ANCHOR_LEFT")
        GameTooltip:SetText("Forever Class Timers")
        GameTooltip:AddLine("Click: open settings",1,1,1)
        GameTooltip:AddLine("Drag: move around the minimap",0.7,0.8,0.9)
        GameTooltip:Show()
    end)
    button:SetScript("OnLeave",function() GameTooltip:Hide() end)
    button:SetScript("OnDragStart",function()
        if InCombatLockdown() then return end
        button.wasDragged=true
        GameTooltip:Hide()
        button:SetScript("OnUpdate",function()
            local x,y=GetCursorPosition()
            local cx,cy=Minimap:GetCenter()
            if not cx or not cy then return end
            local scale=Minimap:GetEffectiveScale()
            db.minimapAngle=math.deg(math.atan2(y/scale-cy,x/scale-cx))
            Place()
        end)
    end)
    button:SetScript("OnDragStop",function() button:SetScript("OnUpdate",nil) end)
    -- Clear the drag-click suppression at the start of the next real click.
    button:SetScript("OnMouseDown",function() button.wasDragged=false end)
end

local function RegisterOptionsCategory()
    local panel=CreateFrame("Frame","ForeverClassTimersSettingsPanel",UIParent)
    panel:Hide()
    local title=Font(panel,20);title:SetPoint("TOPLEFT",20,-20);title:SetText("Forever Class Timers")
    local description=Font(panel,12);description:SetPoint("TOPLEFT",20,-58);description:SetWidth(520)
    description:SetJustifyH("LEFT")
    description:SetText("Customize buff bars, low-time warnings, and large reminders. Settings save automatically. Open the controls outside combat.")
    local function OpenSection(section)
        if InCombatLockdown() then Say("Leave combat before changing settings.");return end
        OpenOptions()
        optionsWindow:SelectPage(section)
    end
    for i,label in ipairs({"Open settings", "Warning settings", "Reminder settings"}) do
        local section=i
        local button=CreateFrame("Button",nil,panel,"UIPanelButtonTemplate")
        button:SetSize(260,32);button:SetPoint("TOPLEFT",20,-115-(i-1)*44);button:SetText(label)
        button:SetScript("OnClick",function() OpenSection(section) end)
    end
    local hint=Font(panel,11);hint:SetPoint("TOPLEFT",20,-265);hint:SetText(("Chat shortcut: /fct options  |  Version "):gsub("/fct",config.command) .. VERSION)
    local category=Settings.RegisterCanvasLayoutCategory(panel,"Forever Class Timers")
    Settings.RegisterAddOnCategory(category)
end

local function Secret(value)
    return issecretvalue and issecretvalue(value)
end

local function ResolveSpell(value)
    local id = tonumber(value)
    if id and (id <= 0 or id ~= math.floor(id)) then return end
    local info = C_Spell.GetSpellInfo(id or value)
    if info then return info.spellID, info.name end
end

local function PrintSpells()
    local ids = {}
    for id in pairs(db.spells) do ids[#ids+1] = id end
    table.sort(ids)
    Say(db.all and "Mode: all timed matching effects." or "Mode: selected effects.")
    for _, id in ipairs(ids) do
        local info = C_Spell.GetSpellInfo(id)
        Say(id .. " - " .. (info and info.name or "not found in this client"))
    end
end

local function Scan()
    Say(config.enemy and "Your current target debuffs (available names/IDs):" or "Active player buffs (available names/IDs):")
    for i = 1, 255 do
        local aura = config.enemy and C_UnitAuras.GetDebuffDataByIndex("target",i,"PLAYER") or (not config.enemy and C_UnitAuras.GetBuffDataByIndex("player",i))
        if not aura then break end
        if not Secret(aura.name) and not Secret(aura.spellId) and aura.name and aura.spellId then
            Say(aura.spellId .. " - " .. aura.name)
        end
    end
end

local function CopyChat()
    local window=_G[config.prefix .. "CopyChat"]
    if not window then
        window=CreateFrame("Frame","ForeverClassTimersCopyChat",UIParent,"BasicFrameTemplateWithInset")
        window:SetSize(620,420);window:SetPoint("CENTER");window:SetFrameStrata("DIALOG")
        window:SetClampedToScreen(true)
        window.TitleText:SetText("Copy chat - Ctrl+C, then paste into Codex")
        local scroll=CreateFrame("ScrollFrame",nil,window,"UIPanelScrollFrameTemplate")
        scroll:SetPoint("TOPLEFT",16,-40);scroll:SetPoint("BOTTOMRIGHT",-34,45)
        local edit=CreateFrame("EditBox",nil,scroll)
        edit:SetMultiLine(true);edit:SetAutoFocus(false)
        edit:SetFont(FONT,12,"");edit:SetWidth(560);edit:SetHeight(310)
        edit:SetScript("OnEscapePressed",function() window:Hide() end)
        scroll:SetScrollChild(edit);window.edit=edit
        local hint=Font(window,11);hint:SetPoint("BOTTOMLEFT",16,18)
        hint:SetText("Text is selected. Ctrl+C to copy. Escape to close.")
    end
    local lines={}
    local chat=DEFAULT_CHAT_FRAME
    local count=chat:GetNumMessages()
    for i=math.max(1,count-149),count do
        local text=chat:GetMessageInfo(i)
        if type(text)=="string" and not (issecretvalue and issecretvalue(text)) then
            text=text:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r","")
            text=text:gsub("|H.-|h(.-)|h","%1"):gsub("|T.-|t","")
            lines[#lines+1]=text
        end
    end
    window:Show();window.edit:SetText(table.concat(lines,"\n"))
    window.edit:SetFocus();window.edit:HighlightText()
end

local function Help()
    Say(("/fct nativewarning [off] - enable or disable saved icon/text reminders"):gsub("/fct",config.command))
    Say(("/fct racials - discover/list racial buff timers"):gsub("/fct",config.command))
    Say(("/fct copychat - copy the last 150 lines from your General chat tab"):gsub("/fct",config.command))
    Say(("/fct reminderadd <ID or name> | reminderremove <ID or name> | reminderlist"):gsub("/fct",config.command))
    Say(("/fct reminder on|off | reminderspell <ID or name> | reminderscale 1.5"):gsub("/fct",config.command))
    Say(("/fct reminderreset - reset reminder position; /fct reminderposition to position it"):gsub("/fct",config.command))
    Say(("/fct options - colors, time order and low-time pulse settings"):gsub("/fct",config.command))
    Say(("/fct unlock or lock - move / hide the drag handle"):gsub("/fct",config.command))
    Say(("/fct test - toggle animated sample bars; no real buff required"):gsub("/fct",config.command))
    Say(("/fct add <ID/name> restores; remove <ID/name> hides; excluded lists hidden IDs"):gsub("/fct",config.command))
    Say(("/fct all or selected - choose which timed effects appear"):gsub("/fct",config.command))
    Say(("/fct scan - show active effect IDs, outside combat"):gsub("/fct",config.command))
    Say(("/fct width 280 | scale 1 | reset - reset position only"):gsub("/fct",config.command))
    Say(("/fct style flat, rounded or beveled - choose bar appearance"):gsub("/fct",config.command))
    Say(("/fct barcolor 29A31F | textcolor FFFFFF | warningcolor FF5533"):gsub("/fct",config.command))
    Say(("/fct sort shortest or longest | flash 5 or off"):gsub("/fct",config.command))
end

_G["SLASH_" .. config.slashKey .. "1"]=config.command
if not config.enemy then SLASH_FOREVERCLASSTIMERS2="/frt" end
SlashCmdList[config.slashKey] = function(message)
    local command, value = message:match("^%s*(%S*)%s*(.-)%s*$")
    command = command:lower()
    if not ready then Say(failure or "Waiting for login."); return end
    if command == "" or command == "help" then Help(); return end
    if InCombatLockdown() then Say("Leave combat before changing settings or scanning buffs."); return end
    if command == "nativewarning" then
        db.reminder=value:lower()~="off";UpdateReminder()
        if optionsWindow then optionsWindow:Refresh() end
    elseif command == "copychat" then CopyChat()
    elseif command == "options" then OpenOptions()
    elseif command == "reminder" then
        value=value:lower()
        if value~="on" and value~="off" then Say(("Use /fct reminder on or off."):gsub("/fct",config.command));return end
        db.reminder=value=="on";if not db.reminder then positioningReminder=false end;UpdateReminder()
        if optionsWindow then optionsWindow:Refresh() end
    elseif command == "racials" then
        DiscoverRacials();container:SetAuraGroupCandidateFilters("buffs",Filters())
        Say("Racial buff tracking (timed player buffs only):")
        local ids={};for id in pairs(db.racialSeen) do if db.spells[id] then ids[#ids+1]=id end end;table.sort(ids)
        for _,id in ipairs(ids) do local info=C_Spell.GetSpellInfo(id);if info then Say(id .. " - " .. info.name) end end
    elseif command == "reminderdebug" then
        Say("Version " .. VERSION .. "; enabled=" .. tostring(db.reminder) .. "; preview=" .. tostring(testing) .. "; threshold=" .. db.threshold)
        Say("Live reminders: native icon/text binding; full-bar pulse unavailable.")
        Say("Last opacity error: " .. (opacityLastError or "none"))
        local ids={};for id in pairs(ReminderFilters().includeSpellIDs) do ids[#ids+1]=id end;table.sort(ids)
        local text={};for _,id in ipairs(ids) do text[#text+1]=tostring(id) end
        Say("Reminder buff IDs: " .. table.concat(text,", "))
    elseif command == "reminderlist" then
        local ids={};for id in pairs(db.reminderSpells) do ids[#ids+1]=id end;table.sort(ids)
        Say("Reminder selection: " .. #ids .. " spell IDs")
        for _,id in ipairs(ids) do local info=C_Spell.GetSpellInfo(id);Say(id .. " - " .. (info and info.name or "unknown")) end
    elseif command == "reminderremove" then
        local id=tonumber(value)
        if id then db.reminderSpells[id]=nil
        else
            local needle=value:lower()
            for selected in pairs(db.reminderSpells) do
                local info=C_Spell.GetSpellInfo(selected)
                if info and info.name:lower()==needle then db.reminderSpells[selected]=nil end
            end
        end
        UpdateReminder();if optionsWindow then optionsWindow:Refresh() end
    elseif command == "reminderspell" or command == "reminderadd" then
        local id=ResolveSpell(value)
        if not id then Say(("Spell not found. Use its buff ID; /fct scan lists active buffs."):gsub("/fct",config.command));return end
        db.reminderSpell=id;db.reminderSpells[id]=true;UpdateReminder()
        if optionsWindow then optionsWindow:Refresh() end
    elseif command == "reminderscale" then
        local size=Bounded(value,nil,1,3)
        if not size then Say("Reminder scale must be 1-3.");return end
        db.reminderScale=size;UpdateReminder()
        if optionsWindow then optionsWindow:Refresh() end
    elseif command == "reminderposition" then
        positioningReminder=true;db.reminder=true;SetPreview(true);UpdateReminder()
        Say(("Drag LARGE REMINDER, then /fct lock to finish."):gsub("/fct",config.command))
    elseif command == "reminderreset" then
        db.reminderX,db.reminderY=-140,config.enemy and -40 or 100;PlaceReminder()
    elseif command == "barcolor" or command == "textcolor" or command == "warningcolor" then
        local hex = ColorValue(value)
        if not hex then Say("Use six hexadecimal digits, for example FF8800.");return end
        local key = command == "barcolor" and "barColor" or command == "textcolor" and "textColor" or "warningColor"
        db[key]=hex;ApplyAppearance()
        if optionsWindow then optionsWindow:Refresh() end
    elseif command == "style" then
        value=value:lower()
        if not styles[value] then Say(("Use /fct style flat, rounded or beveled."):gsub("/fct",config.command));return end
        db.style=value;ApplyAppearance()
        if optionsWindow then optionsWindow:Refresh() end
    elseif command == "sort" then
        value=value:lower()
        if value ~= "shortest" and value ~= "longest" then Say(("Use /fct sort shortest or /fct sort longest."):gsub("/fct",config.command));return end
        db.sort=value;ApplyAppearance()
        if optionsWindow then optionsWindow:Refresh() end
    elseif command == "flash" then
        if value:lower() == "off" then db.flash=false
        elseif value:lower() == "on" then db.flash=true
        else
            local threshold=Bounded(value,nil,1,30)
            if not threshold then Say(("Use /fct flash 1-30, on, or off."):gsub("/fct",config.command));return end
            db.threshold=threshold;db.flash=true
        end
        ApplyAppearance()
        if optionsWindow then optionsWindow:Refresh() end
    elseif command == "lock" then
        db.locked = true; SetPreview(false); UpdateLock()
    elseif command == "unlock" then
        db.locked = false; UpdateLock()
    elseif command == "test" then
        if not testing then db.locked = false; UpdateLock() end
        SetPreview(not testing)
        Say(testing and ("Preview ON. /fct test or /fct lock returns to live buffs."):gsub("/fct",config.command) or "Preview OFF; showing live buffs.")
    elseif command == "all" or command == "selected" then
        db.all = command == "all"
        container:SetAuraGroupCandidateFilters("buffs", Filters())
        Say(db.all and "Showing all timed matching effects." or "Showing selected effects.")
    elseif command == "list" then PrintSpells()
    elseif command == "scan" then Scan()
    elseif command == "excluded" then
        local ids={};for id in pairs(db.excluded) do ids[#ids+1]=id end;table.sort(ids)
        Say("Hidden effects: " .. #ids)
        for _,id in ipairs(ids) do local info=C_Spell.GetSpellInfo(id);Say(id .. " - " .. (info and info.name or "unknown")) end
    elseif command == "add" or command == "remove" then
        local id,name=ResolveSpell(value)
        local numeric=tonumber(value)
        if numeric and numeric>0 and numeric==math.floor(numeric) then id=numeric end
        if not id then Say("Effect not found. Enter its exact name or aura spell ID; use " .. config.command .. " scan outside combat.");return end
        db.excluded[id]=command=="remove" and true or nil
        db.spells[id]=command=="add" and true or nil
        container:SetAuraGroupCandidateFilters("buffs",Filters())
        UpdateReminder()
        Say((command=="add" and "Restored " or "Hidden ") .. (name or tostring(id)) .. " (" .. id .. ").")
    elseif command == "growth" then
        if value~="up" and value~="down" then Say("Use " .. config.command .. " growth up or down.");return end
        db.growth=value;ApplyGrowth()
        if optionsWindow then optionsWindow:Refresh() end
        Say("List grows " .. value .. " from its anchor.")
    elseif command == "width" or command == "scale" then
        local low, high = command == "width" and 180 or 0.5, command == "width" and 600 or 2
        local number = Bounded(value, nil, low, high)
        if not number then Say("Enter a number from " .. low .. " to " .. high .. "."); return end
        db[command] = number; Resize()
        if optionsWindow then optionsWindow:Refresh() end
    elseif command == "reset" then
        db.x, db.y = 180, config.enemy and -220 or -80; db.locked = false; PlaceAnchor(); UpdateLock()
    else Help() end
end

events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("SPELLS_CHANGED")
events:RegisterEvent("SPELL_TEXT_UPDATE")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:RegisterEvent("PLAYER_REGEN_DISABLED")
events:SetScript("OnEvent", function(self, event)
    if event=="SPELLS_CHANGED" or event=="SPELL_TEXT_UPDATE" or event=="PLAYER_REGEN_ENABLED" then
        if ready and event=="PLAYER_REGEN_ENABLED" and resizeGrip then resizeGrip:SetShown(not db.locked) end
        if ready and not InCombatLockdown() and DiscoverRacials()>0 then
            container:SetAuraGroupCandidateFilters("buffs",Filters())
        end
        return
    end
    if event == "PLAYER_REGEN_DISABLED" then
        if ready then
            if resizeGrip then resizeGrip:Hide() end
            if minimapButton then minimapButton:SetScript("OnUpdate",nil) end
            if optionsWindow then optionsWindow:StopMovingOrSizing();optionsWindow:Hide();if optionsWindow.reminderEditor then optionsWindow.reminderEditor:Hide() end end
            if ColorPickerFrame and ColorPickerFrame:GetExtraInfo() == ADDON then ColorPickerFrame:Hide() end
            anchor:StopMovingOrSizing()
            reminderAnchor:StopMovingOrSizing()
            positioningReminder=false;reminderHandle:Hide();reminderHandle:EnableMouse(false)
            -- Preview never masks real combat buffs.
            if testing then SetPreview(false) end
        end
        return
    end
    if ready then return end
    local interface = select(4, GetBuildInfo())
    if interface < 16000 or interface >= 20000 then
        failure = "This build is for WoW Forever 1.60.x."
        Say(failure); return
    end
    NormalizeSaved()
    DiscoverRacials()
    local ok, err = pcall(CreateUI)
    if not ok then
        failure = "Could not initialize. Send the first Lua error and your client build."
        if anchor then anchor:Hide() end
        if reminderAnchor then reminderAnchor:Hide() end
        Say(failure)
        geterrorhandler()(ADDON .. " " .. VERSION .. ": " .. tostring(err))
        return
    end
    ready = true
    if not config.enemy then
    local minimapOK,minimapError=true,nil -- FBUFF uses its own minimap button
    if not minimapOK then geterrorhandler()(ADDON .. " minimap button: " .. tostring(minimapError)) end
    local registered,registrationError=true,nil -- FBUFF uses its own settings panel
    if not registered then
        Say(("Options menu registration failed; /fct options still works."):gsub("/fct",config.command))
        geterrorhandler()(ADDON .. " settings registration: " .. tostring(registrationError))
    end
    end
    -- FBUFF shell handles user-facing startup UI.
end)

local function RefreshLiveFilters()
   if not container or InCombatLockdown() then return end
   container:SetAuraGroupCandidateFilters("buffs",Filters())
   -- Force the AuraContainer to rebuild immediately. This is important for
   -- effects such as Weak Soul that otherwise can remain as a stale native row.
   container:SetEnabled(false)
   container:SetUnit(config.unit)
   container:SetEnabled(true)
   if config.persistMulti and not config.enemy then container:SetAlpha(0) end
end

return {
 open=OpenOptions,
 setSize=function(width,height)
   if not ready or InCombatLockdown() then return end
   db.width=math.max(150,math.min(250,width or db.width or 200))
   db.fbuffHeight=math.max(20,math.min(40,height or db.fbuffHeight or 25))
   db.scale=1
   HEIGHT=db.fbuffHeight
   Resize()
 end,
 getSize=function() return ready and db.width or 200, ready and (db.fbuffHeight or HEIGHT) or 25 end,
 position=function(show)
   if not ready or InCombatLockdown() then return end
   if config.unit=="player" and not config.enemy then
      -- 自身BUFF已改為直接拖曳真實ICON：不再顯示「自己BUFF」拖曳標題框。
      db.locked=true
      SetPreview(false)
      UpdateLock()
      if anchor then anchor:Hide() end
      return
   end
   db.locked=not show
   SetPreview(show)
   UpdateLock()
 end,
 resetPosition=function()
   if not ready or InCombatLockdown() then return end
   db.x=100;db.y=config.defaultShellY or (config.enemy and -165 or 145);PlaceAnchor()
 end,
 getAnchor=function() return anchor end,
 getDB=function() return db end,
 excluded=function() return db and db.excluded or {} end,
 currentEffects=function()
   local out={}
   if not ready or InCombatLockdown() then return out end
   if config.persistMulti and not config.enemy and config.unit=="target" and UnitExists("target") and UnitIsUnit("target","player") then return out end
   for i=1,255 do
     local ok,aura=pcall(function()
       if config.enemy then return C_UnitAuras.GetDebuffDataByIndex(config.unit or "target",i,"PLAYER") end
       return C_UnitAuras.GetBuffDataByIndex(config.unit or "player",i,"PLAYER")
     end)
     if not ok or not aura then break end
     local id,name=aura.spellId,aura.name
     if id and name and not Secret(id) and not Secret(name) and not db.excluded[id] then
       out[#out+1]={id=id,name=name}
     end
   end
   table.sort(out,function(a,b) return tostring(a.name)<tostring(b.name) end)
   return out
 end,
 restore=function(id)
   if db and db.excluded then db.excluded[id]=nil;RefreshLiveFilters() end
 end,
 hide=function(value)
   if not db or InCombatLockdown() then return false end
   local id,name=ResolveSpell(value or "")
   local numeric=tonumber(value)
   if numeric and numeric>0 and numeric==math.floor(numeric) then id=numeric end
   if not id then return false end
   db.excluded[id]=true
   RefreshLiveFilters()
   UpdateReminder()
   return true,id,name
 end,
}
end
trackers.buffs=CreateTracker({enemy=false,savedKey="FBUFF_BuffDB",prefix="FBUFFBuff",slashKey="FBUFFBUFFCORE",command="/fbuffbuff",unit="player",filter="HELPFUL|PLAYER",label="自己BUFF"})
trackers.friendbuffs=CreateTracker({enemy=false,savedKey="FBUFF_FriendBuffDB",prefix="FBUFFFriendBuff",slashKey="FBUFFFRIENDBUFFCORE",command="/fbufffriend",unit="target",filter="HELPFUL|PLAYER",label="友方BUFF",defaultY=15,defaultShellY=-10,persistMulti=true})
trackers.debuffs=CreateTracker({enemy=true,savedKey="FBUFF_DotDB",prefix="FBUFFDot",slashKey="FBUFFDOTCORE",command="/fbuffdot",unit="target",filter="HARMFUL|PLAYER",label="敵方身上DOT",persistMulti=true})


-- ===== FBUFF shell: BY 老哥 =====
local FBUFFPanel, FBUFFPage1, FBUFFPage2
local positioning=false
local function CoreReady() return trackers.buffs and trackers.debuffs end
local function SetBothSize(w,h)
    if not CoreReady() or InCombatLockdown() then return end
    trackers.buffs.setSize(w,h);trackers.friendbuffs.setSize(w,h);trackers.debuffs.setSize(w,h)
end
local function SetPositioning(show)
    positioning=show and true or false
    if not CoreReady() or InCombatLockdown() then return end
    trackers.buffs.position(positioning);trackers.friendbuffs.position(positioning);trackers.debuffs.position(positioning)
 if FBUFFRefreshSelfIconAttach then FBUFFRefreshSelfIconAttach() end
end
local function IgnoreNameSet()
    if type(FBUFF_UI_DB)~="table" then FBUFF_UI_DB={} end
    if type(FBUFF_UI_DB.ignoreNames)~="table" then FBUFF_UI_DB.ignoreNames={} end
    return FBUFF_UI_DB.ignoreNames
end
local function FBUFFAutoExternalIgnoredSet()
    if type(FBUFF_UI_DB.autoExternalIgnored)~="table" then FBUFF_UI_DB.autoExternalIgnored={} end
    return FBUFF_UI_DB.autoExternalIgnored
end
local function FBUFFExternalAllowedSet()
    if type(FBUFF_UI_DB.externalAllowed)~="table" then FBUFF_UI_DB.externalAllowed={} end
    return FBUFF_UI_DB.externalAllowed
end
local function FBUFFManualIgnoredSet()
    if type(FBUFF_UI_DB.manualIgnored)~="table" then FBUFF_UI_DB.manualIgnored={} end
    return FBUFF_UI_DB.manualIgnored
end
local function IgnoreEverywhere(id,name)
    if not id then return false end
    if name and name~="" then
        IgnoreNameSet()[name]=true
        FBUFFManualIgnoredSet()[name]=true
        FBUFFExternalAllowedSet()[name]=nil
    end
    local changed=false
    -- Hide the selected ID in every tracker first.
    for _,tr in pairs(trackers) do if tr.hide(id) then changed=true end end
    -- Some visible auras (notably 虛弱靈魂 / Weakened Soul) can use a rank/variant
    -- spell ID different from the ID returned by a generic name lookup.  While the
    -- unit is inspectable, collect every public aura with the same visible name and
    -- exclude those exact IDs too.  This stays outside combat and never touches a
    -- secret value.
    if name and name~="" and not InCombatLockdown() then
        local function scan(unit,harmful)
            if not UnitExists(unit) then return end
            for i=1,255 do
                local ok,a=pcall(function()
                    if harmful then return C_UnitAuras.GetDebuffDataByIndex(unit,i) end
                    return C_UnitAuras.GetBuffDataByIndex(unit,i)
                end)
                if not ok or not a then break end
                local aid,aname=a.spellId,a.name
                if aid and aname and (not issecretvalue or (not issecretvalue(aid) and not issecretvalue(aname))) and aname==name then
                    for _,tr in pairs(trackers) do if tr.hide(aid) then changed=true end end
                end
            end
        end
        scan("player",false); scan("player",true); scan("target",false); scan("target",true)
    end
    return changed
end
local FBUFFAuraContainerStart168

local function RestoreEverywhere(id,name)
    -- 取消忽略時不能只恢復清單中被點到的舊 ID。Forever 同名 BUFF 可能有
    -- rank/variant spellID；v1.83「忽略」會把目前實際 Aura ID 一併排除，
    -- 因此取消時也要把所有同名排除 ID 一次恢復，才能讓仍存在的 BUFF
    -- 立即重新進入自身 AuraContainer。
    for _,tr in pairs(trackers) do
        tr.restore(id)
        if name and tr.excluded then
            local restoreIDs={}
            for excludedID in pairs(tr.excluded()) do
                local spellName=C_Spell.GetSpellName(excludedID)
                if spellName==name then restoreIDs[#restoreIDs+1]=excludedID end
            end
            for _,restoreID in ipairs(restoreIDs) do tr.restore(restoreID) end
        end
    end
    if name and type(FBUFF_UI_DB)=="table" and type(FBUFF_UI_DB.ignoreNames)=="table" then
        FBUFF_UI_DB.ignoreNames[name]=nil
        FBUFFManualIgnoredSet()[name]=nil
        if FBUFFAutoExternalIgnoredSet()[name] then FBUFFExternalAllowedSet()[name]=true end
    end
    if not InCombatLockdown() and FBUFFAuraContainerStart168 then C_Timer.After(0,FBUFFAuraContainerStart168) end
end

-- v1.85：別人施放到玩家身上的 BUFF 預設自動加入「已忽略效果」。
-- 玩家在「已忽略效果」按取消後，該名稱加入允許名單，之後可正常顯示。
-- 只在脫戰時讀取公開 AuraData；遇到 secret 值直接略過。
local function FBUFFAutoIgnoreExternalPlayerBuffs()
    if InCombatLockdown and InCombatLockdown() then return false end
    local ignored=IgnoreNameSet();local auto=FBUFFAutoExternalIgnoredSet();local allowed=FBUFFExternalAllowedSet();local manual=FBUFFManualIgnoredSet()
    local changed=false
    for i=1,255 do
        local ok,a=pcall(C_UnitAuras.GetBuffDataByIndex,"player",i)
        if not ok or not a then break end
        local id,name=a.spellId,a.name
        if id and name and (not issecretvalue or (not issecretvalue(id) and not issecretvalue(name))) then
            local fromPlayer=false
            local fp=a.isFromPlayerOrPlayerPet
            if fp~=nil and (not issecretvalue or not issecretvalue(fp)) then fromPlayer=(fp==true) end
            if not fromPlayer then
                local src=a.sourceUnit
                if src~=nil and (not issecretvalue or not issecretvalue(src)) then
                    local okSame,same=pcall(UnitIsUnit,src,"player")
                    if okSame and same==true then fromPlayer=true end
                end
            end
            if not fromPlayer and not allowed[name] then
                ignored[name]=true;auto[name]=true
                for _,tr in pairs(trackers) do if tr.hide(id) then changed=true end end
            elseif fromPlayer and auto[name] and not manual[name] then
                -- 同名效果若現在是自己施放，恢復「自己施放預設顯示」。
                ignored[name]=nil;auto[name]=nil
                for _,tr in pairs(trackers) do tr.restore(id) end
                changed=true
            end
        end
    end
    return changed
end



-- FBUFF multi-target supplement. Blizzard AuraContainer can only stay bound to a
-- live unit token (target/player). We cache public timer data for targets we have
-- actually inspected, then keep those rows visible after changing/clearing target.
-- If a timer is secret, we leave it to Blizzard's native AuraContainer instead of
-- touching protected values.
local multi = { friendbuffs={cache={},rows={}}, debuffs={cache={},rows={}} }

local selfLearn={rows={},active={},nativeSeen={}}
local function SelfLearnDB()
    if type(FBUFF_UI_DB)~="table" then FBUFF_UI_DB={} end
    if type(FBUFF_UI_DB.selfLearned)~="table" then FBUFF_UI_DB.selfLearned={} end
    return FBUFF_UI_DB.selfLearned
end

local function IsSecretValue(v) return issecretvalue and issecretvalue(v) end
local function MultiIgnored(kind,id,name)
    if name and IgnoreNameSet()[name] then return true end
    local tr=trackers[kind]
    return tr and tr.excluded and tr.excluded()[id] == true
end
local function MultiMakeRow(kind,index)
    local m=multi[kind]; local anchor=trackers[kind].getAnchor(); if not anchor then return end
    -- Enemy DOT rows are FBUFF-owned frames and must never become children of any
    -- AuraContainer/BUFF layout tree.  Parenting them to UIParent keeps DOT layout
    -- completely isolated from the already-working self/friend BUFF anchors.
    local rowParent = (kind=="debuffs") and UIParent or anchor
    local f=CreateFrame("Frame",nil,rowParent); f:SetHeight(24); f:EnableMouse(false)
    if kind=="debuffs" then f:SetFrameStrata("MEDIUM") end
    local background=f:CreateTexture(nil,"BACKGROUND"); background:SetAllPoints(); background:SetColorTexture(0,0,0,.95)
    local icon=f:CreateTexture(nil,"ARTWORK"); icon:SetPoint("TOPLEFT",0,-1); icon:SetSize(23,22); icon:SetTexCoord(.08,.92,.08,.92)
    local bar=CreateFrame("StatusBar",nil,f,"CastingBarFrameTemplate"); bar:SetPoint("TOPLEFT",f,"TOPLEFT",23,-1); bar:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-1,1)
    -- This supplement lives outside CreateTracker(), so its local helpers
    -- (StyleTexture/RGB/FONT) are not in scope here.  Build the same visual
    -- values locally instead of calling nil functions.
    local tdb=trackers[kind].getDB()
    local style=(tdb and tdb.style) or "flat"
    local texture = style == "flat" and "Interface\\Buttons\\WHITE8X8" or ("Interface\\AddOns\\FBUFF\\" .. (style == "rounded" and "Rounded" or "Beveled"))
    local function MultiRGB(hex)
        hex=tostring(hex or "FFFFFF"):gsub("#","")
        local r=tonumber(hex:sub(1,2),16) or 255
        local g=tonumber(hex:sub(3,4),16) or 255
        local b=tonumber(hex:sub(5,6),16) or 255
        return r/255,g/255,b/255
    end
    local multiFont = GameFontNormal:GetFont()
    local empty=bar:CreateTexture(nil,"BACKGROUND"); empty:SetAllPoints(); empty:SetColorTexture(0,0,0,0); empty:Hide()
    bar.empty=empty
    bar.rowBackground=background
    FBUFF_SetupV033Bar(bar,kind=="debuffs" and "dot" or "friend")
    local name=bar:CreateFontString(nil,"OVERLAY"); name:SetFont(multiFont,15,"OUTLINE"); name:SetPoint("LEFT",bar,"LEFT",5,0); name:SetPoint("RIGHT",bar,"RIGHT",-53,0); name:SetJustifyH("LEFT"); name:SetWordWrap(false)
    if kind=="friendbuffs" then name:SetShown(tdb and tdb.showSkillName==true) end
    local timeLayer=CreateFrame("Frame",nil,f)
    timeLayer:SetAllPoints(bar)
    timeLayer:SetFrameStrata("HIGH")
    timeLayer:SetFrameLevel(math.max((bar:GetFrameLevel() or 1)+20,(f:GetFrameLevel() or 1)+20))
    local targetID=timeLayer:CreateFontString(nil,"OVERLAY"); targetID:SetFont(multiFont,15,"OUTLINE"); targetID:SetPoint("LEFT",timeLayer,"LEFT",5,0); targetID:SetJustifyH("LEFT"); targetID:SetWordWrap(false)
    local skillName=timeLayer:CreateFontString(nil,"OVERLAY"); skillName:SetFont(multiFont,15,"OUTLINE"); skillName:SetJustifyH("LEFT"); skillName:SetWordWrap(false)
    local tm=timeLayer:CreateFontString(nil,"OVERLAY"); tm:SetFont(multiFont,15,"OUTLINE"); tm:SetPoint("RIGHT",timeLayer,"RIGHT",-4,0); tm:SetWidth(48); tm:SetJustifyH("RIGHT")
    if kind=="friendbuffs" or kind=="debuffs" then
        targetID:SetShown(tdb and tdb.showTargetID==true)
        skillName:SetShown(tdb and tdb.showSkillName==true)
        tm:SetShown(not tdb or tdb.showCountdown~=false)
    end
    if tdb and tdb.textColor then name:SetTextColor(MultiRGB(tdb.textColor)); targetID:SetTextColor(MultiRGB(tdb.textColor)); skillName:SetTextColor(MultiRGB(tdb.textColor)); tm:SetTextColor(MultiRGB(tdb.textColor)) else name:SetTextColor(1,1,1); targetID:SetTextColor(1,1,1); skillName:SetTextColor(1,1,1); tm:SetTextColor(1,1,1) end
    m.rows[index]={frame=f,icon=icon,bar=bar,name=name,targetID=targetID,skillName=skillName,time=tm,empty=empty,background=background}; return m.rows[index]
end
local function FBUFFPlayerInCombat()
    local ok,v=pcall(UnitAffectingCombat,"player")
    if not ok or IsSecretValue(v) then return InCombatLockdown() end
    return v and true or false
end

local function MultiScan(kind)
    -- In combat/instances, friendly buffs are tracked from the player's successful casts.
    -- Do not read restricted aura payloads or erase those event-based timers.
    -- Enemy DOTs deliberately do NOT call C_UnitAuras here: Forever makes
    -- combat aura payloads secret.  DOT cache entries are created from our
    -- own successful casts further below (DoesItDie-style tracking).
    if kind=="debuffs" then return end
    if FBUFFPlayerInCombat() or not UnitExists("target") then return end
    if UnitIsUnit("target","player") or not UnitIsFriend("player","target") then return end
    local guid=UnitGUID("target"); if not guid or IsSecretValue(guid) then return end
    local targetName=UnitName("target")
    if IsSecretValue(targetName) or type(targetName)~="string" or targetName=="" then targetName=nil end
    local m=multi[kind]; local seen={}
    for i=1,255 do
        local ok,a=pcall(function() return C_UnitAuras.GetBuffDataByIndex("target",i,"PLAYER") end)
        if not ok or not a then break end
        local id,name=a.spellId,a.name
        if id and name and not IsSecretValue(id) and not IsSecretValue(name) and not MultiIgnored(kind,id,name) then
            local exp,dur=a.expirationTime,a.duration
            if exp and dur and not IsSecretValue(exp) and not IsSecretValue(dur) and tonumber(exp) and tonumber(dur) and dur>0 then
                local key=guid..":"..tostring(id); seen[key]=true
                m.cache[key]={guid=guid,id=id,name=name,targetName=targetName,icon=a.icon or C_Spell.GetSpellTexture(id),expiration=exp,duration=dur}
            end
        end
    end
    for key,e in pairs(m.cache) do if e.guid==guid and not seen[key] then m.cache[key]=nil end end
end

local function MultiRender(kind)
    -- v1.83：隊友 BUFF 已全面改用獨立 AuraContainer ICON。
    -- 舊式友方 BUFF 綠色讀條只停用顯示；敵方 DOT 紅色讀條完全不動。
    if kind=="friendbuffs" or kind=="debuffs" then
        -- v1.84 TEST：友方 BUFF 與敵方 DOT 舊式讀條都停用；改由 AuraContainer ICON 顯示。
        local m=multi[kind]
        for i=1,#m.rows do if m.rows[i] and m.rows[i].frame then m.rows[i].frame:Hide() end end
        return
    end
    local m=multi[kind]; local tr=trackers[kind]; local anchor=tr.getAnchor(); if not anchor then return end
    local now=GetTime(); local nativeCount=0
    local arr={}
    for key,e in pairs(m.cache) do
        if MultiIgnored(kind,e.id,e.name) or now>=e.expiration then
            m.cache[key]=nil
        else
            arr[#arr+1]=e
        end
    end
    table.sort(arr,function(a,b)
        if a.expiration==b.expiration then return tostring(a.key or a.id)<tostring(b.key or b.id) end
        return a.expiration<b.expiration
    end)
    local db=tr.getDB(); local logicalWidth=db and db.width or 200
    local rowHeight=(db and db.fbuffHeight) or 25
    for i,e in ipairs(arr) do
        local r=m.rows[i] or MultiMakeRow(kind,i)
        r.frame:ClearAllPoints(); r.frame:SetPoint("TOPLEFT",anchor,"TOPLEFT",0,-(nativeCount+i-1)*(rowHeight+2))
        r.frame:SetWidth(logicalWidth); r.frame:SetHeight(rowHeight); r.frame:Show()
        r.icon:SetSize(rowHeight-1,rowHeight-2)
        r.bar:ClearAllPoints();r.bar:SetPoint("TOPLEFT",r.frame,"TOPLEFT",rowHeight-1,-1);r.bar:SetPoint("BOTTOMRIGHT",r.frame,"BOTTOMRIGHT",-1,1)
        r.icon:SetTexture(e.icon or 134400)
        if kind=="friendbuffs" or kind=="debuffs" then
            r.name:Hide()
            local showID=db and db.showTargetID==true
            local showSkill=db and db.showSkillName==true
            if r.targetID then
                local displayID=e.targetName or ""
                if #displayID>0 then
                    local chars={}
                    for ch in displayID:gmatch("[%z\1-\127\194-\244][\128-\191]*") do
                        chars[#chars+1]=ch
                    end
                    if #chars>5 then
                        displayID=table.concat(chars,"",1,5)
                    end
                end
                r.targetID:SetText(displayID)
                r.targetID:ClearAllPoints()
                r.targetID:SetPoint("LEFT",r.bar,"LEFT",5,0)
                r.targetID:SetShown(showID)
            end
            if r.skillName then
                local displaySkill=e.name or ""
                if #displaySkill>0 then
                    local skillChars={}
                    for ch in displaySkill:gmatch("[%z\1-\127\194-\244][\128-\191]*") do
                        skillChars[#skillChars+1]=ch
                    end
                    if #skillChars>3 then
                        displaySkill=table.concat(skillChars,"",1,3)
                    end
                end
                r.skillName:SetText(displaySkill)
                r.skillName:ClearAllPoints()
                if showID and r.targetID then
                    r.skillName:SetPoint("LEFT",r.targetID,"RIGHT",8,0)
                else
                    r.skillName:SetPoint("LEFT",r.bar,"LEFT",5,0)
                end
                r.skillName:SetShown(showSkill)
            end
            r.time:SetShown(not db or db.showCountdown~=false)
        else
            r.name:SetText(e.name)
        end
        local rem=math.max(0,e.expiration-now); r.bar:SetMinMaxValues(0,e.duration); r.bar:SetValue(rem); r.time:SetFormattedText("%.1f",rem)
        if kind=="friendbuffs" or kind=="debuffs" then
            if rem <= 5 then r.time:SetTextColor(1,0.20,0.12) else r.time:SetTextColor(1,1,1) end
        end
    end
    for i=#arr+1,#m.rows do m.rows[i].frame:Hide() end
end


local function SelfLearnDurationText(button)
    if not button then return nil end

    -- Blizzard BuffButton 直接提供數字 timeLeft；優先使用，避免把數字當 FontString。
    local direct=button.timeLeft
    if type(direct)=="number" and direct>0 and not IsSecretValue(direct) then
        return direct
    end

    -- 後備：只讀真正具有 GetText() 的原生文字元件。
    for _,key in ipairs({"Duration","duration","DurationText","durationText","TimeLeft"}) do
        local r=button[key]
        if type(r)=="table" and type(r.GetText)=="function" then
            local ok,v=pcall(r.GetText,r)
            if ok and v~=nil and not IsSecretValue(v) then
                local t=tostring(v)
                local n=tonumber(t:match("(%d+%.?%d*)"))
                if n and n>0 then return n end
            end
        end
    end
    if button.GetRegions then
        local ok,regions=pcall(function() return {button:GetRegions()} end)
        if ok then
            for _,r in ipairs(regions or {}) do
                if r and r.GetObjectType and r:GetObjectType()=="FontString" and r.GetText then
                    local ok2,v=pcall(r.GetText,r)
                    if ok2 and v~=nil and not IsSecretValue(v) then
                        local n=tonumber(tostring(v):match("(%d+%.?%d*)"))
                        if n and n>0 then return n end
                    end
                end
            end
        end
    end
end

local selfButtonInfoProbeSeen={}
local function SelfProbeSafeValue(v)
    if v==nil then return "nil" end
    if IsSecretValue and IsSecretValue(v) then return "<secret>" end
    local tv=type(v)
    if tv=="string" or tv=="number" or tv=="boolean" then return tostring(v) end
    return "<"..tv..">"
end

local function SelfProbeButtonInfo(button)
    if not button or type(button.buttonInfo)~="table" then return end
    local info=button.buttonInfo
    local parts={}
    for k,v in pairs(info) do
        if not (IsSecretValue and (IsSecretValue(k) or IsSecretValue(v))) then
            local tk,tv=type(k),type(v)
            if (tk=="string" or tk=="number") and (tv=="string" or tv=="number" or tv=="boolean") then
                parts[#parts+1]=tostring(k).."="..SelfProbeSafeValue(v)
            end
        end
    end
    table.sort(parts)
    local line=table.concat(parts," | ")
    if line=="" then line="<沒有可直接讀取的基本欄位>" end
    if not selfButtonInfoProbeSeen[line] then
        selfButtonInfoProbeSeen[line]=true
        print("|cffFFD700FBUFF buttonInfo探針：|r "..line)

        -- v1.56 TEST：只測試 auraInstanceID 對應的 Aura API 回傳值。
        local auraID = info.auraInstanceID
        if type(auraID)=="number" and C_UnitAuras
            and type(C_UnitAuras.GetAuraDataByAuraInstanceID)=="function" then
            local ok, aura = pcall(C_UnitAuras.GetAuraDataByAuraInstanceID, "player", auraID)
            if ok and type(aura)=="table" then
                local aout={}
                local function add(k,v)
                    local tv=type(v)
                    if tv=="string" or tv=="number" or tv=="boolean" then
                        aout[#aout+1]=k.."="..tostring(v)
                    end
                end
                add("auraInstanceID",aura.auraInstanceID)
                add("name",aura.name)
                add("spellId",aura.spellId)
                add("icon",aura.icon)
                add("duration",aura.duration)
                add("expirationTime",aura.expirationTime)
                add("timeMod",aura.timeMod)
                print("|cff00FF96FBUFF AuraAPI探針：|r "..table.concat(aout," | "))
            elseif ok then
                print("|cff00FF96FBUFF AuraAPI探針：|r ID="..tostring(auraID).." | 無Aura資料")
            else
                print("|cff00FF96FBUFF AuraAPI探針：|r ID="..tostring(auraID).." | API錯誤="..tostring(aura))
            end
        end
    end
end

local function SelfLearnButtonAura(button)
    -- Prefer Blizzard's button auraInstanceID, then index fields.
    local auraID=button and (button.auraInstanceID or button.AuraInstanceID)
    if auraID and not IsSecretValue(auraID) and C_UnitAuras.GetAuraDataByAuraInstanceID then
        local ok,a=pcall(C_UnitAuras.GetAuraDataByAuraInstanceID,"player",auraID)
        if ok and a then return a end
    end
    local idx=button and (button.auraIndex or button.index or button:GetID())
    if idx and not IsSecretValue(idx) then
        local ok,a=pcall(C_UnitAuras.GetBuffDataByIndex,"player",idx)
        if ok and a then return a end
    end
end

local function SelfLearnNativeButtons()
    local buttons={}
    if BuffFrame and BuffFrame.auraFrames then
        for _,b in pairs(BuffFrame.auraFrames) do buttons[#buttons+1]=b end
    end
    for i=1,40 do local b=_G["BuffButton"..i];if b then buttons[#buttons+1]=b end end
    return buttons
end

local function SelfLearnMakeRow(index)
    local anchor=trackers.buffs.getAnchor();if not anchor then return end
    local f=CreateFrame("Frame",nil,anchor);f:SetHeight(24);f:EnableMouse(false)
    local bg=f:CreateTexture(nil,"BACKGROUND");bg:SetAllPoints();bg:SetColorTexture(0.055,0.055,0.055,0.94)
    local icon=f:CreateTexture(nil,"ARTWORK");icon:SetPoint("TOPLEFT",0,-1);icon:SetSize(23,22);icon:SetTexCoord(.08,.92,.08,.92)
    local bar=CreateFrame("StatusBar",nil,f,"CastingBarFrameTemplate");bar:SetPoint("TOPLEFT",f,"TOPLEFT",23,-1);bar:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-1,1)
    bar.rowBackground=bg;FBUFF_SetupV033Bar(bar,"selfcustom")
    local font=GameFontNormal:GetFont()
    local name=bar:CreateFontString(nil,"OVERLAY");name:SetFont(font,15,"OUTLINE");name:SetPoint("LEFT",bar,"LEFT",5,0);name:SetPoint("RIGHT",bar,"RIGHT",-53,0);name:SetJustifyH("LEFT");name:SetWordWrap(false)
    local top=CreateFrame("Frame",nil,f);top:SetAllPoints(bar);top:SetFrameStrata("HIGH");top:SetFrameLevel(math.max((bar:GetFrameLevel() or 1)+20,(f:GetFrameLevel() or 1)+20))
    local tm=top:CreateFontString(nil,"OVERLAY");tm:SetFont(font,15,"OUTLINE");tm:SetPoint("RIGHT",top,"RIGHT",-4,0);tm:SetWidth(48);tm:SetJustifyH("RIGHT")
    selfLearn.rows[index]={frame=f,icon=icon,bar=bar,name=name,time=tm};return selfLearn.rows[index]
end

local function SelfLearnRender()
    for i=1,#selfLearn.rows do local r=selfLearn.rows[i]; if r and r.frame then r.frame:Hide() end end
end

local function SelfLearnScanNative()
    local learned=SelfLearnDB();local seen={};local inCombat=InCombatLockdown and InCombatLockdown()

    -- v1.60：戰鬥中完全不讀 Blizzard BuffButton 內的任何 Aura 資料。
    -- 進戰前已經建立的黃色條，只保留「原生 Button 物件」與已學習的固定時間。
    -- 原生 Button 還顯示＝黃色條繼續本地倒數；Button 消失＝黃色條立即移除。
    if inCombat then
        for id,e in pairs(selfLearn.active) do
            local b=e and e.nativeButton
            if b and b.IsShown and b:IsShown() then
                seen[id]=true
            end
        end
    else
        -- 非戰鬥期間維持已成功的 AuraInstanceID API：
        -- 學習技能 ID、名稱、ICON、固定持續時間，並記住當下對應的原生 Button。
        for _,b in ipairs(SelfLearnNativeButtons()) do
            if b and (not b.IsShown or b:IsShown()) then
                local bi=type(b.buttonInfo)=="table" and b.buttonInfo or nil
                local auraID=bi and bi.auraInstanceID
                if type(auraID)=="number" and not IsSecretValue(auraID) and C_UnitAuras
                    and type(C_UnitAuras.GetAuraDataByAuraInstanceID)=="function" then
                    local ok,result=pcall(C_UnitAuras.GetAuraDataByAuraInstanceID,"player",auraID)
                    local a=(ok and type(result)=="table") and result or nil
                    if a then
                        local id,name=a.spellId,a.name
                        local duration=tonumber(a.duration)
                        local expiration=tonumber(a.expirationTime)
                        if id and name and not IsSecretValue(id) and not IsSecretValue(name)
                            and duration and duration>0 and expiration and expiration>0 then
                            seen[id]=true
                            local info=learned[id]
                            if type(info)~="table" then info={};learned[id]=info end
                            info.name=name
                            info.icon=a.icon or info.icon or C_Spell.GetSpellTexture(id)
                            info.duration=duration
                            if not IgnoreNameSet()[name] then
                                selfLearn.active[id]={
                                    id=id,auraInstanceID=auraID,name=name,icon=info.icon,
                                    duration=duration,expiration=expiration,nativeButton=b,
                                }
                            else
                                selfLearn.active[id]=nil
                            end
                        end
                    end
                end
            end
        end
    end

    selfLearn.nativeSeen=seen
    for id in pairs(selfLearn.active) do
        if not seen[id] then selfLearn.active[id]=nil end
    end
    SelfLearnRender()
end


-- v1.68：沿用 v1.66 實測成功 AuraContainer；只改自動啟動與外層右鍵拖曳。
-- 不接黃色條；不讀 AuraData、auraInstanceID、texture、UNIT_AURA payload。
local selfIconAnchor
local selfExampleHolder
local selfExampleButtons={}
local selfExampleShown=false

local function FBUFFEnsureSelfIconDB()
    FBUFF_DB=FBUFF_DB or {}
    if type(FBUFF_DB.selfIconScale)~="number" then FBUFF_DB.selfIconScale=1 end
    FBUFF_DB.selfIconScale=math.max(1,math.min(3,FBUFF_DB.selfIconScale))
    if FBUFF_DB.selfAuraEnabled==nil then FBUFF_DB.selfAuraEnabled=true end
    if FBUFF_DB.targetAuraEnabled==nil then FBUFF_DB.targetAuraEnabled=true end
    if type(FBUFF_DB.targetIconScale)~="number" then FBUFF_DB.targetIconScale=FBUFF_DB.selfIconScale end
    FBUFF_DB.targetIconScale=math.max(1,math.min(3,FBUFF_DB.targetIconScale))
    if type(FBUFF_DB.selfIconPos)~="table" then FBUFF_DB.selfIconPos={x=230,y=135} end
    if type(FBUFF_DB.selfIconPos.x)~="number" then FBUFF_DB.selfIconPos.x=230 end
    if type(FBUFF_DB.selfIconPos.y)~="number" then FBUFF_DB.selfIconPos.y=135 end
end

local function FBUFFPositionSelfAnchor()
    FBUFFEnsureSelfIconDB()
    if not selfIconAnchor then
        selfIconAnchor=CreateFrame("Frame","FBUFF_SelfIconAnchor",UIParent)
        selfIconAnchor:SetSize(1,1)
        selfIconAnchor:SetClampedToScreen(true)
    end
    selfIconAnchor:ClearAllPoints()
    selfIconAnchor:SetPoint("CENTER",UIParent,"CENTER",FBUFF_DB.selfIconPos.x,FBUFF_DB.selfIconPos.y)
    selfIconAnchor:Show()
    return selfIconAnchor
end

-- v1.80：拖曳更新完全交給 FBUFF 自己的一般 Frame；實際/虛擬 BUFF 共用同一 TOPLEFT 錨點。
-- AuraContainer / AuraButton 只送出開始、停止訊號，不再替 Blizzard Aura 元件更換 OnUpdate。
local selfIconDragController=CreateFrame("Frame","FBUFF_SelfIconDragController",UIParent)
local selfIconDragState=nil
selfIconDragController:Hide()
selfIconDragController:SetScript("OnUpdate",function()
    local drag=selfIconDragState
    if not drag then return end
    local cx,cy=GetCursorPosition()
    local scale=UIParent:GetEffectiveScale()
    cx,cy=cx/scale,cy/scale
    FBUFF_DB.selfIconPos.x=drag.baseX+(cx-drag.x)
    FBUFF_DB.selfIconPos.y=drag.baseY+(cy-drag.y)
    local a=FBUFFPositionSelfAnchor()
    if selfExampleHolder then
        selfExampleHolder:ClearAllPoints();selfExampleHolder:SetPoint("TOPLEFT",a,"CENTER",0,0)
    end
end)

local function FBUFFStartSelfIconDrag(owner)
    FBUFFEnsureSelfIconDB()
    local x,y=GetCursorPosition()
    local sc=UIParent:GetEffectiveScale()
    selfIconDragState={x=x/sc,y=y/sc,baseX=FBUFF_DB.selfIconPos.x,baseY=FBUFF_DB.selfIconPos.y}
    selfIconDragController:Show()
end

local function FBUFFStopSelfIconDrag(owner)
    selfIconDragState=nil
    selfIconDragController:Hide()
end

local function FBUFFRefreshExampleSize()
    if not selfExampleHolder then return end
    FBUFFEnsureSelfIconDB()
    local sz=28*FBUFF_DB.selfIconScale
    local gap=6*FBUFF_DB.selfIconScale
    selfExampleHolder:SetSize(sz*2+gap,sz)
    for i,b in ipairs(selfExampleButtons) do
        b:SetSize(sz,sz)
        b:ClearAllPoints()
        if i==1 then b:SetPoint("LEFT",selfExampleHolder,"LEFT",0,0) else b:SetPoint("LEFT",selfExampleButtons[i-1],"RIGHT",gap,0) end
        if b.icon then b.icon:SetAllPoints() end
    end
end

local function FBUFFEnsureSelfExamples()
    if selfExampleHolder then return end
    local a=FBUFFPositionSelfAnchor()
    selfExampleHolder=CreateFrame("Frame","FBUFF_SelfBuffExamples",UIParent)
    selfExampleHolder:SetPoint("TOPLEFT",a,"CENTER",0,0)
    local exampleSpells={17,17} -- 自我BUFF範例統一使用真言術：盾
    for i=1,2 do
        local b=CreateFrame("Button",nil,selfExampleHolder)
        b:RegisterForDrag("LeftButton")
        b:SetScript("OnDragStart",function(self,button) if button=="LeftButton" and IsControlKeyDown() then FBUFFStartSelfIconDrag(self) end end)
        b:SetScript("OnDragStop",function(self) FBUFFStopSelfIconDrag(self) end)
        local t=b:CreateTexture(nil,"ARTWORK");t:SetAllPoints();t:SetTexture(C_Spell.GetSpellTexture(exampleSpells[i]) or 134400);b.icon=t
        selfExampleButtons[i]=b
    end
    FBUFFRefreshExampleSize()
    selfExampleHolder:Hide()
end

-- v1.79：Forever 的 AuraButton:IsShown() 會回傳 secret boolean，不能拿來做 Lua if。
-- 設定模式不再掃描/判斷 Blizzard AuraButton；兩顆設定用 ICON 由 FBUFF 自己管理。
local function FBUFFUpdateSelfExamples(showWhenEmpty)
    FBUFFEnsureSelfExamples()
    local show=showWhenEmpty and true or false
    selfExampleShown=show and true or false
    selfExampleHolder:SetShown(selfExampleShown)
    if selfExampleShown then
        local a=FBUFFPositionSelfAnchor();selfExampleHolder:ClearAllPoints();selfExampleHolder:SetPoint("TOPLEFT",a,"CENTER",0,0)
        FBUFFRefreshExampleSize()
    end
end

-- v1.83：隊友 BUFF 使用獨立顯示層，不再錨定 Blizzard 隊友頭像／框架。
-- party1~party4 監控核心與 AuraContainer 保留；整組可獨立拖曳、可開關，四排上下間距可調。
local FBUFF_PartyAuraTest = { rows = {} }

local function FBUFFPartyAuraDB()
    FBUFF_UI_DB=FBUFF_UI_DB or {}
    if FBUFF_UI_DB.partyAuraEnabled==nil then FBUFF_UI_DB.partyAuraEnabled=true end
    if type(FBUFF_UI_DB.partyAuraSpacing)~="number" or FBUFF_UI_DB.partyAuraSpacing<70 or FBUFF_UI_DB.partyAuraSpacing>140 then FBUFF_UI_DB.partyAuraSpacing=85 end -- 隊友1~4預設上下間距
    if type(FBUFF_UI_DB.partyAuraIconSize)~="number" or FBUFF_UI_DB.partyAuraIconSize<24 or FBUFF_UI_DB.partyAuraIconSize>72 then FBUFF_UI_DB.partyAuraIconSize=24 end -- 隊友ICON基本尺寸
    if type(FBUFF_UI_DB.partyAuraX)~="number" then FBUFF_UI_DB.partyAuraX=12 end
    if type(FBUFF_UI_DB.partyAuraY)~="number" then FBUFF_UI_DB.partyAuraY=-190 end
    return FBUFF_UI_DB
end

local FBUFFPartyAuraLayer=CreateFrame("Frame",nil,UIParent)
FBUFFPartyAuraLayer:SetSize(360,220)
FBUFFPartyAuraLayer:SetFrameStrata("HIGH")
FBUFFPartyAuraLayer:EnableMouse(false)

local FBUFFPartyAuraDrag=CreateFrame("Frame",nil,FBUFFPartyAuraLayer,"BackdropTemplate")
FBUFFPartyAuraDrag:SetSize(130,20)
FBUFFPartyAuraDrag:SetPoint("BOTTOMLEFT",FBUFFPartyAuraLayer,"TOPLEFT",0,4)
FBUFFPartyAuraDrag:SetFrameStrata("DIALOG")
FBUFFPartyAuraDrag:EnableMouse(true)
FBUFFPartyAuraDrag:RegisterForDrag("LeftButton")
FBUFFPartyAuraDrag:Hide()
local dragText=FBUFFPartyAuraDrag:CreateFontString(nil,"OVERLAY","GameFontNormal")
dragText:SetPoint("CENTER")
dragText:SetText("Ctrl＋左鍵拖曳隊友BUFF區")
FBUFFPartyAuraDrag:SetScript("OnDragStart",function()
    if InCombatLockdown and InCombatLockdown() then return end
    FBUFFPartyAuraLayer:StartMoving()
end)
FBUFFPartyAuraDrag:SetScript("OnDragStop",function()
    FBUFFPartyAuraLayer:StopMovingOrSizing()
    local cx,cy=FBUFFPartyAuraLayer:GetCenter();local ux,uy=UIParent:GetCenter()
    if cx and cy and ux and uy then
        local db=FBUFFPartyAuraDB();db.partyAuraX=cx-ux;db.partyAuraY=cy-uy
    end
end)
FBUFFPartyAuraLayer:SetMovable(true)
FBUFFPartyAuraLayer:SetClampedToScreen(true)

local function FBUFFPositionPartyAuraLayer()
    local db=FBUFFPartyAuraDB()
    FBUFFPartyAuraLayer:ClearAllPoints()
    FBUFFPartyAuraLayer:SetPoint("CENTER",UIParent,"CENTER",db.partyAuraX,db.partyAuraY)
end
FBUFFPositionPartyAuraLayer()

local function FBUFFStartPartyAuraDrag()
    FBUFFPartyAuraLayer:StartMoving()
end
local function FBUFFStopPartyAuraDrag()
    FBUFFPartyAuraLayer:StopMovingOrSizing()
    local cx,cy=FBUFFPartyAuraLayer:GetCenter();local ux,uy=UIParent:GetCenter()
    if cx and cy and ux and uy then
        local db=FBUFFPartyAuraDB();db.partyAuraX=cx-ux;db.partyAuraY=cy-uy
    end
end

local function FBUFFCreatePartyAuraRow(unitToken)
    local holder=CreateFrame("Frame",nil,FBUFFPartyAuraLayer)
    holder:SetSize(360,46)
    holder:SetFrameStrata("HIGH")
    holder:Hide()

    local ok,c=pcall(CreateFrame,"AuraContainer",nil,holder,"CustomAuraContainerTemplate")
    if not ok or not c then return nil end
    c:SetPoint("TOPLEFT",holder,"TOPLEFT",0,0)
    c:SetSize(360,44)
    c:SetFrameStrata("HIGH")
    c:Show()

    if type(c.SetFlowLayoutAnchorPoint)=="function" then pcall(c.SetFlowLayoutAnchorPoint,c,"TOPLEFT") end
    if type(c.SetFlowLayoutAxis)=="function" and Enum and Enum.FlowLayoutAxis then pcall(c.SetFlowLayoutAxis,c,Enum.FlowLayoutAxis.Horizontal) end
    if type(c.SetFlowLayoutMaximumLineSize)=="function" then pcall(c.SetFlowLayoutMaximumLineSize,c,360) end
    if type(c.SetFlowLayoutGrowthDirection)=="function" then pcall(c.SetFlowLayoutGrowthDirection,c,1,-1) end
    if type(c.SetFlowLayoutPadding)=="function" then pcall(c.SetFlowLayoutPadding,c,0,0,0,0) end

    local numberFormatter=C_StringUtil.CreateNumericRuleFormatter()
    numberFormatter:AddBreakpoint({threshold=0,step=1,rounding=Enum.NumericRuleFormatRounding.Up,format="%d"})
    numberFormatter:AddBreakpoint({threshold=60,format="%d",components={{div=60,step=1,rounding=Enum.NumericRuleFormatRounding.Up}}})
    local durationBinding=C_DurationUtil.CreateDurationTextBinding()
    durationBinding:SetUpdateInterval(0.10);durationBinding:SetExpiredText("");durationBinding:SetZeroDurationText("")

    local iconSize=math.max(24,math.min(72,tonumber(FBUFFPartyAuraDB().partyAuraIconSize) or 24));local elementHeight=iconSize
    local function InitPartyAuraButton(button)
        button:SetSize(iconSize,elementHeight)
        -- 隊友 ICON：右鍵直接拖曳整組 party1~party4。
        -- 同時保留 Drag 與 MouseDown/MouseUp 路徑，避免 AuraButton 模板只吃點擊而不觸發拖曳。
        button:RegisterForClicks("LeftButtonUp","RightButtonUp")
        button:RegisterForDrag("LeftButton")
        -- v1.99：所有效果區統一 Ctrl+左鍵拖曳。
        -- 隊友區只在 Ctrl+左鍵真正啟動後才移動／儲存，普通點擊不會移動。
        button:HookScript("OnMouseDown",function(btn,which)
            if which=="LeftButton" and IsControlKeyDown() then
                btn.FBUFFPartyCtrlDragging=true
                FBUFFStartPartyAuraDrag()
            end
        end)
        button:HookScript("OnMouseUp",function(btn,which)
            if which=="LeftButton" and btn.FBUFFPartyCtrlDragging then
                btn.FBUFFPartyCtrlDragging=nil
                FBUFFStopPartyAuraDrag()
            end
        end)
        local icon=button:CreateTexture(nil,"ARTWORK");icon:SetSize(iconSize,iconSize);icon:SetPoint("TOP",button,"TOP",0,0)
        if type(button.SetIcon)=="function" then pcall(button.SetIcon,button,icon) end
        local time=button:CreateFontString(nil,"OVERLAY","NumberFontNormal")
        time:ClearAllPoints();time:SetPoint("CENTER",icon,"CENTER",0,0);time:SetJustifyH("CENTER");time:SetJustifyV("MIDDLE");time:SetTextColor(1,1,1,1)
        time:SetScale(iconSize/24)
        if type(button.SetDurationText)=="function" then pcall(button.SetDurationText,button,time,{binding=durationBinding,textFormatter=numberFormatter}) end
    end

    local partyIgnoredIDs={}
    if trackers and trackers.friendbuffs and trackers.friendbuffs.excluded then
        for id in pairs(trackers.friendbuffs.excluded()) do local sid=tonumber(id);if sid then partyIgnoredIDs[sid]=true end end
    end
    local ignoredNames=IgnoreNameSet();local learned=SelfLearnDB()
    for id,info in pairs(learned) do if type(info)=="table" and info.name and ignoredNames[info.name] then local sid=tonumber(id);if sid then partyIgnoredIDs[sid]=true end end end
    if not InCombatLockdown() then
        for pi=1,4 do local pu="party"..pi;if UnitExists(pu) then
            for ai=1,255 do local okAura,a=pcall(C_UnitAuras.GetBuffDataByIndex,pu,ai);if not okAura or not a then break end
                local aid,aname=a.spellId,a.name
                if aid and aname and not IsSecretValue(aid) and not IsSecretValue(aname) and ignoredNames[aname] then partyIgnoredIDs[aid]=true end
            end
        end end
    end

    local options={maxFrameCount=12,candidateFilters={excludeSpellIDs=partyIgnoredIDs},initializeFrame=InitPartyAuraButton,layout={elementWidth=iconSize,elementHeight=elementHeight,elementSpacing=3,lineSpacing=3}}
    if type(c.AddAuraGroup)~="function" then holder:Hide();return nil end
    -- v1.93：隊友區只保留本人來源且本角色可施放的友方效果。
    -- Forever 實測中單用 HELPFUL|PLAYER 仍會混入隊友自身 BUFF，因此加 RAID 作引擎層二次限制。
    local okGroup=pcall(c.AddAuraGroup,c,"fbuff_party_"..unitToken,"HELPFUL|PLAYER|RAID",options);if not okGroup then holder:Hide();return nil end
    pcall(c.SetUnit,c,unitToken)
    return {holder=holder,container=c,unit=unitToken}
end

local function FBUFFAnchorPartyAuraRows()
    if InCombatLockdown and InCombatLockdown() then return end
    local db=FBUFFPartyAuraDB();FBUFFPositionPartyAuraLayer()
    for i=1,4 do
        local unitToken="party"..i;local row=FBUFF_PartyAuraTest.rows[unitToken]
        if not row then row=FBUFFCreatePartyAuraRow(unitToken);FBUFF_PartyAuraTest.rows[unitToken]=row end
        if row then
            row.holder:ClearAllPoints();row.holder:SetPoint("TOPLEFT",FBUFFPartyAuraLayer,"TOPLEFT",0,-((i-1)*db.partyAuraSpacing))
            if db.partyAuraEnabled and UnitExists(unitToken) then row.holder:Show();pcall(row.container.SetUnit,row.container,unitToken) else row.holder:Hide() end
        end
    end
end

local function FBUFFSetPartyAuraEnabled(enabled)
    local db=FBUFFPartyAuraDB();db.partyAuraEnabled=enabled and true or false
    FBUFFAnchorPartyAuraRows()
end
local FBUFFUpdatePartyAuraExamples
local function FBUFFSetPartyAuraSpacing(v)
    local db=FBUFFPartyAuraDB();db.partyAuraSpacing=math.floor((tonumber(v) or 85)+0.5)
    FBUFFAnchorPartyAuraRows()
    if FBUFF_Settings and FBUFF_Settings:IsShown() then FBUFFUpdatePartyAuraExamples(true) end
end

-- 設定頁用：四排隊友虛擬 ICON，直接預覽上下間距；設定完成後全部隱藏。
local FBUFFPartyAuraExamples={}
local function FBUFFEnsurePartyAuraExamples()
    if #FBUFFPartyAuraExamples>0 then return end
    local exampleSpells={17,139,21562,1459}
    for i=1,4 do
        local row=CreateFrame("Frame",nil,FBUFFPartyAuraLayer)
        row:SetSize(90,40);row:SetFrameStrata("DIALOG");row:EnableMouse(true);row:RegisterForDrag("LeftButton")
        row:SetScript("OnDragStart",function(_,which) if which=="LeftButton" and IsControlKeyDown() then FBUFFStartPartyAuraDrag() end end)
        row:SetScript("OnDragStop",function() FBUFFStopPartyAuraDrag() end)
        local b=CreateFrame("Button",nil,row);b:SetPoint("TOPLEFT",0,0);b:EnableMouse(true);b:RegisterForDrag("LeftButton")
        b:SetScript("OnDragStart",function(_,which) if which=="LeftButton" and IsControlKeyDown() then FBUFFStartPartyAuraDrag() end end)
        b:SetScript("OnDragStop",function() FBUFFStopPartyAuraDrag() end)
        local icon=b:CreateTexture(nil,"ARTWORK");icon:SetPoint("TOP",b,"TOP",0,0);icon:SetTexture(C_Spell.GetSpellTexture(exampleSpells[i]) or 134400)
        local time=b:CreateFontString(nil,"OVERLAY","NumberFontNormal");time:SetPoint("CENTER",icon,"CENTER",0,0);time:SetJustifyH("CENTER");time:SetJustifyV("MIDDLE");time:SetText(tostring(10+i*3));time:SetTextColor(1,1,1,1)
        local label=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall");label:SetPoint("LEFT",b,"RIGHT",5,0);label:SetText("隊友"..i);label:SetTextColor(1,.82,0,1)
        row.FBUFFButton=b;row.FBUFFIcon=icon;row.FBUFFTime=time;row.FBUFFLabel=label
        row:Hide();FBUFFPartyAuraExamples[i]=row
    end
end
FBUFFUpdatePartyAuraExamples=function(show)
    FBUFFEnsurePartyAuraExamples()
    local db=FBUFFPartyAuraDB()
    local iconSize=math.max(24,math.min(72,tonumber(db.partyAuraIconSize) or 24))
    for i,row in ipairs(FBUFFPartyAuraExamples) do
        row:SetSize(iconSize+70,iconSize)
        row.FBUFFButton:SetSize(iconSize,iconSize);row.FBUFFIcon:SetSize(iconSize,iconSize);row.FBUFFTime:SetScale(iconSize/24)
        row:ClearAllPoints();row:SetPoint("TOPLEFT",FBUFFPartyAuraLayer,"TOPLEFT",0,-((i-1)*db.partyAuraSpacing))
        row:SetShown(show and true or false)
    end
end

-- 忽略／取消忽略後重建隊友 AuraContainer，立即套用同一份排除清單。
local function FBUFFRebuildPartyAuraRows()
    if InCombatLockdown and InCombatLockdown() then return end
    for unitToken,row in pairs(FBUFF_PartyAuraTest.rows) do
        if row then if row.holder then row.holder:Hide() end;if row.container then pcall(row.container.Hide,row.container);pcall(row.container.SetParent,row.container,nil) end end
        FBUFF_PartyAuraTest.rows[unitToken]=nil
    end
    C_Timer.After(0,FBUFFAnchorPartyAuraRows)
end

local FBUFFPartyAuraEvents=CreateFrame("Frame")
FBUFFPartyAuraEvents:RegisterEvent("PLAYER_ENTERING_WORLD");FBUFFPartyAuraEvents:RegisterEvent("GROUP_ROSTER_UPDATE");FBUFFPartyAuraEvents:RegisterEvent("PLAYER_REGEN_ENABLED")
FBUFFPartyAuraEvents:SetScript("OnEvent",function(_,event) if event=="PLAYER_ENTERING_WORLD" then C_Timer.After(1.2,FBUFFAnchorPartyAuraRows) else C_Timer.After(0,FBUFFAnchorPartyAuraRows) end end)

-- v1.78：沿用 v1.66 實測成功 AuraContainer；改由一般 Anchor 保存位置，
-- 不再讀取 AuraContainer 的 GetPoint/GetCenter secret 值。自身 ICON 可左鍵拖曳。
FBUFFAuraContainerStart168=function()
    FBUFFAutoIgnoreExternalPlayerBuffs()
    if FBUFF_AuraContainerProbeFrame then
        pcall(FBUFF_AuraContainerProbeFrame.Hide,FBUFF_AuraContainerProbeFrame)
        pcall(FBUFF_AuraContainerProbeFrame.SetParent,FBUFF_AuraContainerProbeFrame,nil)
        FBUFF_AuraContainerProbeFrame=nil
    end

    local anchor=FBUFFPositionSelfAnchor()
    local ok,container=pcall(CreateFrame,"AuraContainer",nil,anchor,"CustomAuraContainerTemplate")
    if not ok or not container then print("FBUFF AuraContainer探針：CreateFrame失敗") return end
    _G.FBUFF_AuraContainer168=container

    local selfScale=FBUFF_DB.selfIconScale
    local iconSize=28*selfScale
    local elementGap=6*selfScale
    local elementHeight=iconSize
    container:SetSize(math.max(360,12*(iconSize+elementGap)),elementHeight+4)
    container:SetPoint("TOPLEFT",anchor,"CENTER",0,0)
    container:EnableMouse(true)
    container:RegisterForDrag("LeftButton")
    container:SetScript("OnDragStart",function(self,button) if button=="LeftButton" and IsControlKeyDown() then FBUFFStartSelfIconDrag(self) end end)
    container:SetScript("OnDragStop",function(self) FBUFFStopSelfIconDrag(self) end)
    container:Show()

    if type(container.SetFlowLayoutAnchorPoint)=="function" then pcall(container.SetFlowLayoutAnchorPoint,container,"TOPLEFT") end
    if type(container.SetFlowLayoutAxis)=="function" and Enum and Enum.FlowLayoutAxis then pcall(container.SetFlowLayoutAxis,container,Enum.FlowLayoutAxis.Horizontal) end
    if type(container.SetFlowLayoutMaximumLineSize)=="function" then pcall(container.SetFlowLayoutMaximumLineSize,container,360) end
    if type(container.SetFlowLayoutGrowthDirection)=="function" then pcall(container.SetFlowLayoutGrowthDirection,container,1,-1) end
    if type(container.SetFlowLayoutPadding)=="function" then pcall(container.SetFlowLayoutPadding,container,0,0,0,0) end

    local durationNumberFormatter=C_StringUtil.CreateNumericRuleFormatter()
    durationNumberFormatter:AddBreakpoint({threshold=0,step=1,rounding=Enum.NumericRuleFormatRounding.Up,format="%d"})
    durationNumberFormatter:AddBreakpoint({threshold=60,format="%d",components={{div=60,step=1,rounding=Enum.NumericRuleFormatRounding.Up}}})
    local selfDurationBinding=C_DurationUtil.CreateDurationTextBinding()
    selfDurationBinding:SetUpdateInterval(0.10);selfDurationBinding:SetExpiredText("");selfDurationBinding:SetZeroDurationText("")

    local function InitButton(button)
        button:SetSize(iconSize,elementHeight)
        button:RegisterForDrag("LeftButton")
        button:SetScript("OnDragStart",function(self,which) if which=="LeftButton" and IsControlKeyDown() then FBUFFStartSelfIconDrag(self) end end)
        button:SetScript("OnDragStop",function(self) FBUFFStopSelfIconDrag(self) end)
        local icon=button:CreateTexture(nil,"ARTWORK");icon:SetSize(iconSize,iconSize);icon:SetPoint("TOP",button,"TOP",0,0)
        if type(button.SetIcon)=="function" then pcall(button.SetIcon,button,icon) end
        local time=button:CreateFontString(nil,"OVERLAY","NumberFontNormal")
        time:ClearAllPoints();time:SetPoint("CENTER",icon,"CENTER",0,0);time:SetJustifyH("CENTER");time:SetJustifyV("MIDDLE");time:SetTextColor(1,1,1,1)
        time:SetScale(iconSize/24)
        if type(button.SetDurationText)=="function" then pcall(button.SetDurationText,button,time,{binding=selfDurationBinding,textFormatter=durationNumberFormatter}) end
    end

    local selfIgnoredIDs={};local learned=SelfLearnDB();local ignoredNames=IgnoreNameSet()
    for id,info in pairs(learned) do if type(info)=="table" and info.name and ignoredNames[info.name] then local sid=tonumber(id);if sid then selfIgnoredIDs[sid]=true end end end
    -- 已忽略名稱要同步到「目前玩家身上真正存在的 Aura spellID」。
    -- 同一個 BUFF 在 Forever 可能使用不同 rank/variant ID；只靠學習資料的舊 ID，
    -- AuraContainer 仍可能把實際 ICON 顯示出來。這裡只在非戰鬥重建時讀公開玩家 BUFF。
    if not InCombatLockdown() then
        for i=1,255 do
            local ok,a=pcall(C_UnitAuras.GetBuffDataByIndex,"player",i)
            if not ok or not a then break end
            local aid,aname=a.spellId,a.name
            if aid and aname and not IsSecretValue(aid) and not IsSecretValue(aname) and ignoredNames[aname] then
                selfIgnoredIDs[aid]=true
            end
        end
    end
    -- 同步既有 tracker 的排除 ID，確保設定頁「已忽略效果」與自身 AuraContainer 使用同一份結果。
    if trackers and trackers.buffs and trackers.buffs.excluded then
        for id in pairs(trackers.buffs.excluded()) do local sid=tonumber(id);if sid then selfIgnoredIDs[sid]=true end end
    end
    local options={maxFrameCount=12,candidateFilters={excludeSpellIDs=selfIgnoredIDs},initializeFrame=InitButton,layout={elementWidth=iconSize,elementHeight=elementHeight,elementSpacing=elementGap,lineSpacing=elementGap}}
    if type(container.AddAuraGroup)~="function" then print("FBUFF AuraContainer探針：AddAuraGroup不存在");container:Hide();return end
    local okGroup,errGroup=pcall(container.AddAuraGroup,container,"fbuff_test","HELPFUL|PLAYER",options)
    if not okGroup then print("FBUFF AuraContainer探針：AddAuraGroup失敗 "..tostring(errGroup));container:Hide();return end
    local okUnit,errUnit=pcall(container.SetUnit,container,"player")
    if not okUnit then print("FBUFF AuraContainer探針：SetUnit失敗 "..tostring(errUnit));container:Hide();return end
    if FBUFF_DB.selfAuraEnabled==false then container:Hide() else container:Show() end
    FBUFF_AuraContainerProbeFrame=container
end

local FBUFFAuraAuto168=CreateFrame("Frame")
FBUFFAuraAuto168:RegisterEvent("PLAYER_ENTERING_WORLD")
FBUFFAuraAuto168:SetScript("OnEvent",function() C_Timer.After(1.0,FBUFFAuraContainerStart168) end)

local FBUFFExternalBuffAutoIgnoreEvents=CreateFrame("Frame")
FBUFFExternalBuffAutoIgnoreEvents:RegisterEvent("PLAYER_REGEN_ENABLED")
FBUFFExternalBuffAutoIgnoreEvents:RegisterEvent("PLAYER_ENTERING_WORLD")
FBUFFExternalBuffAutoIgnoreEvents:SetScript("OnEvent",function(_,event)
    C_Timer.After(event=="PLAYER_ENTERING_WORLD" and 1.1 or 0,function()
        if not InCombatLockdown() and FBUFFAutoIgnoreExternalPlayerBuffs() then FBUFFAuraContainerStart168() end
    end)
end)

local FBUFFStartDotAuraContainer

local function FBUFFSetSelfIconScale(v)
    FBUFFEnsureSelfIconDB();v=math.max(1,math.min(3,tonumber(v) or 1));FBUFF_DB.selfIconScale=v
    if InCombatLockdown and InCombatLockdown() then return end
    FBUFFRefreshExampleSize()
    FBUFFAuraContainerStart168()
    C_Timer.After(0,function() if FBUFF_Settings and FBUFF_Settings:IsShown() then FBUFFUpdateSelfExamples(true) end end)
end

local function FBUFFSetSelfAuraEnabled(enabled)
    FBUFFEnsureSelfIconDB();FBUFF_DB.selfAuraEnabled=enabled and true or false
    if InCombatLockdown and InCombatLockdown() then return end
    FBUFFAuraContainerStart168()
end

local function FBUFFRefreshSelfIconAttach()
    FBUFFPositionSelfAnchor()
    local c=_G.FBUFF_AuraContainer168
    if c then c:SetAlpha(1);c:EnableMouse(true) end
end

-- v1.84 TEST：敵方 DOT 改用目標身上實際存在、且由玩家施放的 AuraContainer ICON。
-- 顯示位置與尺寸皆與自我 BUFF 獨立；右鍵拖曳只移動目標效果區。
local FBUFFDotAuraContainer
local FBUFFDotIconAnchor
local FBUFFDotDragController=CreateFrame("Frame","FBUFF_DotIconDragController",UIParent)
local FBUFFDotDragState=nil
FBUFFDotDragController:Hide()

local function FBUFFEnsureDotIconDB()
    FBUFF_DB=FBUFF_DB or {}
    if type(FBUFF_DB.dotIconPos)~="table" then FBUFF_DB.dotIconPos={x=170,y=260} end
    if type(FBUFF_DB.dotIconPos.x)~="number" then FBUFF_DB.dotIconPos.x=170 end
    if type(FBUFF_DB.dotIconPos.y)~="number" then FBUFF_DB.dotIconPos.y=260 end
    if FBUFF_DB.targetAuraEnabled==nil then FBUFF_DB.targetAuraEnabled=true end
    if type(FBUFF_DB.targetIconScale)~="number" then FBUFF_DB.targetIconScale=tonumber(FBUFF_DB.selfIconScale) or 1 end
    FBUFF_DB.targetIconScale=math.max(1,math.min(3,FBUFF_DB.targetIconScale))
end

local function FBUFFSetTargetIconScale(v)
    FBUFFEnsureDotIconDB();v=math.max(1,math.min(3,tonumber(v) or 1));FBUFF_DB.targetIconScale=v
    if InCombatLockdown and InCombatLockdown() then return end
    if FBUFFStartDotAuraContainer then FBUFFStartDotAuraContainer() end
end

local function FBUFFSetTargetAuraEnabled(enabled)
    FBUFFEnsureDotIconDB();FBUFF_DB.targetAuraEnabled=enabled and true or false
    if InCombatLockdown and InCombatLockdown() then return end
    if FBUFFStartDotAuraContainer then FBUFFStartDotAuraContainer() end
end

local function FBUFFPositionDotAnchor()
    FBUFFEnsureDotIconDB()
    if not FBUFFDotIconAnchor then
        FBUFFDotIconAnchor=CreateFrame("Frame","FBUFF_DotIconAnchor",UIParent)
        FBUFFDotIconAnchor:SetSize(1,1);FBUFFDotIconAnchor:SetClampedToScreen(true)
    end
    FBUFFDotIconAnchor:ClearAllPoints()
    FBUFFDotIconAnchor:SetPoint("CENTER",UIParent,"CENTER",FBUFF_DB.dotIconPos.x,FBUFF_DB.dotIconPos.y)
    FBUFFDotIconAnchor:Show()
    return FBUFFDotIconAnchor
end

FBUFFDotDragController:SetScript("OnUpdate",function()
    local drag=FBUFFDotDragState;if not drag then return end
    local cx,cy=GetCursorPosition();local sc=UIParent:GetEffectiveScale();cx,cy=cx/sc,cy/sc
    FBUFF_DB.dotIconPos.x=drag.baseX+(cx-drag.x);FBUFF_DB.dotIconPos.y=drag.baseY+(cy-drag.y)
    FBUFFPositionDotAnchor()
    if FBUFFTargetExampleHolder and FBUFFTargetExampleHolder:IsShown() then FBUFFRefreshTargetExample() end
end)

local function FBUFFStartDotIconDrag()
    FBUFFEnsureDotIconDB();local x,y=GetCursorPosition();local sc=UIParent:GetEffectiveScale()
    FBUFFDotDragState={x=x/sc,y=y/sc,baseX=FBUFF_DB.dotIconPos.x,baseY=FBUFF_DB.dotIconPos.y}
    FBUFFDotDragController:Show()
end
local function FBUFFStopDotIconDrag() FBUFFDotDragState=nil;FBUFFDotDragController:Hide() end

FBUFFStartDotAuraContainer=function()
    if FBUFFDotAuraContainer then
        pcall(FBUFFDotAuraContainer.Hide,FBUFFDotAuraContainer)
        pcall(FBUFFDotAuraContainer.SetParent,FBUFFDotAuraContainer,nil)
        FBUFFDotAuraContainer=nil
    end
    FBUFFEnsureSelfIconDB();local anchor=FBUFFPositionDotAnchor()
    local ok,c=pcall(CreateFrame,"AuraContainer",nil,anchor,"CustomAuraContainerTemplate")
    if not ok or not c then return end
    FBUFFDotAuraContainer=c
    local iconSize=28*FBUFF_DB.targetIconScale;local gap=6*FBUFF_DB.targetIconScale
    c:SetSize(math.max(360,12*(iconSize+gap)),iconSize+4);c:SetPoint("TOPLEFT",anchor,"CENTER",0,0)
    c:EnableMouse(true);c:RegisterForDrag("LeftButton")
    c:SetScript("OnDragStart",function(_,button) if button=="LeftButton" and IsControlKeyDown() then FBUFFStartDotIconDrag() end end)
    c:SetScript("OnDragStop",function() FBUFFStopDotIconDrag() end);c:Show()
    if type(c.SetFlowLayoutAnchorPoint)=="function" then pcall(c.SetFlowLayoutAnchorPoint,c,"TOPLEFT") end
    if type(c.SetFlowLayoutAxis)=="function" and Enum and Enum.FlowLayoutAxis then pcall(c.SetFlowLayoutAxis,c,Enum.FlowLayoutAxis.Horizontal) end
    if type(c.SetFlowLayoutMaximumLineSize)=="function" then pcall(c.SetFlowLayoutMaximumLineSize,c,360) end
    if type(c.SetFlowLayoutGrowthDirection)=="function" then pcall(c.SetFlowLayoutGrowthDirection,c,1,-1) end
    if type(c.SetFlowLayoutPadding)=="function" then pcall(c.SetFlowLayoutPadding,c,0,0,0,0) end

    local fmt=C_StringUtil.CreateNumericRuleFormatter()
    fmt:AddBreakpoint({threshold=0,step=1,rounding=Enum.NumericRuleFormatRounding.Up,format="%d"})
    fmt:AddBreakpoint({threshold=60,format="%d",components={{div=60,step=1,rounding=Enum.NumericRuleFormatRounding.Up}}})
    local bind=C_DurationUtil.CreateDurationTextBinding();bind:SetUpdateInterval(0.10);bind:SetExpiredText("");bind:SetZeroDurationText("")
    local function InitButton(button)
        button:SetSize(iconSize,iconSize);button:RegisterForDrag("LeftButton")
        button:SetScript("OnDragStart",function(_,which) if which=="LeftButton" and IsControlKeyDown() then FBUFFStartDotIconDrag() end end)
        button:SetScript("OnDragStop",function() FBUFFStopDotIconDrag() end)
        local icon=button:CreateTexture(nil,"ARTWORK");icon:SetSize(iconSize,iconSize);icon:SetPoint("CENTER",button,"CENTER",0,0)
        if type(button.SetIcon)=="function" then pcall(button.SetIcon,button,icon) end
        local time=button:CreateFontString(nil,"OVERLAY","NumberFontNormal")
        time:SetPoint("CENTER",icon,"CENTER",0,0);time:SetJustifyH("CENTER");time:SetJustifyV("MIDDLE");time:SetTextColor(1,1,1,1);time:SetScale(iconSize/24)
        if type(button.SetDurationText)=="function" then pcall(button.SetDurationText,button,time,{binding=bind,textFormatter=fmt}) end
    end
    local excluded={}
    if trackers and trackers.debuffs and trackers.debuffs.excluded then for id in pairs(trackers.debuffs.excluded()) do excluded[tonumber(id) or id]=true end end
    local options={maxFrameCount=12,candidateFilters={excludeSpellIDs=excluded},initializeFrame=InitButton,layout={elementWidth=iconSize,elementHeight=iconSize,elementSpacing=gap,lineSpacing=gap}}
    -- 目標效果區：敵對目標顯示自己施放的 DOT；友善目標顯示自己施放的 BUFF。
    -- 兩組都交由 AuraContainer 的 PLAYER 過濾，不讀取別人的效果。
    local okDot=pcall(c.AddAuraGroup,c,"fbuff_player_dots","HARMFUL|PLAYER",options)
    local okBuff=pcall(c.AddAuraGroup,c,"fbuff_player_target_buffs","HELPFUL|PLAYER",options)
    if not okDot and not okBuff then c:Hide();return end
    local okUnit=pcall(c.SetUnit,c,"target");if not okUnit then c:Hide();return end
    if FBUFF_DB.targetAuraEnabled==false then c:Hide() else c:Show() end
end

local FBUFFDotAuraEvents=CreateFrame("Frame")
FBUFFDotAuraEvents:RegisterEvent("PLAYER_ENTERING_WORLD");FBUFFDotAuraEvents:RegisterEvent("PLAYER_TARGET_CHANGED");FBUFFDotAuraEvents:RegisterEvent("PLAYER_REGEN_ENABLED")
FBUFFDotAuraEvents:SetScript("OnEvent",function(_,event)
    if event=="PLAYER_ENTERING_WORLD" then C_Timer.After(1.1,FBUFFStartDotAuraContainer)
    else C_Timer.After(0,FBUFFStartDotAuraContainer) end
end)

-- WoW Forever enemy DOT tracking.  Based on the safe strategy used by the
-- Forever-only DoesItDie addon: successful player casts + spell description
-- duration + target GUID.  No combat-log registration and no combat aura reads.
local PAIN_DURATION = { [589]=18,[594]=18,[970]=18,[992]=18,[2767]=18,[10892]=18,[10893]=18,[10894]=18 }
local function SafePlain(v) return v~=nil and not IsSecretValue(v) end
local function DotDurationFromDescription(id,desc,name)
    if PAIN_DURATION[id] then return PAIN_DURATION[id] end
    if type(desc)~="string" or IsSecretValue(desc) then return nil end
    -- English clients.
    local d=desc:match("over%s+(%d+%.?%d*)%s+sec") or desc:match("[Ll]asts%s+(%d+%.?%d*)%s+sec")
    -- Traditional / Simplified Chinese Forever clients.  Periodic damage tooltips
    -- commonly describe either 'within N seconds' or 'lasts N seconds'.
    d=d or desc:match("在%s*(%d+%.?%d*)%s*秒[內内]") or desc:match("持續%s*(%d+%.?%d*)%s*秒") or desc:match("持续%s*(%d+%.?%d*)%s*秒")
    d=tonumber(d)
    if not d or d<=0 or d>300 then return nil end
    -- Whether the spell belongs in the hostile-effect tracker is decided with
    -- C_Spell.IsSpellHarmful() in TrackEnemyDotCast().  Do not infer hostility
    -- from words such as "damage": helpful spells like Power Word: Shield also
    -- mention absorbed damage in their tooltip and were therefore false positives.
    return d
end
local instanceTargetSerial=0
local instanceTargetToken=nil
local instanceTargetName=nil
local function FBUFFInstanceTargetKey()
    -- UnitGUID may be secret in Forever instances.  Track target changes locally instead.
    -- "target" existence/death booleans are used only through protected pcall.
    if not instanceTargetToken then
        instanceTargetSerial=instanceTargetSerial+1
        instanceTargetToken="FBUFF_INSTANCE_"..instanceTargetSerial
    end
    return instanceTargetToken
end
local function FBUFFResetInstanceTarget()
    instanceTargetToken=nil
    instanceTargetName=nil
end
local function FBUFFCaptureTargetName()
    local ok,n=pcall(UnitName,"target")
    if ok and SafePlain(n) and type(n)=="string" and n~="" then instanceTargetName=n end
end

local FRIEND_DURATION = {}
local function FriendlyDurationFromDescription(id,desc)
    if FRIEND_DURATION[id] then return FRIEND_DURATION[id] end
    if type(desc)~="string" or IsSecretValue(desc) then return nil end
    local d=desc:match("[Ll]asts%s+(%d+%.?%d*)%s+sec")
        or desc:match("持續%s*(%d+%.?%d*)%s*秒")
        or desc:match("持续%s*(%d+%.?%d*)%s*秒")
        or desc:match("在%s*(%d+%.?%d*)%s*秒[內内]")
    d=tonumber(d)
    if not d or d<=0 or d>300 then return nil end
    return d
end

local pendingFriendlyCastTargets={}
local function RememberFriendlyCastTarget(castGUID,targetName,spellID)
    if not SafePlain(castGUID) or type(castGUID)~="string" then return end
    if not SafePlain(spellID) or type(spellID)~="number" then return end
    local okHelpful,helpful=pcall(C_Spell.IsSpellHelpful,spellID)
    if not okHelpful or not SafePlain(helpful) or not helpful then return end
    if not SafePlain(targetName) or type(targetName)~="string" or targetName=="" then
        pendingFriendlyCastTargets[castGUID]=false
        return
    end
    pendingFriendlyCastTargets[castGUID]=targetName
end

local function TrackFriendlyBuffCast(spellID,castGUID)
    if not SafePlain(spellID) or type(spellID)~="number" then return false end
    local okHelpful,helpful=pcall(C_Spell.IsSpellHelpful,spellID)
    if not okHelpful or not SafePlain(helpful) or not helpful then return false end
    -- A helpful spell is tracked for another unit only when WoW reported that
    -- unit as the actual recipient of this cast.  Merely having an NPC/player/pet
    -- selected while eating or self-buffing must never create a target timer.
    local sentTarget = castGUID and pendingFriendlyCastTargets[castGUID]
    if castGUID then pendingFriendlyCastTargets[castGUID]=nil end
    if not sentTarget or type(sentTarget)~="string" then return false end
    local okExists,exists=pcall(UnitExists,"target"); if not okExists or not exists then return false end
    local okFriend,isFriend=pcall(UnitIsFriend,"player","target")
    if not okFriend or not SafePlain(isFriend) or not isFriend then return false end
    local okSelf,isSelf=pcall(UnitIsUnit,"target","player")
    if okSelf and SafePlain(isSelf) and isSelf then return false end
    local okTargetNameNow,targetNameNow=pcall(UnitName,"target")
    if not okTargetNameNow or not SafePlain(targetNameNow) or type(targetNameNow)~="string" or targetNameNow=="" then return false end
    if sentTarget~=targetNameNow then return false end

    local okGuid,guid=pcall(UnitGUID,"target")
    if not okGuid or not SafePlain(guid) or type(guid)~="string" then return false end
    local okTargetName,targetName=pcall(UnitName,"target")
    if not okTargetName or not SafePlain(targetName) or type(targetName)~="string" or targetName=="" then targetName=nil end
    local okName,name=pcall(C_Spell.GetSpellName,spellID)
    if not okName or not SafePlain(name) or type(name)~="string" then return false end
    if MultiIgnored("friendbuffs",spellID,name) then return true end
    local okDesc,desc=pcall(C_Spell.GetSpellDescription,spellID); if not okDesc then desc=nil end
    local duration=FriendlyDurationFromDescription(spellID,desc)
    if not duration then return false end
    local now=GetTime(); local key=guid..":"..tostring(spellID)
    multi.friendbuffs.cache[key]={key=key,guid=guid,id=spellID,name=name,targetName=targetName,
        icon=C_Spell.GetSpellTexture(spellID),expiration=now+duration,duration=duration}
    return true
end

local function TrackEnemyDotCast(spellID)
    if not SafePlain(spellID) or type(spellID)~="number" then return end
    -- Forever 1.60.1 exposes this predicate as an allowed spell API.  Only spells
    -- that can be cast on hostile targets belong in 敵方身上DOT.  This keeps
    -- hostile debuffs such as Shadow Word: Pain / Psychic Scream while excluding
    -- helpful spells such as Power Word: Shield, even if an enemy is still targeted
    -- when a self-cast macro succeeds.
    local okHarmful,isHarmful=pcall(C_Spell.IsSpellHarmful,spellID)
    if not okHarmful or not SafePlain(isHarmful) or not isHarmful then return end
    local okExists,exists=pcall(UnitExists,"target"); if not okExists or not exists then return end
    local okAttack,attack=pcall(UnitCanAttack,"player","target"); if not okAttack or not attack or IsSecretValue(attack) then return end
    local okGuid,guid=pcall(UnitGUID,"target")
    if not okGuid or not SafePlain(guid) or type(guid)~="string" then
        -- Forever instances can protect enemy GUIDs as secret values.
        -- Never stringify/read that value.  Use a local cast key so the timer
        -- can still be shown for the spell the player just successfully cast.
        guid=FBUFFInstanceTargetKey()
    end
    local okTargetName,targetName=pcall(UnitName,"target")
    if not okTargetName or not SafePlain(targetName) or type(targetName)~="string" or targetName=="" then
        targetName=instanceTargetName
    else
        instanceTargetName=targetName
    end
    local okName,name=pcall(C_Spell.GetSpellName,spellID); if not okName or not SafePlain(name) or type(name)~="string" then return end
    local okDesc,desc=pcall(C_Spell.GetSpellDescription,spellID); if not okDesc then desc=nil end
    local duration=DotDurationFromDescription(spellID,desc,name); if not duration then return end
    -- Remember every confirmed DOT spell outside the live aura system.  Forever
    -- blocks opening/updating the settings UI in combat, so this persistent list
    -- lets the player ignore the DOT after combat has ended.
    if type(FBUFF_UI_DB)~="table" then FBUFF_UI_DB={} end
    if type(FBUFF_UI_DB.seenDots)~="table" then FBUFF_UI_DB.seenDots={} end
    FBUFF_UI_DB.seenDots[spellID]={name=name,icon=C_Spell.GetSpellTexture(spellID)}
    if MultiIgnored("debuffs",spellID,name) then return end
    local now=GetTime(); local key=guid..":"..tostring(spellID)
    multi.debuffs.cache[key]={key=key,guid=guid,id=spellID,name=name,targetName=targetName,icon=C_Spell.GetSpellTexture(spellID),expiration=now+duration,duration=duration}
end

-- Keep the name-based ignore list synchronized with the *actual* aura spell ID.
-- This matters for effects such as Weak Soul, where the visible aura can use an
-- ID/rank variant different from the ID returned by a generic spell-name lookup.
local function SyncIgnoredAuraIDs()
    if FBUFFPlayerInCombat() then return end
    local ignored=IgnoreNameSet()
    local function scan(unit,harmful)
        if not UnitExists(unit) then return end
        for i=1,255 do
            local ok,a=pcall(function()
                if harmful then return C_UnitAuras.GetDebuffDataByIndex(unit,i) end
                return C_UnitAuras.GetBuffDataByIndex(unit,i)
            end)
            if not ok or not a then break end
            local id,name=a.spellId,a.name
            if id and name and not IsSecretValue(id) and not IsSecretValue(name) and ignored[name] then
                for _,tr in pairs(trackers) do
                    if not tr.excluded()[id] then tr.hide(id) end
                end
                for _,m in pairs(multi) do
                    for key,e in pairs(m.cache) do
                        if e.id==id or e.name==name then m.cache[key]=nil end
                    end
                end
            end
        end
    end
    scan("player",false)
    scan("player",true)
    scan("target",false)
    scan("target",true)
end

-- Remove all FBUFF-owned hostile-effect timers for a unit as soon as WoW tells
-- us that unit has died.  This uses normal unit health/death state only; it does
-- not read Secret Aura data and does not register COMBAT_LOG_EVENT_UNFILTERED.
local function ClearEnemyDotsByGUID(deadGUID)
    if not SafePlain(deadGUID) or type(deadGUID)~="string" or deadGUID=="" then return false end
    local changed=false
    for key,e in pairs(multi.debuffs.cache) do
        if e.guid==deadGUID then
            multi.debuffs.cache[key]=nil
            changed=true
        end
    end
    if changed then MultiRender("debuffs") end
    if deadGUID==instanceTargetToken then FBUFFResetInstanceTarget() end
    return changed
end

local function ClearCurrentTargetDotsOnDeath()
    local okDead,dead=pcall(UnitIsDeadOrGhost,"target")
    if not okDead or not SafePlain(dead) or not dead then return false end
    local okGuid,guid=pcall(UnitGUID,"target")
    if okGuid and SafePlain(guid) and type(guid)=="string" then
        return ClearEnemyDotsByGUID(guid)
    end
    -- Restricted-instance fallback: the target died but its GUID is secret.
    -- Clear the synthetic timer group tied to the currently tracked target.
    if instanceTargetToken then
        local token=instanceTargetToken
        local changed=false
        for key,e in pairs(multi.debuffs.cache) do
            if e.guid==token then multi.debuffs.cache[key]=nil; changed=true end
        end
        if changed then MultiRender("debuffs") end
        FBUFFResetInstanceTarget()
        return changed
    end
    return false
end

local function ClearDeadUnitDots(unit)
    if type(unit)~="string" or not UnitExists(unit) then return end
    local okDead,isDead=pcall(UnitIsDeadOrGhost,unit)
    if not okDead or not SafePlain(isDead) or not isDead then return end
    local okGuid,guid=pcall(UnitGUID,unit)
    if not okGuid or not SafePlain(guid) or type(guid)~="string" then return end
    ClearEnemyDotsByGUID(guid)
end

local multiFrame=CreateFrame("Frame")
multiFrame:RegisterEvent("PLAYER_TARGET_CHANGED"); multiFrame:RegisterEvent("UNIT_AURA"); multiFrame:RegisterEvent("PLAYER_REGEN_ENABLED"); multiFrame:RegisterEvent("UNIT_HEALTH")
pcall(function() multiFrame:RegisterEvent("UNIT_HEALTH_FREQUENT") end)
pcall(function() multiFrame:RegisterEvent("UNIT_FLAGS") end)
pcall(function() multiFrame:RegisterEvent("UNIT_DIED") end)
pcall(function() multiFrame:RegisterEvent("PLAYER_TARGET_DIED") end)
pcall(function() multiFrame:RegisterEvent("PARTY_KILL") end)
multiFrame:RegisterUnitEvent("UNIT_SPELLCAST_SUCCEEDED","player")
multiFrame:RegisterUnitEvent("UNIT_SPELLCAST_SENT","player")
multiFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
multiFrame:SetScript("OnEvent",function(_,event,unit,arg2,arg3,arg4)
    if event=="PLAYER_TARGET_CHANGED" then
        -- If the old selected unit died, the health/death state can still be delivered
        -- before/around the target-change event.  Do not depend on its secret GUID:
        -- clear the synthetic timer whenever the current target is reported dead.
        if instanceTargetToken then
            local okDead,dead=pcall(UnitIsDeadOrGhost,"target")
            if okDead and SafePlain(dead) and dead then
                local changed=false
                for key,e in pairs(multi.debuffs.cache) do
                    if e.guid==instanceTargetToken then multi.debuffs.cache[key]=nil;changed=true end
                end
                if changed then MultiRender("debuffs") end
            end
        end
        FBUFFResetInstanceTarget()
        FBUFFCaptureTargetName()
        return
    end
    if event=="UNIT_SPELLCAST_SENT" then
        -- args: unit, targetName, castGUID, spellID
        RememberFriendlyCastTarget(arg3,arg2,arg4)
        return
    end
    if event=="UNIT_SPELLCAST_SUCCEEDED" then
        -- args: unit, castGUID, spellID
        local castGUID,spellID=arg2,arg3
        TrackFriendlyBuffCast(spellID,castGUID) -- 敵方 DOT 改由目標 AuraContainer 實際讀取，不再由施法成功建立假倒數
        return
    end
    if event=="UNIT_DIED" then
        -- Payload: dead unit GUID.
        ClearEnemyDotsByGUID(arg2)
        return
    end
    if event=="PARTY_KILL" then
        -- Payload: attackerGUID, targetGUID.  This covers the player and party
        -- members killing a dotted unit even when it is no longer our target.
        ClearEnemyDotsByGUID(arg3)
        return
    end
    if event=="PLAYER_TARGET_DIED" then
        -- No payload.  Use the still-selected dead target as a direct fallback.
        ClearCurrentTargetDotsOnDeath()
        return
    end
    if event=="UNIT_HEALTH" or event=="UNIT_HEALTH_FREQUENT" or event=="UNIT_FLAGS" then
        if unit=="target" and instanceTargetToken then
            local dead=false
            local okDead,d=pcall(UnitIsDeadOrGhost,"target")
            if okDead and SafePlain(d) and d then dead=true end
            if not dead then
                local okHealth,h=pcall(UnitHealth,"target")
                if okHealth and SafePlain(h) and type(h)=="number" and h<=0 then dead=true end
            end
            if dead then
                local changed=false
                for key,e in pairs(multi.debuffs.cache) do
                    if e.guid==instanceTargetToken then multi.debuffs.cache[key]=nil;changed=true end
                end
                if changed then MultiRender("debuffs") end
                FBUFFResetInstanceTarget()
                return
            end
        end
        ClearDeadUnitDots(unit)
        return
    end
    if event=="PLAYER_TARGET_CHANGED" then
        ClearDeadUnitDots("target")
    end
    if event=="UNIT_AURA" and unit=="player" then SelfLearnScanNative(); return end
    if event=="UNIT_AURA" and unit~="target" then return end
    SyncIgnoredAuraIDs()
    MultiScan("friendbuffs")
end)
multiFrame:SetScript("OnUpdate",function(self,elapsed)
    self.t=(self.t or 0)+elapsed; if self.t<0.08 then return end; self.t=0
    -- Last-resort fallback if a death event is restricted/missed.
    ClearCurrentTargetDotsOnDeath()
    if instanceTargetToken then
        local dead=false
        local okDead,d=pcall(UnitIsDeadOrGhost,"target")
        if okDead and SafePlain(d) and d then dead=true end
        if not dead then
            local okHealth,h=pcall(UnitHealth,"target")
            if okHealth and SafePlain(h) and type(h)=="number" and h<=0 then dead=true end
        end
        if dead then
            local changed=false
            for key,e in pairs(multi.debuffs.cache) do
                if e.guid==instanceTargetToken then multi.debuffs.cache[key]=nil;changed=true end
            end
            if changed then MultiRender("debuffs") end
            FBUFFResetInstanceTarget()
        end
    end
    MultiRender("friendbuffs"); MultiRender("debuffs")
    SelfLearnScanNative()
end)

-- v1.92 TEST：目標區設定範例 ICON。
-- 範例與真正目標 BUFF/DOT 共用 FBUFF_DB.dotIconPos，並使用完全相同的 TOPLEFT→CENTER 起點。
local FBUFFTargetExampleHolder
local FBUFFTargetExampleButton

local function FBUFFRefreshTargetExample()
    if not FBUFFTargetExampleHolder then return end
    FBUFFEnsureDotIconDB()
    local size=28*(FBUFF_DB.targetIconScale or 1)
    local anchor=FBUFFPositionDotAnchor()
    FBUFFTargetExampleHolder:SetSize(size,size)
    FBUFFTargetExampleButton:SetSize(size,size)
    FBUFFTargetExampleHolder:ClearAllPoints()
    FBUFFTargetExampleHolder:SetPoint("TOPLEFT",anchor,"CENTER",0,0)
end

local function FBUFFUpdateTargetExample(show)
    if not FBUFFTargetExampleHolder then
        FBUFFEnsureDotIconDB()
        FBUFFTargetExampleHolder=CreateFrame("Frame","FBUFF_TargetEffectExample",UIParent)
        FBUFFTargetExampleHolder:SetFrameStrata("HIGH")
        FBUFFTargetExampleHolder:EnableMouse(false)

        FBUFFTargetExampleButton=CreateFrame("Button",nil,FBUFFTargetExampleHolder)
        FBUFFTargetExampleButton:SetAllPoints()
        FBUFFTargetExampleButton:EnableMouse(true)
        FBUFFTargetExampleButton:RegisterForDrag("LeftButton")

        local icon=FBUFFTargetExampleButton:CreateTexture(nil,"ARTWORK")
        icon:SetAllPoints()
        icon:SetTexture(C_Spell.GetSpellTexture(589) or 136207) -- 暗言術：痛
        FBUFFTargetExampleButton.icon=icon

        local time=FBUFFTargetExampleButton:CreateFontString(nil,"OVERLAY","NumberFontNormal")
        time:SetPoint("CENTER",icon,"CENTER",0,0)
        time:SetText("20")
        time:SetTextColor(1,1,1,1)
        FBUFFTargetExampleButton.time=time

        FBUFFTargetExampleButton:SetScript("OnDragStart",function(_,button)
            if button=="LeftButton" and IsControlKeyDown() and not FBUFFPlayerInCombat() then FBUFFStartDotIconDrag() end
        end)
        FBUFFTargetExampleButton:SetScript("OnDragStop",function()
            FBUFFStopDotIconDrag()
            FBUFFRefreshTargetExample()
        end)
    end
    FBUFFRefreshTargetExample()
    if show then FBUFFTargetExampleHolder:Show() else FBUFFTargetExampleHolder:Hide() end
end

local function MakeFBUFFPanel()
 if FBUFFPanel then return FBUFFPanel end
 if type(FBUFF_UI_DB)~="table" then FBUFF_UI_DB={} end
 local p=CreateFrame("Frame","FBUFF_Settings",UIParent,"PortraitFrameTemplate");FBUFFPanel=p
 p:SetSize(530,540);p:SetFrameStrata("DIALOG");p:SetMovable(true);p:SetClampedToScreen(true);p:EnableMouse(true);p:RegisterForDrag("LeftButton");p:Hide()
 local panelX=tonumber(FBUFF_UI_DB.panelX) or -400
 local panelY=tonumber(FBUFF_UI_DB.panelY) or 0
 p:SetPoint("CENTER",UIParent,"CENTER",panelX,panelY)
 p:SetScript("OnDragStart",function(self) if not FBUFFPlayerInCombat() then self:StartMoving() end end)
 p:SetScript("OnDragStop",function(self)
   self:StopMovingOrSizing();local cx,cy=self:GetCenter();local ux,uy=UIParent:GetCenter()
   if cx and cy and ux and uy then FBUFF_UI_DB.panelX=cx-ux;FBUFF_UI_DB.panelY=cy-uy end
 end)
 local portrait=(p.PortraitContainer and p.PortraitContainer.portrait) or p.portrait or p.Portrait
 -- 左上角 Logo：直接沿用已成功 FQT 母版的同一個 WoW 圖示。
 if portrait then portrait:SetTexture(3586269) end
 local builtInTitle=(p.TitleContainer and p.TitleContainer.TitleText) or p.TitleText;if builtInTitle then builtInTitle:SetText("") end
 if p.Inset then p.Inset:Hide() end;if p.Bg and p.Bg.Hide then p.Bg:Hide() end
 local function Atlas(tex,name) if not tex or not tex.SetAtlas then return false end return pcall(tex.SetAtlas,tex,name,false) end
 local top=CreateFrame("Frame",nil,p);top:SetPoint("TOPLEFT",p,"TOPLEFT",2,-23);top:SetPoint("TOPRIGHT",p,"TOPRIGHT",-2,-23);top:SetHeight(76)
 local topBG=top:CreateTexture(nil,"BACKGROUND");topBG:SetAllPoints(top);if not Atlas(topBG,"groupfinder-roles-background") then topBG:SetTexture(8373327) end
 local streak=top:CreateTexture(nil,"BORDER");streak:SetPoint("TOPLEFT",top,"TOPLEFT",0,0);streak:SetPoint("TOPRIGHT",top,"TOPRIGHT",0,0);streak:SetHeight(43);if not Atlas(streak,"UI-Frame-TopTileStreaks") then streak:SetTexture(1723833) end
 local body=CreateFrame("Frame",nil,p,"InsetFrameTemplate");body:SetPoint("TOPLEFT",p,"TOPLEFT",3,-100);body:SetPoint("BOTTOMRIGHT",p,"BOTTOMRIGHT",-3,3)
 if body.Bg and body.Bg.SetAlpha then body.Bg:SetAlpha(.90) end;if body.TopEdge then body.TopEdge:Hide() end
 local inside=body:CreateTexture(nil,"BORDER",nil,1);inside:SetPoint("TOPLEFT",body,"TOPLEFT",0,5);inside:SetPoint("TOPRIGHT",body,"TOPRIGHT",0,5);inside:SetPoint("BOTTOMLEFT",body,"BOTTOMLEFT",0,0);inside:SetPoint("BOTTOMRIGHT",body,"BOTTOMRIGHT",0,0);if not Atlas(inside,"common-insideframe") then inside:SetTexture(8124462) end
 local dividerLayer=CreateFrame("Frame",nil,p);dividerLayer:SetAllPoints(p);dividerLayer:SetFrameStrata(p:GetFrameStrata());dividerLayer:SetFrameLevel(math.max(p:GetFrameLevel(),body:GetFrameLevel())+20)
 local divider=dividerLayer:CreateTexture(nil,"OVERLAY",nil,7);divider:SetSize(16,524);divider:SetPoint("CENTER",p,"TOP",0,-95);if not Atlas(divider,"common-framedivider") then divider:SetTexture(8245174) end;if divider.SetRotation then divider:SetRotation(math.pi/2) end
 local titleLayer=CreateFrame("Frame",nil,p);titleLayer:SetAllPoints(p);titleLayer:SetFrameStrata(p:GetFrameStrata());titleLayer:SetFrameLevel(math.max(p:GetFrameLevel(),body:GetFrameLevel())+30)
 local ttl=titleLayer:CreateFontString(nil,"OVERLAY","GameFontNormalLarge");local tf,ts,tflags=ttl:GetFont();if tf and ts then ttl:SetFont(tf,ts+2,tflags) end;ttl:SetPoint("CENTER",p,"TOP",0,-58);ttl:SetText("老哥UI｜自我BUFF監控｜FBUFF")
 local function RecipeMenu(text)
   local b=CreateFrame("Button",nil,p);b:SetSize(150,48);local bg=b:CreateTexture(nil,"BACKGROUND");b.bg=bg;bg:SetAllPoints();if not pcall(bg.SetAtlas,bg,"Professions_Recipe_Active") then bg:SetTexture(4417031) end
   local label=b:CreateFontString(nil,"OVERLAY","GameFontNormal");b.label=label;label:SetPoint("CENTER");local f,sz,fl=label:GetFont();if f and sz then label:SetFont(f,sz+2,fl or "") end;label:SetText(text);return b
 end
 local menu1=RecipeMenu("目標區設定");menu1:SetPoint("TOPLEFT",body,"TOPLEFT",17,-28)
 local menu2=RecipeMenu("隊友區設定");menu2:SetPoint("TOPLEFT",menu1,"BOTTOMLEFT",0,-15)
 local menu3=RecipeMenu("可忽略效果");menu3:SetPoint("TOPLEFT",menu2,"BOTTOMLEFT",0,-15)
 local menu4=RecipeMenu("已忽略效果");menu4:SetPoint("TOPLEFT",menu3,"BOTTOMLEFT",0,-15)
 local verticalDivider=p:CreateTexture(nil,"OVERLAY",nil,7);verticalDivider:SetSize(2,405);verticalDivider:SetPoint("TOP",body,"TOPLEFT",183,-35);if not pcall(verticalDivider.SetAtlas,verticalDivider,"Talents-divider-vertical-c60") then verticalDivider:SetTexture(8116735) end
 local pages={}
 for i=1,4 do
   local pg=CreateFrame("Frame",nil,p)
   if i==1 then _G.FBUFF_SettingsPage1=pg end
   pg:SetPoint("TOPLEFT",body,"TOPLEFT",205,-24)
   if i<=2 then
     pg:SetPoint("BOTTOMRIGHT",body,"BOTTOMRIGHT",-24,54)
   else
     pg:SetPoint("BOTTOMRIGHT",body,"BOTTOMRIGHT",-24,90)
   end
   pages[i]=pg
 end
 FBUFFPage1,FBUFFPage2,FBUFFPage3,FBUFFPage4=pages[1],pages[2],pages[3],pages[4]
 local selected=1
 local function State(b,on) if on then b.bg:SetAlpha(1);b.label:SetTextColor(1,.82,0) else b.bg:SetAlpha(.18);b.label:SetTextColor(.90,.88,.82) end end
 local menus={menu1,menu2,menu3,menu4}
 local function Select(n)
   selected=n
   for i=1,4 do pages[i]:SetShown(i==n) end
   for i,b in ipairs(menus) do State(b,n==i) end
   SetPositioning(false)
   if FBUFFPartyAuraDrag then FBUFFPartyAuraDrag:Hide() end
   if FBUFFUpdatePartyAuraExamples then FBUFFUpdatePartyAuraExamples(n==2 and p:IsShown() and not FBUFFPlayerInCombat()) end
    FBUFFUpdateTargetExample(n==1 and p:IsShown() and not FBUFFPlayerInCombat())
   if (n==3 or n==4) and p.RefreshIgnore then p:RefreshIgnore() end
 end
 for i,b in ipairs(menus) do b:SetScript("OnEnter",function(self) if selected~=i then self.bg:SetAlpha(.60) end end);b:SetScript("OnLeave",function(self) State(self,selected==i) end);b:SetScript("OnClick",function() PlaySound(856);Select(i) end) end
 local values={width=200,height=25};local refs={}
 local function Gold(parent,text,y) local t=parent:CreateFontString(nil,"OVERLAY","GameFontNormalLarge");t:SetPoint("TOPLEFT",0,y);t:SetText("|cffffd200"..text.."|r");return t end
 local function WhiteLabel(parent,text,x,y)
   local t=parent:CreateFontString(nil,"OVERLAY","GameFontNormal");t:SetPoint("TOPLEFT",x,y);t:SetText(text);t:SetTextColor(1,1,1,1);return t
 end

 -- 目標區設定：只把現有自我與目標效果控制拆開；AuraContainer 顯示核心維持原樣。
 FBUFFEnsureSelfIconDB();FBUFFEnsureDotIconDB()
 local selfCheck=CreateFrame("CheckButton",nil,pages[1],"UICheckButtonTemplate")
 selfCheck:SetSize(24,24);selfCheck:SetPoint("TOPLEFT",0,-4);selfCheck:SetChecked(FBUFF_DB.selfAuraEnabled~=false)
 local selfCheckLabel=selfCheck:CreateFontString(nil,"OVERLAY","GameFontNormal");selfCheckLabel:SetPoint("LEFT",selfCheck,"RIGHT",4,0);selfCheckLabel:SetText("顯示自我BUFF");selfCheckLabel:SetTextColor(1,1,1,1)
 selfCheck:SetScript("OnClick",function(self) PlaySound(856);if FBUFFPlayerInCombat() then self:SetChecked(FBUFF_DB.selfAuraEnabled~=false);return end;FBUFFSetSelfAuraEnabled(self:GetChecked()==true) end)
 refs.selfAuraCheck=selfCheck
 Gold(pages[1],"BUFF尺寸調整",-44)
 local selfSl=CreateFrame("Frame",nil,pages[1],"MinimalSliderWithSteppersTemplate")
 selfSl:SetSize(295,30);selfSl:SetPoint("TOPLEFT",0,-74);selfSl:Init(FBUFF_DB.selfIconScale,1,3,20,nil)
 selfSl:RegisterCallback(MinimalSliderWithSteppersMixin.Event.OnValueChanged,function(_,v) if not FBUFFPlayerInCombat() then FBUFFSetSelfIconScale(v) end end)
 refs.selfIconScale={slider=selfSl}

 local targetCheck=CreateFrame("CheckButton",nil,pages[1],"UICheckButtonTemplate")
 targetCheck:SetSize(24,24);targetCheck:SetPoint("TOPLEFT",0,-130);targetCheck:SetChecked(FBUFF_DB.targetAuraEnabled~=false)
 local targetCheckLabel=targetCheck:CreateFontString(nil,"OVERLAY","GameFontNormal");targetCheckLabel:SetPoint("LEFT",targetCheck,"RIGHT",4,0);targetCheckLabel:SetText("顯示目標區BUFF或DOT");targetCheckLabel:SetTextColor(1,1,1,1)
 targetCheck:SetScript("OnClick",function(self) PlaySound(856);if FBUFFPlayerInCombat() then self:SetChecked(FBUFF_DB.targetAuraEnabled~=false);return end;FBUFFSetTargetAuraEnabled(self:GetChecked()==true) end)
 refs.targetAuraCheck=targetCheck
 Gold(pages[1],"BUFF尺寸調整",-170)
 local targetSl=CreateFrame("Frame",nil,pages[1],"MinimalSliderWithSteppersTemplate")
 targetSl:SetSize(295,30);targetSl:SetPoint("TOPLEFT",0,-200);targetSl:Init(FBUFF_DB.targetIconScale,1,3,20,nil)
 targetSl:RegisterCallback(MinimalSliderWithSteppersMixin.Event.OnValueChanged,function(_,v) if not FBUFFPlayerInCombat() then FBUFFSetTargetIconScale(v);FBUFFUpdateTargetExample(true) end end)
 refs.targetIconScale={slider=targetSl}
 local targetHint=WhiteLabel(pages[1],"Ctrl＋左鍵可拖曳BUFF位置",0,-260)

 -- 隊友區設定：沿用既有開關、間距、尺寸與右鍵拖曳邏輯，只搬到獨立頁面。
 local partyAuraCheck=CreateFrame("CheckButton",nil,pages[2],"UICheckButtonTemplate")
 partyAuraCheck:SetSize(24,24);partyAuraCheck:SetPoint("TOPLEFT",0,-4)
 local partyAuraLabel=partyAuraCheck:CreateFontString(nil,"OVERLAY","GameFontNormal")
 partyAuraLabel:SetPoint("LEFT",partyAuraCheck,"RIGHT",4,0);partyAuraLabel:SetText("顯示隊友BUFF");partyAuraLabel:SetTextColor(1,1,1,1)
 partyAuraCheck:SetChecked(FBUFFPartyAuraDB().partyAuraEnabled==true)
 partyAuraCheck:SetScript("OnClick",function(self) PlaySound(856);if FBUFFPlayerInCombat() then self:SetChecked(FBUFFPartyAuraDB().partyAuraEnabled==true);return end;FBUFFSetPartyAuraEnabled(self:GetChecked()==true) end)
 refs.partyAuraCheck=partyAuraCheck
 Gold(pages[2],"間距調整",-44)
 local partySpace=CreateFrame("Frame",nil,pages[2],"MinimalSliderWithSteppersTemplate")
 partySpace:SetSize(295,30);partySpace:SetPoint("TOPLEFT",0,-74);partySpace:Init(FBUFFPartyAuraDB().partyAuraSpacing,70,140,71,nil)
 partySpace:RegisterCallback(MinimalSliderWithSteppersMixin.Event.OnValueChanged,function(_,v) if not FBUFFPlayerInCombat() then FBUFFSetPartyAuraSpacing(v) end end)
 refs.partyAuraSpacing={slider=partySpace}
 Gold(pages[2],"尺寸調整",-130)
 local partySize=CreateFrame("Frame",nil,pages[2],"MinimalSliderWithSteppersTemplate")
 partySize:SetSize(295,30);partySize:SetPoint("TOPLEFT",0,-160);partySize:Init(FBUFFPartyAuraDB().partyAuraIconSize,24,72,49,nil)
 partySize:RegisterCallback(MinimalSliderWithSteppersMixin.Event.OnValueChanged,function(_,v)
   if FBUFFPlayerInCombat() then return end
   local db=FBUFFPartyAuraDB();db.partyAuraIconSize=math.floor((tonumber(v) or 24)+0.5);FBUFFRebuildPartyAuraRows();if FBUFFUpdatePartyAuraExamples then FBUFFUpdatePartyAuraExamples(true) end
 end)
 refs.partyAuraIconSize={slider=partySize}
 local partyHint=WhiteLabel(pages[2],"Ctrl＋左鍵可拖曳BUFF位置",0,-220)

 -- v1.21 已實測成功的原生 ScrollBox + MinimalScrollBar 與裁切方式，原樣沿用。
 local function CreateNativeEffectList(parent)
   local box=CreateFrame("Frame",nil,parent,"WowScrollBoxList")
   box:SetPoint("TOPLEFT",0,0)
   box:SetPoint("BOTTOMRIGHT",-28,0)
   if box.SetClipsChildren then box:SetClipsChildren(true) end
   local bar=CreateFrame("EventFrame",nil,parent,"MinimalScrollBar")
   bar:SetPoint("TOPLEFT",box,"TOPRIGHT",8,-1)
   bar:SetPoint("BOTTOMLEFT",box,"BOTTOMRIGHT",8,1)
   local view=CreateScrollBoxListLinearView()
   view:SetElementExtent(32)
   view:SetElementInitializer("BackdropTemplate",function(row,item)
     if not row.FBUFFReady then
       row.FBUFFReady=true
       row.Text=row:CreateFontString(nil,"OVERLAY","GameFontHighlight")
       row.Text:SetPoint("LEFT",2,0);row.Text:SetWidth(166);row.Text:SetJustifyH("LEFT")
       row.Button=CreateFrame("Button",nil,row,"MainMenuFrameButtonTemplate")
       row.Button:SetSize(88,26);row.Button:SetPoint("RIGHT",-2,0)
       row.Button:SetScript("OnClick",function(btn)
         local data=btn:GetParent().FBUFFItem
         if data and data.callback then PlaySound(856);data.callback() end
       end)
     end
     row.FBUFFItem=item
     row.Text:SetText(item.text or "")
     row.Button:SetText(item.buttonText or "")
     row.Button:SetShown(not item.message)
   end)
   ScrollUtil.InitScrollBoxListWithScrollBar(box,bar,view)
   return box,bar
 end
 local currentBox,currentBar=CreateNativeEffectList(pages[3])
 local ignoredBox,ignoredBar=CreateNativeEffectList(pages[4])

 function p:RefreshIgnore()
   if not FBUFFPlayerInCombat() then FBUFFAutoIgnoreExternalPlayerBuffs() end
   if FBUFFPlayerInCombat() then
     local dp=CreateDataProvider();dp:Insert({message=true,text="戰鬥中暫停更新效果清單"});currentBox:SetDataProvider(dp,ScrollBoxConstants.DiscardScrollPosition)
   else
     local active,activeSeen={},{}
     for _,kind in ipairs({"buffs","friendbuffs","debuffs"}) do for _,e in ipairs(trackers[kind].currentEffects()) do if IgnoreNameSet()[e.name] then IgnoreEverywhere(e.id,e.name) else local key=tostring(e.name);if not activeSeen[key] then activeSeen[key]=true;e.kind=kind;active[#active+1]=e end end end end
     if type(FBUFF_UI_DB)=="table" and type(FBUFF_UI_DB.seenDots)=="table" then
       local stale={};for id,info in pairs(FBUFF_UI_DB.seenDots) do local spellID=tonumber(id) or id;local okH,harmful=pcall(C_Spell.IsSpellHarmful,spellID);if not okH or not SafePlain(harmful) or not harmful then stale[#stale+1]=id else local name=(type(info)=="table" and info.name) or C_Spell.GetSpellName(spellID) or tostring(spellID);if not IgnoreNameSet()[name] and not trackers.debuffs.excluded()[spellID] then local key=tostring(name);if not activeSeen[key] then activeSeen[key]=true;active[#active+1]={kind="debuffs",id=spellID,name=name} end end end end;for _,id in ipairs(stale) do FBUFF_UI_DB.seenDots[id]=nil end
     end
     if type(FBUFF_UI_DB)=="table" and type(FBUFF_UI_DB.selfLearned)=="table" then
       for id,info in pairs(FBUFF_UI_DB.selfLearned) do
         if type(info)=="table" and info.name and not IgnoreNameSet()[info.name] then
           local key=tostring(info.name)
           if not activeSeen[key] then activeSeen[key]=true;active[#active+1]={kind="buffs",id=tonumber(id) or id,name=info.name} end
         end
       end
     end
     table.sort(active,function(a,b)return tostring(a.name)<tostring(b.name) end)
     local dp=CreateDataProvider()
     if #active==0 then dp:Insert({message=true,text="目前沒有可忽略的 BUFF／DOT"}) else
       for _,item in ipairs(active) do
         local captured=item
         dp:Insert({text=item.name..(item.kind=="debuffs" and " |cffff5555[DOT]|r" or " |cff55ff55[BUFF]|r"),buttonText="忽略",callback=function() local changed=IgnoreEverywhere(captured.id,captured.name);SyncIgnoredAuraIDs();if not InCombatLockdown() then C_Timer.After(0,FBUFFAuraContainerStart168);FBUFFRebuildPartyAuraRows() end;if changed then p:RefreshIgnore() end end})
       end
     end
     currentBox:SetDataProvider(dp,ScrollBoxConstants.DiscardScrollPosition)
   end

   local arr,seen={},{}
   if not FBUFFPlayerInCombat() then local union={};for _,tr in pairs(trackers) do for id in pairs(tr.excluded()) do union[id]=true end end;for id in pairs(union) do for _,tr in pairs(trackers) do if not tr.excluded()[id] then tr.hide(id) end end end end
   for _,tr in pairs(trackers) do for id in pairs(tr.excluded()) do local name=C_Spell.GetSpellName(id) or tostring(id);local key=tostring(name);if not seen[key] then seen[key]=true;arr[#arr+1]={kind="buffs",id=id,name=name} end end end
   table.sort(arr,function(a,b)return tostring(a.name)<tostring(b.name) end)
   local dp2=CreateDataProvider()
   if #arr==0 then dp2:Insert({message=true,text="目前沒有忽略的效果"}) else
     for _,item in ipairs(arr) do
       local captured=item
       dp2:Insert({text=item.name.." |cff55ff55[BUFF]|r",buttonText="取消",callback=function() RestoreEverywhere(captured.id,captured.name);SelfLearnScanNative();if not InCombatLockdown() then FBUFFRebuildPartyAuraRows() end;p:RefreshIgnore() end})
     end
   end
   ignoredBox:SetDataProvider(dp2,ScrollBoxConstants.DiscardScrollPosition)
 end
 local auraRefresh=CreateFrame("Frame",nil,p);auraRefresh:RegisterEvent("UNIT_AURA");auraRefresh:RegisterEvent("PLAYER_TARGET_CHANGED");auraRefresh:RegisterEvent("PLAYER_REGEN_ENABLED");auraRefresh:SetScript("OnEvent",function(_,event,unit) if not p:IsShown() or (not pages[3]:IsShown() and not pages[4]:IsShown()) then return end;if event=="UNIT_AURA" and unit~="player" and unit~="target" then return end;p:RefreshIgnore() end)
 local function WhiteButtonText(b) local fs=b:GetFontString();if fs then fs:SetTextColor(1,1,1,1);fs:SetShadowColor(0,0,0,0);fs:SetShadowOffset(0,0) end end
 local reset=CreateFrame("Button",nil,p,"MainMenuFrameButtonTemplate");reset:SetSize(155,32);reset:SetPoint("BOTTOMLEFT",body,"BOTTOMLEFT",14.5,33);reset:SetText("恢復預設");WhiteButtonText(reset);reset:SetScript("OnClick",function() PlaySound(856);if FBUFFPlayerInCombat() then return end;FBUFF_UI_DB.panelX=-400;FBUFF_UI_DB.panelY=0;FBUFF_UI_DB.partyAuraEnabled=true;FBUFF_UI_DB.partyAuraSpacing=85;FBUFF_UI_DB.partyAuraIconSize=24;FBUFF_UI_DB.partyAuraX=12;FBUFF_UI_DB.partyAuraY=-190;FBUFFEnsureSelfIconDB();FBUFFEnsureDotIconDB();FBUFF_DB.selfAuraEnabled=true;FBUFF_DB.targetAuraEnabled=true;FBUFF_DB.selfIconScale=1;FBUFF_DB.targetIconScale=1;FBUFFPositionPartyAuraLayer();FBUFFAnchorPartyAuraRows();FBUFFAuraContainerStart168();FBUFFStartDotAuraContainer();if refs.selfAuraCheck then refs.selfAuraCheck:SetChecked(true) end;if refs.targetAuraCheck then refs.targetAuraCheck:SetChecked(true) end;if refs.selfIconScale then refs.selfIconScale.slider:SetValue(1) end;if refs.targetIconScale then refs.targetIconScale.slider:SetValue(1) end;if refs.partyAuraCheck then refs.partyAuraCheck:SetChecked(true) end;if refs.partyAuraSpacing then refs.partyAuraSpacing.slider:SetValue(85) end;if refs.partyAuraIconSize then refs.partyAuraIconSize.slider:SetValue(24) end;if FBUFFUpdatePartyAuraExamples then FBUFFUpdatePartyAuraExamples(true) end;p:ClearAllPoints();p:SetPoint("CENTER",UIParent,"CENTER",-400,0);SetPositioning(false) end)
 local done=CreateFrame("Button",nil,p,"MainMenuFrameButtonTemplate");done:SetSize(155,32);done:SetPoint("BOTTOMRIGHT",body,"BOTTOMRIGHT",-25,33);done:SetText("設定完成");WhiteButtonText(done);done:SetScript("OnClick",function() PlaySound(856);SetPositioning(false);if FBUFFPartyAuraDrag then FBUFFPartyAuraDrag:Hide() end;if FBUFFUpdatePartyAuraExamples then FBUFFUpdatePartyAuraExamples(false) end;p:Hide() end)
 p:SetScript("OnShow",function() PlaySound(850);Select(1);FBUFFEnsureSelfIconDB();FBUFFEnsureDotIconDB();if refs.selfAuraCheck then refs.selfAuraCheck:SetChecked(FBUFF_DB.selfAuraEnabled~=false) end;if refs.targetAuraCheck then refs.targetAuraCheck:SetChecked(FBUFF_DB.targetAuraEnabled~=false) end;if refs.selfIconScale then refs.selfIconScale.slider:SetValue(FBUFF_DB.selfIconScale) end;if refs.targetIconScale then refs.targetIconScale.slider:SetValue(FBUFF_DB.targetIconScale) end;if refs.partyAuraCheck then refs.partyAuraCheck:SetChecked(FBUFFPartyAuraDB().partyAuraEnabled==true) end;if refs.partyAuraSpacing then refs.partyAuraSpacing.slider:SetValue(FBUFFPartyAuraDB().partyAuraSpacing) end;if refs.partyAuraIconSize then refs.partyAuraIconSize.slider:SetValue(FBUFFPartyAuraDB().partyAuraIconSize) end;C_Timer.After(0,function() FBUFFUpdateSelfExamples(true);FBUFFUpdateTargetExample(true);if FBUFFUpdatePartyAuraExamples then FBUFFUpdatePartyAuraExamples(false) end end) end)
 p:HookScript("OnHide",function() FBUFFUpdateTargetExample(false);if FBUFFPartyAuraDrag then FBUFFPartyAuraDrag:Hide() end;if FBUFFUpdatePartyAuraExamples then FBUFFUpdatePartyAuraExamples(false) end end)
 p:SetScript("OnHide",function() PlaySound(850);SetPositioning(false);FBUFFUpdateSelfExamples(false);FBUFFUpdateTargetExample(false);if FBUFFPartyAuraDrag then FBUFFPartyAuraDrag:Hide() end;if FBUFFUpdatePartyAuraExamples then FBUFFUpdatePartyAuraExamples(false) end end);table.insert(UISpecialFrames,"FBUFF_Settings");Select(1);return p
end
local combatSettingNotice
local function FBUFFCombatSettingWarning()
 if not combatSettingNotice then
  combatSettingNotice=UIParent:CreateFontString(nil,"OVERLAY","GameFontNormalHuge")
  combatSettingNotice:SetPoint("CENTER",UIParent,"CENTER",0,185)
  local cf,cs,cflags=combatSettingNotice:GetFont();if cf and cs then combatSettingNotice:SetFont(cf,cs+4,cflags or "") end
  combatSettingNotice:SetTextColor(1,.82,0,1)
  combatSettingNotice:SetJustifyH("CENTER")
 end
 combatSettingNotice:SetText("請先脫離戰鬥再進行設定。")
 combatSettingNotice:SetAlpha(1);combatSettingNotice:Show()
 if combatSettingNotice.fade then combatSettingNotice.fade:Stop() end
 local ag=combatSettingNotice:CreateAnimationGroup();local pause=ag:CreateAnimation("Alpha");pause:SetFromAlpha(1);pause:SetToAlpha(1);pause:SetDuration(5);pause:SetOrder(1)
 local fade=ag:CreateAnimation("Alpha");fade:SetFromAlpha(1);fade:SetToAlpha(0);fade:SetDuration(.45);fade:SetOrder(2)
 ag:SetScript("OnFinished",function() combatSettingNotice:Hide();combatSettingNotice:SetAlpha(1) end);combatSettingNotice.fade=ag;ag:Play()
 if C_Sound and C_Sound.PlayVocalErrorSound then C_Sound.PlayVocalErrorSound(14) end
end
local function OpenFBUFF() if FBUFFPlayerInCombat() then FBUFFCombatSettingWarning() return end;MakeFBUFFPanel():Show() end
SLASH_FBUFF1="/fbuff";SlashCmdList.FBUFF=OpenFBUFF
local function InitFBUFFUI()
 if type(FBUFF_UI_DB)~="table" then FBUFF_UI_DB={} end
 if FBUFF_UI_DB.friendBuffLayoutVersion ~= 61 then
   if type(FBUFF_FriendBuffDB)=="table" then FBUFF_FriendBuffDB.y=40; FBUFF_FriendBuffDB.x=(type(FBUFF_BuffDB)=="table" and FBUFF_BuffDB.x) or FBUFF_FriendBuffDB.x end
   FBUFF_UI_DB.friendBuffLayoutVersion=61
 end
 if FBUFF_UI_DB.layoutVersion ~= 85 then
   if type(FBUFF_BuffDB)=="table" then FBUFF_BuffDB.x=100;FBUFF_BuffDB.y=145 end
   if type(FBUFF_FriendBuffDB)=="table" then FBUFF_FriendBuffDB.x=100;FBUFF_FriendBuffDB.y=-10 end
   if type(FBUFF_DotDB)=="table" then FBUFF_DotDB.x=100;FBUFF_DotDB.y=-165 end
   FBUFF_UI_DB.panelX=-430;FBUFF_UI_DB.panelY=0
   FBUFF_UI_DB.layoutVersion=85
 end
 if type(FBUFF_UI_DB.minimap)~="table" then FBUFF_UI_DB.minimap={hide=false,minimapPos=165,radius=80} end
 if type(FBUFF_UI_DB.minimapAngle)~="number" then FBUFF_UI_DB.minimapAngle=165 end
 C_Timer.After(1.2,function()
   if not InCombatLockdown() then
     SetPositioning(false)
     if FBUFFRefreshSelfIconAttach then FBUFFRefreshSelfIconAttach() end
   end
 end)
end
local mini
local function ToggleFBUFFSettings()
 if FBUFFPlayerInCombat() then FBUFFCombatSettingWarning() return end
 local cfg=MakeFBUFFPanel();if cfg:IsShown() then cfg:Hide() else cfg:Show() end
end
local function SetupStandardMinimap()
 local LibStub=_G.LibStub;if not LibStub then return false end
 local LDB=LibStub("LibDataBroker-1.1",true);local DBIcon=LibStub("LibDBIcon-1.0",true);if not LDB or not DBIcon then return false end
 local obj=LDB:NewDataObject("FBUFF",{type="launcher",text="FBUFF",icon=3586269,OnClick=function(_,button)if button=="LeftButton"then ToggleFBUFFSettings()end end,OnTooltipShow=function(tt)tt:AddLine("老哥UI｜自我BUFF監控｜FBUFF");tt:AddLine("左鍵：開啟/關閉設定",1,1,1)end})
 if not DBIcon:IsRegistered("FBUFF")then DBIcon:Register("FBUFF",obj,FBUFF_UI_DB.minimap)end
 local b=DBIcon.GetMinimapButton and DBIcon:GetMinimapButton("FBUFF")
 if b and not b.LaogeUIStandardRing then
  b:SetSize(31,31);if b.icon then b.icon:ClearAllPoints();b.icon:SetSize(20,20);b.icon:SetPoint("CENTER",b,"CENTER",1,0);b.icon:SetTexCoord(.07,.93,.07,.93) end
  local bg=b:CreateTexture(nil,"BACKGROUND");bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background");bg:SetSize(20,20);bg:SetPoint("CENTER");bg:Hide()
  local ring=b:CreateTexture(nil,"OVERLAY");ring:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder");ring:SetSize(53,53);ring:SetPoint("TOPLEFT",b,"TOPLEFT",0,0)
  b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight");b.LaogeUIStandardRing=true
 end
 return true
end
local function SetupFallbackMinimap()
 mini=CreateFrame("Button","FBUFFMinimapButton",Minimap);mini:SetSize(31,31);mini:SetFrameStrata("MEDIUM");mini:SetFrameLevel((Minimap:GetFrameLevel()or 0)+8);mini:RegisterForClicks("LeftButtonUp");mini:RegisterForDrag("LeftButton")
 local ic=mini:CreateTexture(nil,"ARTWORK");ic:SetSize(20,20);ic:SetPoint("CENTER",mini,"CENTER",1,0);ic:SetTexture(3586269);ic:SetTexCoord(.07,.93,.07,.93)
 local border=mini:CreateTexture(nil,"OVERLAY");border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder");border:SetSize(53,53);border:SetPoint("TOPLEFT",mini,"TOPLEFT",0,0)
 local hl=mini:CreateTexture(nil,"HIGHLIGHT");hl:SetTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight");hl:SetBlendMode("ADD");hl:SetSize(31,31);hl:SetPoint("CENTER")
 local function Pos()local r=math.max(Minimap:GetWidth()or 140,Minimap:GetHeight()or 140)/2+18;local a=math.rad(FBUFF_UI_DB.minimapAngle or 165);mini:ClearAllPoints();mini:SetPoint("CENTER",Minimap,"CENTER",math.cos(a)*r,math.sin(a)*r)end
 mini:SetScript("OnDragStart",function(self)self:SetScript("OnUpdate",function()local mx,my=Minimap:GetCenter();if not mx then return end;local x,y=GetCursorPosition();local sc=UIParent:GetEffectiveScale();x,y=x/sc,y/sc;FBUFF_UI_DB.minimapAngle=math.deg(math.atan2(y-my,x-mx));Pos()end)end)
 mini:SetScript("OnDragStop",function(self)self:SetScript("OnUpdate",nil)end);mini:SetScript("OnClick",function(_,button)if button=="LeftButton"then ToggleFBUFFSettings()end end)
 mini:SetScript("OnEnter",function(self)GameTooltip:SetOwner(self,"ANCHOR_LEFT");GameTooltip:SetText("老哥UI｜自我BUFF監控｜FBUFF");GameTooltip:AddLine("左鍵：開啟/關閉設定",1,1,1);GameTooltip:Show()end);mini:SetScript("OnLeave",function()GameTooltip:Hide()end);Pos()
end
local settingsCombatGuard=CreateFrame("Frame")
settingsCombatGuard:RegisterEvent("PLAYER_REGEN_DISABLED")
settingsCombatGuard:SetScript("OnEvent",function()
 if FBUFF_Settings and FBUFF_Settings:IsShown() then FBUFF_Settings:Hide() end
end)


local shellEvents=CreateFrame("Frame");shellEvents:RegisterEvent("PLAYER_LOGIN");shellEvents:SetScript("OnEvent",function() InitFBUFFUI();if not SetupStandardMinimap() then SetupFallbackMinimap() end;print("|cff00ff00老哥UI｜自我BUFF監控｜FBUFF：已載入|r") end)
