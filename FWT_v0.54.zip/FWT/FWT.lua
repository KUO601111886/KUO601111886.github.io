-- FWT v0.53 位面顯示版 位面交換器-BY 老哥
-- 登入刷新一次；之後只允許手動刷新，30 秒冷卻。
-- 為避免瞬間大量傳送，刷新後把候選玩家排隊，每 2 秒只處理 1 人。
local PREFIX="FWTLAYER"
local CHANNEL_NAME="FWT-Layer-Exchange"
local REFRESH_CD=30
local SEND_INTERVAL=2


local LOCALE=GetLocale()
local ZH_CN=(LOCALE=="zhCN")
local L=ZH_CN and {
 title="位面交换器-BY 老哥", current="当前位面：", waiting="等待侦测",
 myStatus="更换位面需要组队，我愿意让人组队：", open="随时可以", closed="目前不方便",
 id="ID", world="当前位面", status="状态", party="组队",
 loading="读取中", self="自己", same="同位面", request="请求",
 refresh="刷新名单", refreshing="正在刷新...", done="刷新完成",
 channelWait="频道尚未就绪", layer="位面 ", whisper="我想换到你的位面 请你组我",
 changed="位面变更：", tip="登入刷新一次；之后手动刷新",
 loaded="位面交换器-BY 老哥 v0.53 位面顯示版 已载入"
} or {
 title="位面交換器-BY 老哥", current="目前位面：", waiting="等待偵測",
 myStatus="更換位面需要組隊，我願意讓人組隊：", open="隨時可以", closed="目前不方便",
 id="ID", world="目前位面", status="狀態", party="組隊",
 loading="讀取中", self="自己", same="同位面", request="請求",
 refresh="刷新名單", refreshing="正在刷新...", done="刷新完成",
 channelWait="頻道尚未就緒", layer="位面 ", whisper="我想換到你的位面 請你組我",
 changed="位面變更：", tip="登入刷新一次；之後手動刷新",
 loaded="位面交換器-BY 老哥 v0.53 位面顯示版 已載入"
}
FWT_Data=FWT_Data or {}
FWT_Data.worlds=FWT_Data.worlds or {}
FWT_Data.nextNumber=FWT_Data.nextNumber or 1
FWT_Data.minimapAngle=FWT_Data.minimapAngle or 45
if FWT_Data.openParty==nil then FWT_Data.openParty=true end

local currentWorldID,currentWorldNumber
local peers={}
local queue={}
local queueIndex=1
local queueRunning=false
local nextRefreshAt=0
local loginRefreshDone=false

-- v0.51 安全版：不註冊、不傳送任何 AddOn 網路訊息

local function FullName()
 local n,r=UnitFullName("player")
 if r and r~="" then return n.."-"..r end
 return n or UnitName("player") or "?"
end
local function GetWorldID()
 local g=UnitGUID("target"); if not g then return nil end
 local typ,a,w1,b,w2=strsplit("-",g)
 if (typ~="Creature" and typ~="Vehicle") or not w1 or not w2 then return nil end
 return w1.."/"..w2
end
local function WorldNo(id)
 if not id then return nil end
 if not FWT_Data.worlds[id] then
  FWT_Data.worlds[id]=FWT_Data.nextNumber
  FWT_Data.nextNumber=FWT_Data.nextNumber+1
 end
 return FWT_Data.worlds[id]
end

local frame=CreateFrame("Frame","FWTFrame",UIParent,"BackdropTemplate")
frame:SetSize(600,420); frame:SetPoint("CENTER"); frame:SetFrameStrata("DIALOG")
frame:SetMovable(true); frame:EnableMouse(true); frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart",function(s)s:StartMoving()end)
frame:SetScript("OnDragStop",function(s)s:StopMovingOrSizing()end)
frame:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",edgeSize=14,insets={left=3,right=3,top=3,bottom=3}})
frame:SetBackdropColor(.02,.03,.04,.97); frame:SetBackdropBorderColor(.75,.55,.12,1)

local logo=frame:CreateTexture(nil,"ARTWORK"); logo:SetSize(58,58); logo:SetPoint("TOPLEFT",14,-12); logo:SetTexture("Interface\\AddOns\\FWT\\FWT_Icon.tga")
local title=frame:CreateFontString(nil,"OVERLAY","GameFontNormalLarge"); title:SetPoint("TOPLEFT",80,-18); title:SetText("|cffffd200"..L.title.."|r")
local wl=frame:CreateFontString(nil,"OVERLAY","GameFontHighlight"); wl:SetPoint("TOPLEFT",80,-46); wl:SetText(ZH_CN and "当前位面：先点NPC/怪" or "目前位面：先點NPC/怪")
local close=CreateFrame("Button",nil,frame,"UIPanelCloseButton"); close:SetPoint("TOPRIGHT",-5,-5)

local sb=CreateFrame("Frame",nil,frame,"BackdropTemplate"); sb:SetSize(300,62); sb:SetPoint("TOPRIGHT",-18,-14)
sb:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1}); sb:SetBackdropColor(.06,.06,.05,.92); sb:SetBackdropBorderColor(.55,.42,.12,1)
local st=sb:CreateFontString(nil,"OVERLAY","GameFontNormal"); st:SetPoint("TOPLEFT",10,-7); st:SetText(L.myStatus)
local op=CreateFrame("CheckButton",nil,sb,"UICheckButtonTemplate"); op:SetSize(23,23); op:SetPoint("BOTTOMLEFT",7,5)
local ot=sb:CreateFontString(nil,"OVERLAY","GameFontHighlight"); ot:SetPoint("LEFT",op,"RIGHT",0,0); ot:SetText(L.open)
local cl=CreateFrame("CheckButton",nil,sb,"UICheckButtonTemplate"); cl:SetSize(23,23); cl:SetPoint("LEFT",ot,"RIGHT",10,0)
local ct=sb:CreateFontString(nil,"OVERLAY","GameFontHighlight"); ct:SetPoint("LEFT",cl,"RIGHT",0,0); ct:SetText(L.closed)
local function Checks()op:SetChecked(FWT_Data.openParty);cl:SetChecked(not FWT_Data.openParty)end; Checks()

local head=CreateFrame("Frame",nil,frame,"BackdropTemplate"); head:SetSize(558,32); head:SetPoint("TOPLEFT",20,-88)
head:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8"}); head:SetBackdropColor(.035,.09,.17,1)
for _,v in ipairs({{L.id,12},{L.world,255},{L.status,365},{L.party,485}})do
 local f=head:CreateFontString(nil,"OVERLAY","GameFontNormal"); f:SetPoint("LEFT",v[2],0); f:SetText(v[1])
end

local scroll=CreateFrame("ScrollFrame","FWTScrollFrame",frame,"UIPanelScrollFrameTemplate")
scroll:SetPoint("TOPLEFT",20,-122); scroll:SetPoint("BOTTOMRIGHT",-38,70)
local content=CreateFrame("Frame",nil,scroll); content:SetSize(538,1); scroll:SetScrollChild(content)
local rows={}
local function Row(i)
 if rows[i] then return rows[i] end
 local r=CreateFrame("Frame",nil,content,"BackdropTemplate"); r:SetSize(538,32); r:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8"}); r:SetBackdropColor(.035,.045,.05,.9)
 r.id=r:CreateFontString(nil,"OVERLAY","GameFontHighlight"); r.id:SetPoint("LEFT",10,0); r.id:SetWidth(235); r.id:SetJustifyH("LEFT")
 r.world=r:CreateFontString(nil,"OVERLAY","GameFontHighlight"); r.world:SetPoint("LEFT",245,0); r.world:SetWidth(105)
 r.status=r:CreateFontString(nil,"OVERLAY","GameFontHighlight"); r.status:SetPoint("LEFT",355,0); r.status:SetWidth(115)
 r.action=CreateFrame("Button",nil,r,"UIPanelButtonTemplate"); r.action:SetSize(66,23); r.action:SetPoint("RIGHT",-6,0)
 rows[i]=r; return r
end

local function RefreshUI()
 for _,r in ipairs(rows)do r:Hide()end
 local list={{name=FullName(),id=currentWorldID,open=FWT_Data.openParty,self=true}}
 local now=time()
 for n,p in pairs(peers)do
  if p.seen and now-p.seen<300 then table.insert(list,{name=n,id=p.id,open=p.open}) end
 end
 table.sort(list,function(a,b)if a.self then return true elseif b.self then return false else return a.name<b.name end end)
 content:SetHeight(math.max(1,#list*33))
 for i,p in ipairs(list)do
  local r=Row(i); r:ClearAllPoints(); r:SetPoint("TOPLEFT",0,-(i-1)*33); r:Show(); r.id:SetText(p.name)
  local no=WorldNo(p.id); r.world:SetText(no and (L.layer..no)or"|cff888888"..L.loading.."|r")
  if p.self or p.open==true then r.status:SetText("|cff33ff55"..L.open.."|r")
  elseif p.open==false then r.status:SetText("|cffff5533"..L.closed.."|r")
  else r.status:SetText("|cff888888"..L.loading.."|r") end
  r.action:SetScript("OnClick",nil)
  if p.self then r.action:Show();r.action:Disable();r.action:SetText(L.self)
  elseif p.open~=true or not p.id then r.action:Hide()
  elseif currentWorldID==p.id then r.action:Show();r.action:Disable();r.action:SetText(L.same)
  else
   local who=p.name; r.action:Show();r.action:Enable();r.action:SetText(L.request)
   r.action:SetScript("OnClick",function()SendChatMessage(L.whisper,"WHISPER",nil,who)end)
  end
 end
end

local function Payload() return "DATA|"..(currentWorldID or "?").."|"..(FWT_Data.openParty and "1"or"0") end
local function SendData(name)
 -- v0.51：停用所有 AddOn 私訊。
end

local function ChannelID()
 local id=GetChannelName(CHANNEL_NAME)
 if type(id)=="number" and id>0 then return id end
 return nil
end
local function JoinDiscoveryChannel()
 -- v0.51：登入與背景完全不碰聊天頻道。
 return nil
end

local function ProcessQueue()
 queueRunning=false
end

local function BuildQueueFromChannel()
 -- v0.51：安全版不掃描、不加入任何自訂頻道。
end

local refreshBtn=CreateFrame("Button",nil,frame,"UIPanelButtonTemplate")
refreshBtn:SetSize(105,27); refreshBtn:SetPoint("BOTTOMRIGHT",-24,27); refreshBtn:SetText(ZH_CN and "刷新位面" or "刷新位面")
local statusText=frame:CreateFontString(nil,"OVERLAY","GameFontDisableSmall"); statusText:SetPoint("RIGHT",refreshBtn,"LEFT",-12,0); statusText:SetText(ZH_CN and "位面显示模式：不连接任何频道" or "位面顯示模式：不連接任何頻道")

-- v0.54：正式服頻道/API 尚未確認前，刷新位面按鈕暫停使用。
-- 保留按鈕外觀，永久停用，不執行 Detect、不碰頻道，也不產生 Lua 錯誤。
refreshBtn:Disable()
refreshBtn:SetText(ZH_CN and "刷新位面" or "刷新位面")
refreshBtn:SetScript("OnClick",nil)

local function Detect()
 local id=GetWorldID(); if not id then return end
 if currentWorldID and currentWorldID~=id then print("|cff00ff00[FWT]|r "..L.changed,WorldNo(currentWorldID),"→",WorldNo(id))end
 currentWorldID=id; currentWorldNumber=WorldNo(id)
 wl:SetText(L.current..currentWorldNumber.."  |cff888888(World ID: "..id..")|r")
 RefreshUI()
end
op:SetScript("OnClick",function()FWT_Data.openParty=true;Checks();RefreshUI()end)
cl:SetScript("OnClick",function()FWT_Data.openParty=false;Checks();RefreshUI()end)

local function Ask() end

local ev=CreateFrame("Frame")
ev:RegisterEvent("PLAYER_ENTERING_WORLD");ev:RegisterEvent("PLAYER_TARGET_CHANGED")
ev:SetScript("OnEvent",function(_,e,...)
 if e=="PLAYER_TARGET_CHANGED" then
  Detect()
 elseif e=="PLAYER_ENTERING_WORLD" then
  C_Timer.After(1,function()
   Detect()
   RefreshUI()
  end)
 end
end)

local mini=CreateFrame("Button","FWTMinimapButton",Minimap);mini:SetSize(38,38);mini:SetFrameStrata("MEDIUM");mini:SetFrameLevel(Minimap:GetFrameLevel()+8);mini:RegisterForClicks("LeftButtonUp");mini:RegisterForDrag("LeftButton")
local ic=mini:CreateTexture(nil,"ARTWORK");ic:SetAllPoints();ic:SetTexture("Interface\\AddOns\\FWT\\FWT_Icon.tga")
local function UR()local r=math.max(Minimap:GetWidth()or 140,Minimap:GetHeight()or 140)/2+18;local a=math.rad(FWT_Data.minimapAngle or 45);mini:ClearAllPoints();mini:SetPoint("CENTER",Minimap,"CENTER",math.cos(a)*r,math.sin(a)*r)end;UR()
local drag=false
mini:SetScript("OnDragStart",function(s)drag=true;s:SetScript("OnUpdate",function()local mx,my=Minimap:GetCenter();if not mx then return end;local x,y=GetCursorPosition();local sc=UIParent:GetEffectiveScale();x,y=x/sc,y/sc;FWT_Data.minimapAngle=math.deg(math.atan2(y-my,x-mx));UR()end)end)
mini:SetScript("OnDragStop",function(s)s:SetScript("OnUpdate",nil);UR();C_Timer.After(.1,function()drag=false end)end)
mini:SetScript("OnClick",function()if drag then return end;if frame:IsShown()then frame:Hide()else frame:Show();Detect();RefreshUI()end end)
mini:SetScript("OnEnter",function(s)GameTooltip:SetOwner(s,"ANCHOR_LEFT");GameTooltip:SetText(L.title);GameTooltip:AddLine(L.tip,1,1,1);GameTooltip:Show()end)
mini:SetScript("OnLeave",function()GameTooltip:Hide()end)

SLASH_FWT1="/fwt"
SlashCmdList["FWT"]=function()
 if frame:IsShown()then frame:Hide()else frame:Show();Detect();RefreshUI()end
end

frame:Hide()
print("|cff00ff00"..L.loaded.."|r")
