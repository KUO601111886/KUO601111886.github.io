local ADDON="FWM"
FWMDB=FWMDB or {}

local hooked=false

local function SavePosition(f)
    if not f then return end
    local point, _, relativePoint, x, y = f:GetPoint(1)
    if point then
        FWMDB.point=point
        FWMDB.relativePoint=relativePoint or point
        FWMDB.x=x or 0
        FWMDB.y=y or 0
    end
end

local function RestorePosition(f)
    if not f or not FWMDB.point then return end
    f:ClearAllPoints()
    f:SetPoint(FWMDB.point, UIParent, FWMDB.relativePoint or FWMDB.point, FWMDB.x or 0, FWMDB.y or 0)
end

local function ApplyScale(f)
    if not f then return end
    local scale=tonumber(FWMDB.scale) or 1
    if scale < 0.60 then scale=0.60 end
    if scale > 1.50 then scale=1.50 end
    FWMDB.scale=scale
    f:SetScale(scale)
end

local function ChangeScale(f,delta)
    local old=tonumber(FWMDB.scale) or 1
    local new=old + (delta > 0 and 0.05 or -0.05)
    if new < 0.60 then new=0.60 end
    if new > 1.50 then new=1.50 end
    FWMDB.scale=new
    f:SetScale(new)
end

local function MakeMovable()
    local f=_G.ContainerFrameCombinedBags
    if not f or hooked then return false end

    f:SetMovable(true)
    f:EnableMouse(true)
    f:EnableMouseWheel(true)
    f:SetScript("OnMouseWheel",function(self,delta)
        if IsControlKeyDown() then ChangeScale(self,delta) end
    end)
    if f.SetClampedToScreen then f:SetClampedToScreen(true) end
    if f.SetUserPlaced then f:SetUserPlaced(true) end

    -- 專用拖曳區：覆蓋背包最上方整條標題列。
    -- 高度加大，避免一定要點中文字才能拖。
    local drag=CreateFrame("Frame",nil,f)
    drag:SetPoint("TOPLEFT",f,"TOPLEFT",8,-3)
    drag:SetPoint("TOPRIGHT",f,"TOPRIGHT",-38,-3) -- 右上關閉鈕保留正常點擊
    drag:SetHeight(42)
    drag:SetFrameLevel((f:GetFrameLevel() or 1)+20)
    drag:EnableMouse(true)
    drag:EnableMouseWheel(true)
    drag:RegisterForDrag("LeftButton")

    -- 標題拖曳區也可直接用滾輪縮放，不需要 Ctrl。
    drag:SetScript("OnMouseWheel",function(_,delta)
        if IsControlKeyDown() then ChangeScale(f,delta) end
    end)

    drag:SetScript("OnDragStart",function()
        f:StartMoving()
    end)

    drag:SetScript("OnDragStop",function()
        f:StopMovingOrSizing()
        SavePosition(f)
    end)

    -- 背包內的子元件可能會吃掉滾輪事件；把可安全設定的子 Frame
    -- 也轉交給同一個縮放函式，讓游標停在背包區域大多數位置都能縮放。
    local function HookWheelChildren(parent)
        if not parent or not parent.GetChildren then return end
        local children={parent:GetChildren()}
        for _,child in ipairs(children) do
            if child and child.EnableMouseWheel and child.HookScript then
                child:EnableMouseWheel(true)
                child:HookScript("OnMouseWheel",function(_,delta)
                    if IsControlKeyDown() then ChangeScale(f,delta) end
                end)
            end
        end
    end
    HookWheelChildren(f)

    f:HookScript("OnShow",function(self)
        C_Timer.After(0,function()
            if self:IsShown() then
                ApplyScale(self)
                if FWMDB.point then RestorePosition(self) end
            end
        end)
    end)

    ApplyScale(f)
    RestorePosition(f)
    hooked=true
    DEFAULT_CHAT_FRAME:AddMessage("|cff33ff66FWM - BY 老哥：|r合併背包 Ctrl＋全區滾輪縮放已載入")
    return true
end

local e=CreateFrame("Frame")
e:RegisterEvent("ADDON_LOADED")
e:RegisterEvent("PLAYER_LOGIN")
e:SetScript("OnEvent",function(_,event,name)
    if event=="ADDON_LOADED" and name==ADDON then
        FWMDB=FWMDB or {}
    end

    if MakeMovable() then return end

    -- 永恆服可能稍後才建立合併背包 Frame，短暫等待它出現。
    local tries=0
    local function Try()
        tries=tries+1
        if MakeMovable() or tries>=20 then return end
        C_Timer.After(.25,Try)
    end
    Try()
end)
