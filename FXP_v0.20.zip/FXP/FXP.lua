local ADDON=...
FXPDB=FXPDB or {}

local DEF={
 shown=true,locked=false,bgMode=1,halfAlpha=.55,border=true,
 showXP=true,showBonus=true,showLayer=true,minimapAngle=165,sizeMode=1,
 minimap={hide=false,minimapPos=165}
}
local function InitDB()
 for k,v in pairs(DEF) do
  if FXPDB[k]==nil then
   if type(v)=="table" then FXPDB[k]={} for a,b in pairs(v) do FXPDB[k][a]=b end
   else FXPDB[k]=v end
  end
 end
 FXPDB.minimap=FXPDB.minimap or {hide=false,minimapPos=FXPDB.minimapAngle or 165}
 FXPDB.worlds=FXPDB.worlds or {}
 FXPDB.nextNumber=FXPDB.nextNumber or 1
 -- Existing FWT numbering survives when the old add-on has been removed.
 if not FXPDB.layerMigrated and type(FWT_Data)=="table" and type(FWT_Data.worlds)=="table" then
  for id,n in pairs(FWT_Data.worlds) do if FXPDB.worlds[id]==nil then FXPDB.worlds[id]=n end end
  FXPDB.nextNumber=math.max(FXPDB.nextNumber,tonumber(FWT_Data.nextNumber) or 1)
  FXPDB.layerMigrated=true
 end
end

local function comma(n)
 local s=tostring(math.floor(tonumber(n) or 0)); local o=""
 while #s>3 do o=","..s:sub(-3)..o;s=s:sub(1,-4) end
 return s..o
end

-- ===== 主資訊框 =====
local f=CreateFrame("Frame","FXPFrame",UIParent,"BackdropTemplate")
f:SetFrameStrata("MEDIUM");f:SetClampedToScreen(true);f:SetMovable(true);f:EnableMouse(true);f:RegisterForDrag("LeftButton")
f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})

local text=f:CreateFontString(nil,"OVERLAY","GameFontNormal")
text:SetPoint("CENTER");text:SetJustifyH("CENTER")

local function BarHeight()
 return math.max(30,math.min(45,math.floor((tonumber(FXPDB.barHeight) or 30)+.5)))
end

local function ApplySize()
 local h=BarHeight()
 f:SetHeight(h)
 local fontPath,_,flags=text:GetFont()
 text:SetFont(fontPath,math.floor(h*.4+.5),flags)
end

local function ApplyLook()
 local mode=tonumber(FXPDB.bgMode) or 1
 local a=1
 if mode==2 then a=.55
 elseif mode==3 then a=0 end
 -- 全黑就是 RGB 0,0,0 + Alpha 1.0
 f:SetBackdropColor(0,0,0,a)
 if FXPDB.border then f:SetBackdropBorderColor(.47,.43,.26,.78)
 else f:SetBackdropBorderColor(0,0,0,0) end
end

local currentWorldID, currentWorldNumber
local latencyHome,latencyWorld,fps,addonMemory,addonCPU=0,0,0,"--","無資料"
local nextFPSAlertAt=0
local function YellowNotice(message)
 if DEFAULT_CHAT_FRAME then
  DEFAULT_CHAT_FRAME:AddMessage("[FXP] "..message,1,.82,0)
 else
  print("|cffffd100[FXP] "..message.."|r")
 end
end
local function CheckFPSAlert()
 if fps<=0 or fps>=30 then return end
 local now=GetTime and GetTime() or 0
 if now>=nextFPSAlertAt then
  YellowNotice("幀數低於 30，請注意")
  nextFPSAlertAt=now+60
 end
end
local function RefreshPerformance()
 if GetNetStats then
  local _,_,home,world=GetNetStats()
  latencyHome=tonumber(home) or 0;latencyWorld=tonumber(world) or 0
 end
 if GetFramerate then fps=math.floor((tonumber(GetFramerate()) or 0)+.5) end
 if UpdateAddOnMemoryUsage and GetAddOnMemoryUsage then
  local ok,total=pcall(function()
   UpdateAddOnMemoryUsage()
   local count=(C_AddOns and C_AddOns.GetNumAddOns and C_AddOns.GetNumAddOns())
    or (GetNumAddOns and GetNumAddOns()) or 0
   local n=0
   for i=1,count do n=n+(tonumber(GetAddOnMemoryUsage(i)) or 0) end
   return n
  end)
  if ok then
   addonMemory=(total>=1024) and string.format("%.1f MB",total/1024)
    or string.format("%.0f KB",total)
  end
 end
 -- Prefer the same already-formatted overall percentage used by Blizzard's
 -- performance tooltip. This API may not be present on every Forever build.
 addonCPU="無資料"
 if AddonList and AddonList.GetOverallMetric and Enum and Enum.AddOnProfilerMetric
  and ADDON_LIST_PERFORMANCE_AVERAGE_CPU then
  local ok,result=pcall(AddonList.GetOverallMetric,AddonList,
   ADDON_LIST_PERFORMANCE_AVERAGE_CPU,Enum.AddOnProfilerMetric.SessionAverageTime)
  if ok and type(result)=="string" then
   local percent=result:match("([%d%.]+)%s*%%")
   if percent then addonCPU=percent.."%" end
  end
 end
 if addonCPU=="無資料" and C_AddOnProfiler and C_AddOnProfiler.GetOverallMetric
  and Enum and Enum.AddOnProfilerMetric then
  local ok,ms=pcall(C_AddOnProfiler.GetOverallMetric,
   Enum.AddOnProfilerMetric.SessionAverageTime)
  if ok and type(ms)=="number" then
   addonCPU=string.format("%.2f ms/幀",ms)
  end
 end
end
local function DetectLayer()
 if IsInInstance and IsInInstance() then
  currentWorldID=nil; currentWorldNumber=nil
  return
 end
 local guid=UnitGUID("target")
 if not guid then return end
 local kind,_,w1,_,w2=strsplit("-",guid)
 if (kind~="Creature" and kind~="Vehicle") or not w1 or not w2 then return end
 local id=w1.."/"..w2
 if not FXPDB.worlds[id] then
  FXPDB.worlds[id]=FXPDB.nextNumber
  FXPDB.nextNumber=FXPDB.nextNumber+1
 end
 if currentWorldID and currentWorldID~=id then
  YellowNotice("位面變更："..tostring(currentWorldNumber).." → "..tostring(FXPDB.worlds[id]))
 end
 currentWorldID=id;currentWorldNumber=FXPDB.worlds[id]
end

local function UpdateText()
 local parts={
  "|cffffd100延遲|r |cffffffff（本地"..latencyHome.." ms）（世界"..latencyWorld.." ms）|r",
  "|cffffd100幀數|r |cffffffff"..fps.."|r",
  "|cffffd100記憶體|r |cffffffff"..addonMemory.."|r",
  "|cffffd100插件CPU|r |cffffffff"..addonCPU.."|r"
 }
 if FXPDB.showXP then
  parts[#parts+1]="|cffffd100經驗|r |cffffffff"..comma(UnitXP("player") or 0).." / "..comma(UnitXPMax("player") or 0).."|r"
 end
 if FXPDB.showBonus then
  local rested=GetXPExhaustion and GetXPExhaustion()
  local pct=(rested and rested>0) and 200 or 100
  parts[#parts+1]="|cffffd100加成|r |cff40ff40"..pct.."%|r"
 end
 if FXPDB.showLayer then
  local layer=currentWorldNumber and tostring(currentWorldNumber) or "待偵測"
  parts[#parts+1]="|cffffd100位面|r |cffffffff"..layer.."|r"
 end
 local localTime=date and date("%H:%M") or "--:--"
 parts[#parts+1]="|cffffd100時間|r |cffffffff"..localTime.."|r"
 text:SetText(table.concat(parts,"  |cffaaaaaa｜|r  "))
 local h=BarHeight()
 local fontSize=math.floor(h*.4+.5)
 local pad=math.floor(h*.8+.5)
 local fontPath,_,flags=text:GetFont()
 local maxWidth=math.max(250,UIParent:GetWidth()-24)
 for font=fontSize,9,-1 do
  text:SetFont(fontPath,font,flags)
  if text:GetStringWidth()+pad<=maxWidth then break end
 end
 f:SetWidth(math.min(maxWidth,text:GetStringWidth()+pad))
end

f:SetScript("OnDragStart",function(s)if not FXPDB.locked then s:StartMoving()end end)
f:SetScript("OnDragStop",function(s)
 s:StopMovingOrSizing()
 local p,_,rp,x,y=s:GetPoint(1);FXPDB.point=p;FXPDB.relPoint=rp;FXPDB.x=x;FXPDB.y=y
end)
local function RestoreMain()
 f:ClearAllPoints()
 if FXPDB.point then f:SetPoint(FXPDB.point,UIParent,FXPDB.relPoint or FXPDB.point,FXPDB.x or 0,FXPDB.y or 0)
 else f:SetPoint("TOP",UIParent,"TOP",0,-5) end
end

-- ===== BY 老哥系列設定視窗 =====
local cfg=CreateFrame("Frame","FXPSettingsFrame",UIParent,"BackdropTemplate")
table.insert(UISpecialFrames,"FXPSettingsFrame")
cfg:SetSize(590,455);cfg:SetPoint("CENTER",UIParent,"CENTER",FXPDB.panelX or -430,FXPDB.panelY or 0);cfg:SetClampedToScreen(true)
cfg:SetFrameStrata("DIALOG");cfg:SetMovable(true);cfg:EnableMouse(true)
cfg:RegisterForDrag("LeftButton");cfg:Hide()
cfg:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background-Dark",edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",tile=true,tileSize=32,edgeSize=32,insets={left=8,right=8,top=8,bottom=8}})
cfg:SetBackdropColor(.02,.025,.03,.99)
cfg:SetScript("OnDragStart",cfg.StartMoving)
cfg:SetScript("OnDragStop",function(self)
 self:StopMovingOrSizing()
 local x,y=self:GetCenter();local ux,uy=UIParent:GetCenter()
 if x and y and ux and uy then FXPDB.panelX=x-ux;FXPDB.panelY=y-uy end
end)
local logo=cfg:CreateTexture(nil,"ARTWORK")
logo:SetSize(62,62);logo:SetPoint("TOPLEFT",20,-22)
logo:SetTexture("Interface\\AddOns\\FXP\\FXP_B.tga")
local title=cfg:CreateFontString(nil,"OVERLAY","GameFontNormalHuge")
title:SetPoint("LEFT",cfg,"TOPLEFT",103,-40);title:SetScale(1.05)
title:SetText("|cffffd200FXP｜經驗加成及位面器 - BY老哥|r")
local rule=cfg:CreateTexture(nil,"ARTWORK");rule:SetColorTexture(1,.82,0,.9)
rule:SetPoint("TOPLEFT",100,-76);rule:SetPoint("TOPRIGHT",-20,-76);rule:SetHeight(1)
local close=CreateFrame("Button",nil,cfg,"UIPanelCloseButton");close:SetPoint("TOPRIGHT",-4,-4)

local function Button(label,parent,x,y,w,fn)
 local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
 b:SetSize(w or 92,25);b:SetPoint("TOPLEFT",x,y);b:SetText(label);b:SetScript("OnClick",fn)
 return b
end
local function Label(parent,content,x,y)
 local t=parent:CreateFontString(nil,"OVERLAY","GameFontNormal")
 t:SetPoint("TOPLEFT",x,y);t:SetText(content);return t
end
local tabs={};local pages={}
local function Tab(name,y,index)
 local t=Button(name,cfg,28,y,135,function()
  for n,p in ipairs(pages) do p:SetShown(n==index) end
  for n,b in ipairs(tabs) do b:SetEnabled(n~=index) end
 end)
 tabs[index]=t
 t:SetHeight(34)
 local page=CreateFrame("Frame",nil,cfg)
 page:SetPoint("TOPLEFT",185,-100);page:SetSize(375,295)
 pages[index]=page
 return page
end
local display=Tab("監視顯示",-118,1)
local appearance=Tab("外觀設定",-162,2)
local function Check(parent,label,x,y,key,fn)
 local c=CreateFrame("CheckButton",nil,parent,"UICheckButtonTemplate")
 c:SetPoint("TOPLEFT",x,y);c.text:SetText(label)
 c:SetScript("OnClick",function(self)FXPDB[key]=self:GetChecked() and true or false;if fn then fn()end end)
 c.Refresh=function()c:SetChecked(FXPDB[key] and true or false)end
 return c
end
Label(display,"|cffffd100監視內容|r",0,-5)
local cShown=Check(display,"顯示資訊框",0,-35,"shown",function()f:SetShown(FXPDB.shown)end)
local cXP=Check(display,"顯示經驗值 / 升級經驗值",0,-68,"showXP",UpdateText)
local cBonus=Check(display,"顯示經驗加成百分比",0,-101,"showBonus",UpdateText)
local cLayer=Check(display,"顯示目前位面",0,-134,"showLayer",UpdateText)
local cLock=Check(display,"鎖定資訊框位置",0,-167,"locked")
Label(display,"|cffdddddd位面需先選取地圖上的 NPC 或怪物偵測。|r",0,-218)
Label(appearance,"|cffffd100資訊框外觀|r",0,-5)
local cBorder=Check(appearance,"顯示淡色細邊框",0,-38,"border",ApplyLook)
Label(appearance,"|cffffd100背景：|r",0,-88)
Button("全黑",appearance,70,-79,82,function()FXPDB.bgMode=1;ApplyLook()end)
Button("半透明",appearance,160,-79,82,function()FXPDB.bgMode=2;ApplyLook()end)
Button("透明",appearance,250,-79,82,function()FXPDB.bgMode=3;ApplyLook()end)
Label(appearance,"|cffffd100大小：|r",0,-138)
local heightSlider=CreateFrame("Slider",nil,appearance,"UISliderTemplate")
local sliderReady=false
heightSlider:SetOrientation("HORIZONTAL")
heightSlider:SetPoint("TOPLEFT",70,-165)
heightSlider:SetSize(230,17)
heightSlider:SetMinMaxValues(30,45)
heightSlider:SetValueStep(1)
if heightSlider.SetObeyStepOnDrag then heightSlider:SetObeyStepOnDrag(true) end
local left=CreateFrame("Button",nil,appearance,"UIPanelScrollUpButtonTemplate")
left:SetSize(22,22);left:SetPoint("RIGHT",heightSlider,"LEFT",-7,0)
local right=CreateFrame("Button",nil,appearance,"UIPanelScrollDownButtonTemplate")
right:SetSize(22,22);right:SetPoint("LEFT",heightSlider,"RIGHT",7,0)
for _,b in ipairs({left,right}) do
 for _,m in ipairs({"GetNormalTexture","GetPushedTexture","GetDisabledTexture"}) do
  local tx=b[m] and b[m](b);if tx then tx:SetRotation(math.pi/2) end
 end
end
local function SetHeightSlider(v)
 v=math.max(30,math.min(45,math.floor(v+.5)))
 heightSlider:SetValue(v)
end
left:SetScript("OnClick",function() SetHeightSlider((tonumber(FXPDB.barHeight) or 30)-1) end)
right:SetScript("OnClick",function() SetHeightSlider((tonumber(FXPDB.barHeight) or 30)+1) end)
heightSlider:SetScript("OnValueChanged",function(_,v)
 if not sliderReady then return end
 local h=math.max(30,math.min(45,math.floor(v+.5)))
 FXPDB.barHeight=h
 ApplySize();UpdateText()
end)
heightSlider:SetValue(tonumber(FXPDB.barHeight) or 30)
sliderReady=true
Label(appearance,"|cffdddddd拖曳可調整遊戲畫面位置。|r",0,-200)
Button("恢復預設",cfg,28,-402,130,function()
 FXPDB.point=nil;FXPDB.relPoint=nil;FXPDB.x=nil;FXPDB.y=nil;RestoreMain()
 FXPDB.panelX=-430;FXPDB.panelY=0
 cfg:ClearAllPoints();cfg:SetPoint("CENTER",UIParent,"CENTER",-430,0)
end)
Button("完成",cfg,460,-402,100,function()cfg:Hide()end)
local function RefreshCfg()
 cShown.Refresh();cXP.Refresh();cBonus.Refresh();cLayer.Refresh();cBorder.Refresh();cLock.Refresh()
 if heightSlider:GetValue()~=BarHeight() then heightSlider:SetValue(BarHeight()) end
end
cfg:SetScript("OnShow",RefreshCfg)
pages[2]:Hide();tabs[1]:Disable()

-- ===== Minimap button =====
-- 優先使用 LibDataBroker + LibDBIcon 標準註冊。
-- 這是常見 Minimap Button Bag / 收納器相容路徑。
-- 若永恆服沒有這些函式庫，才回退成 FWT 同款本機小地圖按鈕，不報錯。
local mini

local function OpenSettings()
 if cfg:IsShown()then cfg:Hide()else cfg:Show()end
end
local function ToggleFrame()
 FXPDB.shown=not FXPDB.shown;if FXPDB.shown then f:Show()else f:Hide()end
end

local function SetupStandardMinimap()
 local LibStub=_G.LibStub
 if not LibStub then return false end
 local LDB=LibStub("LibDataBroker-1.1",true)
 local DBIcon=LibStub("LibDBIcon-1.0",true)
 if not LDB or not DBIcon then return false end
 local obj=LDB:NewDataObject("FXP",{
  type="launcher",
  text="FXP",
  icon="Interface\\AddOns\\FXP\\FXP_X.tga",
  OnClick=function(_,button)if button=="RightButton"then ToggleFrame()else OpenSettings()end end,
  OnTooltipShow=function(tt)
   tt:AddLine("FXP - BY 老哥")
   tt:AddLine("左鍵：開啟設定",1,1,1);tt:AddLine("右鍵：顯示 / 隱藏資訊框",1,1,1)
  end
 })
 if not DBIcon:IsRegistered("FXP") then DBIcon:Register("FXP",obj,FXPDB.minimap) end
 return true
end

local function SetupFallbackMinimap()
 mini=CreateFrame("Button","FXPMinimapButton",Minimap)
 mini:SetSize(38,38);mini:SetFrameStrata("MEDIUM");mini:SetFrameLevel((Minimap:GetFrameLevel()or 0)+8)
 mini:RegisterForClicks("LeftButtonUp","RightButtonUp");mini:RegisterForDrag("LeftButton")
 local ic=mini:CreateTexture(nil,"ARTWORK");ic:SetAllPoints();ic:SetTexture("Interface\\AddOns\\FXP\\FXP_X.tga")
 local function Pos()
  local r=math.max(Minimap:GetWidth()or 140,Minimap:GetHeight()or 140)/2+18
  local a=math.rad(FXPDB.minimapAngle or 165);mini:ClearAllPoints();mini:SetPoint("CENTER",Minimap,"CENTER",math.cos(a)*r,math.sin(a)*r)
 end
 local dragging=false
 mini:SetScript("OnDragStart",function(self)
  dragging=true;self:SetScript("OnUpdate",function()
   local mx,my=Minimap:GetCenter();if not mx then return end
   local x,y=GetCursorPosition();local sc=UIParent:GetEffectiveScale();x,y=x/sc,y/sc
   FXPDB.minimapAngle=math.deg(math.atan2(y-my,x-mx));Pos()
  end)
 end)
 mini:SetScript("OnDragStop",function(self)self:SetScript("OnUpdate",nil);Pos();C_Timer.After(.1,function()dragging=false end)end)
 mini:SetScript("OnClick",function(_,button)if dragging then return end;if button=="RightButton"then ToggleFrame()else OpenSettings()end end)
 mini:SetScript("OnEnter",function(self)GameTooltip:SetOwner(self,"ANCHOR_LEFT");GameTooltip:SetText("FXP - BY 老哥");GameTooltip:AddLine("左鍵：開啟設定",1,1,1);GameTooltip:AddLine("右鍵：顯示 / 隱藏資訊框",1,1,1);GameTooltip:Show()end)
 mini:SetScript("OnLeave",function()GameTooltip:Hide()end)
 Pos()
end

local ev=CreateFrame("Frame")
for _,e in ipairs({"PLAYER_LOGIN","PLAYER_XP_UPDATE","UPDATE_EXHAUSTION","PLAYER_LEVEL_UP","PLAYER_TARGET_CHANGED","PLAYER_ENTERING_WORLD"})do ev:RegisterEvent(e)end
ev:SetScript("OnEvent",function(_,e)
 if e=="PLAYER_LOGIN"then
  InitDB()
  if FXPDB.barHeight==nil then
   local legacy=tonumber(FXPDB.sizeMode) or 1
   FXPDB.barHeight=(legacy==3 and 45) or (legacy==2 and 37) or 30
  end
  if not FXPDB.topBarMigrated then
   FXPDB.point=nil;FXPDB.relPoint=nil;FXPDB.x=nil;FXPDB.y=nil
   FXPDB.topBarMigrated=true
  end
  RestoreMain();ApplySize();ApplyLook()
  if FXPDB.shown then f:Show()else f:Hide()end
  if not SetupStandardMinimap() then SetupFallbackMinimap() end
  RefreshPerformance()
  if C_Timer and C_Timer.NewTicker then
   C_Timer.NewTicker(2,function()
    RefreshPerformance();CheckFPSAlert()
    if FXPDB.shown then UpdateText() end
   end)
  end
 end
 if e=="PLAYER_TARGET_CHANGED" or e=="PLAYER_ENTERING_WORLD" then DetectLayer() end
 UpdateText()
end)

SLASH_FXP1="/fxp"
SlashCmdList["FXP"]=function(msg)
 msg=(msg or ""):lower():match("^%s*(.-)%s*$")
 if msg=="show"then FXPDB.shown=true;f:Show()
 elseif msg=="hide"then FXPDB.shown=false;f:Hide()
 elseif msg=="reset"then FXPDB.point=nil;FXPDB.relPoint=nil;FXPDB.x=nil;FXPDB.y=nil;RestoreMain()
 else OpenSettings()end
end
