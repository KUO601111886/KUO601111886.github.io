local ADDON = ...
local F = CreateFrame("Frame")
local DB

local defaults = {
  size = 24,
  gap = 8,
  background = "TRANSPARENT",
  shown = true,
  orientation = "VERTICAL",
  minimap = {},
  minimapAngle = 165,
  partyX = 330, partyY = 90,
  selfX = 0, selfY = -150,
  panelPoint = "CENTER", panelX = -300, panelY = 80,
}

local function copyDefaults()
  FDEC_DB = FDEC_DB or {}
  for k,v in pairs(defaults) do if FDEC_DB[k] == nil then FDEC_DB[k] = v end end
  DB = FDEC_DB
  -- v0.06：ICON 大小維持 FBUFF v1.99 範圍；隊友「空隙」改為 8～100px。
  if type(DB.size) ~= "number" or DB.size < 24 or DB.size > 72 then DB.size = 24 end
  if type(DB.gap) ~= "number" then DB.gap = 8 end
  DB.gap = math.max(8, math.min(100, DB.gap))
  if type(DB.panelPoint) ~= "string" then DB.panelPoint = "CENTER" end
  if type(DB.panelX) ~= "number" then DB.panelX = -300 end
  if type(DB.panelY) ~= "number" then DB.panelY = 80 end
  if DB.shown == nil then DB.shown = true end
  if DB.background ~= "BLACK" then DB.background = "TRANSPARENT" end
  if DB.orientation ~= "HORIZONTAL" then DB.orientation = "VERTICAL" end
  if type(DB.minimap) ~= "table" then DB.minimap = {} end
  if type(DB.minimapAngle) ~= "number" then DB.minimapAngle = 165 end
end

-- Friendly dispels. First known spell wins. Types are used by Forever's AuraContainer.
local classCures = {
  PRIEST = {
    { spells = {527}, types = { Magic=true } },                    -- current Forever Purify: Magic
    { spells = {213634}, types = { Disease=true } },               -- Purify Disease
  },
  PALADIN = {
    { spells = {4987}, types = { Magic=true, Poison=true, Disease=true } },
    { spells = {1152}, types = { Poison=true, Disease=true } }, -- Paladin Purify (Forever)
  },
  DRUID = {
    { spells = {88423}, types = { Magic=true, Curse=true, Poison=true } },
    { spells = {2782}, types = { Curse=true, Poison=true } },      -- Remove Corruption
  },
  SHAMAN = {
    { spells = {77130}, types = { Magic=true, Curse=true } },
    { spells = {51886}, types = { Curse=true } },                  -- Cleanse Spirit
  },
  MAGE = {
    { spells = {475}, types = { Curse=true } },
  },
  MONK = {
    { spells = {115450}, types = { Magic=true, Poison=true, Disease=true } },
    { spells = {218164}, types = { Poison=true, Disease=true } },
  },
  EVOKER = {
    { spells = {360823}, types = { Poison=true } },
    { spells = {374251}, types = { Poison=true, Disease=true, Curse=true } },
  },
}

local cureSpell, cureTypes
local function spellKnown(id)
  if C_SpellBook and C_SpellBook.IsSpellKnown then
    local ok, known = pcall(C_SpellBook.IsSpellKnown, id)
    if ok and known then return true end
  end
  if IsSpellKnown then
    local ok, known = pcall(IsSpellKnown, id)
    if ok and known then return true end
  end
  return false
end
local function spellName(id)
  if C_Spell and C_Spell.GetSpellName then return C_Spell.GetSpellName(id) end
  if GetSpellInfo then return GetSpellInfo(id) end
end
local function detectCure()
  cureSpell, cureTypes = nil, nil
  local _, class = UnitClass("player")
  local list = classCures[class]
  if not list then return end
  for _, entry in ipairs(list) do
    for _, id in ipairs(entry.spells) do
      if spellKnown(id) then
        local name = spellName(id)
        if name and name ~= "" then
          cureSpell, cureTypes = name, entry.types
          return
        end
      end
    end
  end
end

local partyAnchor = CreateFrame("Frame", "FDEC_PartyAnchor", UIParent)
partyAnchor:SetSize(40, 160)
partyAnchor:SetClampedToScreen(true)
local selfAnchor = CreateFrame("Frame", "FDEC_SelfAnchor", UIParent)
selfAnchor:SetSize(40,40)
selfAnchor:SetClampedToScreen(true)

local buttons = {}
local saveAnchor
local function makeButton(unit, parent, index)
  local b = CreateFrame("Button", "FDEC_Button_"..unit, parent, "SecureActionButtonTemplate,SecureUnitButtonTemplate")
  b.unit = unit
  b.index = index
  b:RegisterForClicks("LeftButtonUp")
  b:RegisterForDrag("LeftButton")
  b:SetAttribute("unit", unit)
  b:SetAttribute("type1", "spell")

  b.preview = b:CreateTexture(nil, "BACKGROUND")
  b.preview:SetAllPoints()
  b.preview:SetColorTexture(0.00, 0.00, 0.00, 0.45)
  b.preview:Show()

  -- 解鎖定位格：四邊 1px 細金黃框，不覆蓋中央內容。
  b.previewBorders = {}
  local gold = {0.82, 0.68, 0.28, 0.48}
  local top = b:CreateTexture(nil, "OVERLAY"); top:SetColorTexture(unpack(gold)); top:SetPoint("TOPLEFT"); top:SetPoint("TOPRIGHT"); top:SetHeight(1)
  local bottom = b:CreateTexture(nil, "OVERLAY"); bottom:SetColorTexture(unpack(gold)); bottom:SetPoint("BOTTOMLEFT"); bottom:SetPoint("BOTTOMRIGHT"); bottom:SetHeight(1)
  local left = b:CreateTexture(nil, "OVERLAY"); left:SetColorTexture(unpack(gold)); left:SetPoint("TOPLEFT"); left:SetPoint("BOTTOMLEFT"); left:SetWidth(1)
  local right = b:CreateTexture(nil, "OVERLAY"); right:SetColorTexture(unpack(gold)); right:SetPoint("TOPRIGHT"); right:SetPoint("BOTTOMRIGHT"); right:SetWidth(1)
  b.previewBorders = {top,bottom,left,right}
  for _,tex in ipairs(b.previewBorders) do tex:Show() end

  if CreateFrame and Enum and Enum.CustomAuraButtonDispelTypeTextureStyle then
    local c = CreateFrame("AuraContainer", nil, b, "CustomAuraContainerTemplate")
    c:SetAllPoints(b)
    c:AddAuraSlot("FDEC_DISPELLABLE", "HARMFUL", {
      sortMethod = 0,
      sortDirection = 0,
      candidateFilters = { includeDispelTypes = {} },
      initializeFrame = function(ab)
        ab:EnableMouse(false)
        ab:ClearAllPoints()
        ab:SetAllPoints(b)
        ab:SetFrameLevel(b:GetFrameLevel()+2)
        local auraBorder = ab:CreateTexture(nil, "OVERLAY")
        auraBorder:SetAllPoints(ab)
        auraBorder:SetColorTexture(1.00, 1.00, 1.00, 1)
        auraBorder:Hide()
        if ab.ClearDispelTypeTextures then ab:ClearDispelTypeTextures() end
        if ab.AddDispelTypeTexture then
          ab:AddDispelTypeTexture(auraBorder, {
            showIcon = true,
            showWhenHarmful = true,
            showWhenHelpful = false,
            showWithoutDispelType = false,
            style = Enum.CustomAuraButtonDispelTypeTextureStyle.PreserveAsset,
          })
        end
      end,
    })
    c:SetUnit(unit)
    c:SetShown(true)
    c:SetEnabled(true)
    b.auraContainer = c
  end

  -- v0.10：拖曳直接掛在 Secure Button 本身，避免透明 DragOverlay 蓋住左鍵施法。
  b:SetScript("OnDragStart", function(btn)
    if DB and IsControlKeyDown() and not (InCombatLockdown and InCombatLockdown()) then
      local anchor = (btn.unit == "player") and selfAnchor or partyAnchor
      btn._fdecDragging = anchor
      anchor:StartMoving()
    end
  end)
  b:SetScript("OnDragStop", function(btn)
    local anchor = btn._fdecDragging
    if not anchor then return end
    btn._fdecDragging = nil
    anchor:StopMovingOrSizing()
    saveAnchor(anchor, btn.unit == "player" and "self" or "party")
  end)

  buttons[#buttons+1] = b
  return b
end

local party = {}
for i=1,4 do party[i] = makeButton("party"..i, partyAnchor, i) end
local selfButton = makeButton("player", selfAnchor, 0)

local function updateSecure()
  if InCombatLockdown and InCombatLockdown() then return end
  detectCure()
  for _,b in ipairs(buttons) do
    -- Forever：直接使用 SecureActionButton 的 spell + unit，避免 macrotext 點擊不施法。
    b:SetAttribute("type1", cureSpell and "spell" or nil)
    b:SetAttribute("spell1", cureSpell)
    b:SetAttribute("spell", cureSpell)
    b:SetAttribute("unit", b.unit)
    if b.auraContainer then
      local f = { includeDispelTypes = cureTypes or {} }
      b.auraContainer:SetAuraSlotCandidateFilters("FDEC_DISPELLABLE", f)
      b.auraContainer:SetUnit(b.unit)
    end
  end
end

local function layout()
  partyAnchor:ClearAllPoints()
  partyAnchor:SetPoint("CENTER", UIParent, "CENTER", DB.partyX, DB.partyY)
  selfAnchor:ClearAllPoints()
  selfAnchor:SetPoint("CENTER", UIParent, "CENTER", DB.selfX, DB.selfY)
  local step = DB.size + DB.gap
  if DB.orientation == "HORIZONTAL" then
    partyAnchor:SetSize(step*3 + DB.size, DB.size)
  else
    partyAnchor:SetSize(DB.size, step*3 + DB.size)
  end
  selfAnchor:SetSize(DB.size, DB.size)
  for i,b in ipairs(party) do
    b:SetSize(DB.size, DB.size)
    b:ClearAllPoints()
    if DB.orientation == "HORIZONTAL" then
      b:SetPoint("LEFT", partyAnchor, "LEFT", (i-1)*step, 0)
    else
      b:SetPoint("TOP", partyAnchor, "TOP", 0, -((i-1)*step))
    end
  end
  selfButton:SetSize(DB.size, DB.size)
  selfButton:ClearAllPoints(); selfButton:SetPoint("CENTER", selfAnchor, "CENTER")
  partyAnchor:SetShown(DB.shown ~= false)
  selfAnchor:SetShown(DB.shown ~= false)
end

local function updateBackground()
  local alpha = (DB and DB.background == "BLACK") and 1.0 or 0.45
  for _,b in ipairs(buttons) do
    b.preview:SetColorTexture(0, 0, 0, alpha)
    b.preview:Show()
    if b.previewBorders then for _,tex in ipairs(b.previewBorders) do tex:Show() end end
  end
  partyAnchor:SetMovable(true)
  selfAnchor:SetMovable(true)
  if FDEC_PartyDragOverlay then FDEC_PartyDragOverlay:Hide() end
  if FDEC_SelfDragOverlay then FDEC_SelfDragOverlay:Hide() end
end

saveAnchor = function(frame, which)
  local x,y = frame:GetCenter(); local ux,uy = UIParent:GetCenter()
  if x and ux then
    if which == "party" then DB.partyX,DB.partyY=x-ux,y-uy else DB.selfX,DB.selfY=x-ux,y-uy end
  end
end

local function makeDragOverlay(anchor, which)
  local d = CreateFrame("Frame", nil, UIParent)
  d:SetFrameStrata("TOOLTIP")
  d:EnableMouse(false)
  d:SetMovable(true)
  d:RegisterForDrag("LeftButton")
  d:Hide()
  d:SetScript("OnDragStart", function(s)
    -- 監控區只允許 Ctrl + 左鍵拖曳；戰鬥中不移動 Secure Frame。
    if DB and IsControlKeyDown() and not (InCombatLockdown and InCombatLockdown()) then
      s.dragging = true
      anchor:StartMoving()
    end
  end)
  d:SetScript("OnDragStop", function(s)
    if not s.dragging then return end
    s.dragging = nil
    anchor:StopMovingOrSizing()
    saveAnchor(anchor, which)
    s:ClearAllPoints()
    s:SetAllPoints(anchor)
  end)
  d:SetScript("OnUpdate", function(s)
    if s:IsShown() then
      s:ClearAllPoints()
      s:SetAllPoints(anchor)
    end
  end)
  return d
end

FDEC_PartyDragOverlay = makeDragOverlay(partyAnchor, "party")
FDEC_SelfDragOverlay = makeDragOverlay(selfAnchor, "self")

-- =========================================================
-- FDEC 設定視窗：直接沿用 FXP v0.63 母版外觀
-- =========================================================
local cfg = CreateFrame("Frame", "FDEC_Settings", UIParent, "PortraitFrameTemplate")
cfg:SetSize(530, 540)
cfg:SetPoint("CENTER", UIParent, "CENTER", defaults.panelX or -300, defaults.panelY or 80)
cfg:SetFrameStrata("DIALOG"); cfg:SetClampedToScreen(true)
cfg:SetMovable(true); cfg:EnableMouse(true); cfg:RegisterForDrag("LeftButton")
cfg:SetScript("OnDragStart", function(self)
  if InCombatLockdown and InCombatLockdown() then return end
  self:StartMoving()
  self._fdecMoving = true
end)

local portrait = (cfg.PortraitContainer and cfg.PortraitContainer.portrait) or cfg.portrait or cfg.Portrait
if portrait then portrait:SetTexture(3586269) end
local nativeTitle = (cfg.TitleContainer and cfg.TitleContainer.TitleText) or cfg.TitleText
if nativeTitle then nativeTitle:SetText("") end
if cfg.Inset then cfg.Inset:Hide() end
if cfg.Bg and cfg.Bg.Hide then cfg.Bg:Hide() end

local function atlas(tex,name)
  if not tex or not tex.SetAtlas then return false end
  return pcall(tex.SetAtlas,tex,name,false)
end

local top=CreateFrame("Frame",nil,cfg)
top:SetPoint("TOPLEFT",cfg,"TOPLEFT",2,-23); top:SetPoint("TOPRIGHT",cfg,"TOPRIGHT",-2,-23); top:SetHeight(76)
local topBG=top:CreateTexture(nil,"BACKGROUND"); topBG:SetAllPoints(top)
if not atlas(topBG,"groupfinder-roles-background") then topBG:SetTexture(8373327) end
local streak=top:CreateTexture(nil,"BORDER"); streak:SetPoint("TOPLEFT"); streak:SetPoint("TOPRIGHT"); streak:SetHeight(43)
if not atlas(streak,"UI-Frame-TopTileStreaks") then streak:SetTexture(1723833) end

local body=CreateFrame("Frame",nil,cfg,"InsetFrameTemplate")
body:SetPoint("TOPLEFT",cfg,"TOPLEFT",3,-100); body:SetPoint("BOTTOMRIGHT",cfg,"BOTTOMRIGHT",-3,3)
if body.Bg and body.Bg.SetAlpha then body.Bg:SetAlpha(.90); if body.TopEdge then body.TopEdge:Hide() end end
local inside=body:CreateTexture(nil,"BORDER",nil,1)
inside:SetPoint("TOPLEFT",body,"TOPLEFT",0,5); inside:SetPoint("TOPRIGHT",body,"TOPRIGHT",0,5)
inside:SetPoint("BOTTOMLEFT"); inside:SetPoint("BOTTOMRIGHT")
if not atlas(inside,"common-insideframe") then inside:SetTexture(8124462) end

local dividerLayer=CreateFrame("Frame",nil,cfg); dividerLayer:SetAllPoints(cfg)
dividerLayer:SetFrameStrata(cfg:GetFrameStrata()); dividerLayer:SetFrameLevel(math.max(cfg:GetFrameLevel(),body:GetFrameLevel())+20)
local divider=dividerLayer:CreateTexture(nil,"OVERLAY",nil,7); divider:SetSize(16,524); divider:SetPoint("CENTER",cfg,"TOP",0,-95)
if not atlas(divider,"common-framedivider") then divider:SetTexture(8245174) end
divider:SetTexCoord(0,1,0,1); if divider.SetRotation then divider:SetRotation(math.pi/2) end

local titleLayer=CreateFrame("Frame",nil,cfg); titleLayer:SetAllPoints(cfg)
titleLayer:SetFrameStrata(cfg:GetFrameStrata()); titleLayer:SetFrameLevel(math.max(cfg:GetFrameLevel(),body:GetFrameLevel())+30)
local mainTitle=titleLayer:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
local tf,ts,tflags=mainTitle:GetFont(); if tf and ts then mainTitle:SetFont(tf,ts+2,tflags) end
mainTitle:SetPoint("CENTER",cfg,"TOP",0,-58); mainTitle:SetText("老哥UI｜一鍵驅除｜FDEC")

local function CreateRecipeMenu(parent,text)
  local b=CreateFrame("Button",nil,parent); b:SetSize(150,48)
  local bg=b:CreateTexture(nil,"BACKGROUND"); b.bg=bg; bg:SetAllPoints()
  if not pcall(bg.SetAtlas,bg,"Professions_Recipe_Active") then bg:SetTexture(4417031) end
  local label=b:CreateFontString(nil,"OVERLAY","GameFontNormal"); b.label=label; label:SetPoint("CENTER")
  local f,z,fl=label:GetFont(); if f and z then label:SetFont(f,z+2,fl or "") end; label:SetText(text)
  return b
end
local menu1=CreateRecipeMenu(cfg,"監視設定"); menu1:SetPoint("TOPLEFT",body,"TOPLEFT",17,-28)
menu1.bg:SetAlpha(1); menu1.label:SetTextColor(1,.82,0)

local verticalDivider=cfg:CreateTexture(nil,"OVERLAY",nil,7); verticalDivider:SetSize(2,405)
verticalDivider:SetPoint("TOP",body,"TOPLEFT",183,-35)
if not pcall(verticalDivider.SetAtlas,verticalDivider,"Talents-divider-vertical-c60") then verticalDivider:SetTexture(8116735) end

local page=CreateFrame("Frame",nil,cfg); page:SetPoint("TOPLEFT",body,"TOPLEFT",205,-24); page:SetPoint("BOTTOMRIGHT",body,"BOTTOMRIGHT",-24,54)
local function Check(label,y)
  local c=CreateFrame("CheckButton",nil,page,"UICheckButtonTemplate"); c:SetPoint("TOPLEFT",0,y)
  c.text:ClearAllPoints(); c.text:SetPoint("LEFT",c,"RIGHT",4,1); c.text:SetText(label)
  local f,z,fl=c.text:GetFont(); if f and z then c.text:SetFont(f,z+1,fl or "") end
  c.text:SetTextColor(1,1,1,1); c.text:SetShadowColor(0,0,0,0); c.text:SetShadowOffset(0,0)
  return c
end
local cShown=Check("顯示監視塊",-4)
cShown:SetScript("OnClick",function(self)
  PlaySound(856); if InCombatLockdown and InCombatLockdown() then self:SetChecked(DB.shown~=false); return end
  DB.shown=self:GetChecked() and true or false; layout()
end)
local function NativeButton(label,x,y,w)
  local b=CreateFrame("Button",nil,page,"MainMenuFrameButtonTemplate"); b:SetSize(w or 110,32); b:SetPoint("TOPLEFT",x,y); b:SetText(label)
  local fs=b:GetFontString(); if fs then local f,z=fs:GetFont(); fs:SetFont(f,z,""); fs:SetTextColor(1,1,1,1); fs:SetShadowColor(0,0,0,0); fs:SetShadowOffset(0,0) end
  return b
end
local blackBtn=NativeButton("全黑",0,-42,110)
local transparentBtn=NativeButton("半透明",120,-42,110)
local function RefreshBackgroundButtons()
  if DB.background=="BLACK" then blackBtn:Disable(); transparentBtn:Enable()
  else blackBtn:Enable(); transparentBtn:Disable() end
end
local blackHit=CreateFrame("Button",nil,page); blackHit:SetAllPoints(blackBtn); blackHit:SetFrameLevel(blackBtn:GetFrameLevel()+5)
local transparentHit=CreateFrame("Button",nil,page); transparentHit:SetAllPoints(transparentBtn); transparentHit:SetFrameLevel(transparentBtn:GetFrameLevel()+5)
blackHit:SetScript("OnClick",function()
  PlaySound(856); DB.background="BLACK"; updateBackground(); RefreshBackgroundButtons()
end)
transparentHit:SetScript("OnClick",function()
  PlaySound(856); DB.background="TRANSPARENT"; updateBackground(); RefreshBackgroundButtons()
end)
local verticalBtn=NativeButton("直立顯示",0,-92,110)
local horizontalBtn=NativeButton("橫式顯示",120,-92,110)
local function RefreshOrientation()
  if DB.orientation=="HORIZONTAL" then verticalBtn:Disable(); horizontalBtn:Enable() else verticalBtn:Enable(); horizontalBtn:Disable() end
end
local vHit=CreateFrame("Button",nil,page); vHit:SetAllPoints(verticalBtn); vHit:SetFrameLevel(verticalBtn:GetFrameLevel()+5)
local hHit=CreateFrame("Button",nil,page); hHit:SetAllPoints(horizontalBtn); hHit:SetFrameLevel(horizontalBtn:GetFrameLevel()+5)
vHit:SetScript("OnClick",function() if InCombatLockdown and InCombatLockdown() then return end; PlaySound(856); DB.orientation="VERTICAL"; layout(); RefreshOrientation() end)
hHit:SetScript("OnClick",function() if InCombatLockdown and InCombatLockdown() then return end; PlaySound(856); DB.orientation="HORIZONTAL"; layout(); RefreshOrientation() end)

local function Label(content,y)
  local t=page:CreateFontString(nil,"OVERLAY","GameFontNormal"); t:SetPoint("TOPLEFT",5,y); t:SetText(content); return t
end
Label("ICON 大小",-155)
local sizeSlider=CreateFrame("Frame","FDECSizeSlider",page,"MinimalSliderWithSteppersTemplate")
sizeSlider:SetSize(295,30); sizeSlider:SetPoint("TOPLEFT",page,"TOPLEFT",0,-184)
local sizeReady=false; sizeSlider:Init(defaults.size or 24,24,72,48,nil)
sizeSlider:RegisterCallback(MinimalSliderWithSteppersMixin.Event.OnValueChanged,function(_,v)
  if not sizeReady or (InCombatLockdown and InCombatLockdown()) then return end
  DB.size=math.max(24,math.min(72,math.floor(v+.5))); layout()
end); sizeReady=true

Label("隊友方塊間距",-235)
local gapSlider=CreateFrame("Frame","FDECGapSlider",page,"MinimalSliderWithSteppersTemplate")
gapSlider:SetSize(295,30); gapSlider:SetPoint("TOPLEFT",page,"TOPLEFT",0,-264)
local gapReady=false; gapSlider:Init(defaults.gap or 8,8,100,92,nil)
gapSlider:RegisterCallback(MinimalSliderWithSteppersMixin.Event.OnValueChanged,function(_,v)
  if not gapReady or (InCombatLockdown and InCombatLockdown()) then return end
  DB.gap=math.max(8,math.min(100,math.floor(v+.5))); layout()
end); gapReady=true

local function WhiteText(b)
  local fs=b:GetFontString(); if fs then local f,z=fs:GetFont(); fs:SetFont(f,z,""); fs:SetTextColor(1,1,1,1); fs:SetShadowColor(0,0,0,0); fs:SetShadowOffset(0,0) end
end
local resetButton=CreateFrame("Button",nil,cfg,"MainMenuFrameButtonTemplate"); resetButton:SetSize(155,32)
resetButton:SetPoint("BOTTOMLEFT",body,"BOTTOMLEFT",14.5,33); resetButton:SetText("恢復預設"); WhiteText(resetButton)
resetButton:SetScript("OnClick",function()
  if InCombatLockdown and InCombatLockdown() then return end; PlaySound(856)
  DB.partyX,DB.partyY=defaults.partyX,defaults.partyY; DB.selfX,DB.selfY=defaults.selfX,defaults.selfY
  DB.size,DB.gap=defaults.size,defaults.gap; DB.orientation="VERTICAL"; DB.shown=true; DB.background=defaults.background
  layout(); updateBackground(); cShown:SetChecked(true)
  sizeSlider:SetValue(DB.size); gapSlider:SetValue(DB.gap); RefreshOrientation(); RefreshBackgroundButtons()
end)
local doneButton=CreateFrame("Button",nil,cfg,"MainMenuFrameButtonTemplate"); doneButton:SetSize(155,32)
doneButton:SetPoint("BOTTOMRIGHT",body,"BOTTOMRIGHT",-25,33); doneButton:SetText("設定完成"); WhiteText(doneButton)
doneButton:SetScript("OnClick",function() PlaySound(856); cfg:Hide() end)
local versionText=cfg:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall"); versionText:SetPoint("BOTTOM",body,"BOTTOM",0,27); versionText:SetText("v0.24")

cfg:Hide(); table.insert(UISpecialFrames,"FDEC_Settings")
local function StopConfigMoving(self)
  if self._fdecMoving then
    self:StopMovingOrSizing()
    self._fdecMoving = nil
    if DB then
      local x,y=self:GetCenter(); local ux,uy=UIParent:GetCenter()
      if x and y and ux and uy then DB.panelPoint="CENTER"; DB.panelX=x-ux; DB.panelY=y-uy end
    end
  end
end
cfg:SetScript("OnDragStop",StopConfigMoving)
cfg:SetScript("OnMouseUp",function(self) StopConfigMoving(self) end)
cfg:SetScript("OnShow",function()
  if not DB then return end
  PlaySound(850); cShown:SetChecked(DB.shown~=false)
  sizeSlider:SetValue(DB.size); gapSlider:SetValue(DB.gap); RefreshOrientation(); RefreshBackgroundButtons()
end)
cfg:SetScript("OnHide",function(self)
  StopConfigMoving(self)
  PlaySound(850)
end)

local function OpenSettings()
  if not DB then return end
  if cfg:IsShown() then cfg:Hide() else cfg:Show() end
end

-- FXP v0.63 同款標準小地圖按鈕
local mini
local function SetupStandardMinimap()
  local LibStub=_G.LibStub; if not LibStub then return false end
  local LDB=LibStub("LibDataBroker-1.1",true); local DBIcon=LibStub("LibDBIcon-1.0",true)
  if not LDB or not DBIcon then return false end
  local obj=LDB:NewDataObject("FDEC",{type="launcher",text="FDEC",icon=3586269,
    OnClick=function() OpenSettings() end,
    OnTooltipShow=function(tt) tt:AddLine("老哥UI｜一鍵驅除｜FDEC"); tt:AddLine("左鍵：開啟/關閉設定",1,1,1) end})
  if not DBIcon:IsRegistered("FDEC") then DBIcon:Register("FDEC",obj,DB.minimap) end
  local b=DBIcon.GetMinimapButton and DBIcon:GetMinimapButton("FDEC")
  if b and not b.FDECStandardRing then
    b:SetSize(31,31)
    if b.icon then b.icon:ClearAllPoints(); b.icon:SetSize(20,20); b.icon:SetPoint("CENTER",b,"CENTER",1,0); b.icon:SetTexCoord(.07,.93,.07,.93) end
    local ring=b:CreateTexture(nil,"OVERLAY"); ring:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder"); ring:SetSize(53,53); ring:SetPoint("TOPLEFT",b,"TOPLEFT",0,0)
    b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    local hl=b:GetHighlightTexture(); if hl then hl:SetSize(31,31); hl:ClearAllPoints(); hl:SetPoint("CENTER") end
    b.FDECStandardRing=true
  end
  return true
end
local function SetupFallbackMinimap()
  mini=CreateFrame("Button","FDECMinimapButton",Minimap); mini:SetSize(31,31); mini:SetFrameStrata("MEDIUM"); mini:SetFrameLevel((Minimap:GetFrameLevel() or 0)+8)
  mini:RegisterForClicks("LeftButtonUp"); mini:RegisterForDrag("LeftButton")
  local ic=mini:CreateTexture(nil,"ARTWORK"); ic:SetSize(20,20); ic:SetPoint("CENTER",mini,"CENTER",1,0); ic:SetTexture(3586269); ic:SetTexCoord(.07,.93,.07,.93)
  local border=mini:CreateTexture(nil,"OVERLAY"); border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder"); border:SetSize(53,53); border:SetPoint("TOPLEFT",mini,"TOPLEFT",0,0)
  local hl=mini:CreateTexture(nil,"HIGHLIGHT"); hl:SetTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight"); hl:SetBlendMode("ADD"); hl:SetSize(31,31); hl:SetPoint("CENTER")
  local function Pos()
    local r=math.max(Minimap:GetWidth() or 140,Minimap:GetHeight() or 140)/2+18; local a=math.rad(DB.minimapAngle or 165)
    mini:ClearAllPoints(); mini:SetPoint("CENTER",Minimap,"CENTER",math.cos(a)*r,math.sin(a)*r)
  end
  local dragging=false
  mini:SetScript("OnDragStart",function(self) dragging=true; self:SetScript("OnUpdate",function()
    local mx,my=Minimap:GetCenter(); if not mx then return end; local x,y=GetCursorPosition(); local sc=UIParent:GetEffectiveScale(); x,y=x/sc,y/sc
    DB.minimapAngle=math.deg(math.atan2(y-my,x-mx)); Pos()
  end) end)
  mini:SetScript("OnDragStop",function(self) self:SetScript("OnUpdate",nil); Pos(); C_Timer.After(.1,function() dragging=false end) end)
  mini:SetScript("OnClick",function() if not dragging then OpenSettings() end end)
  mini:SetScript("OnEnter",function(self) GameTooltip:SetOwner(self,"ANCHOR_LEFT"); GameTooltip:SetText("老哥UI｜一鍵驅除｜FDEC"); GameTooltip:AddLine("左鍵：開啟/關閉設定",1,1,1); GameTooltip:Show() end)
  mini:SetScript("OnLeave",function() GameTooltip:Hide() end); Pos()
end

SLASH_FDEC1="/fdec"
SLASH_FDEC2="/驅除"
SlashCmdList.FDEC=function() OpenSettings() end

F:RegisterEvent("ADDON_LOADED")
F:RegisterEvent("PLAYER_LOGIN")
F:RegisterEvent("PLAYER_REGEN_ENABLED")
F:RegisterEvent("SPELLS_CHANGED")
F:RegisterEvent("GROUP_ROSTER_UPDATE")
F:SetScript("OnEvent",function(_,event,arg)
  if event=="ADDON_LOADED" and arg==ADDON then
    copyDefaults()
    cfg:ClearAllPoints()
    cfg:SetPoint(DB.panelPoint or "CENTER", UIParent, DB.panelPoint or "CENTER", DB.panelX or defaults.panelX, DB.panelY or defaults.panelY)
    layout(); updateBackground()
    cfg:Hide()
  elseif event=="PLAYER_LOGIN" then
    updateSecure()
    if not SetupStandardMinimap() then SetupFallbackMinimap() end
    print("|cffffd100老哥UI｜一鍵驅除|r v0.24 已載入，輸入 /fdec 開啟設定。")
  elseif event=="PLAYER_REGEN_ENABLED" or event=="SPELLS_CHANGED" or event=="GROUP_ROSTER_UPDATE" then
    updateSecure()
  end
end)
