local ADDON = "FAR"

local function MoneyText(copper)
    copper = tonumber(copper) or 0
    local g = math.floor(copper / 10000)
    local s = math.floor((copper % 10000) / 100)
    local c = copper % 100
    local t = {}
    if g > 0 then t[#t+1] = g .. "金" end
    if s > 0 or g > 0 then t[#t+1] = s .. "銀" end
    t[#t+1] = c .. "銅"
    return table.concat(t, " ")
end

local function Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cffffcc55FAR：|r" .. msg)
end

-- 任務物品保護：
-- 1. C_Container.GetContainerItemQuestInfo 能確認任務相關 -> 不賣
-- 2. API 不存在或資料不明 -> 不冒險賣
local function IsSafeGrayItem(bag, slot)
    if not C_Container or not C_Container.GetContainerItemInfo then
        return false
    end

    local info = C_Container.GetContainerItemInfo(bag, slot)
    if not info or not info.itemID or not info.stackCount then
        return false
    end

    -- 永恆服已直接回傳品質。只賣真正的灰色品質(Poor = 0)。
    if info.quality ~= 0 then
        return false
    end

    -- hasNoValue=true 代表沒有商店價值，不處理。
    if info.hasNoValue then
        return false
    end

    -- 有任務資訊 API 時才做額外任務保護；沒有就不因 API 缺失卡死所有灰物。
    if C_Container.GetContainerItemQuestInfo then
        local q = C_Container.GetContainerItemQuestInfo(bag, slot)
        if q and (q.isQuestItem or q.questID or q.isActive) then
            return false
        end
    end

    return true, info.stackCount, info.itemName or ("item:" .. tostring(info.itemID))
end

local function SellSafeGrayItems()
    if not C_Container or not C_Container.PickupContainerItem then
        return
    end

    local soldCount = 0
    local moneyBefore = GetMoney()
    local maxBag = NUM_TOTAL_EQUIPPED_BAG_SLOTS or 4

    -- 逐格出售：拿起單一物品後丟到商人。
    -- 不使用 UseContainerItem，避免永恆服把動作導向「出售所有垃圾」確認框。
    for bag = 0, maxBag do
        local slots = C_Container.GetContainerNumSlots and C_Container.GetContainerNumSlots(bag) or 0
        for slot = slots, 1, -1 do
            local safe, count = IsSafeGrayItem(bag, slot)
            if safe and not CursorHasItem() then
                C_Container.PickupContainerItem(bag, slot)
                if CursorHasItem() then
                    if SellCursorItem then
                        SellCursorItem()
                    elseif MerchantFrame and MerchantFrame:IsShown() then
                        -- 相容舊客戶端：再次點擊商人出售區的行為不可用時，
                        -- 清除游標以避免卡住；不冒險呼叫垃圾全售。
                        ClearCursor()
                    end
                    if not CursorHasItem() then
                        soldCount = soldCount + (count or 1)
                    else
                        ClearCursor()
                    end
                end
            end
        end
    end

    if soldCount > 0 then
        local gained = math.max(0, GetMoney() - moneyBefore)
        if gained > 0 then
            Print("已逐件出售灰色物品 " .. soldCount .. " 件，收入 " .. MoneyText(gained) .. "。")
        else
            Print("已逐件出售灰色物品 " .. soldCount .. " 件。")
        end
    end
end

local function RepairWithOwnMoney()
    if not CanMerchantRepair or not CanMerchantRepair() then
        return
    end

    local cost, canRepair = GetRepairAllCost()
    cost = tonumber(cost) or 0

    if not canRepair or cost <= 0 then
        return
    end

    if GetMoney() < cost then
        Print("金錢不足，無法自動修理；需要 " .. MoneyText(cost) .. "。")
        return
    end

    -- false = 使用玩家自己的金錢，不使用公會資金
    RepairAllItems(false)
    Print("已用自己的金錢自動修理，花費 " .. MoneyText(cost) .. "。")
end

local frame = CreateFrame("Frame")
frame:RegisterEvent("MERCHANT_SHOW")
frame:SetScript("OnEvent", function(_, event)
    if event ~= "MERCHANT_SHOW" then return end

    -- 商店真正開啟後才執行；完全沒有自動找NPC/自動互動。
    SellSafeGrayItems()
    RepairWithOwnMoney()
end)
