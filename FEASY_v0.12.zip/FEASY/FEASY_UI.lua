local ADDON = ...
FEASY_DB = FEASY_DB or {}
local defaults = {
    sellJunk=true, autoRepair=true, mailEnhance=true,
    movableWindows=true, movableBag=true, minimapCollector=true,
    minimap={hide=false,minimapPos=225}, collector={hide=false,minimapPos=200},
}
local function InitDB()
    for k,v in pairs(defaults) do
        if FEASY_DB[k] == nil then
            if type(v)=="table" then FEASY_DB[k]={}; for a,b in pairs(v) do FEASY_DB[k][a]=b end
            else FEASY_DB[k]=v end
        end
    end
    FEASY_DB.minimap=FEASY_DB.minimap or {hide=false,minimapPos=225}
end
InitDB()
local LDB = LibStub and LibStub("LibDataBroker-1.1", true)
local DBIcon = LibStub and LibStub("LibDBIcon-1.0", true)

-- 老哥UI｜便利工具｜FEASY：視窗外觀完整沿用 FXP v0.63 成功母版。
local main,pages={},{}
local checkboxes={}

local function MakeCheck(parent,text,key,y)
    local c=CreateFrame("CheckButton",nil,parent,"UICheckButtonTemplate")
    c:SetPoint("TOPLEFT",0,y)
    c.text:ClearAllPoints();c.text:SetPoint("LEFT",c,"RIGHT",4,1);c.text:SetText(text)
    local fs=c.Text or c.text
    if fs then
        local font,size,flags=fs:GetFont();if font and size then fs:SetFont(font,size+1,flags or "") end
        fs:SetTextColor(1,1,1,1);fs:SetShadowColor(0,0,0,0);fs:SetShadowOffset(0,0)
    end
    c.Refresh=function() c:SetChecked(FEASY_DB[key] and true or false) end
    c:SetScript("OnClick",function(self)
        PlaySound(856);FEASY_DB[key]=self:GetChecked() and true or false
    end)
    checkboxes[#checkboxes+1]=c;c.Refresh();return c
end

local function SetButtonWhiteText(b)
    local fs=b:GetFontString();if not fs then return end
    local font,size=fs:GetFont();fs:SetFont(font,size,"");fs:SetTextColor(1,1,1,1);fs:SetShadowColor(0,0,0,0);fs:SetShadowOffset(0,0)
end

local function CreateMain()
    if main.frame then return end
    local f=CreateFrame("Frame","FEASY_MainFrame",UIParent,"PortraitFrameTemplate");main.frame=f
    f:SetSize(530,540);f:SetPoint("CENTER",UIParent,"CENTER",FEASY_DB.panelX or -400,FEASY_DB.panelY or 0)
    f:SetFrameStrata("DIALOG");f:SetClampedToScreen(true);f:SetMovable(true);f:EnableMouse(true);f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart",f.StartMoving)
    f:SetScript("OnDragStop",function(self)
        self:StopMovingOrSizing()
        local x,y=self:GetCenter();local ux,uy=UIParent:GetCenter()
        if x and y and ux and uy then FEASY_DB.panelX=x-ux;FEASY_DB.panelY=y-uy end
    end)
    local portrait=(f.PortraitContainer and f.PortraitContainer.portrait) or f.portrait or f.Portrait
    if portrait then portrait:SetTexture(3586269) end
    local nativeTitle=(f.TitleContainer and f.TitleContainer.TitleText) or f.TitleText
    if nativeTitle then nativeTitle:SetText("") end
    if f.Inset then f.Inset:Hide() end
    if f.Bg and f.Bg.Hide then f.Bg:Hide() end

    local function atlas(tex,name) if not tex or not tex.SetAtlas then return false end;return pcall(tex.SetAtlas,tex,name,false) end
    local top=CreateFrame("Frame",nil,f);top:SetPoint("TOPLEFT",f,"TOPLEFT",2,-23);top:SetPoint("TOPRIGHT",f,"TOPRIGHT",-2,-23);top:SetHeight(76)
    local topBG=top:CreateTexture(nil,"BACKGROUND");topBG:SetAllPoints(top);if not atlas(topBG,"groupfinder-roles-background") then topBG:SetTexture(8373327) end
    local streak=top:CreateTexture(nil,"BORDER");streak:SetPoint("TOPLEFT",top,"TOPLEFT",0,0);streak:SetPoint("TOPRIGHT",top,"TOPRIGHT",0,0);streak:SetHeight(43);if not atlas(streak,"UI-Frame-TopTileStreaks") then streak:SetTexture(1723833) end
    local body=CreateFrame("Frame",nil,f,"InsetFrameTemplate");main.body=body;body:SetPoint("TOPLEFT",f,"TOPLEFT",3,-100);body:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-3,3)
    if body.Bg and body.Bg.SetAlpha then body.Bg:SetAlpha(.90) end;if body.TopEdge then body.TopEdge:Hide() end
    local inside=body:CreateTexture(nil,"BORDER",nil,1);inside:SetPoint("TOPLEFT",body,"TOPLEFT",0,5);inside:SetPoint("TOPRIGHT",body,"TOPRIGHT",0,5);inside:SetPoint("BOTTOMLEFT",body,"BOTTOMLEFT",0,0);inside:SetPoint("BOTTOMRIGHT",body,"BOTTOMRIGHT",0,0);if not atlas(inside,"common-insideframe") then inside:SetTexture(8124462) end
    local dividerLayer=CreateFrame("Frame",nil,f);dividerLayer:SetAllPoints(f);dividerLayer:SetFrameStrata(f:GetFrameStrata());dividerLayer:SetFrameLevel(math.max(f:GetFrameLevel(),body:GetFrameLevel())+20)
    local divider=dividerLayer:CreateTexture(nil,"OVERLAY",nil,7);divider:SetSize(16,524);divider:SetPoint("CENTER",f,"TOP",0,-95);if not atlas(divider,"common-framedivider") then divider:SetTexture(8245174) end;divider:SetTexCoord(0,1,0,1);if divider.SetRotation then divider:SetRotation(math.pi/2) end
    local titleLayer=CreateFrame("Frame",nil,f);titleLayer:SetAllPoints(f);titleLayer:SetFrameStrata(f:GetFrameStrata());titleLayer:SetFrameLevel(math.max(f:GetFrameLevel(),body:GetFrameLevel())+30)
    local mainTitle=titleLayer:CreateFontString(nil,"OVERLAY","GameFontNormalLarge");local tf,ts,tfl=mainTitle:GetFont();if tf and ts then mainTitle:SetFont(tf,ts+2,tfl) end;mainTitle:SetPoint("CENTER",f,"TOP",0,-58);mainTitle:SetText("老哥UI｜便利工具｜FEASY")

    local function CreateRecipeMenu(text)
        local b=CreateFrame("Button",nil,f);b:SetSize(150,48)
        local bg=b:CreateTexture(nil,"BACKGROUND");b.bg=bg;bg:SetAllPoints();if not pcall(bg.SetAtlas,bg,"Professions_Recipe_Active") then bg:SetTexture(4417031) end
        local label=b:CreateFontString(nil,"OVERLAY","GameFontNormal");b.label=label;label:SetPoint("CENTER");local mf,ms,mfl=label:GetFont();if mf and ms then label:SetFont(mf,ms+2,mfl or "") end;label:SetText(text)
        return b
    end
    local menu1=CreateRecipeMenu("遊戲便利");menu1:SetPoint("TOPLEFT",body,"TOPLEFT",17,-28)
    local menu2=CreateRecipeMenu("畫面功能");menu2:SetPoint("TOPLEFT",menu1,"BOTTOMLEFT",0,-15)
    main.menu={menu1,menu2}
    local vdiv=f:CreateTexture(nil,"OVERLAY",nil,7);vdiv:SetSize(2,405);vdiv:SetPoint("TOP",body,"TOPLEFT",183,-35);if not pcall(vdiv.SetAtlas,vdiv,"Talents-divider-vertical-c60") then vdiv:SetTexture(8116735) end

    local selectedPage=1
    local function SetMenuState(b,on) b.bg:SetAlpha(on and 1 or .18);b.label:SetTextColor(on and 1 or .90,on and .82 or .88,on and 0 or .82) end
    local function SelectPage(i) selectedPage=i;for n,p in ipairs(pages) do p:SetShown(n==i) end;SetMenuState(menu1,i==1);SetMenuState(menu2,i==2) end
    for i,b in ipairs(main.menu) do
        b:SetScript("OnEnter",function(self) if selectedPage~=i then self.bg:SetAlpha(.60) end end)
        b:SetScript("OnLeave",function(self) SetMenuState(self,selectedPage==i) end)
        b:SetScript("OnClick",function() PlaySound(856);SelectPage(i) end)
    end
    local function MakePage() local p=CreateFrame("Frame",nil,f);p:SetPoint("TOPLEFT",body,"TOPLEFT",205,-24);p:SetPoint("BOTTOMRIGHT",body,"BOTTOMRIGHT",-24,54);return p end
    local p1=MakePage();pages[1]=p1;MakeCheck(p1,"自動賣垃圾","sellJunk",-4);MakeCheck(p1,"自動修理","autoRepair",-42);MakeCheck(p1,"郵箱加強","mailEnhance",-80)
    local p2=MakePage();pages[2]=p2;MakeCheck(p2,"商人／其他視窗可移動","movableWindows",-4);MakeCheck(p2,"背包可移動／放大／縮小","movableBag",-42);MakeCheck(p2,"地圖上小按鈕收納","minimapCollector",-80)

    local reset=CreateFrame("Button",nil,f,"MainMenuFrameButtonTemplate");reset:SetSize(155,32);reset:SetPoint("BOTTOMLEFT",body,"BOTTOMLEFT",14.5,33);reset:SetText("恢復預設");SetButtonWhiteText(reset)
    reset:SetScript("OnClick",function()
        PlaySound(856);for k,v in pairs(defaults) do if type(v)~="table" then FEASY_DB[k]=v end end
        FEASY_DB.panelX=-400;FEASY_DB.panelY=0;f:ClearAllPoints();f:SetPoint("CENTER",UIParent,"CENTER",-400,0)
        for _,c in ipairs(checkboxes) do c.Refresh() end
    end)
    local done=CreateFrame("Button",nil,f,"MainMenuFrameButtonTemplate");done:SetSize(155,32);done:SetPoint("BOTTOMRIGHT",body,"BOTTOMRIGHT",-25,33);done:SetText("設定完成");SetButtonWhiteText(done);done:SetScript("OnClick",function() PlaySound(856);f:Hide() end)
    f:SetScript("OnShow",function() PlaySound(850);for _,c in ipairs(checkboxes) do c.Refresh() end;SelectPage(1) end);f:SetScript("OnHide",function() PlaySound(850) end)
    f:Hide();tinsert(UISpecialFrames,"FEASY_MainFrame");SelectPage(1)
end
local function ToggleMain() CreateMain();if main.frame:IsShown() then main.frame:Hide() else main.frame:Show() end end

-- FXP v0.63 標準小地圖按鈕外觀：31x31、20x20 圖示、53x53 原生外框。
local function ApplyFXPMinimapStyle(b)
    if not b or b.FEASYFXPStyle then return end
    b:SetSize(31,31)
    if b.icon then b.icon:ClearAllPoints();b.icon:SetSize(20,20);b.icon:SetPoint("CENTER",b,"CENTER",1,0);b.icon:SetTexture(3586269);b.icon:SetTexCoord(.07,.93,.07,.93) end
    local ring=b:CreateTexture(nil,"OVERLAY");ring:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder");ring:SetSize(53,53);ring:SetPoint("TOPLEFT",b,"TOPLEFT",0,0)
    b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight");local hl=b:GetHighlightTexture();if hl then hl:SetSize(31,31);hl:ClearAllPoints();hl:SetPoint("CENTER") end
    b.FEASYFXPStyle=true
end
local function SetupMainMini()
    if not LDB or not DBIcon then return end
    local o=LDB:NewDataObject("FEASY",{type="launcher",text="FEASY",icon=3586269,OnClick=function(_,btn) if btn=="LeftButton" then ToggleMain() end end,OnTooltipShow=function(tt) tt:AddLine("老哥UI｜便利工具｜FEASY");tt:AddLine("左鍵：開啟/關閉設定",1,1,1) end})
    if not DBIcon:IsRegistered("FEASY") then DBIcon:Register("FEASY",o,FEASY_DB.minimap) end;ApplyFXPMinimapStyle(DBIcon:GetMinimapButton("FEASY"))
end


local E=CreateFrame("Frame")
E:RegisterEvent("PLAYER_LOGIN")
E:SetScript("OnEvent",function()
    InitDB()
    SetupMainMini()
    -- FUI 核心原碼保持不變；這裡只修正整合後的圖示顯示路徑（介面層）。
    if DBIcon then
        local b=DBIcon:GetMinimapButton("FUI")
        if b and b.icon then b.icon:SetTexture("Interface\\AddOns\\FEASY\\FUI_U.tga") end
    end
end)
