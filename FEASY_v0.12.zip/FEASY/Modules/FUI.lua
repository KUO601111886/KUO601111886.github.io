local ADDON_NAME = ...
FUIDB = FUIDB or { minimap = { hide=false, minimapPos=225 } }
FUIDB.minimap = FUIDB.minimap or { hide=false, minimapPos=225 }

local LDB = LibStub("LibDataBroker-1.1", true)
local DBIcon = LibStub("LibDBIcon-1.0", true)
local collected, seen = {}, {}
local expanded = false
local UButton
local GAP = 4

local function msg(s)
    if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99FUI｜|r"..s) end
end

local deny = {
    FUI=true, GameTimeFrame=true, TimeManagerClockButton=true, QueueStatusMinimapButton=true,
    MiniMapMailFrame=true, MiniMapTracking=true, MinimapZoomIn=true, MinimapZoomOut=true,
    MinimapZoneTextButton=true, ExpansionLandingPageMinimapButton=true, AddonCompartmentFrame=true,
}

local function isSafeButton(name, b)
    if not b or b == UButton or name == "FUI" or deny[name] then return false end
    if seen[b] then return false end
    if not b.IsObjectType or not b:IsObjectType("Button") then return false end
    local w,h=b:GetSize(); if not w or not h or w<16 or h<16 or w>64 or h>64 then return false end
    return true
end

local function remember(b)
    if b.__FUIOriginal then return end
    local p,r,rp,x,y=b:GetPoint(1)
    b.__FUIOriginal={p=p,r=r,rp=rp,x=x,y=y,shown=b:IsShown()}
end

local function add(name,b)
    if #collected >= 40 or not isSafeButton(name,b) then return end
    remember(b); seen[b]=true
    collected[#collected+1]={name=name,button=b}
    if not expanded then b:Hide() end
end

local function scanLibDBIcon()
    if not DBIcon or not DBIcon.objects then return end
    for name,b in pairs(DBIcon.objects) do add(name,b) end
end

local function scanCompatibleChildren()
    -- 只補抓標準型、直接掛在小地圖上的第三方 Button；不碰 Blizzard 內建元件。
    local children={Minimap:GetChildren()}
    for _,b in ipairs(children) do
        local n=b.GetName and b:GetName()
        if n and n ~= "FUI_MinimapButton" and not n:match("^Minimap") and not n:match("^MiniMap") then
            if b.dataObject or b.db or n:match("LibDBIcon") then add(n,b) end
        end
    end
end

local function layout()
    if not UButton then return end
    for i,item in ipairs(collected) do
        local b=item.button
        if b then
            if expanded then
                b:ClearAllPoints()
                b:SetPoint("RIGHT",UButton,"LEFT",-GAP-(i-1)*(31+GAP),0)
                b:Show()
            else
                b:Hide()
            end
        end
    end
end

local function scan()
    scanLibDBIcon()
    scanCompatibleChildren()
    layout()
end

local function toggle()
    expanded=not expanded
    scan()
end

local function setupU()
    if not LDB or not DBIcon then
        msg("缺少標準小地圖按鈕元件。")
        return
    end
    local obj=LDB:NewDataObject("FUI",{
        type="launcher", text="FUI", icon="Interface\\AddOns\\FUI\\FUI_U.tga",
        OnClick=function(_,button)
            if button=="LeftButton" then toggle()
            elseif button=="RightButton" then scan(); msg("重新掃描完成，共收納 "..#collected.." 個按鈕。") end
        end,
        OnTooltipShow=function(tt)
            tt:AddLine("FUI｜小地圖按鈕收納器 - BY老哥")
            tt:AddLine("左鍵：展開 / 收起",1,1,1)
            tt:AddLine("右鍵：重新掃描",1,1,1)
            tt:AddLine("直接拖曳 U：沿小地圖移動",1,1,1)
        end,
    })
    if not DBIcon:IsRegistered("FUI") then DBIcon:Register("FUI",obj,FUIDB.minimap) end
    UButton=DBIcon:GetMinimapButton("FUI")
end

local E=CreateFrame("Frame")
E:RegisterEvent("ADDON_LOADED")
E:RegisterEvent("PLAYER_LOGIN")
E:SetScript("OnEvent",function(_,event,arg)
    if event=="ADDON_LOADED" and arg==ADDON_NAME then
        FUIDB=FUIDB or {}; FUIDB.minimap=FUIDB.minimap or {hide=false,minimapPos=225}
    elseif event=="PLAYER_LOGIN" then
        setupU()
        C_Timer.After(2,scan)
        C_Timer.After(6,scan)
        C_Timer.NewTicker(10,scan)
        msg("小地圖按鈕收納器 - BY老哥")
    end
end)

SLASH_FUI1="/fui"
SlashCmdList.FUI=function(s)
    s=(s or ""):lower()
    if s=="scan" then scan(); msg("重新掃描完成，共收納 "..#collected.." 個按鈕。")
    else msg("左鍵 U：展開/收起；右鍵：重新掃描；直接拖曳 U：移動。") end
end
