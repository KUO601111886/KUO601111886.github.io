local ADDON = ...
FMAIL_DB = FMAIL_DB or {}

local panel, toggleButton
local initialized = false

local function Print(msg)
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage("|cffffd200FMAIL|r｜" .. tostring(msg))
    end
end

local function Trim(s)
    if not s then return "" end
    return (s:gsub("^%s+", ""):gsub("%s+$", ""))
end

local function GetRecipientBox()
    return _G.SendMailNameEditBox
        or _G.SendMailNameEditBoxRecipient
        or (_G.SendMailFrame and _G.SendMailFrame.NameEditBox)
end

local function NormalizeDB()
    if type(FMAIL_DB) ~= "table" then FMAIL_DB = {} end
    if type(FMAIL_DB.favorites) ~= "table" then FMAIL_DB.favorites = {} end
end

local function RecipientExists(name)
    local low = string.lower(name)
    for _, v in ipairs(FMAIL_DB.favorites) do
        if string.lower(v) == low then return true end
    end
    return false
end

local function AddRecipient(name)
    NormalizeDB()
    name = Trim(name)
    if name == "" then
        Print("請先在「收件人」輸入角色名稱。")
        return
    end
    if RecipientExists(name) then
        Print(name .. " 已經在常用收件人名單。")
        return
    end
    table.insert(FMAIL_DB.favorites, name)
    Print("已加入常用收件人：" .. name)
    if panel and panel:IsShown() then panel:Refresh() end
end

local function RemoveRecipient(index)
    NormalizeDB()
    local name = FMAIL_DB.favorites[index]
    if name then
        table.remove(FMAIL_DB.favorites, index)
        Print("已移除常用收件人：" .. name)
        if panel and panel:IsShown() then panel:Refresh() end
    end
end

local function ChooseRecipient(name)
    local box = GetRecipientBox()
    if not box then
        Print("找不到遊戲原本的收件人欄位。")
        return
    end
    box:SetText(name)
    if box.ClearFocus then box:ClearFocus() end
    if panel then panel:Hide() end
end

local function CreatePanel()
    if panel then return end

    panel = CreateFrame("Frame", "FMAILFavoritePanel", SendMailFrame or MailFrame, "BackdropTemplate")
    panel:SetSize(210, 80)
    panel:SetFrameStrata("DIALOG")
    panel:SetClampedToScreen(true)
    panel:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 32, edgeSize = 24,
        insets = { left = 7, right = 7, top = 7, bottom = 7 }
    })
    panel:Hide()

    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOPLEFT", 14, -13)
    title:SetText("常用收件人")

    local close = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", 2, 2)

    panel.rows = {}

    local add = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    add:SetSize(170, 22)
    add:SetText("＋ 新增目前收件人")
    add:SetScript("OnClick", function()
        local box = GetRecipientBox()
        AddRecipient(box and box:GetText() or "")
    end)
    panel.addButton = add

    function panel:Refresh()
        NormalizeDB()

        for _, row in ipairs(self.rows) do row:Hide() end

        local y = -38
        for i, name in ipairs(FMAIL_DB.favorites) do
            local row = self.rows[i]
            if not row then
                row = CreateFrame("Frame", nil, self)
                row:SetSize(180, 24)

                row.pick = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
                row.pick:SetSize(145, 22)
                row.pick:SetPoint("LEFT", 0, 0)

                row.del = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
                row.del:SetSize(26, 22)
                row.del:SetPoint("LEFT", row.pick, "RIGHT", 4, 0)
                row.del:SetText("X")

                self.rows[i] = row
            end

            row:SetPoint("TOPLEFT", 14, y)
            row.pick:SetText(name)
            row.pick:SetScript("OnClick", function() ChooseRecipient(name) end)
            row.del:SetScript("OnClick", function() RemoveRecipient(i) end)
            row:Show()
            y = y - 26
        end

        if #FMAIL_DB.favorites == 0 then
            if not self.emptyText then
                self.emptyText = self:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                self.emptyText:SetText("尚未加入常用收件人")
            end
            self.emptyText:SetPoint("TOPLEFT", 17, y - 2)
            self.emptyText:Show()
            y = y - 24
        elseif self.emptyText then
            self.emptyText:Hide()
        end

        self.addButton:ClearAllPoints()
        self.addButton:SetPoint("TOPLEFT", 19, y - 3)
        self:SetHeight(math.max(88, (-y) + 43))
    end
end

local function PositionPanel()
    if not panel or not toggleButton then return end
    panel:ClearAllPoints()
    panel:SetPoint("TOPLEFT", toggleButton, "BOTTOMLEFT", -6, -4)
end

local function CreateToggleButton()
    if toggleButton or not SendMailFrame then return end

    local box = GetRecipientBox()

    -- WoW 原生風格的小型方形「＋」按鈕。
    -- 位置鎖在原本收件人輸入框的最右端，不再使用「常用」長按鈕。
    toggleButton = CreateFrame("Button", "FMAILFavoriteButton", SendMailFrame, "UIPanelButtonTemplate")
    toggleButton:SetSize(20, 20)
    toggleButton:SetText("+")
    toggleButton:SetFrameStrata("DIALOG")
    toggleButton:SetFrameLevel((box and box:GetFrameLevel() or SendMailFrame:GetFrameLevel()) + 10)
    toggleButton:EnableMouse(true)
    local fs = toggleButton:GetFontString()
    if fs then
        fs:SetFontObject("GameFontNormal")
    end

    if box then
        -- 疊在收件人框右端；保留一點內縮，避免超出郵箱框。
        toggleButton:ClearAllPoints()
        -- 直接以收件人框右端為基準，整顆按鈕往左 45 UI。
        toggleButton:SetPoint("RIGHT", box, "RIGHT", -78, 0)
    else
        toggleButton:SetPoint("TOPRIGHT", SendMailFrame, "TOPRIGHT", -31, -35)
    end

    toggleButton:SetScript("OnClick", function()
        CreatePanel()
        panel:Refresh()
        PositionPanel()
        if panel:IsShown() then panel:Hide() else panel:Show() end
    end)

    CreatePanel()
end

local function InitializeMailUI()
    if not _G.SendMailFrame then return false end
    CreateToggleButton()
    initialized = true
    return true
end


-- 右鍵直接領取收件箱郵件附件／金錢，不開啟第二個郵件視窗。
local function GetInboxRowIndex(button)
    if not button then return nil end

    -- 永恆/舊版郵箱常見的收件列會把實際信件索引存在 index。
    if type(button.index) == "number" then
        return button.index
    end

    local id = button.GetID and button:GetID()
    if not id or id < 1 then return nil end

    -- 原生收件箱每頁顯示的列數；舊版通常是 7。
    local perPage = _G.INBOXITEMS_TO_DISPLAY or 7
    local page = _G.InboxFrame and _G.InboxFrame.pageNum or 1
    return ((page - 1) * perPage) + id
end

local function LootInboxMail(index)
    if not index or index < 1 then return end
    if not GetInboxHeaderInfo then return end

    local _, _, sender, subject, money, CODAmount, _, hasItem = GetInboxHeaderInfo(index)
    CODAmount = tonumber(CODAmount) or 0

    -- C.O.D. 郵件不能用右鍵直接領，避免誤付貨到付款。
    if CODAmount > 0 then
        Print("這封是 C.O.D. 郵件，請用原本郵件視窗確認後領取。")
        return
    end

    local tookSomething = false

    if money and money > 0 and TakeInboxMoney then
        TakeInboxMoney(index)
        tookSomething = true
    end

    if hasItem and TakeInboxItem then
        local maxAttach = _G.ATTACHMENTS_MAX_RECEIVE or 16
        -- 一次只送出一個附件請求，避免伺服器尚未完成前連續請求造成失敗。
        for attach = 1, maxAttach do
            local name = GetInboxItem and GetInboxItem(index, attach)
            if name then
                TakeInboxItem(index, attach)
                tookSomething = true
                break
            end
        end
    end

    if not tookSomething then
        Print("這封郵件沒有可直接領取的金錢或附件。")
    end
end

local hookedInboxButtons = {}

local function HookInboxRows()
    local perPage = _G.INBOXITEMS_TO_DISPLAY or 7
    for i = 1, perPage do
        local b = _G["MailItem"..i.."Button"] or _G["MailItem"..i]
        if b and not hookedInboxButtons[b] then
            hookedInboxButtons[b] = true
            b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
            b:HookScript("OnClick", function(self, mouseButton)
                if mouseButton == "RightButton" then
                    LootInboxMail(GetInboxRowIndex(self))
                end
            end)
        end
    end
end


-- 原生郵箱自由拖曳：拖住郵箱上方標題區即可移動。
local mailDragReady = false

local function SaveMailPosition()
    if not MailFrame or not FMAIL_DB then return end
    local point, _, relativePoint, x, y = MailFrame:GetPoint(1)
    if point then
        FMAIL_DB.mailPosition = {
            point = point,
            relativePoint = relativePoint or point,
            x = x or 0,
            y = y or 0,
        }
    end
end

local function RestoreMailPosition()
    if not MailFrame or not FMAIL_DB or not FMAIL_DB.mailPosition then return end
    local p = FMAIL_DB.mailPosition
    MailFrame:ClearAllPoints()
    MailFrame:SetPoint(p.point or "CENTER", UIParent, p.relativePoint or "CENTER", p.x or 0, p.y or 0)
end

local function EnableMailDragging()
    if mailDragReady or not MailFrame then return end
    mailDragReady = true

    MailFrame:SetMovable(true)
    MailFrame:SetClampedToScreen(true)
    MailFrame:RegisterForDrag("LeftButton")

    MailFrame:HookScript("OnDragStart", function(self)
        if not self:IsMovable() then return end

        -- 只允許從郵箱上方標題區拖曳，避免點信件/按鈕時誤移動。
        local scale = self:GetEffectiveScale() or 1
        local _, cursorY = GetCursorPosition()
        cursorY = cursorY / scale
        local top = self:GetTop()
        if top and cursorY >= (top - 32) then
            self:StartMoving()
            self.__FMAILMoving = true
        end
    end)

    MailFrame:HookScript("OnDragStop", function(self)
        if self.__FMAILMoving then
            self:StopMovingOrSizing()
            self.__FMAILMoving = nil
            SaveMailPosition()
        end
    end)

    RestoreMailPosition()
end

local event = CreateFrame("Frame")
event:RegisterEvent("ADDON_LOADED")
event:RegisterEvent("MAIL_SHOW")
event:RegisterEvent("MAIL_CLOSED")
event:SetScript("OnEvent", function(_, evt, arg1)
    if evt == "ADDON_LOADED" and arg1 == ADDON then
        NormalizeDB()
    elseif evt == "MAIL_SHOW" then
        if not initialized then InitializeMailUI() end
        if toggleButton then toggleButton:Show() end
        HookInboxRows()
        EnableMailDragging()
        RestoreMailPosition()

        -- 原生郵箱在 MAIL_SHOW 後仍可能再次套用預設位置。
        -- 下一幀再套一次玩家最後儲存的位置，避免重新跳回左上角。
        if C_Timer and C_Timer.After then
            C_Timer.After(0, RestoreMailPosition)
        end
    elseif evt == "MAIL_CLOSED" then
        if panel then panel:Hide() end
    end
end)

-- Some clients create Blizzard's mail UI lazily.
if _G.SendMailFrame then
    InitializeMailUI()
end
