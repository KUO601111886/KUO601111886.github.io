-- FMV｜商人視窗自由移動 - BY老哥
-- v0.01

FMV_DB = FMV_DB or {}

local initialized = false
local moving = false

local function SavePosition()
    if not MerchantFrame then return end
    local point, _, relativePoint, x, y = MerchantFrame:GetPoint(1)
    if not point then return end

    FMV_DB.position = {
        point = point,
        relativePoint = relativePoint or point,
        x = x or 0,
        y = y or 0,
    }
end

local function RestorePosition()
    if not MerchantFrame or not FMV_DB.position then return end

    local p = FMV_DB.position
    MerchantFrame:ClearAllPoints()
    MerchantFrame:SetPoint(
        p.point or "CENTER",
        UIParent,
        p.relativePoint or "CENTER",
        p.x or 0,
        p.y or 0
    )
end

local function EnableMerchantDragging()
    if initialized or not MerchantFrame then return end
    initialized = true

    MerchantFrame:SetMovable(true)
    MerchantFrame:SetClampedToScreen(true)
    MerchantFrame:EnableMouse(true)
    MerchantFrame:RegisterForDrag("LeftButton")

    MerchantFrame:HookScript("OnDragStart", function(self)
        if InCombatLockdown and InCombatLockdown() then return end

        -- 只允許抓住商人視窗最上方標題區拖曳，
        -- 避免購買商品時誤把視窗拖走。
        local scale = self:GetEffectiveScale() or 1
        local _, cursorY = GetCursorPosition()
        cursorY = cursorY / scale

        local top = self:GetTop()
        if top and cursorY >= (top - 35) then
            self:StartMoving()
            moving = true
        end
    end)

    MerchantFrame:HookScript("OnDragStop", function(self)
        if moving then
            self:StopMovingOrSizing()
            moving = false
            SavePosition()
        end
    end)
end

local event = CreateFrame("Frame")
event:RegisterEvent("PLAYER_LOGIN")
event:RegisterEvent("MERCHANT_SHOW")

event:SetScript("OnEvent", function(_, evt)
    if evt == "PLAYER_LOGIN" then
        EnableMerchantDragging()

    elseif evt == "MERCHANT_SHOW" then
        EnableMerchantDragging()
        RestorePosition()

        -- 原生 UI 在開啟流程中可能重新套用預設錨點，
        -- 下一幀再恢復一次玩家最後的位置。
        if C_Timer and C_Timer.After then
            C_Timer.After(0, RestorePosition)
        end
    end
end)


-- FEASY 擴充：同一個「商人／其他視窗可移動」開關涵蓋主要 Blizzard 原生面板。
-- 原 FMV 商人內碼保留不改；以下只新增外層支援名單。
local FEASY_EXTRA_MOVABLE_FRAMES = {
    "CharacterFrame",            -- 角色／裝備
    "SpellBookFrame",            -- 技能／法術
    "PlayerSpellsFrame",         -- 新版技能／天賦整合面板
    "ClassTalentFrame",          -- 天賦
    "TalentFrame",
    "QuestLogFrame",             -- 任務
    "GuildFrame",                -- 工會
    "CommunitiesFrame",          -- 社群
    "LFGParentFrame",            -- 搜尋／組隊搜尋
    "PVEFrame",
    "CollectionsJournal",        -- 收藏

    -- v0.05：只補修使用者指定的三類視窗
    -- 1. 專業
    "ProfessionsFrame",
    "ProfessionsBookFrame",
    "TradeSkillFrame",

    -- 2. 任務日誌
    "QuestMapFrame",
    "QuestLogPopupDetailFrame",

    -- 3. 尋求組隊
    "LFGListFrame",
    "LFGListPVEStub",
    "LFGListApplicationDialog",

    -- v0.06：任務日誌實際附著在 WorldMapFrame；尋求組隊內容位於 GroupFinderFrame。
    "WorldMapFrame",
    "GroupFinderFrame",
    "LFDParentFrame",

}

local feasyExtraHooked = {}
local function FEASY_EnableExtraMovable(frameName)
    local f=_G[frameName]
    if not f or feasyExtraHooked[f] then return false end
    if f.SetMovable then f:SetMovable(true) end
    if f.SetClampedToScreen then f:SetClampedToScreen(true) end
    if f.SetUserPlaced then f:SetUserPlaced(true) end
    if f.EnableMouse then f:EnableMouse(true) end
    if f.RegisterForDrag then f:RegisterForDrag("LeftButton") end

    local movingExtra=false
    if f.HookScript then
        f:HookScript("OnDragStart",function(self)
            if InCombatLockdown and InCombatLockdown() then return end
            local scale=self:GetEffectiveScale() or 1
            local _,cursorY=GetCursorPosition()
            cursorY=cursorY/scale
            local top=self:GetTop()
            if top and cursorY >= (top-40) and self.StartMoving then
                self:StartMoving()
                movingExtra=true
            end
        end)
        f:HookScript("OnDragStop",function(self)
            if movingExtra and self.StopMovingOrSizing then
                self:StopMovingOrSizing()
                movingExtra=false
            end
        end)
    end
    feasyExtraHooked[f]=true
    return true
end

local function FEASY_EnableExtraMovables()
    for _,frameName in ipairs(FEASY_EXTRA_MOVABLE_FRAMES) do
        FEASY_EnableExtraMovable(frameName)
    end
end

local feasyExtraEvent=CreateFrame("Frame")
feasyExtraEvent:RegisterEvent("PLAYER_LOGIN")
feasyExtraEvent:RegisterEvent("ADDON_LOADED")
feasyExtraEvent:SetScript("OnEvent",function()
    FEASY_EnableExtraMovables()
    if C_Timer and C_Timer.After then
        C_Timer.After(0,FEASY_EnableExtraMovables)
        C_Timer.After(1,FEASY_EnableExtraMovables)
    end
end)


-- v0.06：任務／尋求組隊屬於延遲載入 Blizzard 面板；開啟後再補一次外層 Frame。
local feasyLateMovable=CreateFrame("Frame")
feasyLateMovable:RegisterEvent("PLAYER_ENTERING_WORLD")
feasyLateMovable:RegisterEvent("ADDON_LOADED")
feasyLateMovable:SetScript("OnEvent",function()
    if C_Timer and C_Timer.After then
        C_Timer.After(0.10,FEASY_EnableExtraMovables)
        C_Timer.After(0.50,FEASY_EnableExtraMovables)
        C_Timer.After(1.50,FEASY_EnableExtraMovables)
    else
        FEASY_EnableExtraMovables()
    end
end)
