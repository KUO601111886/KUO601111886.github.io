-- FMV｜商人視窗自由移動 - BY老哥
-- v0.01

FMV_DB = FMV_DB or {}

local initialized = false
local moving = false

local function SavePosition()
    if not MerchantFrame then return end
    local point, _, relativePoint, x, y = MerchantFrame:GetPoint(1)
    if not point then return end

    FMV_DB.position = {
        point = point,
        relativePoint = relativePoint or point,
        x = x or 0,
        y = y or 0,
    }
end

local function RestorePosition()
    if not MerchantFrame or not FMV_DB.position then return end

    local p = FMV_DB.position
    MerchantFrame:ClearAllPoints()
    MerchantFrame:SetPoint(
        p.point or "CENTER",
        UIParent,
        p.relativePoint or "CENTER",
        p.x or 0,
        p.y or 0
    )
end

local function EnableMerchantDragging()
    if initialized or not MerchantFrame then return end
    initialized = true

    MerchantFrame:SetMovable(true)
    MerchantFrame:SetClampedToScreen(true)
    MerchantFrame:EnableMouse(true)
    MerchantFrame:RegisterForDrag("LeftButton")

    MerchantFrame:HookScript("OnDragStart", function(self)
        if InCombatLockdown and InCombatLockdown() then return end

        -- 只允許抓住商人視窗最上方標題區拖曳，
        -- 避免購買商品時誤把視窗拖走。
        local scale = self:GetEffectiveScale() or 1
        local _, cursorY = GetCursorPosition()
        cursorY = cursorY / scale

        local top = self:GetTop()
        if top and cursorY >= (top - 35) then
            self:StartMoving()
            moving = true
        end
    end)

    MerchantFrame:HookScript("OnDragStop", function(self)
        if moving then
            self:StopMovingOrSizing()
            moving = false
            SavePosition()
        end
    end)
end

local event = CreateFrame("Frame")
event:RegisterEvent("PLAYER_LOGIN")
event:RegisterEvent("MERCHANT_SHOW")

event:SetScript("OnEvent", function(_, evt)
    if evt == "PLAYER_LOGIN" then
        EnableMerchantDragging()

    elseif evt == "MERCHANT_SHOW" then
        EnableMerchantDragging()
        RestorePosition()

        -- 原生 UI 在開啟流程中可能重新套用預設錨點，
        -- 下一幀再恢復一次玩家最後的位置。
        if C_Timer and C_Timer.After then
            C_Timer.After(0, RestorePosition)
        end
    end
end)
